# Maclean Messaging 1.4.3 — build verification

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name/code: `1.4.3` / `10403`
- Minimum/target SDK: Android 10 (API 29) / API 35
- Signed APK: `Maclean-Messaging-1.4.3-Signed.apk`
- APK size: 1,143,442 bytes
- APK SHA-256: `027ba4550e98b88719d5c910e57535484e3bce400901e6095edd3d04dc2912af`

## Corrected behavior

- The incoming MMS decoder now retains From, To, Cc, and Bcc instead of discarding every address except From.
- Incoming MMS provider insertion derives the Android thread from the complete remote participant set and writes each typed address row. A carrier group MMS therefore remains a distinct group conversation rather than entering the sender's one-to-one thread.
- Active SIM numbers are normalized, cached briefly, and excluded from remote participants when Android exposes them.
- MMS hydration returns both the visible sender and the complete conversation participants. Inbox grouping, open-thread replies, voice replies, resend copies, optimistic sending rows, notification titles, notification opening, and Quick reply retain the full group.
- Android Contacts is bulk-loaded for conversations. Saved names are used in inbox titles, thread toolbars, incoming-message headings, voice details, and SMS/MMS notifications; the number remains the fallback for unmatched participants.
- SMS/MMS inbox cards no longer repeat the raw phone number beneath an already resolved contact/group title. Email participant subtitles likewise prefer saved names.

## Verification record

- All 74 production Kotlin files compiled for JVM 17 against Android API 35 without compiler errors, producing 798 class files.
- Android Build Tools 35.0.1 compiled and linked resources, generated release DEX, ZIP-aligned the APK, and passed compressed-archive integrity checks.
- Python host suites passed 54/54 checks, including new contracts for MMS address-header retention, group-thread construction, typed provider addresses, contact-first labels, and multi-recipient reply paths.
- `ImapProtocolTest.kt`, `MmsImageFitPolicyTest.kt`, `MmsPduWriterTest.kt`, and the expanded `MmsPduParserTest.kt` compiled and passed.
- The parser regression decodes two To recipients plus Cc and Bcc, strips carrier `/TYPE=PLMN` suffixes, and retains the original attachment bytes.
- Compiled-manifest inspection reports package/version `com.macleanofduartenterprises.macleanmessaging` / `1.4.3` (`10403`), compile/target API 35, minimum API 29, and the expected default-SMS/share surface.
- APK Signature Scheme v3 verification passed with one 4096-bit RSA signer.
- Signer certificate SHA-256 is `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`, exactly matching the supplied signed 1.4.2 APK for an in-place update.
- ZIP alignment and APK archive-integrity checks passed.
- Compiler output contains only the existing compact email-code and Android API deprecation warnings; this repair introduced no compiler error.

## Protocol boundary

True carrier group messaging is MMS and includes an address set that can be preserved. A carrier or sender that delivers a mass text as separate SMS messages supplies no other-recipient metadata in the SMS protocol, so those independent SMS messages cannot be reconstructed reliably into a group.

## Device-specific validation still required

This build environment has no attached Android handset, ADB runtime, active SIM, carrier account, or synchronized Contacts provider. The following checks are therefore not represented as completed:

- Install 1.4.3 over the currently signed release without clearing data and confirm retained conversations, drafts, schedules, email accounts, credentials, backgrounds, display profiles, and Android default-SMS role.
- Receive a genuine group MMS from at least two saved contacts and confirm it creates a group row, does not enter either one-to-one history, shows both names, and opens with both recipients in the toolbar.
- Reply from the inline composer, voice recorder, notification Quick reply, and resend-copy path; confirm every remote participant receives the result in the same group.
- Repeat with one or more unknown numbers, dual SIM, a SIM whose line number is unavailable to Android, and contact add/rename/delete changes.
- Confirm historical group messages imported by older releases remain understandable. Rows previously stored with only the sender cannot be reconstructed when their discarded recipient metadata is no longer available.
- Recheck ordinary one-to-one SMS/MMS, incoming/outgoing attachments, provider visibility, notifications, email sync/send, sharing, keyboards, schedules, accessibility, and display/font profiles on representative Android 10–15 devices.

The APK is source-, compile-, host-test-, archive-, signer-, and package-identity-verified. It is not represented as live-device or carrier verified.
