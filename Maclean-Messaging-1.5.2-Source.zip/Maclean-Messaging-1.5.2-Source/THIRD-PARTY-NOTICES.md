# Third-party cryptography notices

Maclean Messaging remains licensed under GNU AGPLv3. Version 1.5.0 also distributes the following unmodified dependency JARs in `app/libs`:

| Component | Version | License | Project |
|---|---:|---|---|
| PGPainless Core | 2.0.4 | Apache License 2.0 | https://pgpainless.org/ |
| Bouncy Castle Provider / OpenPGP / Utilities | 1.84 | Bouncy Castle License (MIT-style) | https://www.bouncycastle.org/ |
| SLF4J API / NOP binding | 1.7.36 | MIT License | https://www.slf4j.org/ |
| JSR-305 annotations | 3.0.2 | BSD-style license | https://github.com/amaembo/jsr-305 |

Dependency SHA-256 values:

```text
c0e6303a0d7589040f400950ecee87a14b81312e84ed15e5390ebb0c4566ddab  bcpg-jdk18on-1.84.jar
64d6c5a6121fcd927152dd182cbed39afe0fda641a970d9bcc0c9cb1858b2731  bcprov-jdk18on-1.84.jar
b374e16963421fb9cfb01cc20d7ad8fd2f8b8188e3eef0ec0a8965e245f7619a  bcutil-jdk18on-1.84.jar
766ad2a0783f2687962c8ad74ceecc38a28b9f72a2d085ee438b7813e928d0c7  jsr305-3.0.2.jar
265dfefbfa4c5d33d659482e9813d526643122de982368727c6f1a0861275290  pgpainless-core-2.0.4.jar
d3ef575e3e4979678dc01bf1dcce51021493b4d11fb7f1be8ad982877c16a1c0  slf4j-api-1.7.36.jar
c214958b07816cb4412b30c7bdbd4308ffdc6ba2a83767b8f3a9229cbd9274d6  slf4j-nop-1.7.36.jar
```

The corresponding license texts and notices are available from the project links and Maven Central artifacts. No dependency changes the license of Maclean Messaging's own source code.

