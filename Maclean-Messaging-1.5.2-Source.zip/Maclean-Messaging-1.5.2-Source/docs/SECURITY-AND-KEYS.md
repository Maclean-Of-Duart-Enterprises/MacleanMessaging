# Maclean Messaging 1.5.1 security and key management

## Separate key purposes

The Android APK signing key and user message-encryption keys are deliberately separate:

- The existing production Android keystore signs the APK and proves upgrade continuity. It never encrypts conversations.
- Each app user creates an individual OpenPGP identity on their own Android device. That identity signs and decrypts their messages.
- Contacts exchange public certificates only. A contact public key can encrypt to its owner and verify that owner's signatures, but cannot decrypt or impersonate them.

No additional shared private signing or decryption key is bundled in the APK or release download. Shipping one common private key would let every holder impersonate every user and decrypt traffic intended for the shared key. The app therefore creates the required OpenPGP signing/encryption key locally under **Settings → Security & encryption**.

## Generated OpenPGP identity

PGPainless 2.0.4 generates an OpenPGP v4 key using:

- Ed25519 primary key for certification;
- X25519 subkey for communications and storage encryption;
- Ed25519 subkey for message signatures;
- a five-year default validity period from the upstream modern-key template.

The user chooses a backup password of at least 12 characters. The standard secret-key file remains encrypted with that password. For scheduled sends and notification replies, a copy of the password is encrypted with AES-256-GCM by a non-exportable Android Keystore key. Android backup is disabled for the application, and the key files are held in app-private storage.

Exported private-key backups remain password protected. They must be stored securely and never sent to a contact. Public keys may be shared freely. Users should compare the displayed fingerprint over a different trusted channel before relying on a newly imported contact key.

## Sending policy

- **Encrypt when possible**: encrypt only when the sender identity exists and every recipient has a public key; otherwise preserve ordinary plaintext behavior.
- **Require encryption**: refuse to send if the identity or any recipient key is missing. This prevents an unnoticed downgrade.
- **Always unencrypted**: preserve legacy SMS/MMS/email behavior even when keys exist.

Full SMS/MMS and email composers may inherit Settings or override this policy per draft. Group messages encrypt only when all remote participants have keys. The ciphertext is also addressed to the sender's public key so sent items can be decrypted on the sending device.

## Formats and metadata

- SMS/MMS text: ASCII-armored, signed-and-encrypted OpenPGP message. A long protected SMS may use several carrier SMS segments.
- MMS attachments: binary signed-and-encrypted OpenPGP with the original filename in the literal-data packet and MIME type `application/pgp-encrypted`.
- Email: RFC 3156 `multipart/encrypted` PGP/MIME with the body, signature text, and attachments inside the encrypted MIME entity.
- Email key discovery: an Autocrypt header carries the sender's public certificate; it is accepted only when its `addr` matches the actual From identity.

Routing metadata is not end-to-end encrypted. Phone/email addresses, timestamps, SMS/MMS carrier metadata, email subjects, and mail transport headers remain visible. OpenPGP does not make regular carrier SMS/MMS anonymous, prevent traffic analysis, or guarantee that a recipient still controls a previously imported key.

## Recovery and deletion

Uninstalling or clearing app data removes the Android Keystore wrapper and local private key. Restore requires both the exported password-protected secret-key file and its password. On a device with no current identity, use **Settings → Security & encryption → Restore password-protected backup**. The app verifies that the password can unlock a signing key before committing the restored identity.

