/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanmessaging.ui

/** Live selection, keyed by stable ID (never by a recycled list position). */
internal fun MutableSet<String>.toggleRow(id: String) {
    if (!remove(id)) add(id)
}

internal fun MutableSet<String>.tapRow(id: String, changed: () -> Unit, open: (() -> Unit)?) {
    if (isEmpty()) open?.invoke() else {
        toggleRow(id)
        changed()
    }
}
