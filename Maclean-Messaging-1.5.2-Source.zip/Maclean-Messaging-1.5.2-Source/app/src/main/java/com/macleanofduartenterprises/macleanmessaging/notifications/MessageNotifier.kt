/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.notifications

import android.Manifest
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Telephony
import com.macleanofduartenterprises.macleanmessaging.contacts.ContactIndex
import com.macleanofduartenterprises.macleanmessaging.settings.UserSettings
import com.macleanofduartenterprises.macleanmessaging.telephony.DevicePhoneNumbers
import com.macleanofduartenterprises.macleanmessaging.ui.MainActivity

object MessageNotifier {
    const val KEY_REPLY = "reply"
    internal const val EXTRA_RECIPIENTS = "recipients"
    internal const val EXTRA_NOTIFICATION_ID = "notificationId"

    fun notifyIncoming(
        context: Context,
        address: String,
        body: String,
        messageUri: String?,
        recipients: List<String> = listOf(address)
    ) {
        val conversationRecipients = DevicePhoneNumbers.distinct(recipients).ifEmpty { listOf(address) }
        val threadId = messageUri?.let { threadId(context, it) }
        val notificationId = threadId?.let(::notificationIdForThread) ?: address.hashCode()
        val settings = UserSettings(context).notifications
        if (!settings.enabled || !settings.messageNotifications) {
            cancelNotification(context, notificationId)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        val contacts = ContactIndex.load(context)
        val title = conversationRecipients.joinToString(", ") { recipient ->
            contacts.resolve(recipient)?.displayName ?: recipient
        }.ifBlank { address }
        val visibleBody = if (settings.showPreviews) body else "New SMS/MMS message"

        val open = PendingIntent.getActivity(
            context,
            notificationId,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(
                    MainActivity.EXTRA_NOTIFICATION_ADDRESS,
                    conversationRecipients.joinToString(", ")
                )
                putExtra(MainActivity.EXTRA_NOTIFICATION_MESSAGE_URI, messageUri)
                threadId?.let { putExtra(MainActivity.EXTRA_NOTIFICATION_THREAD_ID, it) }
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val replyIntent = Intent(context, NotificationReplyReceiver::class.java).apply {
            putExtra("address", address)
            putStringArrayListExtra(EXTRA_RECIPIENTS, ArrayList(conversationRecipients))
            putExtra(EXTRA_NOTIFICATION_ID, notificationId)
        }
        val replyPending = PendingIntent.getBroadcast(
            context,
            notificationId xor 0x55AA,
            replyIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )
        val remoteInput = RemoteInput.Builder(KEY_REPLY)
            .setLabel("Reply")
            .build()
        val replyAction = Notification.Action.Builder(
            android.R.drawable.ic_menu_send,
            "Reply",
            replyPending
        ).addRemoteInput(remoteInput).build()

        val builder = Notification.Builder(context, NotificationChannels.MESSAGES)
            .setSmallIcon(android.R.drawable.sym_action_chat)
            .setContentTitle(title)
            .setContentText(visibleBody)
            .setStyle(Notification.BigTextStyle().bigText(visibleBody))
            .setContentIntent(open)
            .setAutoCancel(!settings.persistentUnread)
            .setOngoing(settings.persistentUnread)
            .setVisibility(if (settings.showPreviews) Notification.VISIBILITY_PRIVATE else Notification.VISIBILITY_SECRET)
            .setCategory(Notification.CATEGORY_MESSAGE)
        if (settings.quickReply) builder.addAction(replyAction)
        val notification = builder.build()

        context.getSystemService(NotificationManager::class.java)
            .notify(notificationId, notification)
    }

    fun cancel(context: Context, address: String) {
        cancelNotification(context, address.hashCode())
    }

    fun cancelThread(context: Context, threadId: Long) =
        cancelNotification(context, notificationIdForThread(threadId))

    internal fun cancelNotification(context: Context, notificationId: Int) {
        context.getSystemService(NotificationManager::class.java).cancel(notificationId)
    }

    private fun notificationIdForThread(threadId: Long): Int = "thread:$threadId".hashCode()

    private fun threadId(context: Context, messageUri: String): Long? = runCatching {
        val uri = Uri.parse(messageUri)
        context.contentResolver.query(uri, arrayOf(Telephony.Sms.THREAD_ID), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getLong(0) else null
        }
    }.getOrNull()
}
