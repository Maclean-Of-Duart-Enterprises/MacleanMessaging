/* Maclean Messaging — SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanmessaging.telephony

import android.content.Context
import java.util.Locale

data class MmsCapacityResult(
    val subscriptionId: Int,
    val simLabel: String,
    val carrierName: String,
    val carrierAdvertisedBytes: Int,
    val appEnvelopeBytes: Int,
    val largestSyntheticAttachmentBytes: Int,
    val encodedPduBytes: Int,
    val recommendedAttachmentBytes: Int,
    val maxImageWidth: Int,
    val maxImageHeight: Int
)

/**
 * Per-SIM, non-billable MMS capacity test.
 *
 * Android exposes the carrier's configured maximum for each subscription. This diagnostic then
 * binary-searches the largest synthetic attachment that the app's real MM1 encoder can place in
 * that envelope. It deliberately does not transmit messages or claim delivery acceptance, which
 * can only be established by paid live carrier tests.
 */
object MmsCapacityDiagnostic {
    fun run(context: Context): List<MmsCapacityResult> = SimRepository.active(context).map { sim ->
        val profile = MmsCarrierConfig.profile(context, sim.subscriptionId)
        var low = 0
        var high = profile.maxMessageBytes
        var encodedAtLow = 0
        while (low <= high) {
            val candidate = low + (high - low) / 2
            val encoded = encode(candidate)
            if (encoded.size <= profile.maxMessageBytes) {
                encodedAtLow = encoded.size
                low = candidate + 1
            } else high = candidate - 1
        }
        val maximum = high.coerceAtLeast(0)
        if (maximum > 0) encodedAtLow = encode(maximum).size
        val reserve = maxOf(16 * 1024, (maximum * 0.08).toInt())
        MmsCapacityResult(
            subscriptionId = sim.subscriptionId,
            simLabel = "SIM ${sim.slotIndex + 1}: ${sim.displayName}",
            carrierName = sim.carrierName,
            carrierAdvertisedBytes = profile.advertisedMessageBytes,
            appEnvelopeBytes = profile.maxMessageBytes,
            largestSyntheticAttachmentBytes = maximum,
            encodedPduBytes = encodedAtLow,
            recommendedAttachmentBytes = (maximum - reserve).coerceAtLeast(0),
            maxImageWidth = profile.maxImageWidth,
            maxImageHeight = profile.maxImageHeight
        )
    }

    fun formatBytes(bytes: Int): String = when {
        bytes >= 1024 * 1024 -> String.format(Locale.US, "%.2f MiB", bytes / (1024.0 * 1024.0))
        else -> String.format(Locale.US, "%.1f KiB", bytes / 1024.0)
    }

    private fun encode(attachmentBytes: Int): ByteArray = MmsPduWriter.encodeSendRequest(
        recipients = listOf("+15555550123"),
        body = "Maclean Messaging MMS capacity diagnostic",
        media = if (attachmentBytes == 0) emptyList() else listOf(
            MmsPduWriter.Part(
                mimeType = "application/octet-stream",
                name = "capacity-test.bin",
                data = ByteArray(attachmentBytes) { index -> (index * 31 + 17).toByte() },
                contentId = "capacity-test"
            )
        ),
        requestDeliveryReport = false,
        transactionId = "capacity-test"
    )
}

