/* Maclean Messaging — SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanmessaging.telephony

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import android.telephony.PhoneNumberUtils
import android.telephony.SubscriptionManager

/** Normalizes carrier addresses and separates this device's SIM numbers from remote recipients. */
object DevicePhoneNumbers {
    @Volatile private var cachedOwnNumbers: Set<String>? = null
    @Volatile private var cachedAt = 0L

    fun clean(address: String): String = address
        .replace(Regex("(?i)/TYPE=.*$"), "")
        .trim()
        .trim('<', '>')

    fun distinct(addresses: Iterable<String>): List<String> = addresses
        .map(::clean)
        .filter(String::isNotBlank)
        .filterNot { it.equals("insert-address-token", true) }
        .distinctBy(::key)

    fun remoteParticipants(context: Context, addresses: Iterable<String>): List<String> {
        val own = ownNumbers(context).mapTo(mutableSetOf(), ::key)
        return distinct(addresses).filterNot { key(it) in own }
    }

    private fun ownNumbers(context: Context): Set<String> {
        val canReadNumber = context.checkSelfPermission(Manifest.permission.READ_PHONE_NUMBERS) ==
            PackageManager.PERMISSION_GRANTED
        val canReadState = context.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) ==
            PackageManager.PERMISSION_GRANTED
        if (!canReadNumber && !canReadState) return emptySet()

        val now = SystemClock.elapsedRealtime()
        cachedOwnNumbers?.takeIf { now - cachedAt < OWN_NUMBER_CACHE_MS }?.let { return it }

        return synchronized(this) {
            cachedOwnNumbers?.takeIf { now - cachedAt < OWN_NUMBER_CACHE_MS } ?: loadOwnNumbers(context).also {
                cachedOwnNumbers = it
                cachedAt = SystemClock.elapsedRealtime()
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun loadOwnNumbers(context: Context): Set<String> {
        val subscriptions = context.getSystemService(SubscriptionManager::class.java)
        return buildSet {
            runCatching { subscriptions.activeSubscriptionInfoList.orEmpty() }
                .getOrDefault(emptyList())
                .forEach { info ->
                    if (Build.VERSION.SDK_INT >= 33) {
                        runCatching { subscriptions.getPhoneNumber(info.subscriptionId) }
                            .getOrNull()?.let { addIfPresent(it) }
                    } else runCatching { info.number }.getOrNull()?.let { addIfPresent(it) }
                }
        }
    }

    private fun MutableSet<String>.addIfPresent(value: String) {
        clean(value).takeIf(String::isNotBlank)?.let { add(it) }
    }

    private fun key(address: String): String {
        val normalized = PhoneNumberUtils.normalizeNumber(clean(address))
        return when {
            normalized.length >= 10 -> normalized.takeLast(10)
            normalized.isNotBlank() -> normalized
            else -> clean(address).lowercase()
        }
    }

    private const val OWN_NUMBER_CACHE_MS = 60_000L
}
