package com.macleanofduartenterprises.macleanmessaging.email.mime

import android.text.Html

/** Convert HTML email to readable plain text, never exposing stylesheet/source markup. */
object EmailBodyFormatter {
    private val styleBlocks = Regex("""(?is)<\s*(?:style|script|head|svg|template)\b[^>]*>.*?<\s*/\s*(?:style|script|head|svg|template)\s*>""")
    private val htmlTags = Regex("""(?is)<\s*(?:html|body|div|table|p|span|br|td|tr|h[1-6])\b""")
    private val cssRule = Regex("""(?is)(?:@media|@font-face|@supports|\.[\w-]+|#[\w-]+|[\w-]+\s*\{)[^{}]{0,400}\{""")
    fun cleanHtml(html: String): String {
        val withoutHidden = html.replace(styleBlocks, " ")
        return Html.fromHtml(withoutHidden, Html.FROM_HTML_MODE_COMPACT).toString()
            .replace('\u00a0', ' ').replace(Regex("[ \t]+"), " ")
            .replace(Regex("""\n{3,}"""), "\n\n").trim()
    }
    fun readable(plain: String, html: String?): String {
        val htmlText = html?.takeIf(String::isNotBlank)?.let(::cleanHtml).orEmpty()
        val looksLikeMarkup = htmlTags.containsMatchIn(plain) ||
            (plain.contains("<style", true) || plain.contains("<!doctype", true))
        val looksLikeCss = cssRule.findAll(plain.take(12000)).take(3).count() >= 2 ||
            (plain.contains("@media", true) && plain.contains("!important", true))
        if (looksLikeMarkup) return cleanHtml(plain).ifBlank { htmlText }
        if (looksLikeCss) return htmlText.ifBlank { stripCss(plain) }
        return plain.ifBlank { htmlText }
    }
    private fun stripCss(value: String): String {
        // Fallback for malformed text/plain parts with CSS prepended to human text.
        val lines = value.lines().filterNot { line ->
            line.contains("@media") || line.contains("@font-face") ||
                (line.contains('{') && line.contains('}')) ||
                (line.contains(':') && line.contains(';') && line.contains('{'))
        }
        return lines.joinToString("\n").trim().ifBlank { "[Email contains unsupported formatting]" }
    }
}
