/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.app.RemoteInput
import com.macleanofduartenterprises.macleanmessaging.data.SystemMessageRepository
import com.macleanofduartenterprises.macleanmessaging.model.OutgoingMessage
import com.macleanofduartenterprises.macleanmessaging.telephony.SimRepository
import com.macleanofduartenterprises.macleanmessaging.util.Async

class NotificationReplyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val address = intent.getStringExtra("address") ?: return
        val recipients = intent.getStringArrayListExtra(MessageNotifier.EXTRA_RECIPIENTS)
            ?.filter(String::isNotBlank)
            ?.distinct()
            .orEmpty()
            .ifEmpty { listOf(address) }
        val reply = RemoteInput.getResultsFromIntent(intent)
            ?.getCharSequence(MessageNotifier.KEY_REPLY)
            ?.toString()
            ?.takeIf { it.isNotBlank() } ?: return

        val subId = SimRepository.active(context).firstOrNull()?.subscriptionId ?: return
        val pending = goAsync()
        Async.launch {
            try {
                SystemMessageRepository(context).send(
                    OutgoingMessage(recipients, reply, subscriptionId = subId)
                )
                val notificationId = intent.getIntExtra(MessageNotifier.EXTRA_NOTIFICATION_ID, Int.MIN_VALUE)
                if (notificationId != Int.MIN_VALUE) {
                    MessageNotifier.cancelNotification(context, notificationId)
                } else MessageNotifier.cancel(context, address)
            } finally {
                pending.finish()
            }
        }
    }
}
