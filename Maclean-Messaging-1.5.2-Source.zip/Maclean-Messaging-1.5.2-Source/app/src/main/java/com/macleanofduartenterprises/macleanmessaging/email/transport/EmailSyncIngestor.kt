/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.email.transport

import android.content.Context
import android.util.Log
import com.macleanofduartenterprises.macleanmessaging.data.LocalDatabase
import com.macleanofduartenterprises.macleanmessaging.email.data.*
import com.macleanofduartenterprises.macleanmessaging.email.mime.MimeCodec
import com.macleanofduartenterprises.macleanmessaging.security.MessageSecurityService
import com.macleanofduartenterprises.macleanmessaging.security.OpenPgpKeyStore
import org.json.JSONArray
import java.security.MessageDigest

data class EmailIngestResult(val newMessages: Int, val updatedMessages: Int)

class EmailSyncIngestor(private val context:Context){
    private val security = MessageSecurityService(context)
    suspend fun ingest(account:EmailAccountEntity,messages:List<RemoteEmail>): EmailIngestResult {
        val db=LocalDatabase.get(context)
        val touchedThreads=linkedSetOf<String>()
        var newMessages=0
        var updatedMessages=0
        messages.forEach{remote->
            val p=runCatching { parseProtectedEmail(remote.raw) }
                .onFailure { Log.e(TAG, "Could not parse IMAP UID ${remote.uid}; continuing mailbox sync", it) }
                .getOrNull() ?: return@forEach
            val messageId=p.messageId ?: "imap:${account.id}:${remote.uid}"
            if (db.isEmailMessageDeleted(messageId)) return@forEach
            val threadId=stableThreadId(account.id,p.subject.orEmpty(),p.from,p.to+p.cc)
            val unread=remote.flags.none { it.equals("\\Seen", true) }
            val existingMessage=db.emailMessageDao().get(messageId)
            if(existingMessage==null){
                if(unread)newMessages++
            } else updatedMessages++

            db.emailMessageDao().upsert(EmailMessageEntity(
                stableId=messageId,accountId=account.id,threadId=threadId,remoteMessageId=remote.uid.toString(),
                sender=p.from,recipientsJson=JSONArray(p.to+p.cc).toString(),subject=p.subject,
                bodyText=p.textBody,bodyHtml=p.htmlBody,timestamp=p.dateMillis,
                incoming=!p.from.contains(account.emailAddress,true),unread=unread,folder="INBOX",
                attachmentCount=p.attachmentCount
            ))

            val existing=db.emailThreadDao().get(threadId)
            db.emailThreadDao().upsert(EmailThreadEntity(
                stableId=threadId,accountId=account.id,remoteThreadId=null,subject=p.subject,
                participantsJson=JSONArray(listOf(p.from)+p.to+p.cc).toString(),
                preview=p.textBody.replace(Regex("\\s+")," ").take(240),
                timestamp=maxOf(existing?.timestamp?:0,p.dateMillis),
                unreadCount=existing?.unreadCount?:0,
                pinned=existing?.pinned?:false,favorite=existing?.favorite?:false,archived=existing?.archived?:false
            ))
            touchedThreads+=threadId
        }
        touchedThreads.forEach(db::refreshEmailThread)
        return EmailIngestResult(newMessages,updatedMessages)
    }

    private fun parseProtectedEmail(raw: ByteArray): com.macleanofduartenterprises.macleanmessaging.email.mime.ParsedMimeMessage {
        val outer = MimeCodec.parse(raw)
        outer.autocryptHeader?.let { importAutocrypt(outer.from, it) }
        val encrypted = MimeCodec.pgpMimePayload(raw) ?: return outer
        return runCatching {
            val decrypted = security.decryptAttachmentIfNeeded(
                encrypted,
                "message.eml.pgp",
                MessageSecurityService.PGP_MIME
            )
            val inner = MimeCodec.parse(decrypted.bytes)
            inner.copy(
                messageId = outer.messageId,
                from = outer.from,
                to = outer.to,
                cc = outer.cc,
                subject = outer.subject,
                dateMillis = outer.dateMillis,
                autocryptHeader = outer.autocryptHeader
            )
        }.getOrElse {
            outer.copy(
                textBody = "[Encrypted email — this device could not unlock it.]",
                htmlBody = null,
                attachmentCount = 0
            )
        }
    }

    private fun importAutocrypt(from: String, header: String) {
        val values = header.split(';').mapNotNull { item ->
            val separator = item.indexOf('=')
            if (separator <= 0) null else item.substring(0, separator).trim().lowercase() to
                item.substring(separator + 1).replace(Regex("\\s+"), "").trim()
        }.toMap()
        val address = values["addr"] ?: return
        val keyData = values["keydata"] ?: return
        if (OpenPgpKeyStore.normalizeIdentity(from) != OpenPgpKeyStore.normalizeIdentity(address)) return
        security.importAutocrypt(address, keyData)
    }
    private fun stableThreadId(accountId:String,subject:String,from:String,recipients:List<String>):String{
        val s=subject.replace(Regex("(?i)^\\s*((re|fw|fwd):\\s*)+"),"").trim().lowercase()
        val parties=(recipients+from).map{it.trim().lowercase()}.sorted().joinToString("|")
        return MessageDigest.getInstance("SHA-256").digest("$accountId|$s|$parties".toByteArray())
            .joinToString(""){"%02x".format(it)}.take(32)
    }

    private companion object {
        const val TAG = "EmailSyncIngestor"
    }
}
