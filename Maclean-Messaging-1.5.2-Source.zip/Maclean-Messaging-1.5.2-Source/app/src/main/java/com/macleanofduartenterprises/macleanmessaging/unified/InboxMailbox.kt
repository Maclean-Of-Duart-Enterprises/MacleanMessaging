/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanmessaging.unified

/** Only display metadata belongs in the inbox snapshot, never account settings/credentials. */
data class InboxMailbox(val id: String, val address: String, val name: String) {
    val label: String get() = if (name.isBlank() || name.equals(address, true)) address else "$name <$address>"
}

internal fun UnifiedConversation.inMailbox(id: String?): Boolean =
    id == null || (transport == CommunicationTransport.EMAIL && accountId == id)

internal fun mailboxOrder(accounts: Map<String, InboxMailbox>): Comparator<UnifiedConversation> =
    compareByDescending<UnifiedConversation> { it.pinned }
        .thenBy { it.transport != CommunicationTransport.EMAIL }
        .thenBy(String.CASE_INSENSITIVE_ORDER) { accounts[it.accountId]?.address.orEmpty() }
        .thenBy { it.accountId.orEmpty() }
        .thenByDescending { it.timestamp }
        .thenBy { it.stableId }
