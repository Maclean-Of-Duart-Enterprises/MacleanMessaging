/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanmessaging.ui

/** Main-thread coordinator. A refresh can replace the target, not the request for the same photo. */
internal class CurrentPhoto<T : Any> {
    private var key: String? = null
    private var generation = 0L
    private var loading = false
    private var cached: T? = null
    private var target: ((T?) -> Unit)? = null

    fun clear() {
        generation++
        key = null
        loading = false
        cached = null
        target = null
    }

    fun bind(requested: String?, start: ((T?) -> Unit) -> Unit, render: (T?) -> Unit) {
        if (requested != key) {
            clear()
            key = requested
        }
        target = render
        render(cached)
        if (requested == null || cached != null || loading) return
        loading = true
        val ticket = ++generation
        start { value ->
            if (ticket == generation) {
                loading = false
                cached = value
                target?.invoke(value)
            }
        }
    }
}
