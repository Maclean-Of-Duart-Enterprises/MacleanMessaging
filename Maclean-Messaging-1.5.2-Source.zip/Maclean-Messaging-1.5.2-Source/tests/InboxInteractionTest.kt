/* SPDX-License-Identifier: AGPL-3.0-only */
package tests

import com.macleanofduartenterprises.macleanmessaging.ui.CurrentPhoto
import com.macleanofduartenterprises.macleanmessaging.ui.tapRow
import com.macleanofduartenterprises.macleanmessaging.ui.toggleRow
import com.macleanofduartenterprises.macleanmessaging.unified.*

private fun selection() {
    val selected = linkedSetOf<String>()
    var opens = 0
    var updates = 0
    fun tap(id: String) = selected.tapRow(id, { updates++ }, { opens++ })
    tap("one")
    check(opens == 1 && selected.isEmpty())
    selected.toggleRow("one") // long press
    tap("two"); tap("three"); tap("two")
    check(selected == setOf("one", "three") && opens == 1 && updates == 3)
    tap("one"); tap("three")
    check(selected.isEmpty() && opens == 1)
    tap("two")
    check(opens == 2)
    // In conversation mode rows have no default Open; a plain tap can still extend the selection.
    selected.toggleRow("mail"); selected.tapRow("other", { updates++ }, null)
    check(selected == setOf("mail", "other"))
}

private fun mailboxes() {
    val a = InboxMailbox("id-z", "Alpha@example.org", "Work")
    val b = InboxMailbox("id-a", "bravo@example.org", "Work")
    val empty = InboxMailbox("id-empty", "empty@example.org", "")
    val accounts = listOf(b, empty, a).associateBy { it.id }
    fun row(id: String, account: String?, time: Long, pinned: Boolean = false) = UnifiedConversation(
        id, if (account == null) CommunicationTransport.MMS else CommunicationTransport.EMAIL,
        emptyList(), "identical subject", "identical sender", time, 0, pinned, accountId = account
    )
    val rows = listOf(row("b1", b.id, 90), row("a1", a.id, 1), row("sms", null, 100),
        row("bp", b.id, 5, true), row("a2", a.id, 29), row("a3", a.id, 29))
    check(a.label != b.label && a.label.contains(a.address))
    check(rows.filter { it.inMailbox(a.id) }.map { it.stableId } == listOf("a1", "a2", "a3"))
    check(rows.none { it.inMailbox(empty.id) } && rows.all { it.inMailbox(null) })
    check(rows.sortedWith(mailboxOrder(accounts)).map { it.stableId } == listOf("bp", "a2", "a3", "a1", "b1", "sms"))
    val selected = mutableSetOf("a1", "b1", "sms")
    selected.retainAll(rows.filter { it.inMailbox(b.id) }.map { it.stableId }.toSet())
    check(selected == setOf("b1"))
}

private fun backgrounds() {
    val requests = CurrentPhoto<String>()
    val pending = mutableListOf<(String?) -> Unit>()
    val paints = mutableListOf<Pair<String, String?>>()
    fun bind(key: String?, screen: String) =
        requests.bind(key, { pending.add(it) }, { paints.add(screen to it) })
    bind("photo-a", "launch")
    bind("photo-a", "refresh")
    bind("photo-a", "thread")
    check(pending.size == 1)
    pending[0]("image-a")
    check(paints.last() == "thread" to "image-a")
    check(paints.none { it.first in setOf("launch", "refresh") && it.second != null })
    bind("photo-a", "return")
    check(pending.size == 1 && paints.last() == "return" to "image-a")
    bind("photo-b", "replace"); bind("photo-c", "replace-again")
    pending[2]("image-c"); pending[1]("stale image-b")
    check(paints.last() == "replace-again" to "image-c")
    bind("photo-d", "before remove"); bind(null, "removed"); pending[3]("deleted")
    check(paints.last() == "removed" to null)
    bind("photo-e", "load"); pending[4](null)
    bind("photo-e", "retry"); pending[5]("recovered")
    check(paints.last() == "retry" to "recovered")
    bind("photo-f", "dying activity"); requests.clear(); pending[6]("late")
    check(paints.none { it.second == "late" })
}

fun main() {
    selection(); mailboxes(); backgrounds()
    println("Inbox selection, per-mailbox filtering/order, and background refresh/replacement regressions passed")
}
