/* Maclean Messaging — SPDX-License-Identifier: AGPL-3.0-only */
package tests

import java.io.ByteArrayOutputStream
import org.pgpainless.PGPainless
import org.pgpainless.algorithm.OpenPGPKeyVersion
import org.pgpainless.decryption_verification.ConsumerOptions
import org.pgpainless.encryption_signing.EncryptionOptions
import org.pgpainless.encryption_signing.ProducerOptions
import org.pgpainless.encryption_signing.SigningOptions
import org.pgpainless.key.protection.SecretKeyRingProtector
import org.pgpainless.util.Passphrase

/** Host-side proof that the pinned OpenPGP stack signs, encrypts, decrypts, and verifies. */
fun main() {
    val api = PGPainless()
    val senderPassword = Passphrase.fromPassword("sender test password")
    val recipientPassword = Passphrase.fromPassword("recipient test password")
    val sender = api.generateKey(OpenPGPKeyVersion.v4).modernKeyRing("Sender <sender@example.com>", senderPassword)
    val recipient = api.generateKey(OpenPGPKeyVersion.v4).modernKeyRing("Recipient <recipient@example.com>", recipientPassword)
    val senderProtector = SecretKeyRingProtector.unlockEachKeyWith(
        Passphrase.fromPassword("sender test password"), sender
    )
    val encryption = EncryptionOptions.encryptCommunications(api)
        .addRecipient(sender)
        .addRecipient(recipient)
    val signing = SigningOptions.get(api).addInlineSignature(senderProtector, sender)
    val plaintext = "Maclean Messaging OpenPGP ✓".toByteArray(Charsets.UTF_8)
    val ciphertext = ByteArrayOutputStream().also { output ->
        api.generateMessage().onOutputStream(output).withOptions(
            ProducerOptions.signAndEncrypt(encryption, signing)
                .setAsciiArmor(true)
                .setFileName("message.txt")
        ).use { it.write(plaintext) }
    }.toByteArray()
    check(ciphertext.toString(Charsets.US_ASCII).startsWith("-----BEGIN PGP MESSAGE-----"))

    val recipientProtector = SecretKeyRingProtector.unlockEachKeyWith(
        Passphrase.fromPassword("recipient test password"), recipient
    )
    val stream = api.processMessage().onInputStream(ciphertext.inputStream()).withOptions(
        ConsumerOptions.get(api)
            .addDecryptionKey(recipient, recipientProtector)
            .addVerificationCert(sender)
    )
    val verified = PGPainless.verifyAndOpen(stream)
    val decrypted = verified.use { it.readBytes() }
    check(decrypted.contentEquals(plaintext))
    check(verified.metadata.isEncrypted)
    check(verified.metadata.isVerifiedSignedBy(sender))
    check(verified.metadata.filename == "message.txt")
    println("OpenPGP interoperability test passed")
}

