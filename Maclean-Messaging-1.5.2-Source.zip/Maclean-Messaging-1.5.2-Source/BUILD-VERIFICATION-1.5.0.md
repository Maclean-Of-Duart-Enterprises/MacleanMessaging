# Maclean Messaging 1.5.0 build verification

Verification date: 2026-10-20 UTC

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name: `1.5.0`
- Version code: `10500`
- Minimum Android API: 29
- Target/compile Android API: 35
- APK Signature Scheme: v3
- Signer: `CN=Maclean Phone, OU=Mobile Applications, O=Maclean of Duart Enterprises`
- Signer certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`
- Signer key: RSA 4096-bit
- Certificate validity: 2026-08-02 01:04:55 UTC through 2056-07-25 01:04:55 UTC

The 1.5.0 signer certificate digest exactly matches the supplied 1.4.3 APK. Android can therefore accept 1.5.0 as an upgrade when normal version and device policy requirements are satisfied.

## Implemented and reviewed

- Optional OpenPGP protection for SMS, MMS, attachments, and email.
- Plaintext compatibility for ordinary incoming and outgoing SMS, MMS, and email.
- Opportunistic, required-encryption, and always-unencrypted policies, with per-draft overrides.
- On-device OpenPGP v4 identities using Ed25519 certification/signing keys and an X25519 encryption subkey.
- Password-protected secret-key backup and restore, public-key sharing, contact-key import/removal, and fingerprint display.
- Android Keystore AES-256-GCM protection for the background-use copy of the identity password.
- RFC 3156 PGP/MIME email creation and ingestion, plus constrained Autocrypt key discovery.
- Per-active-SIM MMS maximum-size diagnostics using the production MM1 PDU encoder without transmitting or billing an MMS.
- `android:allowBackup="false"`; no release keystore, signing password, shared user private key, or literal private-key block is present in the source tree.

## Reproducible build inputs

- Java 17
- Kotlin compiler/stdlib 1.9.24
- Android platform 35 and Build Tools 35.0.1
- PGPainless Core 2.0.4
- Bouncy Castle Provider/OpenPGP/Utilities 1.84
- SLF4J API/NOP 1.7.36
- JSR-305 3.0.2

All seven pinned JARs passed `sha256sum -c app/libs/SHA256SUMS`. Their licenses are recorded in `THIRD-PARTY-NOTICES.md` and the packaged app asset.

## Automated results

- Kotlin application compilation: PASS (76 Kotlin source files; 848 generated class files)
- D8 release dexing: PASS (one `classes.dex`, 9,368,624 bytes)
- Android resource compile/link: PASS
- APK zip alignment: PASS
- APK archive integrity: PASS
- APK signature verification: PASS
- Python contract, workflow, and transport-state tests: PASS (56/56)
- Kotlin IMAP protocol test: PASS
- Kotlin MMS adaptive image-fit policy test: PASS
- Kotlin MMS PDU parser test: PASS
- Kotlin MMS PDU writer test: PASS
- Kotlin OpenPGP interoperability test: PASS

The OpenPGP interoperability test independently generated sender and recipient modern keys, signed and encrypted a UTF-8 payload, decrypted it using the recipient key, and verified both the plaintext and literal filename.

## APK result

- File: `Maclean-Messaging-1.5.0-Signed.apk`
- Size: 3,498,718 bytes
- SHA-256: `8a56eb88c9d2d631db073c703c9d11f97979ded61ca42a8c7302a534aab50f44`

## Required device and service acceptance tests

No Android handset, SIM, carrier MMSC, or live mail account was connected to this build environment. Before broad deployment, test:

1. In-place upgrade from 1.4.3 while retaining app data.
2. Identity creation, public/private export, restore, password failure, and uninstall/restore on representative Android devices.
3. Encrypted and unencrypted one-to-one and group SMS/MMS across carriers, including long armored SMS and encrypted attachments.
4. PGP/MIME exchange with independent OpenPGP clients and the intended IMAP/SMTP providers.
5. Fingerprint verification, missing-key behavior, required-encryption refusal, and key replacement/removal.
6. The MMS diagnostic on each supported SIM, followed by one deliberate live delivery near the recommended ceiling if carrier confirmation is required.

The MMS diagnostic deliberately does not send probe messages. It validates Android carrier configuration and the app's encoder limit, but an MMSC may enforce an unpublished server-side limit that only a real delivery can confirm.
