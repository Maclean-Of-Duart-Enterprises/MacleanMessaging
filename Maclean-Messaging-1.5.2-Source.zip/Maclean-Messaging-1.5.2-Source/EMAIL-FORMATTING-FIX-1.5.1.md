# Maclean Messaging 1.5.1 — HTML email display fix

- Remove style, script, head, SVG, and template blocks before converting HTML email to readable text.
- Detect malformed plain-text messages that contain HTML or CSS and prefer the decoded HTML alternative.
- Apply the same display correction to previously synchronized emails when rendering message cards.
- Version name 1.5.1, version code 10501.

Build and device tests have not been executed in this environment. Verify with multipart/alternative messages, HTML-only messages, and existing stored messages.
