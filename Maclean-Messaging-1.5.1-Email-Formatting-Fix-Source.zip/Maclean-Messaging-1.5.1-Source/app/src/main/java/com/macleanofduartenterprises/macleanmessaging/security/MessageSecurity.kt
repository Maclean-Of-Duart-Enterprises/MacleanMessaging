/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 */

package com.macleanofduartenterprises.macleanmessaging.security

import android.content.Context
import android.net.Uri
import com.macleanofduartenterprises.macleanmessaging.email.security.AndroidKeystoreCredentialStore
import com.macleanofduartenterprises.macleanmessaging.files.PduContentProvider
import com.macleanofduartenterprises.macleanmessaging.model.Attachment
import com.macleanofduartenterprises.macleanmessaging.model.OutgoingMessage
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.Locale
import java.util.UUID
import org.bouncycastle.openpgp.PGPPublicKeyRing
import org.bouncycastle.openpgp.PGPKeyRing
import org.bouncycastle.openpgp.PGPSecretKeyRing
import org.bouncycastle.openpgp.api.OpenPGPCertificate
import org.bouncycastle.openpgp.api.OpenPGPKey
import org.json.JSONObject
import org.pgpainless.PGPainless
import org.pgpainless.algorithm.OpenPGPKeyVersion
import org.pgpainless.bouncycastle.extensions.certificate
import org.pgpainless.decryption_verification.ConsumerOptions
import org.pgpainless.encryption_signing.EncryptionOptions
import org.pgpainless.encryption_signing.ProducerOptions
import org.pgpainless.encryption_signing.SigningOptions
import org.pgpainless.key.parsing.KeyRingReader
import org.pgpainless.key.protection.SecretKeyRingProtector
import org.pgpainless.util.Passphrase

enum class MessageEncryptionMode(val storedValue: String, val label: String) {
    OPPORTUNISTIC("OPPORTUNISTIC", "Encrypt when possible"),
    REQUIRED("REQUIRED", "Require encryption"),
    OFF("OFF", "Always unencrypted");

    companion object {
        fun from(value: String?): MessageEncryptionMode = entries.firstOrNull {
            it.storedValue == value
        } ?: OPPORTUNISTIC
    }
}

enum class ContentSecurityState {
    PLAIN,
    ENCRYPTED_VERIFIED,
    ENCRYPTED_UNVERIFIED,
    ENCRYPTED_UNAVAILABLE,
    ENCRYPTED_INVALID
}

data class SecurityIdentitySummary(
    val userId: String,
    val fingerprint: String,
    val createdAt: Long
)

data class ContactKeySummary(
    val identity: String,
    val fingerprint: String
)

data class DecryptedContent(
    val bytes: ByteArray,
    val state: ContentSecurityState,
    val fileName: String? = null
) {
    fun text(): String = bytes.toString(Charsets.UTF_8)
}

data class PreparedSecurityMessage(
    val message: OutgoingMessage,
    val encrypted: Boolean,
    val missingRecipients: List<String>
)

data class EncryptionDecision(
    val encrypt: Boolean,
    val missingRecipients: List<String>,
    val mode: MessageEncryptionMode
)

/** Small preference boundary shared by SMS/MMS and email composition. */
class SecurityPreferences(context: Context) {
    private val preferences = context.applicationContext
        .getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)

    var defaultMode: MessageEncryptionMode
        get() = MessageEncryptionMode.from(preferences.getString(KEY_DEFAULT_MODE, null))
        set(value) { preferences.edit().putString(KEY_DEFAULT_MODE, value.storedValue).apply() }

    companion object {
        const val MODE_DEFAULT = "DEFAULT"
        private const val PREFERENCES = "message_security"
        private const val KEY_DEFAULT_MODE = "default_mode"
    }
}

/**
 * App-private OpenPGP key store.
 *
 * Secret keys are standard passphrase-protected OpenPGP keys. The passphrase is separately
 * encrypted by a non-exportable Android Keystore AES/GCM key so scheduled and notification sends
 * can run in the background. Public contact certificates contain no secret material.
 */
class OpenPgpKeyStore(context: Context) {
    private val context = context.applicationContext
    private val directory = File(this.context.filesDir, "openpgp").apply { mkdirs() }
    private val contactDirectory = File(directory, "contacts").apply { mkdirs() }
    private val preferences = this.context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
    private val credentials = AndroidKeystoreCredentialStore(this.context)

    fun identity(): SecurityIdentitySummary? {
        if (!secretFile().isFile || !publicFile().isFile) return null
        val userId = preferences.getString(KEY_IDENTITY_USER_ID, null)?.takeIf(String::isNotBlank)
            ?: return null
        val fingerprint = preferences.getString(KEY_IDENTITY_FINGERPRINT, null)?.takeIf(String::isNotBlank)
            ?: return null
        return SecurityIdentitySummary(
            userId,
            fingerprint,
            preferences.getLong(KEY_IDENTITY_CREATED, secretFile().lastModified())
        )
    }

    @Synchronized
    fun createIdentity(userId: String, password: CharArray): SecurityIdentitySummary {
        val cleanUserId = userId.replace(Regex("[\\r\\n]+"), " ").trim()
        require(cleanUserId.length in 3..200) { "Enter a name, email address, or phone number for this identity." }
        require(password.size >= 12) { "Use a backup password with at least 12 characters." }
        check(identity() == null) { "An encryption identity already exists. Export it before replacing it." }

        try {
        val passphrase = Passphrase.fromPassword(password.concatToString())
        val key = try {
            API.generateKey(OpenPGPKeyVersion.v4).modernKeyRing(cleanUserId, passphrase)
        } finally {
            if (passphrase.isValid) passphrase.clear()
        }
        val secretArmor = API.toAsciiArmor(key)
        val secretRing = requireNotNull(KeyRingReader().secretKeyRing(secretArmor))
        val certificate = secretRing.certificate
        val publicArmor = API.toAsciiArmor(API.toCertificate(certificate))
        val fingerprint = fingerprint(certificate)

        atomicWrite(secretFile(), secretArmor.toByteArray(Charsets.US_ASCII))
        atomicWrite(publicFile(), publicArmor.toByteArray(Charsets.US_ASCII))
        credentials.put(PASSPHRASE_ALIAS, password.copyOf())
        preferences.edit()
            .putString(KEY_IDENTITY_USER_ID, cleanUserId)
            .putString(KEY_IDENTITY_FINGERPRINT, fingerprint)
            .putLong(KEY_IDENTITY_CREATED, System.currentTimeMillis())
            .apply()
        return requireNotNull(identity())
        } finally {
            password.fill('\u0000')
        }
    }

    @Synchronized
    fun restoreIdentity(encoded: ByteArray, password: CharArray): SecurityIdentitySummary {
        require(encoded.size in 64..MAX_KEY_BYTES) { "The selected private-key backup is empty or too large." }
        check(identity() == null) { "An encryption identity already exists." }
        try {
            val secretRing = requireNotNull(KeyRingReader().secretKeyRing(encoded)) {
                "The selected file does not contain an OpenPGP private key."
            }
            val key = API.toKey(secretRing)
            val passphrase = Passphrase.fromPassword(password.concatToString())
            try {
                val protector = SecretKeyRingProtector.unlockEachKeyWith(passphrase, key)
                // Building the signing method forces a protected signing subkey to unlock now,
                // before any identity file or Android Keystore credential is committed.
                SigningOptions.get(API).addInlineSignature(protector, key)
            } finally {
                if (passphrase.isValid) passphrase.clear()
            }
            val certificate = secretRing.certificate
            val fingerprint = fingerprint(certificate)
            val userId = certificate.publicKey.userIDs.asSequence().firstOrNull()
                ?.replace(Regex("[\\r\\n]+"), " ")?.trim()?.takeIf(String::isNotBlank)
                ?: fingerprint
            atomicWrite(secretFile(), API.toAsciiArmor(key).toByteArray(Charsets.US_ASCII))
            atomicWrite(
                publicFile(),
                API.toAsciiArmor(API.toCertificate(certificate)).toByteArray(Charsets.US_ASCII)
            )
            credentials.put(PASSPHRASE_ALIAS, password.copyOf())
            preferences.edit()
                .putString(KEY_IDENTITY_USER_ID, userId)
                .putString(KEY_IDENTITY_FINGERPRINT, fingerprint)
                .putLong(KEY_IDENTITY_CREATED, System.currentTimeMillis())
                .apply()
            return requireNotNull(identity())
        } finally {
            password.fill('\u0000')
        }
    }

    fun publicKeyBytes(): ByteArray = publicFile().takeIf(File::isFile)?.readBytes()
        ?: error("Create an encryption identity first.")

    fun secretKeyBackupBytes(): ByteArray = secretFile().takeIf(File::isFile)?.readBytes()
        ?: error("Create an encryption identity first.")

    fun publicKeyFile(): File = publicFile().takeIf(File::isFile)
        ?: error("Create an encryption identity first.")

    fun contactKeys(): List<ContactKeySummary> {
        val index = contactIndex()
        return index.keys().asSequence().mapNotNull { identity ->
            index.optString(identity).takeIf(String::isNotBlank)?.let {
                ContactKeySummary(identity, it)
            }
        }.sortedBy(ContactKeySummary::identity).toList()
    }

    /** Imports only the public certificate even if the selected file contains a secret key. */
    @Synchronized
    fun importContactKey(identityHint: String, encoded: ByteArray): ContactKeySummary {
        require(encoded.size in 32..MAX_KEY_BYTES) { "The selected OpenPGP key file is empty or too large." }
        val ring = KeyRingReader().keyRing(encoded) ?: error("No OpenPGP certificate was found in this file.")
        val certificate = when (ring) {
            is PGPPublicKeyRing -> ring
            is PGPSecretKeyRing -> ring.certificate
            else -> error("The selected file is not an OpenPGP key ring.")
        }
        val embedded = certificate.publicKey.userIDs.asSequence().toList()
        val identity = normalizeIdentity(identityHint).ifBlank {
            embedded.asSequence().map(::normalizeIdentity).firstOrNull(String::isNotBlank).orEmpty()
        }
        require(identity.isNotBlank()) { "Enter the phone number or email address that owns this key." }
        val fingerprint = fingerprint(certificate)
        val armor = API.toAsciiArmor(API.toCertificate(certificate))
        atomicWrite(contactFile(fingerprint), armor.toByteArray(Charsets.US_ASCII))
        val index = contactIndex().put(identity, fingerprint)
        preferences.edit().putString(KEY_CONTACT_INDEX, index.toString()).apply()
        return ContactKeySummary(identity, fingerprint)
    }

    @Synchronized
    fun removeContactKey(identity: String) {
        val normalized = normalizeIdentity(identity)
        val index = contactIndex()
        val fingerprint = index.optString(normalized)
        index.remove(normalized)
        preferences.edit().putString(KEY_CONTACT_INDEX, index.toString()).apply()
        if (fingerprint.isNotBlank() && index.keys().asSequence().none { index.optString(it) == fingerprint }) {
            contactFile(fingerprint).delete()
        }
    }

    fun missingRecipients(recipients: List<String>): List<String> = recipients
        .map(::normalizeIdentity)
        .filter(String::isNotBlank)
        .distinct()
        .filter { certificateFor(it) == null }

    internal fun secretKey(): OpenPGPKey {
        val ring = requireNotNull(KeyRingReader().secretKeyRing(secretKeyBackupBytes())) {
            "The saved OpenPGP secret key is unreadable."
        }
        return API.toKey(ring)
    }

    internal fun ownCertificate(): OpenPGPCertificate {
        val ring = requireNotNull(KeyRingReader().publicKeyRing(publicKeyBytes())) {
            "The saved OpenPGP public certificate is unreadable."
        }
        return API.toCertificate(ring)
    }

    internal fun certificateFor(identity: String): OpenPGPCertificate? {
        val normalized = normalizeIdentity(identity)
        val index = contactIndex()
        val matchedIdentity = normalized.takeIf { index.has(it) } ?: if ('@' !in normalized) {
            index.keys().asSequence().firstOrNull { candidate ->
                '@' !in candidate && android.telephony.PhoneNumberUtils.compare(candidate, normalized)
            }
        } else null
        val fingerprint = matchedIdentity?.let(index::optString)?.takeIf(String::isNotBlank) ?: return null
        val ring = runCatching { KeyRingReader().publicKeyRing(contactFile(fingerprint).readBytes()) }.getOrNull()
            ?: return null
        return API.toCertificate(ring)
    }

    internal fun allCertificates(): List<OpenPGPCertificate> = contactKeys().mapNotNull {
        certificateFor(it.identity)
    }.distinctBy { fingerprint(it.pgpKeyRing) }

    internal fun passphrase(): CharArray = credentials.get(PASSPHRASE_ALIAS)
        ?: error("Android Keystore could not unlock this encryption identity. Restore its backup or create a new identity.")

    private fun contactIndex(): JSONObject = runCatching {
        JSONObject(preferences.getString(KEY_CONTACT_INDEX, "{}") ?: "{}")
    }.getOrElse { JSONObject() }

    private fun secretFile() = File(directory, "identity-secret.asc")
    private fun publicFile() = File(directory, "identity-public.asc")
    private fun contactFile(fingerprint: String) = File(contactDirectory, "$fingerprint.asc")

    private fun atomicWrite(target: File, bytes: ByteArray) {
        target.parentFile?.mkdirs()
        val temporary = File(target.parentFile, ".${target.name}.${UUID.randomUUID()}.tmp")
        try {
            temporary.outputStream().use { output -> output.write(bytes); output.fdSync() }
            if (target.exists()) check(target.delete()) { "Could not replace the OpenPGP key file." }
            check(temporary.renameTo(target)) { "Could not commit the OpenPGP key file." }
        } finally {
            temporary.delete()
        }
    }

    private fun java.io.FileOutputStream.fdSync() = fd.sync()

    companion object {
        internal val API: PGPainless by lazy { PGPainless() }
        private const val PREFERENCES = "message_security"
        private const val KEY_IDENTITY_USER_ID = "identity_user_id"
        private const val KEY_IDENTITY_FINGERPRINT = "identity_fingerprint"
        private const val KEY_IDENTITY_CREATED = "identity_created"
        private const val KEY_CONTACT_INDEX = "contact_key_index"
        private const val PASSPHRASE_ALIAS = "openpgp-identity-passphrase-v1"
        private const val MAX_KEY_BYTES = 2 * 1024 * 1024

        fun normalizeIdentity(value: String): String {
            val clean = value.trim().removePrefix("mailto:")
            val angle = Regex("<([^<>]+)>").find(clean)?.groupValues?.get(1) ?: clean
            return if ('@' in angle) angle.trim().lowercase(Locale.US)
            else {
                val plus = angle.trim().startsWith('+')
                angle.filter(Char::isDigit).takeIf(String::isNotBlank)?.let {
                    (if (plus) "+" else "") + it
                }.orEmpty()
            }
        }

        fun fingerprint(certificate: PGPKeyRing): String =
            certificate.publicKey.fingerprint.joinToString("") { "%02X".format(Locale.US, it.toInt() and 0xff) }
    }
}

/** OpenPGP transform used immediately before transport and after provider/mailbox reads. */
class MessageSecurityService(context: Context) {
    private val context = context.applicationContext
    private val keys = OpenPgpKeyStore(this.context)
    private val preferences = SecurityPreferences(this.context)

    fun prepareMessage(message: OutgoingMessage): PreparedSecurityMessage {
        val decision = encryptionDecision(message.recipients, message.securityMode)
        if (!decision.encrypt) return PreparedSecurityMessage(message, false, decision.missingRecipients)

        val encryptedBody = if (message.body.isNotEmpty()) {
            encrypt(message.body.toByteArray(Charsets.UTF_8), message.recipients, "message.txt", armor = true)
                .toString(Charsets.US_ASCII)
        } else ""
        val encryptedAttachments = message.attachments.map { attachment ->
            encryptAttachment(attachment, message.recipients)
        }
        return PreparedSecurityMessage(
            message.copy(body = encryptedBody, attachments = encryptedAttachments),
            encrypted = true,
            missingRecipients = emptyList()
        )
    }

    fun encryptionDecision(recipients: List<String>, requestedMode: String): EncryptionDecision {
        val mode = resolveMode(requestedMode)
        if (mode == MessageEncryptionMode.OFF) return EncryptionDecision(false, emptyList(), mode)
        val missing = keys.missingRecipients(recipients)
        val identityMissing = keys.identity() == null
        if (identityMissing || missing.isNotEmpty()) {
            if (mode == MessageEncryptionMode.REQUIRED) {
                val reason = if (identityMissing) "Create your encryption identity in Settings → Security & encryption."
                else "Import OpenPGP keys for: ${missing.joinToString()}."
                error("Encryption is required. $reason")
            }
            return EncryptionDecision(false, missing, mode)
        }
        return EncryptionDecision(true, emptyList(), mode)
    }

    fun encryptFor(recipients: List<String>, bytes: ByteArray, fileName: String, armor: Boolean): ByteArray {
        val missing = keys.missingRecipients(recipients)
        require(keys.identity() != null) { "Create your encryption identity in Settings → Security & encryption." }
        require(missing.isEmpty()) { "Import OpenPGP keys for: ${missing.joinToString()}." }
        return encrypt(bytes, recipients, fileName, armor)
    }

    fun decryptTextIfNeeded(value: String): DecryptedContent {
        val normalized = value.trim()
        if (!normalized.startsWith(BEGIN_MESSAGE) || !normalized.contains(END_MESSAGE)) {
            return DecryptedContent(value.toByteArray(Charsets.UTF_8), ContentSecurityState.PLAIN)
        }
        val encoded = normalized.toByteArray(Charsets.US_ASCII)
        val cacheKey = sha256(encoded) + ":" + (keys.identity()?.fingerprint ?: "none")
        synchronized(TEXT_CACHE) { TEXT_CACHE[cacheKey] }?.let { return it }
        return runCatching { decrypt(encoded, MAX_TEXT_BYTES) }
            .getOrElse {
                DecryptedContent(
                    "[Encrypted message — this device could not unlock it.]".toByteArray(),
                    if (keys.identity() == null) ContentSecurityState.ENCRYPTED_UNAVAILABLE
                    else ContentSecurityState.ENCRYPTED_INVALID
                )
            }.also { result ->
                if (result.state == ContentSecurityState.ENCRYPTED_VERIFIED ||
                    result.state == ContentSecurityState.ENCRYPTED_UNVERIFIED
                ) synchronized(TEXT_CACHE) {
                    TEXT_CACHE[cacheKey] = result
                    while (TEXT_CACHE.size > MAX_TEXT_CACHE_ITEMS) {
                        val oldest = TEXT_CACHE.entries.iterator()
                        if (oldest.hasNext()) { oldest.next(); oldest.remove() }
                    }
                }
            }
    }

    fun decryptAttachmentIfNeeded(bytes: ByteArray, suggestedName: String, mimeType: String): DecryptedContent {
        val encrypted = mimeType.equals(PGP_MIME, true) || suggestedName.endsWith(".pgp", true) ||
            bytes.toString(Charsets.US_ASCII).trimStart().startsWith(BEGIN_MESSAGE)
        if (!encrypted) return DecryptedContent(bytes, ContentSecurityState.PLAIN, suggestedName)
        return decrypt(bytes, MAX_ATTACHMENT_BYTES)
    }

    fun publicAutocryptKeyData(address: String): String? = keys.identity()?.let {
        val certificate = requireNotNull(KeyRingReader().publicKeyRing(keys.publicKeyBytes()))
        val normalized = OpenPgpKeyStore.normalizeIdentity(address)
        if (certificate.publicKey.userIDs.asSequence().none {
                OpenPgpKeyStore.normalizeIdentity(it) == normalized
            }
        ) return null
        android.util.Base64.encodeToString(
            certificate.encoded,
            android.util.Base64.NO_WRAP
        )
    }

    fun importAutocrypt(address: String, keyData: String): ContactKeySummary? = runCatching {
        val bytes = android.util.Base64.decode(keyData.replace(Regex("\\s+"), ""), android.util.Base64.DEFAULT)
        keys.importContactKey(address, bytes)
    }.getOrNull()

    private fun resolveMode(value: String): MessageEncryptionMode =
        if (value == SecurityPreferences.MODE_DEFAULT) preferences.defaultMode else MessageEncryptionMode.from(value)

    private fun encryptAttachment(attachment: Attachment, recipients: List<String>): Attachment {
        val source = context.contentResolver.openInputStream(Uri.parse(attachment.uri))
            ?: error("Android could not open ${attachment.displayName ?: "the attachment"} for encryption.")
        val bytes = source.use { input ->
            val output = ByteArrayOutputStream()
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            var total = 0L
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                total += count
                require(total <= MAX_ATTACHMENT_BYTES) { "Encrypted attachments are limited to 50 MiB." }
                output.write(buffer, 0, count)
            }
            output.toByteArray()
        }
        val originalName = attachment.displayName?.replace(Regex("[\\r\\n/\\\\]+"), "_")
            ?.take(120)?.ifBlank { null } ?: "attachment"
        val encrypted = encrypt(bytes, recipients, originalName, armor = false)
        val folder = File(context.cacheDir, "secure-outgoing/${UUID.randomUUID()}").apply { mkdirs() }
        val target = File(folder, "$originalName.pgp")
        target.writeBytes(encrypted)
        cleanupOutgoingCache()
        return Attachment(
            uri = PduContentProvider.uriFor(context, target).toString(),
            mimeType = PGP_MIME,
            displayName = target.name,
            sizeBytes = target.length()
        )
    }

    private fun encrypt(
        bytes: ByteArray,
        recipients: List<String>,
        fileName: String,
        armor: Boolean
    ): ByteArray {
        val secret = keys.secretKey()
        val password = keys.passphrase()
        val passphrase = Passphrase.fromPassword(password.concatToString())
        password.fill('\u0000')
        val protector = SecretKeyRingProtector.unlockEachKeyWith(passphrase, secret)
        return try {
            val certificates = buildList {
                add(keys.ownCertificate())
                recipients.mapNotNull(keys::certificateFor).forEach(::add)
            }.distinctBy { OpenPgpKeyStore.fingerprint(it.pgpKeyRing) }
            val encryption = EncryptionOptions.encryptCommunications(OpenPgpKeyStore.API)
            certificates.forEach(encryption::addRecipient)
            val signing = SigningOptions.get(OpenPgpKeyStore.API)
                .addInlineSignature(protector, secret)
            val options = ProducerOptions.signAndEncrypt(encryption, signing)
                .setAsciiArmor(armor)
                .setFileName(fileName)
                .setVersion("Maclean Messaging 1.5.1")
            ByteArrayOutputStream().also { output ->
                OpenPgpKeyStore.API.generateMessage().onOutputStream(output).withOptions(options).use {
                    it.write(bytes)
                }
            }.toByteArray()
        } finally {
            if (passphrase.isValid) passphrase.clear()
        }
    }

    private fun decrypt(bytes: ByteArray, maximumBytes: Int): DecryptedContent {
        val secret = keys.secretKey()
        val password = keys.passphrase()
        val passphrase = Passphrase.fromPassword(password.concatToString())
        password.fill('\u0000')
        val protector = SecretKeyRingProtector.unlockEachKeyWith(passphrase, secret)
        return try {
            val options = ConsumerOptions.get(OpenPgpKeyStore.API)
                .addDecryptionKey(secret, protector)
                .addVerificationCert(keys.ownCertificate())
                .addVerificationCerts(keys.allCertificates())
            val stream = OpenPgpKeyStore.API.processMessage()
                .onInputStream(bytes.inputStream())
                .withOptions(options)
            val verified = PGPainless.verifyAndOpen(stream, maximumBytes)
            val plaintext = verified.use { it.readBytes() }
            val metadata = verified.metadata
            DecryptedContent(
                plaintext,
                if (metadata.isVerifiedSigned()) ContentSecurityState.ENCRYPTED_VERIFIED
                else ContentSecurityState.ENCRYPTED_UNVERIFIED,
                metadata.filename?.takeIf(String::isNotBlank)
            )
        } finally {
            if (passphrase.isValid) passphrase.clear()
        }
    }

    private fun cleanupOutgoingCache() {
        val cutoff = System.currentTimeMillis() - OUTGOING_CACHE_MAX_AGE_MS
        File(context.cacheDir, "secure-outgoing").listFiles()?.forEach { folder ->
            if (folder.lastModified() < cutoff) folder.deleteRecursively()
        }
    }

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(bytes).joinToString("") { "%02x".format(Locale.US, it.toInt() and 0xff) }

    companion object {
        const val PGP_MIME = "application/pgp-encrypted"
        const val BEGIN_MESSAGE = "-----BEGIN PGP MESSAGE-----"
        const val END_MESSAGE = "-----END PGP MESSAGE-----"
        private const val MAX_TEXT_BYTES = 8 * 1024 * 1024
        private const val MAX_ATTACHMENT_BYTES = 50 * 1024 * 1024
        private const val OUTGOING_CACHE_MAX_AGE_MS = 24L * 60L * 60L * 1000L
        private const val MAX_TEXT_CACHE_ITEMS = 256
        private val TEXT_CACHE = object : LinkedHashMap<String, DecryptedContent>(32, 0.75f, true) {}
    }
}

