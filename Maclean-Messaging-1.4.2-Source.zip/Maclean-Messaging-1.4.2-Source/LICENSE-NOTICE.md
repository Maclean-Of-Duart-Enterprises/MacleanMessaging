# License notice

Maclean Messaging original source code is licensed under:

**GNU Affero General Public License, version 3 only — SPDX: `AGPL-3.0-only`.**

Copyright (C) 2026 Maclean Of Duart Enterprises.

The complete, unmodified GNU AGPLv3 license text must accompany distributed source/binaries and must also be made readable from the application's license screen before release.

Official license text:
https://www.gnu.org/licenses/agpl-3.0.txt
