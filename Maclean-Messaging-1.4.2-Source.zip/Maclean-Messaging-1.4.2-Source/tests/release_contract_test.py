#!/usr/bin/env python3
"""Source-level release contracts for Android behavior that cannot run off-device."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class ReleaseContractTest(unittest.TestCase):
    def source(self, relative: str) -> str:
        return (ROOT / relative).read_text(encoding="utf-8")

    def test_modern_default_role_is_authoritative(self):
        source = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/system/DefaultSmsRole.kt")
        self.assertIn("isRoleHeld(RoleManager.ROLE_SMS)", source)

    def test_null_role_result_is_handled_before_file_picker_guard(self):
        source = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/ui/MainActivity.kt")
        role = source.index("if (requestCode == REQUEST_DEFAULT_SMS_ROLE)")
        null_data = source.index("if (resultCode != RESULT_OK || data == null) return", role)
        self.assertLess(role, null_data)
        self.assertIn("resumePendingSmsRoleAction()", source[role:null_data])

    def test_send_and_schedule_are_saved_then_resumed(self):
        source = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/ui/MainActivity.kt")
        self.assertIn("requestSmsRoleAndContinue(id, payload, runAt, ROLE_ORIGIN_COMPOSER)", source)
        self.assertIn("ComposeStore.get(this).saveDraft(itemId, payload)", source)
        self.assertNotIn("then send or schedule again", source)

    def test_due_sms_rechecks_role(self):
        source = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/schedule/ScheduledMessage.kt")
        self.assertIn("check(DefaultSmsRole.isDefault(context))", source)

    def test_mms_has_real_download_and_provider_import(self):
        source = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/IncomingMmsManager.kt")
        self.assertIn("downloadMultimediaMessage", source)
        self.assertIn("Telephony.Mms.Inbox.CONTENT_URI", source)
        self.assertIn("MmsPduParser.parseRetrieveConf", source)

    def test_incoming_mms_uri_identifies_the_correct_storage_root(self):
        provider = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/files/PduContentProvider.kt")
        self.assertIn('ROOT_FILES to context.filesDir.canonicalFile', provider)
        self.assertIn('(listOf(rootName) + relative.split', provider)
        self.assertIn('relative.startsWith("incoming-mms${File.separator}")', provider)

    def test_incoming_mms_is_retained_before_parse_and_retried(self):
        source = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/IncomingMmsManager.kt")
        write = source.index("writeAtomic(notificationFile, pdu)")
        parse = source.index("MmsPduParser.parseNotification(pdu)")
        self.assertLess(write, parse)
        self.assertIn("scheduleRetry(context, token, subscriptionId)", source)
        self.assertIn("fun reconcile(context: Context)", source)

    def test_incoming_sms_uses_async_durable_provider_commit(self):
        receiver = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/SmsDeliverReceiver.kt")
        manager = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/IncomingSmsManager.kt")
        manifest = self.source("app/src/main/AndroidManifest.xml")
        self.assertIn("val pending = goAsync()", receiver)
        self.assertIn("IncomingSmsManager.accept", receiver)
        self.assertIn("writeAtomic(file", manager)
        self.assertIn("Telephony.Sms.Inbox.CONTENT_URI", manager)
        self.assertIn("findExisting(context, pending)", manager)
        self.assertIn("IncomingSmsRetryJobService", manifest)

    def test_delivery_receivers_acknowledge_before_detaching_result(self):
        for relative in (
            "app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/SmsDeliverReceiver.kt",
            "app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/MmsWapPushReceiver.kt",
        ):
            source = self.source(relative)
            self.assertLess(
                source.index("setResultCode(Telephony.Sms.Intents.RESULT_SMS_HANDLED)"),
                source.index("val pending = goAsync()"),
            )

    def test_carrier_callback_keeps_receiver_alive_and_clears_successful_outbox(self):
        receiver = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/SmsStatusReceiver.kt")
        store = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/workflow/ComposeStore.kt")
        self.assertIn("val pending = goAsync()", receiver)
        self.assertIn("runCatching { pending.finish() }", receiver)
        self.assertIn("ComposeStore.get(context).applyTransportResult", receiver)
        self.assertIn("state in SUCCESSFUL_TRANSPORT_STATES", store)
        self.assertIn("deleteCompleted(it.id)", store)

    def test_multipart_sms_is_aggregated_before_terminal_state(self):
        receiver = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/SmsStatusReceiver.kt")
        database = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/data/LocalDatabase.kt")
        self.assertIn("recordSmsPartResult", receiver)
        self.assertIn("PRIMARY KEY(token,phase,part)", database)
        self.assertIn("rows.size >= totalParts", database)

    def test_scheduled_mms_and_retry_require_cellular_network(self):
        schedule = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/schedule/ScheduledMessage.kt")
        incoming = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/IncomingMmsManager.kt")
        self.assertIn("JobInfo.NETWORK_TYPE_CELLULAR", schedule)
        self.assertIn("JobInfo.NETWORK_TYPE_CELLULAR", incoming)

    def test_mms_keeps_two_megabyte_selection_but_obeys_carrier_transport_limit(self):
        policy = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/MmsCarrierConfig.kt")
        fit = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/MmsImageFitPolicy.kt")
        codec = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/MmsPduCodec.kt")
        outgoing = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/MmsTransport.kt")
        incoming = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/IncomingMmsManager.kt")
        self.assertIn("2 * 1024 * 1024", policy)
        self.assertIn("KEY_MMS_MAX_MESSAGE_SIZE_INT", policy)
        self.assertIn("KEY_MMS_MAX_IMAGE_WIDTH_INT", policy)
        self.assertIn("KEY_MMS_MAX_IMAGE_HEIGHT_INT", policy)
        self.assertIn("Bundle.EMPTY", policy)
        self.assertIn("MmsCarrierConfig.profile(context, message.subscriptionId)", outgoing)
        self.assertIn("MmsCarrierConfig.operationOverrides()", outgoing)
        self.assertIn("MmsCarrierConfig.operationOverrides()", incoming)
        self.assertIn("RESERVE_FRACTION = 0.18", fit)
        self.assertIn("MIN_RESERVE_BYTES = 30 * 1024", fit)
        self.assertIn("MAX_RESERVE_BYTES = 60 * 1024", fit)
        self.assertIn("val skeletonPdu = encode(msg, skeleton)", codec)
        self.assertIn("if (encoded.size <= carrier.maxMessageBytes) return encoded", codec)
        self.assertIn("inJustDecodeBounds = true", codec)

    def test_binary_mms_parts_use_canonical_file_descriptors(self):
        writer = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/MmsProviderWriter.kt")
        incoming = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/IncomingMmsManager.kt")
        outgoing = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/data/SystemMessageRepository.kt")
        self.assertIn('Uri.parse("content://mms/part")', writer)
        self.assertIn('openFileDescriptor(uri, "w")', writer)
        self.assertIn('openOutputStream(uri, "w")', writer)
        self.assertIn('openFileDescriptor(uri, "rwt")', writer)
        self.assertIn('put("mid", messageId)', writer)
        self.assertIn("MmsProviderWriter.insertBinaryPart", incoming)
        self.assertIn("MmsProviderWriter.insertBinaryPart", outgoing)

    def test_mms_inline_parts_and_vendor_attachment_fallback(self):
        parser = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/MmsPduParser.kt")
        incoming = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/IncomingMmsManager.kt")
        outgoing = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/data/SystemMessageRepository.kt")
        repository = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/data/DeviceMessageRepository.kt")
        fallback = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/LocalMmsAttachmentStore.kt")
        for content_type in ('"text/plain"', '"text/html"', '"application/smil"'):
            self.assertIn(content_type, parser)
        self.assertIn("MmsPduParser.isInlineTextPart(part.mimeType)", incoming)
        self.assertIn('equals("application/smil", true)) -1 else sequence', incoming)
        self.assertIn("LocalMmsAttachmentStore.store", incoming)
        self.assertIn("LocalMmsAttachmentStore.store", outgoing)
        self.assertIn("LocalMmsAttachmentStore.list", repository)
        self.assertIn("LocalMmsAttachmentStore.deleteMessage", repository)
        self.assertIn("AtomicFile", fallback)

    def test_outgoing_provider_failure_is_not_silently_hidden(self):
        source = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/data/SystemMessageRepository.kt")
        section = source[source.index("fun send(message:"):source.index("private fun insertOutgoingSms")]
        self.assertNotIn("runCatching", section)
        self.assertIn("insertOutgoingSms(message)", section)
        self.assertIn("insertOutgoingMms(message)", section)

    def test_default_sms_role_components_are_complete(self):
        manifest = self.source("app/src/main/AndroidManifest.xml")
        for value in (
            "android.provider.Telephony.SMS_DELIVER",
            "android.provider.Telephony.WAP_PUSH_DELIVER",
            "android.intent.action.SENDTO",
            "android.intent.action.RESPOND_VIA_MESSAGE",
            "android.permission.BROADCAST_SMS",
            "android.permission.BROADCAST_WAP_PUSH",
            "android.permission.SEND_RESPOND_VIA_MESSAGE",
        ):
            self.assertIn(value, manifest)

    def test_release_is_1_4_2(self):
        manifest = self.source("app/src/main/AndroidManifest.xml")
        gradle = self.source("app/build.gradle.kts")
        self.assertIn('android:versionCode="10402"', manifest)
        self.assertIn('android:versionName="1.4.2"', manifest)
        self.assertIn('versionCode = 10402', gradle)
        self.assertIn('versionName = "1.4.2"', gradle)

    def test_streamlined_threads_use_inline_reply_without_selection_boxes(self):
        source = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/ui/MainActivity.kt")
        self.assertIn("installInlineReplyComposer(replyHost, threadId, fallbackAddress)", source)
        self.assertIn("focusInlineReply(\"↪ Reply to", source)
        self.assertIn("if (returnThreadId != null && payload.kind == \"MESSAGE\")", source)
        self.assertNotIn("compactSelectionBox", source)
        self.assertNotIn('primaryButton("Reply")', source)

    def test_first_inline_reply_appears_before_provider_dispatch_and_refreshes_afterward(self):
        source = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/ui/MainActivity.kt")
        queue = source[source.index("private fun queueComposerPayload"):source.index("/** Paints an outgoing inline reply")]
        pending = source[source.index("private fun appendPendingInlineReply"):source.index("private fun removePendingInlineReply")]
        card = source[source.index("private fun bindDeviceMessageCard"):source.index("private fun bindEmailMessageCard")]
        self.assertLess(queue.index("appendPendingInlineReply"), queue.index("composeWork({"))
        self.assertIn("if (!immediateInlineReply)", queue)
        self.assertLess(queue.index("ScheduleCoordinator.perform"), queue.index("showSmsThread(returnThreadId, returnAddress)", queue.index("ScheduleCoordinator.perform")))
        self.assertIn("activeDeviceAdapter?.submit(activeDeviceMessages, activeDeviceSort)", pending)
        self.assertIn("activeDeviceAdapter?.positionOf(pending.stableId)", pending)
        self.assertIn("activeDeviceList?.setSelection(position)", pending)
        self.assertIn("id = pendingId", pending)
        self.assertIn('pending -> "$type • Sending…"', card)
        self.assertIn("card.setOnLongClickListener(null)", card)

    def test_reply_location_is_saved_and_keyboard_safe(self):
        activity = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/ui/MainActivity.kt")
        settings = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/settings/UserSettings.kt")
        manifest = self.source("app/src/main/AndroidManifest.xml")
        self.assertIn('android:windowSoftInputMode="adjustResize"', manifest)
        self.assertIn("WindowInsets.Type.ime()", activity)
        self.assertIn("maxOf(keyboardBottom, navigationBottom)", activity)
        self.assertIn("appearance.display.replyLocation == REPLY_LOCATION_TOP", activity)
        self.assertIn("threadScreen.topReply", activity)
        self.assertIn('text("Message reply location"', activity)
        self.assertIn('preferences.getString("${prefix}reply_location"', settings)
        self.assertIn("replyLocation = REPLY_LOCATION_BOTTOM", settings)

    def test_sms_threads_load_complete_history_into_recycled_rows(self):
        activity = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/ui/MainActivity.kt")
        repository = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/data/DeviceMessageRepository.kt")
        self.assertIn("repository.threadHeaders(threadId)", activity)
        self.assertIn("repository.hydrateThread(threadId, headers)", activity)
        self.assertIn('"Loading complete conversation…"', activity)
        self.assertIn("cachedMessages", activity)
        self.assertNotIn('compactButton("Load older messages")', activity)
        self.assertNotIn("threadPage(threadId", activity)
        self.assertIn("class DeviceMessageAdapter", activity)
        self.assertNotIn("DeviceMessagePage", repository)
        self.assertNotIn("DEFAULT_THREAD_PAGE_SIZE", repository)
        self.assertIn('Log.e(TAG, "Could not hydrate mms:${header.id}"', repository)

    def test_standalone_sms_runtime_contract_is_recoverable(self):
        manifest = self.source("app/src/main/AndroidManifest.xml")
        readiness = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/system/SmsRuntimeReadiness.kt")
        repository = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/data/SystemMessageRepository.kt")
        activity = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/ui/MainActivity.kt")
        self.assertIn("android.permission.WRITE_SMS", manifest)
        self.assertIn("android.intent.category.APP_MESSAGING", manifest)
        self.assertIn('WRITE_SMS_APP_OP = "android:write_sms"', readiness)
        self.assertIn("requiredComponentsEnabled(context)", readiness)
        self.assertIn("SmsRuntimeReadiness.inspect(context)", repository)
        self.assertIn("check(readiness.operational)", repository)
        self.assertIn("Google Messages is not required", activity)

    def test_performance_work_is_bounded_cached_and_progressive(self):
        async_source = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/util/Async.kt")
        activity = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/ui/MainActivity.kt")
        repository = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/data/DeviceMessageRepository.kt")
        snapshot = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/unified/UnifiedInboxSnapshotStore.kt")
        voice = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/voice/VoiceRecorder.kt")
        self.assertIn("Executors.newFixedThreadPool", async_source)
        self.assertIn("Executors.newSingleThreadExecutor", async_source)
        self.assertNotIn("newCachedThreadPool", async_source)
        self.assertIn("class InboxConversationAdapter", activity)
        self.assertIn("UnifiedInboxSnapshotStore.load(this)", activity)
        self.assertIn("DeviceMessageRepository.peekThread(threadId)", activity)
        self.assertIn("threadHeaders(threadId)", repository)
        self.assertIn("hydrateThread(threadId", repository)
        self.assertIn("AtomicFile", snapshot)
        self.assertIn("Async.launch", voice)
        self.assertIn("Finalizing voice message in the background", activity)

    def test_imap_auth_and_sync_are_complete_and_incremental(self):
        transport = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/email/transport/ImapTransport.kt")
        database = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/data/LocalDatabase.kt")
        ingestor = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/email/transport/EmailSyncIngestor.kt")
        self.assertIn('authenticate("PLAIN"', transport)
        self.assertIn('authenticate("LOGIN"', transport)
        self.assertIn('send("$tag AUTHENTICATE $mechanism")', transport)
        self.assertIn("serverUids.filterNot(knownUids::contains)", transport)
        self.assertIn("chunked(FETCH_BATCH_SIZE)", transport)
        self.assertIn("connection.fetchFlags(existingUids)", transport)
        self.assertNotIn("takeLast(250)", transport)
        self.assertIn("fun knownEmailUids", database)
        self.assertIn("fun applyEmailSeenFlags", database)
        self.assertIn("continuing mailbox sync", ingestor)

    def test_text_layout_tracks_selected_surface_shape(self):
        activity = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/ui/MainActivity.kt")
        contour = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/ui/ShapeContourLayout.kt")
        contour_text = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/ui/ContourTextView.kt")
        self.assertIn("shapeHorizontalPadding", activity)
        self.assertIn("shapeVerticalPadding", activity)
        self.assertIn("applyShapeAwarePadding(field, appearance.display.cardShape", activity)
        self.assertIn("appearance.display.bubbleShape", activity)
        self.assertIn("Layout.BREAK_STRATEGY_HIGH_QUALITY", activity)
        self.assertIn("Layout.HYPHENATION_FREQUENCY_NORMAL", activity)
        self.assertIn("ShapeContourLayout(this)", activity)
        self.assertIn("roundedBoundaryInset", contour)
        self.assertIn("params.leftMargin = requestedLeft", contour)
        self.assertIn("ContourTextView(this)", activity)
        self.assertIn("setIndents(indents, indents)", contour_text)
        self.assertIn("clickableSpanAt", contour_text)

    def test_display_profiles_persist_and_apply_expanded_font_and_format_choices(self):
        activity = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/ui/MainActivity.kt")
        settings = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/settings/UserSettings.kt")
        self.assertIn('text("System text style"', activity)
        self.assertIn("DISPLAY_FONT_OPTIONS", activity)
        self.assertIn("DISPLAY_FONT_CURSIVE_SCRIPT", activity)
        self.assertIn("DISPLAY_FONT_CURSIVE_CASUAL", activity)
        self.assertIn("DISPLAY_FONT_CALLIGRAPHY_CLASSIC", activity)
        self.assertIn("DISPLAY_FONT_CALLIGRAPHY_FLOURISHED", activity)
        self.assertIn("DISPLAY_FONT_SPECIAL_SMALL_CAPS", activity)
        self.assertIn("DISPLAY_FONT_SPECIAL_SLAB", activity)
        self.assertIn("DISPLAY_FONT_SPECIAL_LIGHT", activity)
        self.assertIn("DISPLAY_FONT_SPECIAL_HEAVY", activity)
        self.assertIn("TEXT_FORMAT_OPTIONS", activity)
        self.assertIn("TEXT_FORMAT_BOLD_ITALIC", activity)
        self.assertIn("appearance.display.textFont", activity)
        self.assertIn("appearance.display.textFormat", activity)
        self.assertIn("private fun appTypeface", activity)
        self.assertIn("private fun typefaceFor", activity)
        self.assertIn('preferences.getString("${prefix}text_font"', settings)
        self.assertIn('putString("${prefix}text_font"', settings)
        self.assertIn('preferences.getString("${prefix}text_format"', settings)
        self.assertIn('putString("${prefix}text_format"', settings)

    def test_external_share_intents_open_attachment_composers(self):
        manifest = self.source("app/src/main/AndroidManifest.xml")
        activity = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/ui/MainActivity.kt")
        self.assertIn("android.intent.action.SEND", manifest)
        self.assertIn("android.intent.action.SEND_MULTIPLE", manifest)
        self.assertIn('android:mimeType="*/*"', manifest)
        self.assertIn("importAndComposeSharedContent", activity)
        self.assertIn("importSharedAttachment", activity)
        self.assertIn("Share with Maclean Messaging", activity)
        self.assertIn("initialAttachments = shared.attachments", activity)

    def test_email_sync_exposes_diagnostics_and_handles_android_15_network_changes(self):
        transport = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/email/transport/ImapTransport.kt")
        tls = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/email/transport/TlsSocket.kt")
        worker = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/email/sync/EmailSyncWorker.kt")
        activity = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/ui/MainActivity.kt")
        self.assertIn("diagnosticFailure", transport)
        self.assertIn("Log.e(TAG", transport)
        self.assertIn("opening the secure connection", transport)
        self.assertIn("SNIHostName(host)", tls)
        self.assertIn("endpointIdentificationAlgorithm", tls)
        self.assertIn("override fun onNetworkChanged", worker)
        self.assertIn("performDetailed", worker)
        self.assertIn("Last successful sync:", activity)

    def test_outgoing_mms_uses_aosp_compatible_multipart_metadata(self):
        writer = self.source(
            "app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/MmsPduWriter.kt"
        )
        codec = self.source(
            "app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/MmsPduCodec.kt"
        )
        self.assertIn("PARAMETER_RELATED_TYPE = 0x89", writer)
        self.assertIn("PARAMETER_START = 0x8a", writer)
        self.assertIn("writeQuotedString(headers, \"<$safeContentId>\")", writer)
        self.assertIn("val parts = listOf(smil) + content", writer)
        self.assertIn("MmsPduWriter.encodeSendRequest", codec)

    def test_inbox_isolates_sms_and_mms_provider_failures(self):
        source = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/data/DeviceMessageRepository.kt")
        self.assertIn("runCatching { scanSmsConversations(summaries) }", source)
        self.assertIn("runCatching { scanMmsConversations(summaries) }", source)
        self.assertIn("preserving SMS inbox", source)

    def test_orphaned_completed_mms_download_is_recovered(self):
        source = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/telephony/IncomingMmsManager.kt")
        self.assertIn("if (destination.length() > 0L)", source)
        self.assertIn("Activity.RESULT_OK", source)

    def test_email_actions_are_remote_and_sent_copy_is_persisted(self):
        actions = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/email/compose/EmailActionService.kt")
        compose = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/email/compose/EmailComposeCoordinator.kt")
        self.assertIn("ImapTransport(context).setSeen", actions)
        self.assertIn("ImapTransport(context).delete", actions)
        self.assertIn("folder=\"SENT\"", compose)

    def test_individual_and_bulk_read_controls_cover_messages_and_email(self):
        activity = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/ui/MainActivity.kt")
        device = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/data/DeviceMessageRepository.kt")
        email = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/email/compose/EmailActionService.kt")
        database = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/data/LocalDatabase.kt")
        self.assertGreaterEqual(activity.count('MenuAction("Mark as read")'), 3)
        self.assertGreaterEqual(activity.count('MenuAction("Mark selected as read")'), 3)
        self.assertGreaterEqual(activity.count('MenuAction("Mark as unread")'), 3)
        self.assertGreaterEqual(activity.count('MenuAction("Mark selected as unread")'), 3)
        self.assertIn("markSelectedDeviceMessagesRead", activity)
        self.assertIn("markSelectedEmailMessagesRead", activity)
        self.assertIn("markSelectedInboxConversationsRead", activity)
        self.assertIn("fun markRead(messages: Collection<DeviceMessage>)", device)
        self.assertIn("fun markUnread(messages: Collection<DeviceMessage>)", device)
        self.assertIn("chunked(READ_UPDATE_CHUNK_SIZE)", device)
        self.assertIn("Telephony.Sms.SEEN", device)
        self.assertIn("Telephony.Mms.SEEN", device)
        self.assertIn("suspend fun setUnread(messageIds: Collection<String>", email)
        self.assertIn("groupBy(EmailMessageEntity::accountId)", email)
        self.assertIn("db.emailMessages(messageIds)", email)
        self.assertIn("fun setEmailMessagesUnread", database)
        self.assertIn("chunked(SQLITE_BIND_CHUNK_SIZE)", database)

    def test_voice_message_uses_opus_with_m4a_fallback(self):
        voice = self.source("app/src/main/java/com/macleanofduartenterprises/macleanmessaging/voice/VoiceRecorder.kt")
        self.assertIn("MediaRecorder.AudioEncoder.OPUS", voice)
        self.assertIn("MediaRecorder.AudioEncoder.AAC", voice)
        self.assertIn("setAudioSamplingRate(48_000)", voice)
        self.assertIn("setAudioEncodingBitRate(32_000)", voice)


if __name__ == "__main__":
    unittest.main(verbosity=2)
