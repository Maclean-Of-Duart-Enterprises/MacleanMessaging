/* Maclean Messaging — SPDX-License-Identifier: AGPL-3.0-only */
import com.macleanofduartenterprises.macleanmessaging.telephony.MmsPduParser
import java.io.ByteArrayOutputStream

private fun text(out: ByteArrayOutputStream, value: String) {
    out.write(value.toByteArray(Charsets.UTF_8)); out.write(0)
}

private fun encodedSender(out: ByteArrayOutputStream, value: String) {
    val encoded = value.toByteArray(Charsets.UTF_8)
    out.write(encoded.size + 2); out.write(0x80); text(out, value)
}

private fun uintvar(out: ByteArrayOutputStream, value: Int) {
    if (value < 128) out.write(value) else {
        out.write((value shr 7) or 0x80); out.write(value and 0x7F)
    }
}

fun main() {
    check(MmsPduParser.isInlineTextPart("text/plain; charset=utf-8"))
    check(MmsPduParser.isInlineTextPart("text/html"))
    check(MmsPduParser.isInlineTextPart("application/smil"))
    check(!MmsPduParser.isInlineTextPart("image/jpeg"))
    check(MmsPduParser.isVisibleTextPart("text/html; charset=utf-8"))
    check(!MmsPduParser.isVisibleTextPart("application/smil"))

    val notification = ByteArrayOutputStream().apply {
        write(0x8C); write(0x82)
        write(0x98); text(this, "transaction-1")
        write(0x89); encodedSender(this, "+17175550123/TYPE=PLMN")
        write(0x8D); write(0x92)
        write(0x83); text(this, "https://mmsc.example/retrieve/1")
    }.toByteArray()
    MmsPduParser.parseNotification(notification).let {
        check(it.transactionId == "transaction-1")
        check(it.sender == "+17175550123")
        check(it.contentLocation.endsWith("/1"))
    }

    val body = "Hello from MMS ✓".toByteArray(Charsets.UTF_8)
    val partHeader = ByteArrayOutputStream().apply {
        val contentType = ByteArrayOutputStream().apply {
            write(0x83); write(0x81); write(0xEA); write(0x85); text(this, "text.txt")
        }.toByteArray()
        write(contentType.size); write(contentType)
        write(0x8E); text(this, "text.txt")
    }.toByteArray()
    val image = byteArrayOf(0x7F, 0x45, 0x4C, 0x46, 0x01, 0x02)
    val imageHeader = byteArrayOf(0x9E.toByte()) // Well-known image/jpeg content type.
    val retrieve = ByteArrayOutputStream().apply {
        write(0x8C); write(0x84)
        write(0x98); text(this, "transaction-1")
        write(0x8B); text(this, "message-1")
        write(0x89); encodedSender(this, "+17175550123/TYPE=PLMN")
        write(0x8D); write(0x92)
        write(0x84); write(0xA3)
        uintvar(this, 2)
        uintvar(this, partHeader.size); uintvar(this, body.size)
        write(partHeader); write(body)
        uintvar(this, imageHeader.size); uintvar(this, image.size)
        write(imageHeader); write(image)
    }.toByteArray()
    MmsPduParser.parseRetrieveConf(retrieve).let {
        check(it.messageId == "message-1")
        check(it.sender == "+17175550123")
        check(it.text == "Hello from MMS ✓")
        check(it.attachments.size == 1)
        check(it.attachments.single().mimeType == "image/jpeg")
        check(it.attachments.single().name == "image.jpg")
        check(it.attachments.single().data.contentEquals(image))
    }
    println("MMS PDU parser tests passed")
}
