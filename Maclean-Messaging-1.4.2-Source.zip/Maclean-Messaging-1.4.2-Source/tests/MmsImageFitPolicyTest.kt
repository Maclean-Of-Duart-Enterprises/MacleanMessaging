/* Maclean Messaging — SPDX-License-Identifier: AGPL-3.0-only */
import com.macleanofduartenterprises.macleanmessaging.telephony.MmsImageFitPolicy

fun main() {
    val carrierLimit = 300 * 1024
    val reserve = MmsImageFitPolicy.structuralReserve(carrierLimit)
    check(reserve in 30 * 1024..60 * 1024)
    check(reserve == 55_296)
    check(MmsImageFitPolicy.totalImageBudget(carrierLimit, 20 * 1024) == 251_904)
    check(MmsImageFitPolicy.perImageBudget(251_904, 2) == 125_952)

    // Large text/non-image content must reserve its exact footprint instead of the estimate.
    check(MmsImageFitPolicy.totalImageBudget(carrierLimit, 100 * 1024) == 204_800)
    check(MmsImageFitPolicy.totalImageBudget(carrierLimit, carrierLimit + 1) == 0)

    val steps = MmsImageFitPolicy.steps
    check(steps.size >= 10)
    check(steps.first().dimensionScale == 1.0)
    check(steps.first().jpegQuality >= 90)
    check(steps.last().dimensionScale <= 0.25)
    check(steps.zipWithNext().all { (left, right) ->
        right.dimensionScale < left.dimensionScale && right.jpegQuality <= left.jpegQuality
    })
    println("MMS adaptive image-fit policy tests passed")
}
