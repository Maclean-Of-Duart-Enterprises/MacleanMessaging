package com.macleanofduartenterprises.macleanmessaging.email.transport

import java.util.Base64

fun main() {
    val username = "mailbox@example.net"
    val password = "spaces \\\" quotes \\ and café"
    val decoded = Base64.getDecoder().decode(ImapProtocol.saslPlain(username, password))
        .toString(Charsets.UTF_8)
    check(decoded == "\u0000$username\u0000$password") {
        "SASL PLAIN must preserve credentials without IMAP quoted-string parsing."
    }
    check(Base64.getDecoder().decode(ImapProtocol.base64Utf8(password)).toString(Charsets.UTF_8) == password)

    val fetch = "* 42 FETCH (UID 987 FLAGS (\\Seen \\Answered) BODY[] {1234}"
    check(ImapProtocol.uid(fetch) == 987L)
    check(ImapProtocol.flags(fetch) == setOf("\\Seen", "\\Answered"))
    check(ImapProtocol.flags("* 7 FETCH (UID 8 FLAGS ())").isEmpty())
    check(ImapProtocol.uidSet(listOf(9L, 10L, 10L, 15L)) == "9,10,15")

    check(runCatching { ImapProtocol.saslPlain("", "secret") }.isFailure)
    check(runCatching { ImapProtocol.saslPlain(username, "") }.isFailure)
    check(runCatching { ImapProtocol.saslPlain(username, "bad\u0000secret") }.isFailure)
    check(runCatching { ImapProtocol.uidSet(emptyList()) }.isFailure)

    println("IMAP protocol tests passed")
}
