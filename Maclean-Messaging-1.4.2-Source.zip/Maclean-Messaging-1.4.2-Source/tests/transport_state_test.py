#!/usr/bin/env python3
"""Host regressions for callback aggregation and durable Outbox terminal states."""

from pathlib import Path
import re
import sqlite3
import unittest

ROOT = Path(__file__).resolve().parents[1]
LOCAL = (ROOT / "app/src/main/java/com/macleanofduartenterprises/macleanmessaging/data/LocalDatabase.kt").read_text()
COMPOSE = (ROOT / "app/src/main/java/com/macleanofduartenterprises/macleanmessaging/workflow/ComposeStore.kt").read_text()

PART_SCHEMA = re.search(
    r'db\.execSQL\("(CREATE TABLE IF NOT EXISTS sms_part_results [^"]+)"\)', LOCAL
).group(1)
COMPOSE_SCHEMA = re.search(
    r'db\.execSQL\("(CREATE TABLE compose_items [^"]+)"\)', COMPOSE
).group(1)


class TransportStateTest(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(":memory:")
        self.db.execute(PART_SCHEMA)
        self.db.execute(COMPOSE_SCHEMA)

    def callback(self, token, phase, part, total, ok, code=0):
        self.db.execute(
            "INSERT OR REPLACE INTO sms_part_results(token,phase,part,ok,resultCode) VALUES(?,?,?,?,?)",
            (token, phase, part, int(ok), code),
        )
        rows = self.db.execute(
            "SELECT ok,resultCode FROM sms_part_results WHERE token=? AND phase=?",
            (token, phase),
        ).fetchall()
        if any(not row[0] for row in rows):
            return "FAILED"
        return "COMPLETE" if len(rows) >= total else "PENDING"

    def add_compose(self, state="SENDING", token=None):
        self.db.execute(
            "INSERT INTO compose_items(id,payload,state,runAt,updatedAt,resultToken) VALUES('one','{}',?,?,?,?)",
            (state, 0, 1, token),
        )

    def test_multipart_success_waits_for_every_unique_part(self):
        self.assertEqual(self.callback("t", "SENT", 0, 3, True), "PENDING")
        self.assertEqual(self.callback("t", "SENT", 0, 3, True), "PENDING")
        self.assertEqual(self.callback("t", "SENT", 2, 3, True), "PENDING")
        self.assertEqual(self.callback("t", "SENT", 1, 3, True), "COMPLETE")

    def test_any_sms_part_failure_is_terminal(self):
        self.assertEqual(self.callback("t", "SENT", 0, 2, True), "PENDING")
        self.assertEqual(self.callback("t", "SENT", 1, 2, False, 4), "FAILED")

    def test_successful_callback_removes_outbox_item(self):
        self.add_compose("SUBMITTED", "token")
        removed = self.db.execute(
            "DELETE FROM compose_items WHERE resultToken=? AND state IN ('SENT','SUBMITTED','SENDING')",
            ("token",),
        ).rowcount
        self.assertEqual(removed, 1)
        self.assertEqual(self.db.execute("SELECT count(*) FROM compose_items").fetchone()[0], 0)

    def test_failed_callback_stays_reviewable(self):
        self.add_compose("SUBMITTED", "token")
        changed = self.db.execute(
            "UPDATE compose_items SET state='FAILED',error='No service' "
            "WHERE resultToken=? AND state IN ('SENDING','SUBMITTED','UNKNOWN')",
            ("token",),
        ).rowcount
        self.assertEqual(changed, 1)
        self.assertEqual(
            self.db.execute("SELECT state,error FROM compose_items").fetchone(),
            ("FAILED", "No service"),
        )

    def test_callback_before_dispatcher_commit_is_reconciled(self):
        self.add_compose("SENDING", None)
        # Carrier metadata becomes SENT before perform() commits the token.
        self.db.execute(
            "UPDATE compose_items SET state='SUBMITTED',resultToken='token' "
            "WHERE id='one' AND state IN ('SENDING','UNKNOWN','SCHEDULED')"
        )
        self.db.execute(
            "DELETE FROM compose_items WHERE resultToken='token' "
            "AND state IN ('SENT','SUBMITTED','SENDING')"
        )
        self.assertEqual(self.db.execute("SELECT count(*) FROM compose_items").fetchone()[0], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
