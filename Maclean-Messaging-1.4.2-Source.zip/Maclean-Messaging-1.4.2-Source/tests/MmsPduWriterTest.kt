/* Maclean Messaging — SPDX-License-Identifier: AGPL-3.0-only */
import com.macleanofduartenterprises.macleanmessaging.telephony.MmsPduWriter

private class Cursor(private val bytes: ByteArray, var position: Int = 0) {
    fun uintvar(): Int {
        var value = 0
        do {
            check(position < bytes.size) { "Truncated uintvar" }
            val octet = bytes[position++].toInt() and 0xff
            value = (value shl 7) or (octet and 0x7f)
        } while (octet and 0x80 != 0)
        return value
    }

    fun slice(length: Int): ByteArray {
        check(length >= 0 && position + length <= bytes.size) { "Truncated PDU part" }
        return bytes.copyOfRange(position, position + length).also { position += length }
    }
}

private fun ByteArray.indexOfSequence(sequence: ByteArray, start: Int = 0): Int {
    if (sequence.isEmpty()) return start.coerceAtMost(size)
    for (index in start..size - sequence.size) {
        if (sequence.indices.all { this[index + it] == sequence[it] }) return index
    }
    return -1
}

private fun bytes(vararg values: Int) = ByteArray(values.size) { values[it].toByte() }

fun main() {
    val image = bytes(0xff, 0xd8, 0xff, 0xe0, 0x11, 0x22, 0xff, 0xd9)
    val encoded = MmsPduWriter.encodeSendRequest(
        recipients = listOf("+17175550123"),
        body = "Photo attached ✓",
        media = listOf(
            MmsPduWriter.Part(
                mimeType = "image/jpeg",
                name = "camera photo.jpg",
                data = image,
                contentId = "media-1"
            )
        ),
        requestDeliveryReport = true,
        transactionId = "test-transaction"
    )

    // X-Mms-Content-Type: multipart/related; start="<smil>"; type="application/smil"
    val rootMarker = bytes(0x84)
    val rootPosition = encoded.indexOfSequence(rootMarker)
    check(rootPosition >= 0) { "Missing top-level MMS Content-Type" }
    val root = Cursor(encoded, rootPosition + 1)
    val rootLengthFirst = encoded[root.position++].toInt() and 0xff
    val rootLength = if (rootLengthFirst < 31) rootLengthFirst else root.uintvar()
    val rootBytes = root.slice(rootLength)
    check(rootBytes.first() == 0xb3.toByte()) { "Root must be multipart/related" }
    check(rootBytes.indexOfSequence(bytes(0x8a)) >= 0) { "Missing multipart start parameter" }
    check(rootBytes.indexOfSequence(bytes(0x89)) >= 0) { "Missing multipart related-type parameter" }
    check(rootBytes.indexOfSequence("<smil>\u0000".toByteArray()) >= 0)
    check(rootBytes.indexOfSequence("application/smil\u0000".toByteArray()) >= 0)

    val parts = Cursor(encoded, root.position)
    check(parts.uintvar() == 3) { "Expected SMIL, text, and image parts" }
    val decodedParts = buildList {
        repeat(3) {
            val headerLength = parts.uintvar()
            val dataLength = parts.uintvar()
            add(parts.slice(headerLength) to parts.slice(dataLength))
        }
    }
    check(parts.position == encoded.size) { "Unexpected trailing PDU data" }

    decodedParts.forEachIndexed { index, (headers, data) ->
        check(headers.indexOfSequence(bytes(0xc0, 0x22)) >= 0) {
            "Part $index Content-ID must use quoted-string encoding"
        }
        check(headers.indexOfSequence(bytes(0x8e)) >= 0) {
            "Part $index must have Content-Location"
        }
        check(data.isNotEmpty()) { "Part $index must contain data" }
    }
    check(decodedParts[0].second.toString(Charsets.UTF_8).contains("<smil>"))
    check(decodedParts[1].second.toString(Charsets.UTF_8) == "Photo attached ✓")
    check(decodedParts[2].second.contentEquals(image)) { "Image bytes were omitted or changed" }
    check(decodedParts[2].first.indexOfSequence(bytes(0x9e)) >= 0) {
        "Image part must be encoded as image/jpeg"
    }
    println("MMS PDU writer tests passed")
}
