#!/usr/bin/env python3
"""Host regressions for the actual queue SQL. No carrier or mail account is contacted.

Extracts schema and guarded predicates from ComposeStore.kt, executes them on real
SQLite connections, and checks race/restart outcomes. Android UI, alarms and
ContentResolver still require the device checks in docs/COMPOSE-WORKFLOWS.md.
"""
import concurrent.futures
import json
from pathlib import Path
import re
import sqlite3
import tempfile
import threading
import unittest

SOURCE = Path(__file__).resolve().parents[1] / "app/src/main/java/com/macleanofduartenterprises/macleanmessaging/workflow/ComposeStore.kt"
CODE = SOURCE.read_text(encoding="utf-8")
SCHEMA = re.findall(r'db.execSQL\("(CREATE [^"]+)"\)', CODE)


def predicate(method, next_method):
    section = CODE.split(f"fun {method}(", 1)[1].split(f"fun {next_method}(", 1)[0]
    return re.findall(r'"(id=\? AND [^"]+)"', section)[0]


CLAIM = predicate("claim", "finish")
FINISH = predicate("finish", "recoverInterrupted")
EDIT = predicate("pauseForEdit", "reschedule")
DELETE = predicate("delete", "flags")
RECOVER = re.search(r'execSQL\("(UPDATE compose_items SET state=\'UNKNOWN\'[^"]+)"', CODE).group(1)


class WorkflowSqlTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / "queue.db"
        self.db = self.connection()
        self.assertEqual(len(SCHEMA), 3, "Test must use all production schema statements")
        for sql in SCHEMA:
            self.db.execute(sql)

    def tearDown(self):
        self.db.close()
        self.temp.cleanup()

    def connection(self):
        return sqlite3.connect(self.path, timeout=10, isolation_level=None)

    def add(self, id="one", state="SCHEDULED", run_at=100, owner=None, payload="{}"):
        self.db.execute("INSERT INTO compose_items(id,payload,state,runAt,updatedAt,owner) VALUES(?,?,?,?,?,?)",
                        (id, payload, state, run_at, 10, owner))

    def claim(self, db, id="one", now=100, owner="current-process"):
        return db.execute("UPDATE compose_items SET state='SENDING',owner=? WHERE " + CLAIM,
                          (owner, id, str(now))).rowcount

    def test_due_only_and_exactly_one_claim(self):
        self.add(run_at=200)
        self.assertEqual(self.claim(self.db, now=199), 0)
        self.assertEqual(self.claim(self.db, now=200), 1)
        self.assertEqual(self.claim(self.db, now=201), 0)

    def test_alarm_and_job_race_dispatches_once(self):
        self.add()
        barrier = threading.Barrier(8)

        def competitor(_):
            db = self.connection()
            try:
                barrier.wait()
                return self.claim(db)
            finally:
                db.close()

        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            self.assertEqual(sum(pool.map(competitor, range(8))), 1)

    def test_cancel_before_dispatch_blocks_old_worker(self):
        self.add()
        self.assertEqual(self.db.execute("UPDATE compose_items SET state='DRAFT',runAt=0 WHERE " + EDIT, ("one",)).rowcount, 1)
        self.assertEqual(self.claim(self.db), 0)

    def test_dispatch_before_edit_cannot_be_requeued(self):
        self.add()
        self.assertEqual(self.claim(self.db), 1)
        self.assertEqual(self.db.execute("UPDATE compose_items SET state='DRAFT' WHERE " + EDIT, ("one",)).rowcount, 0)
        self.assertEqual(self.db.execute("DELETE FROM compose_items WHERE " + DELETE, ("one",)).rowcount, 0)

    def test_stale_outbox_edit_does_not_resend_terminal_items(self):
        for state in ("SENT", "SUBMITTED", "FAILED", "UNKNOWN"):
            self.add(state, state)
            self.assertEqual(self.db.execute("UPDATE compose_items SET state='DRAFT' WHERE " + EDIT, (state,)).rowcount, 0)
            self.assertEqual(self.claim(self.db, state), 0)

    def test_restart_marks_only_interrupted_sends_unknown(self):
        self.add("old", "SENDING", owner="old-process")
        self.add("live", "SENDING", owner="current-process")
        self.add("pending", "SCHEDULED")
        self.db.execute(RECOVER, ("current-process",))
        states = dict(self.db.execute("SELECT id,state FROM compose_items"))
        self.assertEqual(states, {"old": "UNKNOWN", "live": "SENDING", "pending": "SCHEDULED"})
        self.assertEqual(self.claim(self.db, "old"), 0)

    def test_late_callback_does_not_overwrite_cancelled_draft(self):
        self.add(state="DRAFT")
        self.assertEqual(self.db.execute("UPDATE compose_items SET state='FAILED' WHERE " + FINISH, ("one",)).rowcount, 0)

    def test_payload_survives_process_reopen_with_separate_bcc(self):
        payload = {"kind": "EMAIL", "to": ["to@example.test"], "cc": ["cc@example.test"],
                   "bcc": ["private@example.test"], "body": "Привет 👋\n1 + 1 = 2 & <test>",
                   "attachments": ["content://app.files/voice.ogg"], "accountId": "account-2", "subscriptionId": 7}
        self.add(payload=json.dumps(payload, ensure_ascii=False))
        self.db.close(); self.db = self.connection()
        self.assertEqual(json.loads(self.db.execute("SELECT payload FROM compose_items").fetchone()[0]), payload)

    def test_rescheduling_retains_android_job_identity(self):
        self.add()
        first = self.db.execute("SELECT jobId FROM compose_items WHERE id='one'").fetchone()[0]
        self.db.execute("UPDATE compose_items SET state='DRAFT' WHERE " + EDIT, ("one",))
        self.db.execute("UPDATE compose_items SET state='SCHEDULED',runAt=400 WHERE id='one'")
        self.assertEqual(self.db.execute("SELECT jobId FROM compose_items WHERE id='one'").fetchone()[0], first)
        self.assertEqual(self.claim(self.db, now=399), 0)
        self.assertEqual(self.claim(self.db, now=400), 1)

    def test_removed_item_cannot_be_claimed(self):
        self.add()
        self.assertEqual(self.db.execute("DELETE FROM compose_items WHERE " + DELETE, ("one",)).rowcount, 1)
        self.assertEqual(self.claim(self.db), 0)

    def test_job_ids_are_not_reused_after_deletion(self):
        self.add()
        first = self.db.execute("SELECT jobId FROM compose_items").fetchone()[0]
        self.db.execute("DELETE FROM compose_items WHERE " + DELETE, ("one",))
        self.add("two")
        self.assertGreater(self.db.execute("SELECT jobId FROM compose_items").fetchone()[0], first)

    def test_archive_and_pin_persist_independently_per_transport(self):
        self.db.execute("INSERT INTO conversation_flags(id,archived,pinned) VALUES('sms:42',1,1)")
        self.db.execute("INSERT INTO conversation_flags(id,archived,pinned) VALUES('email:42',0,0)")
        self.db.execute("UPDATE conversation_flags SET archived=0 WHERE id='sms:42'")
        self.db.close(); self.db = self.connection()
        self.assertEqual(self.db.execute("SELECT archived,pinned FROM conversation_flags WHERE id='sms:42'").fetchone(), (0, 1))
        self.assertEqual(self.db.execute("SELECT archived,pinned FROM conversation_flags WHERE id='email:42'").fetchone(), (0, 0))


if __name__ == "__main__":
    unittest.main(verbosity=2)
