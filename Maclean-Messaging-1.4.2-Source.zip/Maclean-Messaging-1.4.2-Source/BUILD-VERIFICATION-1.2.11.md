# Maclean Messaging 1.2.11 — verification

Built on 2026-09-12. This is a signed corrective release for default-SMS role handling and real carrier MMS send/receive processing.

## Release identity

- Package/application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name/code: `1.2.11` / `10211`
- Minimum Android API: 29; target/compile API: 35
- APK: `Maclean-Messaging-1.2.11-Signed.apk`
- APK size: 1,053,330 bytes
- APK SHA-256: `4f6d7a95fa5ce8046e3fb091cad60eab4f2bb2077c20fd74cd34658b596fe86c`
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`
- Signature: APK Signature Scheme v3; one 4096-bit RSA signer, matching the documented 1.2.10 certificate.
- License: GNU AGPLv3 / `AGPL-3.0-only`; the readable offline license remains included.

The increasing version code and unchanged package/certificate support an in-place update over 1.2.10. An actual install was not performed because no Android device or emulator was attached.

## Corrective changes

- Replaced the legacy-only default-app test with Android `RoleManager.ROLE_SMS` state.
- Fixed the role callback being discarded whenever Android returned `data == null`.
- Saves the exact pending Send now or Schedule send action before the role prompt, resumes it after approval, survives Activity recreation, and consumes it once to avoid duplicate dispatch.
- Requests the default role before SMS-group permissions on clean install, and adds `RECEIVE_WAP_PUSH` to the full-role permission set.
- Rechecks default role, send permission, selected SIM, and provider insertion at actual scheduled-send time.
- Stops swallowing SMS/MMS provider insertion failures.
- Implements incoming MMS Notification.ind parsing, subscription-specific carrier download, Retrieve.conf decoding, provider Inbox/address/part insertion, notification, deterministic deduplication, and five bounded persisted network retries.
- Replaces the minimal outgoing multipart body with `multipart/related`, a SMIL root, unique content IDs/locations, sanitized names, UTF-8 text, carrier-size validation, and cache cleanup.
- Reports successful MMS callbacks as `CARRIER_ACCEPTED`, which accurately describes carrier handoff rather than claiming recipient delivery.

## Completed checks

- All 62 Kotlin production files compiled with Kotlin 1.9.24, Java 17, and Android API 35.
- AAPT2 resource/manifest linking and D8 release bytecode conversion succeeded with Build Tools 35.0.1.
- APK badging confirms package `com.macleanofduartenterprises.macleanmessaging`, version `1.2.11`/`10211`, min API 29, target API 35, launcher activity, and the required SMS/MMS/WAP permissions.
- Standalone Android lint on compiled shipping sources completed with **0 errors and 73 warnings**. Warnings are non-blocking localization, conservative Kotlin resource-close analysis, deprecated-but-API-compatible calls, backup metadata, a retained XML resource, and supplied icon shape. No release error was suppressed.
- **12 workflow SQLite regression tests passed** for due-time gating, atomic claims, schedule/edit/cancel races, restart recovery, terminal-state protection, Unicode persistence, stable job IDs, deletion, and archive/pin flags.
- **5 release contract tests passed** for modern role detection, null-data callback ordering, saved continuation, dispatch-time role verification, and MMS download/provider-import wiring.
- The synthetic MM1 parser test passed for Notification.ind sender/content-location extraction and Retrieve.conf UTF-8 text/part decoding.
- APK ZIP integrity, four-byte ZIP alignment, embedded corrected transport classes, and the v3 release signature were verified.
- Source audit found no APK, keystore, private signing password, or generated class/dex files in the source package.

## Device-only validation remaining

ADB reported no attached device or emulator. Live installation/update, default-role/permission dialogs, real SMS transmission, carrier/APN MMS upload/download, Android-to-iPhone media interoperability, mobile-data retry, dual-SIM routing, OEM background restrictions, and carrier size policies cannot be executed in this host environment.

The code now contains the missing transport and role flows and passes host verification; it must still be tested on the affected phone and carrier before broad distribution. Android/carrier acceptance is not proof of delivery to a recipient handset.
