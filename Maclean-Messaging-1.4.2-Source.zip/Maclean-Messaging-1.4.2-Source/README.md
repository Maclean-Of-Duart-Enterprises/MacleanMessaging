# Maclean Messaging 1.4.2 — Release Source

Maclean Messaging is a SIM-first SMS/MMS client with optional multi-account email. Email remains invisible and dormant until at least one account is enabled.

This package is the in-place-compatible 1.4.2 continuation of the completed 1.4.1 source, with version code 10402. It retains the same application ID, data model, and production signing lineage.

## 1.4.2 immediate outgoing conversation updates

- Shows an outgoing **Sending…** bubble in the open SMS/MMS conversation as soon as Send is tapped, including for the first reply in the thread session.
- Updates the visible message count and scroll position immediately; no second message, manual refresh, conversation close, or reopen is required.
- Keeps the temporary row protected from provider-only message actions until Android creates its real SMS/MMS provider row.
- Performs an automatic authoritative thread refresh after dispatch so the temporary bubble is replaced by the normal sent row and overflow controls.
- Avoids the previous zero-delay worker race for inline replies while retaining a durable Outbox record and reviewable failure state.
- Keeps every 1.4.1 standalone SMS/MMS, performance, email, sharing, read/unread, display, font, contour-text, and keyboard-safe reply feature.

## 1.4.1 standalone operation and smooth background loading

- Operates as the complete carrier SMS/MMS client after Android assigns Maclean Messaging the default SMS role; Google Messages or another messaging application is not required.
- Verifies the role, SMS/MMS permissions, protected provider-write app-op, and all required Android messaging components, then offers a direct recovery action when the operating system state is incomplete.
- Uses a bounded background pool for general I/O and an independent ordered lane for carrier/provider commits, preventing mailbox, attachment, and media work from delaying incoming SMS/MMS persistence.
- Opens the unified inbox from an atomic last-known snapshot, refreshes it in the background, and renders conversations with recycled rows rather than eagerly creating the whole screen.
- Loads every SMS/MMS in a conversation without paging: lightweight SMS/MMS headers paint first, then MMS bodies, addresses, voice notes, and attachments hydrate in a second background pass.
- Adds short-lived inbox caching, a bounded full-thread cache, and an email-thread cache so reopening screens avoids repeat provider/database work while authoritative refreshes continue.
- Moves document metadata, link detection, MMS preview decoding, voice duration probing, voice finalization, recorder cleanup, and background-photo work away from the UI thread; media caches and in-flight guards prevent duplicate work and visible row churn.
- Suppresses the app's own provider-observer echo while a conversation is being marked read, keeping the active reply, attachment, and voice controls stable.
- Retains the complete email implementation, full mailbox synchronization, sharing, read/unread controls, display/font profiles, keyboard-safe replies, scheduling, notifications, and carrier-aware MMS behavior.

## 1.4.0 standalone SMS/MMS role recovery

- Made Android default-SMS ownership and messaging-permission recovery explicit in the inbox.
- Kept email available independently when SMS/MMS role access is not active.
- Retained the app's native `SmsManager` SMS/MMS transport and Android provider storage without adding any Google Messages dependency.

## 1.3.9 expanded system text styles

- Expands each Sleek/Utility profile from four standard typefaces to twelve choices: System sans, Serif, Monospace, Condensed, two Cursive choices, two Calligraphy choices, and four Special choices.
- Adds an independently persisted Text format choice with Regular, Bold, Italic, and Bold italic options.
- Combines the chosen format with semantic heading emphasis so headings remain distinguishable while the global style reaches messages, email, editors, controls, recipient suggestions, and screen headings.
- Adds an immediate live preview in Settings → Display & appearance and keeps pre-1.3.9 profiles compatible by defaulting their new format value to Regular.
- Uses Android-provided offline font families, preserving the small app footprint and avoiding any network font dependency.
- Preserves every 1.3.8 email, contour text, read/unread, sharing, complete-history, and keyboard-safe reply improvement.

## 1.3.8 email, contour text, fonts, unread, and Android sharing

- Repairs direct TLS email connections with SNI and verified hostnames, exposes the exact credential-safe IMAP failure stage, records last success/error on each account card, and implements Android 15 network-change job handling.
- Makes manual Sync all now run immediately and refresh the visible result; non-recoverable authentication/configuration errors no longer cause rapid JobScheduler retry loops.
- Replaces one flat text margin with calculated child and per-line contour insets, so headings, wrapped bodies, dates, and controls follow Square, Soft corners, Rounded, and Oval card/message boundaries while links remain tappable.
- Adds System sans, Serif, Monospace, and Condensed Text font choices to each independently saved Sleek/Utility profile and applies the selected typeface across app-rendered text, inputs, and controls.
- Adds individual, bulk/selected, and conversation-level Mark as unread directly below matching Mark as read controls for unified inbox, SMS, MMS, voice messages, and email.
- Registers as an Android share target for text and single/multiple attachments, imports temporary grants safely, and offers SMS/MMS or email composition when an email account is enabled.
- Retains complete mailbox and conversation loading, recycled rows, incremental email refreshes, and keyboard-safe top/bottom replies.

## 1.3.7 individual and bulk Mark as read

- Adds a visible **Mark as read** action to each SMS, MMS, voice-message, email, and unified-inbox conversation overflow menu.
- Adds **Mark selected as read** to the bulk management menus for selected conversations, selected SMS/MMS messages, and selected emails.
- Adds explicit conversation-level Mark as read actions inside SMS/MMS and email threads while retaining email Mark as unread.
- Batches SMS and MMS provider updates in bounded ID groups and sets both Android `read` and `seen` state.
- Batches selected email changes by account so each account uses one IMAP Seen operation, then updates local rows, thread badges, and notifications together.
- Clears completed selections and refreshes the active recycled row model without reloading entire message bodies or attachments.
- Preserves the 1.3.6 complete-history, incremental email-sync, shape-aware text, keyboard-safe reply placement, and app/signing identity behavior.

## 1.3.6 complete, faster conversations and repaired email

- Replaces the malformed IMAP quoted `LOGIN` path reported by the supplied shared diagnostic with capability-aware SASL PLAIN or SASL LOGIN authentication, using server continuations so credentials containing spaces, quotes, backslashes, or Unicode cannot break command parsing.
- Removes the newest-250 email ceiling. The first sync imports every INBOX UID in bounded multi-message batches, persists each batch, and resumes safely; later syncs fetch only missing messages plus lightweight Seen metadata.
- Removes the 50-message SMS/MMS conversation ceiling and Load older step. Complete mixed SMS/MMS histories load off the UI thread into the existing recycled list, cached rows remain visible during provider refreshes, and only visible rows become Android views.
- Applies shape-aware content insets to Square, Soft corners, Rounded, and Oval message bubbles, cards, and email/message text boxes.
- Enables high-quality wrapping and hyphenation for SMS/MMS and email bodies, including long links and unbroken text, without clipping against curved corners.
- Retains the 1.3.5 keyboard-safe top/bottom reply setting, package identity, database, accounts, messages, drafts, and signing lineage.

## 1.3.5 keyboard-safe and configurable replies

- Keeps the complete inline SMS/MMS reply panel above a docked on-screen keyboard on Android 15+ by applying IME/navigation insets to the conversation layout.
- Declares resize behavior for the software keyboard on supported Android releases.
- Adds Settings → Display & appearance → Message reply location with Bottom of conversation and Top of conversation choices.
- Stores a separate reply location in each Sleek and Utility display profile and defaults existing/fresh profiles to Bottom of conversation.
- Moves the same reply field, Send, attachment, voice, SIM, scheduling, and draft controls without changing transport behavior.
- Preserves every 1.3.4 streamlined-thread feature and all SMS/MMS, email, provider, scheduling, notification, appearance, and upgrade data.

## 1.3.4 streamlined conversations and inline replies

- Places the SMS/MMS reply field, Send button, attachment menu, voice recorder, SIM choice, and scheduling access directly below the open conversation.
- Keeps immediate and scheduled replies in the conversation instead of navigating to the separate new-message screen or Drafts & Outbox.
- Routes quoted replies and compatible text reactions into the same inline reply field.
- Removes permanent conversation and message selection boxes. Long press or each item’s overflow menu still selects it, and bulk controls appear only while something is selected.
- Removes the redundant Open button from conversation cards; the complete card remains the open target.
- Reduces persistent thread controls to status and sorting while preserving management through the existing toolbar menu.
- Retains SMS/MMS transport, carrier-aware image preparation, attachments, voice messages, drafts, scheduling, bulk management, email, notifications, settings, and upgrade data.

See `BUILD-VERIFICATION-1.4.2.md` for the completed host/build checks and the remaining device-specific validation boundary.

## 1.3.3 intelligent carrier-aware image preparation

This release reads the selected SIM's actual MMS byte limit and image dimensions, reserves 18% (bounded to 30–60 KiB) for text, recipients, SMIL, WSP/MM1 headers, and multipart overhead, and measures the exact fixed PDU footprint before assigning image budgets. It decodes large photos using sampled bounds, preserves small compatible originals, handles portrait and landscape limits correctly, and progressively reduces dimensions and JPEG quality together. The complete serialized MMS must fit the carrier envelope before Android receives it; otherwise the app reports an actionable error instead of submitting an oversized message.

## 1.3.2 outgoing MMS media repair

This corrective release replaces the remaining hand-written multipart boundary details with a deterministic MM1 Send.req writer aligned to Android's PDU composer. It uses the required multipart/related `start` and `type` parameter tokens, quoted Content-ID values, Content-Location names, SMIL presentation metadata, UTF-8 text, and exact header/data lengths. A host regression test independently decodes the generated part table and verifies that the original image bytes are present as a real image part. See `CHANGELOG.md`, `docs/BUGREPORT-FINDINGS-1.3.2.md`, and `BUILD-VERIFICATION-1.3.2.md`.

## 1.3.1 incoming SMS/MMS delivery repair

This corrective release fixes the broadcast-result ordering crash affecting both SMS and MMS delivery, stores SMIL/HTML parts using Android's inline MMS representation, and adds a durable attachment fallback for vendor MMS providers that refuse binary part streams. See `CHANGELOG.md`, `docs/BUGREPORT-FINDINGS-1.3.1.md`, and `BUILD-VERIFICATION-1.3.1.md` for the exact evidence and validation boundary.

## 1.3.0 Android SMS/MMS provider and carrier repair

- Implements Android's complete default-SMS role surface: SMS deliver, MMS WAP-push deliver, SENDTO composition, respond-via-message, required permissions, canonical system-provider storage, and SIM-specific `SmsManager` transport.
- Repairs downloaded MMS attachment import on vendor providers by opening canonical `content://mms/part/{id}` file descriptors and using an explicit-message-id fallback.
- Requires the outgoing Android provider row before carrier submission, preventing an SMS/MMS from being transmitted while remaining invisible in its conversation.
- Retains a 2 MiB app selection limit while obeying the SIM's real encoded-PDU limit; large photos are resized and recompressed to the carrier envelope before sending.
- Uses carrier APN/mobile-data handling for MMS and the selected SIM radio path for SMS; it no longer overrides the carrier's advertised maximum.
- Serializes MMS provider imports, contains carrier-callback failures, bounds provider refresh work to the visible activity, and recovers retained 1.2.14 MMS downloads after upgrade.

## 1.2.13 Incoming SMS/MMS reliability repair

- Corrects the carrier-download content URI so incoming MMS attachment bytes are written to the authorized durable destination.
- Moves incoming SMS database, provider, contact, and notification work off Android's broadcast main thread.
- Atomically stages incoming SMS and MMS notifications before provider work and retries recoverable failures after process death or app update.
- Prevents notification, provider, receiver-finalization, and stopped-job lifecycle failures from crashing incoming delivery.
- Keeps received SMS and complete MMS text/attachment parts in Android's canonical provider so existing open, preview, save, share, forward, copy, delete, read/unread, pin, and archive workflows can manage them.

## 1.2.12 Outbox and end-to-end state repair

- Keeps SMS/MMS carrier callback receivers alive until metadata, Android provider rows, and the durable Outbox have all been committed.
- Removes successful SMS, MMS, voice/file attachment, and email sends from Drafts & Outbox automatically; failed sends remain reviewable with a carrier/network explanation.
- Aggregates every multipart SMS segment idempotently, preventing the first part from prematurely marking the whole message sent or delivered.
- Preserves delivered state if Android reports callbacks out of order and records delivery failure separately from carrier-send failure.
- Uses canonical SMS/MMS provider URIs and repairs terminal provider rows left in Outbox by older builds during startup reconciliation.
- Requires cellular connectivity before scheduled MMS/voice/file dispatch and before incoming-MMS retry, while ordinary SMS continues to work without IP data.
- Retains atomic schedule claims, autosaved drafts, local archive/pin flags, remote IMAP read/delete operations, SMTP reply/forward, and Ogg/Opus voice recording with M4A fallback.

## 1.2.11 default-role and carrier MMS repairs

- Uses Android `RoleManager` as the authoritative default-SMS check.
- Saves and resumes the exact Send now or Schedule send action after role approval; a null role-result Intent no longer cancels the operation.
- Keeps the continuation stable through Activity recreation and prevents double dispatch between `onResume` and the role callback.
- Verifies the role, SMS permissions, selected SIM, and provider row at actual dispatch time.
- Downloads incoming MMS Notification.ind payloads, decodes Retrieve.conf parts, inserts messages and attachments into Android's MMS provider, notifies the user, deduplicates messages, and retries transient network failures.
- Encodes outgoing MMS as carrier-compatible multipart/related with a SMIL root, unique content IDs, UTF-8 text, named attachments, carrier size validation, and accurate carrier-handoff status.
- Provider insertion failures are now visible failures instead of being swallowed while the app reports success.

## 1.2.10 compose, schedule, and organization repairs
- Both SMS/MMS and email composers have a Schedule send choice with separate Date and Time drop-down buttons opening native pickers.
- The top-right compose menu now contains Send now, Schedule send, Save draft, Attach file, Manage attachments, Copy, Paste, Select all text, and Discard draft.
- Drafts auto-save text, recipient fields, sending account/SIM, reply/forward context, and attached files; open them from Drafts & Outbox on the inbox or in Settings.
- Scheduled sends persist across process restarts and device reboot, with a pending Outbox, editable schedules, cancellation, send results, and explicit review/resend after failure.
- Archive/unarchive and pin/unpin work for individual and selected conversations. Archive is local organization in this app, including for email; it does not move mail into a server Archive folder. Pinned conversations sort first within the active filters.
- Resend opens an editable copy of a sent SMS/MMS or email, including available attachments. Sending remains an explicit action and retains the original message.
- Recorded voice previews can be attached to a draft or schedule, retaining their audio bytes and voice-message filename. Normal audio/file attachments are not transcoded.
- Outgoing email attachments are retained separately from Outbox copies, so deleting a draft/history item does not break a sent email's attachments.
- Sleek/Utility display profiles, photo backgrounds, notification settings, email account credentials, and existing conversation data are retained.

Read [the workflow guide](docs/COMPOSE-WORKFLOWS.md) for usage, scheduling timing limits, and device checks. Drafts and schedules are device-local, not synchronized with a server Drafts/Outbox folder. Android, network, and SIM restrictions can delay or prevent a scheduled send; inspect the Outbox result.

### Rebuild and verify
The existing Gradle project remains available. For a dependency-complete Android SDK build, run `bash tools/build-release.sh` with Java 17, Android SDK platform 35/Build Tools 35.0.1, Kotlin compiler dependencies 1.9.24, `rg`, `zip`, and `unzip` installed. Set `ANDROID_SDK_ROOT`, `KOTLIN_LIB`, `KEYSTORE_PATH`, `MACLEAN_STORE_PASSWORD`, and `MACLEAN_KEY_PASSWORD` in your environment. `KEY_ALIAS` defaults to `macleanphonerelease`; optional `APP_BUILD_DIR` and `APP_OUTPUT` must be absolute paths. No keystore or signing password is included.

Run `python3 tests/workflow_sql_test.py`, `python3 tests/transport_state_test.py`, and `python3 tests/release_contract_test.py` for host regressions. Compile and run `tests/ImapProtocolTest.kt` with `ImapProtocol.kt` for credential encoding and FETCH metadata coverage, `tests/MmsPduParserTest.kt` with `MmsPduParser.kt` for synthetic Notification.ind/Retrieve.conf coverage, `tests/MmsPduWriterTest.kt` with `MmsPduWriter.kt` for outgoing multipart media coverage, and `tests/MmsImageFitPolicyTest.kt` with `MmsImageFitPolicy.kt` for adaptive carrier-budget coverage. These do not replace Android, live-provider, or live-carrier tests.

## 1.2.9 selectable display styles
- adds two manually selectable rendering profiles under Settings → Display style and appearance;
- makes **Sleek** the default, with softer spacing, rounded cards and bubbles, pill controls, gentle elevation, narrower aligned messages, and a subtle sent-message tint;
- preserves the current compact, outlined, block-forward presentation as **Utility**, including near-full-width messages and square controls;
- stores Sleek and Utility preferences independently so each profile can be changed or reset without erasing the other;
- lets either profile independently control message-bubble, card/panel, and button/control shapes using Square, Soft corners, Rounded, or Oval choices;
- adds Compact, Comfortable, and Spacious density, 70–100% message width, 1–4 inbox preview lines, outlines, elevation, and 0–35% sent-message tint controls;
- expands Custom palette editing to background, surface, accent/toolbar, and text colors while retaining photo backgrounds, opacity, text sizing, and high contrast;
- applies the selected profile through the shared rendering layer across the inbox, SMS/MMS and email threads, settings, contacts, account screens, composers, inputs, cards, and action controls;
- preserves package identity, signing lineage, database schema, messages, accounts, backgrounds, notifications, contacts, voice messages, and all earlier behavior.

## 1.2.8 long-conversation performance repair
- replaces eager SMS/MMS and email thread layouts with native recycled lists so only visible message rows exist as Android views;
- initially reads the 50 newest SMS/MMS items and exposes an explicit Load older messages control while preserving full-thread export;
- merges SMS and MMS headers by date before hydrating only the MMS items in the requested page;
- keeps selection and sorting incremental instead of destroying and recreating every row after each checkbox or menu action;
- loads email attachments only when their email row becomes visible instead of issuing a database query for every message at thread startup;
- decodes MMS image previews only for visible rows and retains a bounded 24 MiB preview cache;
- reuses per-thread date formatters instead of allocating a formatter for every displayed message;
- rejects stale asynchronous thread results after navigation and preserves the visible scroll anchor while older messages are added;
- preserves the compact interface, photo/palette backgrounds, safe status area, voice messages, email/server actions, notification settings, package identity, signing lineage, and database compatibility.

## 1.2.7 links, replies, reactions, and voice messages
- makes every web link, email address, and phone number in an SMS/MMS body independently clickable;
- adds quoted per-message replies and carrier-compatible text reactions from message management menus;
- adds a distinct hold-to-record voice-message flow with slide-left cancel, slide-up lock, pause/resume, and preview before sending;
- records Ogg + Opus, mono, 48 kHz, approximately 32 kbps by default, with an automatic M4A/AAC fallback only when a device rejects Android's public Opus recorder configuration;
- adds compact waveforms, elapsed time, seek, 1×/1.5×/2× playback, and one in-app player that survives conversation view navigation;
- adds long-press and overflow actions for Save to device, Share, Forward, Reply, compatible reaction, Delete, and View details;
- keeps normal audio attachment as a separate, no-conversion path for M4A, MP3, WAV, FLAC, OGG, and other files;
- replaces URI placeholders in outgoing carrier PDUs with the actual attachment bytes in a WSP multipart/mixed MMS body;
- preserves package ID, signing lineage, database version, accounts, settings, backgrounds, notifications, contacts, and all earlier message-management behavior.

## 1.2.6 notification controls
- adds one Settings page for master notifications, SMS/MMS alerts, email alerts, persistent unread alerts, content previews, and SMS/MMS Quick reply;
- makes persistent SMS/MMS alerts clear when their conversation is opened or answered, while persistent email alerts track the real unread count;
- leaves dismissed non-persistent email notifications dismissed until genuinely new mail arrives;
- applies disabled categories immediately and provides a Clear current notifications control;
- links directly to Android's app notification controls for channel sound, vibration, lock-screen, pop-up, and badge settings;
- preserves Android's final authority over notification permission and per-channel behavior.

## 1.2.5 sent-thread, email-action, notification, and icon repairs
- writes outgoing SMS rows into Android's system SMS provider before transmission, using the provider thread ID shared with received messages;
- writes outgoing MMS metadata, recipients, text, and attachment parts into the matching Android MMS thread and updates sent/failed state from the carrier callback;
- routes notification replies, scheduled sends, respond-via-message, and normal composition through the same persisted send path;
- replaces repeated “new email” totals with the actual unread count for each account and updates or clears the existing notification when mail is read or deleted;
- marks opened email conversations read locally immediately and updates the corresponding IMAP `\\Seen` flags in the background;
- adds working Mark read/Mark unread actions that update both IMAP and the local conversation badge;
- performs email deletion through IMAP `\\Deleted` plus `EXPUNGE` before removing synchronized inbox rows locally;
- sends Reply, Reply All, and Forward drafts through the configured SMTP account, adds Message-ID/In-Reply-To/References headers, and keeps sent replies in the source thread;
- fixes new outgoing-email thread keys so later replies resolve into the same conversation;
- replaces the launcher icon with the supplied blue message-bubble and green-envelope artwork without altering the uploaded image bytes.

## 1.2.4 startup, safe-area, and background repairs
- removes the duplicate inbox load that previously ran during both creation and the first resume;
- builds SMS/MMS conversation summaries from lightweight provider rows and hydrates only the newest MMS per thread;
- replaces per-conversation Contacts-provider lookups with one short-lived bulk contact index;
- immediately paints the last inbox snapshot while a later resume refresh runs in the background;
- adds a white status-area spacer above every app toolbar on Android 15 and later, with a slim separator on earlier Android releases;
- copies a selected background photo into private app storage so document-provider permission changes cannot make it disappear;
- migrates an existing 1.2.3 background URI to the durable app-owned copy on first successful load;
- explicitly keeps the inbox, conversations, and other screen containers transparent so the chosen photo or palette is visible;
- caches the decoded background between screens and retains image sampling to limit memory use;
- keeps Android 10 and 11 SMS/MMS sending compatible while using the modern subscription API on Android 12 and later.

## 1.2.3 compact interface, backgrounds, and sorting
- replaces full-width management grids with compact toolbar, filter, sort, and overflow menus;
- gives each conversation and each SMS, MMS, or email a small action menu while retaining individual and bulk management;
- presents incoming and outgoing items as compact offset message panels;
- adds six coordinated color palettes, a custom background-color field, text scaling, high contrast, and panel/background transparency controls;
- adds local photo selection, preview, enable/disable, replacement, and removal for app backgrounds;
- adds persistent default filters for SMS/MMS versus email and saved contacts versus non-contacts;
- adds persistent main-page ordering by date, address/name, content, unread state, transport, or contact status;
- adds a remembered sort override inside every SMS/MMS or email conversation;
- retains the application ID, signing/update path, database, account data, Contacts-provider integration, MMS rendering, and Unicode handling;
- keeps standard Android `sms:`, `smsto:`, `mms:`, and `mmsto:` compose entry points for later Maclean Phone integration.

## 1.2.2 MMS, Unicode, and Contacts repairs
- renders MMS images inside conversations and exposes every MMS attachment with Open and Save actions;
- reads MMS plain-text and HTML parts with their declared MMS charset instead of assuming a platform default;
- preserves Unicode email subjects, sender/recipient headers, quoted-printable bodies, Base64 bodies, multipart bodies, and UTF-8 outgoing mail;
- uses Android's Unicode-capable sans-serif fallback family throughout messages and editors;
- reads the aggregated Android Contacts provider live, including names, photos, phone numbers, and email addresses;
- adds a searchable Contacts and recipients page with refresh, contact creation, and Android account-sync access;
- adds contact-name/phone autocomplete and multi-contact pickers to SMS/MMS composition;
- adds contact-name/email autocomplete and To/Cc/Bcc contact pickers to email composition.

## 1.2.1 message management
- unified main-page search across message text, contact names, email addresses, and phone numbers;
- All, SMS/MMS, and Email transport filters;
- newest, oldest, address/name, message-text, and unread-first sorting;
- stable individual and bulk selection for conversations and messages;
- individual and bulk delete, forward, UTF-8 text download, and clipboard copy;
- clipboard paste controls for search, recipients, and SMS/MMS or email drafts;
- combined SMS/MMS thread loading and deletion;
- persistent local email-deletion tombstones so deleted mail does not reappear during synchronization.

## Email release functionality
- multiple accounts;
- add/edit/remove/enable/disable accounts;
- default sender and per-account sync controls;
- IMAP TLS/STARTTLS;
- SMTP TLS/STARTTLS;
- password/app-password authentication;
- OAuth2 Authorization Code + PKCE and XOAUTH2;
- Android Keystore AES/GCM secret storage;
- MIME parsing/building;
- attachments;
- manual and periodic sync;
- unified inbox;
- account-specific thread storage;
- New Email;
- Reply;
- Reply All;
- Forward;
- From, To, Cc, Bcc;
- provider presets for Gmail, Microsoft, Yahoo and Fastmail;
- connection testing;
- offline-readable GNU AGPLv3 license.

OAuth providers require distributor-owned OAuth registrations. Provider credentials are deployment configuration and must never be copied from another application.

See `RELEASE-COMPLIANCE-MATRIX.md` and `WORK-CHAT-BUILD-PROMPT.txt`.
