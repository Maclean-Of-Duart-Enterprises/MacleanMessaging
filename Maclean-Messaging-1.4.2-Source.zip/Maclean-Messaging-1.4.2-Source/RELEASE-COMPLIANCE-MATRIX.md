# Maclean Messaging 1.4.2 — Release Compliance Matrix

This source is the in-place-compatible continuation of the 1.4.1 release source.

| Requirement | Source status | Final external validation |
|---|---|---|
| Carrier-safe MMS envelope | Source attachments may be selected up to 2 MiB; the encoded PDU follows the active SIM's Android carrier configuration and still images are reduced to fit instead of overriding the MMSC limit | Live carrier tests below/near/above the reported 307,200-byte envelope |
| Default SMS role surface | Manifest includes SMS_DELIVER, WAP_PUSH_DELIVER, SENDTO for sms/smsto/mms/mmsto, RESPOND_VIA_MESSAGE, and the Android-protected receiver/service permissions | Role-eligibility and two-device Android 10–15 tests |
| Standalone SMS/MMS readiness | Inbox and Settings inspect the Android SMS role, runtime permissions, provider-write app-op, and required components; sending stops with an actionable explanation until the handoff is complete; no Google Messages package/API is referenced | Fresh-install role handoff, switch-away/switch-back, disabled-component, and Google-Messages-disabled device tests |
| Bounded background execution | General I/O uses 2–4 workers while telephony/provider transactions use an independent serialized lane; the application startup path keeps optional email/network work off the carrier lane | Cold-start plus simultaneous mail sync, attachment decode, incoming SMS, and incoming MMS stress test |
| Immediate inbox first paint | An atomic app-private last-known snapshot paints before the authoritative provider/database refresh; inbox rows are recycled and only visible rows become views | Cold/warm timing with thousands of mixed conversations, process restart, stale snapshot, and corrupted snapshot tests |
| Canonical MMS part storage | Binary parts open canonical `content://mms/part/{id}` descriptors with cleanup and explicit-`mid` fallback for vendor provider behavior | Re-test the supplied DOOGEE device plus AOSP/Pixel provider behavior |
| SMS/MMS isolation | SMS and MMS scans/counts/hydration fail independently so a broken MMS row cannot blank SMS | Corrupt/inaccessible MMS provider instrumentation plus live inbox test |
| Interrupted MMS recovery | Non-empty downloaded PDUs are imported after process restart; originating subscription is retained and retries are re-armed | Kill process between carrier write and callback on single/dual-SIM devices |
| Crash-safe incoming SMS | Delivery is atomically staged, committed off the receiver main thread, duplicate-checked, retained on provider failure, and retried by a persisted job | Two-device single/multipart SMS test with the app foregrounded, backgrounded, force-stopped/reopened, and under provider contention |
| Durable incoming MMS | Raw WAP notification is retained before parsing; failed downloads/imports survive process death and are reconciled after restart/default-role changes | Two-device picture, audio, contact, group, and multi-attachment MMS test across mobile-data transitions |
| Carrier MMS destination | Content URIs explicitly encode cache/files ownership and carrier-write access resolves to `files/incoming-mms` | Live carrier download plus provider URI instrumentation test |
| Successful Outbox lifecycle | Carrier/server success removes the durable compose item and private draft snapshot; failures remain reviewable | Real SMS/MMS/SMTP send plus process-kill callback test |
| Immediate inline reply visibility | Tapping Send synchronously inserts a protected **Sending…** row into the active recycled thread, increments its visible count, and scrolls it into view; completion automatically reloads the provider-backed row without navigation or a second message | Send the first SMS, text-only MMS, and attachment MMS in an already-open thread and confirm uninterrupted temporary-to-provider row replacement |
| Multipart SMS callback integrity | Per-part sent/delivered callbacks are idempotently aggregated and tolerate callback reordering | Multi-segment SMS test with delivery reports |
| Existing Outbox repair | Startup normalizes provider URIs and reapplies known terminal metadata from older versions | Upgrade from 1.2.11 with terminal rows retained |
| MMS scheduling network | Scheduled outgoing MMS and incoming download retries wait for cellular connectivity | Airplane/Wi-Fi/mobile-data transition test |
| Selectable rendering styles | Sleek is the default; Utility preserves the compact block-forward presentation; either is manually selectable in Settings | Upgrade/fresh-install UI test on representative phone sizes |
| Independent style profiles | Sleek and Utility persist separate font family, text format, shape, spacing, width, preview, outline, elevation, and sent-tint values; either can be reset independently | Process-restart and repeated style-switch test |
| Message-bubble appearance | Square, Soft corners, Rounded, and Oval shapes plus 70–100% width, sent-message tint, calculated child/per-line contour insets, tappable link hit-testing, and high-quality body wrapping apply to recycled SMS/MMS and email rows | Long/short incoming/outgoing message and long-link test at every shape and text scale |
| System text styles | Twelve families—four standard, two Cursive, two Calligraphy, and four Special—plus Regular, Bold, Italic, and Bold italic formats are independently saved per display profile, previewed before save, and applied through shared app text/control factories | Process-restart, OEM-family fallback, and screen-by-screen accessibility/readability test |
| Whole-app display tokens | Card, button, density, palette, background, opacity, and text settings flow through shared inbox, thread, settings, contact, account, and compose controls | Device/UI/accessibility test across every screen |
| Complete SMS/MMS thread rendering | Every mixed SMS/MMS row is read with no count limit; lightweight headers paint before a second background MMS hydration pass, malformed MMS hydration is isolated per row, and the native recycled list creates only visible Android views | Reproduce the reported high-volume thread on the affected phone; confirm complete history, progressive paint, no ANR, and bounded view memory |
| Bounded media rendering | MMS image decode occurs only for visible recycled rows and remains bounded by a 24 MiB cache | Long mixed-media thread test while scrolling rapidly and navigating away |
| Incremental thread controls | Long-press/menu selection and sorting update adapter data in place and stale asynchronous full-thread results are rejected after navigation | Long-press, bulk-select, repeated-sort, and rapid-navigation stress test |
| SMS/MMS read controls | Individual SMS/MMS and voice-message menus expose Mark as read/unread; selected messages and complete conversations use bounded provider batches, change `read`, and retain `seen` to avoid duplicate alerts | Live Android-provider test for single, mixed SMS/MMS bulk, notification clearing, and large selections |
| Android share target | ACTION_SEND and ACTION_SEND_MULTIPLE accept text and every MIME type, copy temporary URI grants into app cache with a 50 MiB per-file bound, and seed an SMS/MMS or email composer | Android share-sheet tests from Files, Photos, browser, recorder, and office apps |
| Long email thread rendering | Email rows are recycled and attachments are queried only for visible owning rows | High-volume email thread test with attachments and provider sync active |
| Clickable message links | Every web URL, email address, and phone number in each SMS/MMS body is linkified; multiple links remain separately actionable | Device/UI test with representative URL punctuation and OEM browsers |
| Inline message reply | Open SMS/MMS conversations keep a compact composer on the same page; quoted replies and reactions seed it without leaving the thread | Two-device carrier round-trip plus attachment, voice, SIM, schedule, and draft tests |
| Keyboard-safe reply layout | Activity resize behavior plus Android 15 IME/navigation insets keep the bottom reply panel above a docked keyboard | Portrait/landscape device tests with OEM and third-party keyboards, including floating keyboards |
| Reply location | Display & appearance stores Top or Bottom independently for Sleek and Utility and places the complete composer accordingly | Process-restart, style-switch, keyboard, and accessibility tests |
| Message reactions | Six reactions are available and compose explicit compatible reaction text because SMS/MMS has no universal native reaction metadata | Cross-client carrier test |
| Voice capture gestures | Hold-to-record, slide-left cancel, slide-up lock, pause/resume, live waveform, elapsed time, discard, and preview-before-send are wired | Real microphone/touch/accessibility test |
| Voice encoding | Ogg/Opus mono 48 kHz ~32 kbps is attempted first; Android media-stack rejection falls back to M4A/AAC and is shown in the UI | Device codec matrix and audio inspection |
| Voice playback | Compact bubble, seekable waveform, elapsed/total duration, and 1×/1.5×/2× playback share a navigation-persistent in-app player | Device playback, interruption, and long-thread test |
| Voice management | Long press/overflow exposes save-original, share, forward, reply, reaction, delete, and details | Device/UI/document-provider/share-sheet test |
| Original audio attachments | A separate audio picker preserves the selected file and MIME type without voice-note conversion | Send/open test for M4A, MP3, WAV, FLAC, and OGG |
| MMS attachment transport | Actual attachment bytes are embedded in an Android-compatible WSP multipart/related MM1 Send.req with SMIL, quoted Content-IDs, and matching Content-Location values; no local URI placeholder is transmitted | Live SIM/MMSC tests across target carriers and size limits |
| Carrier-aware image preparation | Selected-SIM message and image limits, 30–60 KiB structural reserve, exact fixed-PDU measurement, orientation-aware sampled decode, balanced dimension/quality reduction, and final full-PDU validation | Image MMS test on 300 KiB and larger carrier profiles; inspect delivered quality and total PDU size |
| Notification preferences | Master, SMS/MMS, email, persistent unread, previews, Quick reply, active-alert clearing, and Android channel controls are reachable from Settings | Android 10–15 device/notification-shade test |
| Persistent notification lifecycle | Active alerts update between ongoing and dismissible; SMS/MMS clears on open/reply; email tracks unread count; dismissed non-persistent email stays dismissed without new mail | Live SMS/MMS and IMAP notification test |
| Sent SMS/MMS thread visibility | Outgoing provider rows use Android thread IDs; immediate inline replies paint optimistically and then reconcile automatically; SMS and MMS carrier callbacks update sent/failed state | Real SIM send/receive test, including first-send visibility, notification reply, and multipart SMS |
| Email unread badges and notifications | Thread counts are rebuilt from message rows; the existing per-account notification updates/cancels against the true unread count | Live IMAP + notification test |
| Email read state | Opening a thread marks rows read immediately and pushes IMAP `\\Seen`; individual, selected, and whole-conversation Mark as read/unread actions batch by account and update local badges/notifications after remote success | Live provider test for single and cross-account bulk actions, including offline/error behavior |
| Email deletion | Synchronized INBOX mail receives IMAP `\\Deleted` and `EXPUNGE` before local removal/tombstoning | Live Gmail/Microsoft/Yahoo/Fastmail test according to provider retention policy |
| Reply/Reply All/Forward | Compose actions send with the receiving account over SMTP; replies include standard threading headers and persist in the source thread | Live provider round-trip test |
| Launcher icon | Supplied artwork is the application icon with identical source/image SHA-256 | Installed launcher test across OEM masks |
| Faster inbox startup | One initial request; lightweight SMS/MMS summaries; latest-MMS-only hydration; bulk cached contact lookup; cached UI during refresh | Timed cold/warm device test with representative history |
| System-status safe area | White status inset above every toolbar on Android 15+, slim separator on earlier versions | Device/UI test across cutout and non-cutout phones |
| Secure credential storage | Implemented: Android Keystore AES/GCM; SQLite stores aliases only | Device test |
| Unified inbox search | Implemented for content, names, email addresses and phone numbers | Device/UI test |
| Compact primary interface | Large action grids and permanent selection boxes are replaced by compact toolbar, filter, sort, overflow, long-press, and selection-context controls | Device/UI test |
| Transport/contact filters and sorting | Persistent defaults for All/SMS-MMS/Email, saved/non-contact status, date, address, text, unread, transport, and contact ordering | Device/UI test |
| Per-conversation sorting | Remembered oldest/newest/received/sent/text order for each SMS/MMS or email conversation | Device/UI test |
| Individual message management | Delete, forward, text download and copy implemented for SMS/MMS/email | Device/UI test |
| Bulk message management | Stable selection plus delete, forward, text download and copy implemented | Device/UI test |
| Clipboard paste | Implemented for search, recipients and message drafts | Device/UI test |
| Color palettes | Six coordinated palettes plus custom background, surface, accent/toolbar, and text colors, high contrast, text size, and opacity controls | Device/UI/accessibility test |
| Local photo backgrounds | Android document picker, private app-owned copy, 1.2.3 URI migration, preview, cache, use/disable, replace, and remove | Device/UI/document-provider/process-restart test |
| Background visibility | Root image/palette with explicitly transparent outer, scroll, and content layers across inbox and conversation screens | Device/UI test |
| MMS content visibility | Plain/HTML parts decoded; images rendered inline; all media parts expose Open and Save | Carrier/device MMS test |
| Special characters | Declared MMS/MIME charsets, RFC 2047, quoted-printable, Base64, raw UTF-8 headers, and Unicode UI fallback supported | Device/interoperability test |
| Contacts synchronization | Live aggregated Android Contacts provider with refresh and Android account-sync settings | Synced-account/device test |
| Contact recipient lookup | Searchable directory, name/address autocomplete, and multi-contact phone/email pickers | Device/UI test |
| IMAP synchronization | Implemented: TLS/STARTTLS with explicit peer host, SNI and hostname verification; continuation-based SASL PLAIN/LOGIN and XOAUTH2; full UID discovery; batched missing-message ingestion; Seen refresh; credential-safe stage diagnostics; Android 15 network-change callback | Live provider test, including the supplied `mail.mcclainfamilies.net` account |
| SMTP sending | Implemented: TLS/STARTTLS, AUTH LOGIN/XOAUTH2, DATA submission | Live provider test |
| MIME | Implemented: parse/build Unicode text, multipart, Base64, quoted-printable | Interop test |
| Attachments | Implemented in MIME + compose document picker | Send/open test |
| OAuth2 | Implemented: Authorization Code + PKCE, refresh tokens, XOAUTH2 | Requires distributor-owned provider client IDs |
| Account setup | Implemented and reachable from Settings | Device/UI test |
| Account test | Implemented for IMAP + SMTP | Live provider test |
| Multiple accounts | Implemented | Live multi-account test |
| Edit accounts | Implemented | Device/UI test |
| Remove accounts | Implemented, including credential deletion | Device/UI test |
| Enable/disable account | Implemented | Device/UI test |
| Per-account sync toggle | Implemented | Device/UI test |
| Default sending account | Implemented | Device/UI test |
| Manual sync | Implemented | Live provider test |
| Compose | Implemented and wired from unified inbox | Send test |
| Reply | Implemented and wired from email thread | Send test |
| Reply All | Implemented and wired from email thread | Send test |
| Forward | Implemented and wired from email thread | Send test |
| From selector | Implemented for multiple accounts | Device/UI test |
| Cc/Bcc | Implemented | Send test |
| Email hidden when unconfigured | Implemented | Startup test |
| Unified inbox | Implemented | Device/UI test |
| Email thread view | Implemented | Device/UI test |
| AGPLv3 readable in app | Implemented Settings → Legal | APK test |
| Destructive database migration | Removed for 2→3 migration | Upgrade test |
| TLS trust-all bypass | Not present | Security review |

## Release boundary

"Implemented" above means source wiring exists and no deliberate placeholder is used for that requirement. It does **not** mean a live carrier or mail provider has been exercised in this environment.

Before the APK is called production-verified, it must be installed and exercised for UI, accessibility, document-provider, live-provider, and SIM cases on representative devices.
