# Maclean Messaging 1.3.9 — build verification

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name/code: `1.3.9` / `10309`
- Minimum/target SDK: Android 10 (API 29) / API 35
- Signed APK: `Maclean-Messaging-1.3.9-Signed.apk`
- APK size: 1,118,866 bytes
- APK SHA-256: `f2b4580290295a9680e79b20a41edfd6c7f62b0314bff1465d066497e33af8f8`

## Update scope

- Settings → Display & appearance now presents twelve System text style choices: System sans, Serif, Monospace, Condensed, Cursive — Script, Cursive — Casual, Calligraphy — Classic, Calligraphy — Flourished, Special — Small caps, Special — Slab serif, Special — Light, and Special — Heavy.
- A separate Text format control provides Regular, Bold, Italic, and Bold italic.
- Font family and format are saved independently in both Sleek and Utility profiles. Existing profiles without the new format key load as Regular, and resetting one profile does not affect the other.
- A live preview shows the selected family/format before saving.
- The shared typeface factory applies the selection across app-rendered messages, email, inputs, controls, recipient suggestions, and headings. Semantic headings retain bold emphasis while respecting the selected italic/bold format.
- The choices use Android's offline system families and safely fall back through the platform on an OEM that substitutes a named family.
- All 1.3.8 email/TLS diagnostics, contour-aware text, complete-history loading, read/unread controls, Android sharing, and keyboard-safe top/bottom replies remain present.

## Verification record

- All 71 production Kotlin files compiled for JVM 17 against Android API 35 with no compiler errors, producing 758 class files.
- Android Build Tools 35.0.1 compiled and linked resources, generated release DEX, aligned the APK, and passed compressed-archive integrity checks.
- Python host suites passed 49/49 checks: 12 workflow/SQLite, 5 transport-state, and 32 release-contract tests.
- `ImapProtocolTest.kt`, `MmsImageFitPolicyTest.kt`, `MmsPduWriterTest.kt`, and `MmsPduParserTest.kt` compiled and passed.
- Release contracts verify all expanded family constants, the four format choices, per-profile `text_font` and `text_format` persistence, shared typeface routing, and the prior transport/workflow contracts.
- Compiled DEX inspection found the System text style control, preview, Cursive, Calligraphy, Special, and Bold italic strings.
- Compiled-manifest inspection reports package `com.macleanofduartenterprises.macleanmessaging`, version `1.3.9` (`10309`), minimum API 29, target/compile API 35, launcher activity `.ui.MainActivity`, `adjustResize`, and the existing single/multiple Android share filters.
- APK Signature Scheme v3 verification passed with one 4096-bit RSA signer.
- Signer certificate SHA-256 is `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`, exactly matching 1.3.8 for an in-place update.
- ZIP alignment and archive-integrity checks passed.
- Compiler output contains only pre-existing compact email-code and Android deprecation warnings; the 1.3.9 changes introduce no compiler errors.

## Device-specific validation still required

This environment has no attached Android handset, ADB runtime, active SIM, or configured live mailbox. The following checks are therefore not represented as completed:

- Install 1.3.9 directly over signed 1.3.8 without clearing data and confirm retained conversations, drafts, accounts, Keystore credentials, backgrounds, both display profiles, and default-SMS role.
- On the target phones, inspect every new family and Regular/Bold/Italic/Bold italic at small and large text sizes. Confirm the OEM supplies visibly suitable Cursive, Calligraphy, and Special faces or applies a readable platform fallback.
- Switch repeatedly between Sleek and Utility, restart the process, and confirm each profile retains its own family and format while headings remain distinguishable.
- Inspect long SMS/MMS and email bodies in Square, Soft corners, Rounded, and Oval surfaces to confirm each new font's metrics retain the existing contour wrapping and do not clip.
- Recheck live email synchronization/sending, real SIM SMS/MMS, attachment sharing, keyboard placement, notifications, schedules, and voice recording/playback on the target device and providers.

The APK is build-verified and update-compatible; it is not represented as live-device, carrier, mailbox-provider, or production verified.
