# Maclean Messaging 1.2.1 — Build Verification

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name: `1.2.1`
- Version code: `10201`
- Minimum Android API: 29
- Target/compile Android API: 35
- License: GNU AGPLv3 / `AGPL-3.0-only`

## Added in 1.2.1

- Main-inbox search across message text, contact names, email addresses, and phone numbers.
- All, SMS/MMS, and Email filters.
- Newest, oldest, address/name, message-text, and unread-first sorting.
- Stable individual and bulk selection for conversations, SMS, MMS, and email.
- Individual and bulk delete, forward, UTF-8 `.txt` download, and clipboard copy.
- Clipboard paste for search, recipients, and message drafts.
- Combined SMS/MMS thread management.
- Durable local email deletion records that prevent deleted messages from reappearing during synchronization.

## Completed build checks

- Full Kotlin source compilation completed without errors.
- Android resources and manifest linked successfully.
- DEX generation completed successfully.
- APK ZIP alignment verified.
- APK archive integrity verified.
- APK Signature Schemes v2 and v3 verified.
- Signing certificate matches the Maclean Messaging 1.2.0 production APK.
- Signing key: 4096-bit RSA.
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`.
- APK SHA-256: `9d9acce8fd8779309f64d955f159065a7443a6bf3c4036fe24309c01510d474a`.
- Signing password is absent from packaged APK strings.

## Device-validation boundary

No Android device or emulator was attached to the build environment. Installation, startup, Android SMS-role behavior, real SMS/MMS operations, Downloads integration, clipboard interaction, and live IMAP/SMTP/OAuth flows remain device tests.

Email deletion in this release removes the local synchronized copy and records a durable local tombstone. It does not issue a remote IMAP mailbox deletion command.
