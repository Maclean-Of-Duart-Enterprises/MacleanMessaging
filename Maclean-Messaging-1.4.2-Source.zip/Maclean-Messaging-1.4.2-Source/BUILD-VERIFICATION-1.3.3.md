# Maclean Messaging 1.3.3 — build verification

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name/code: `1.3.3` / `10303`
- Minimum/target SDK: Android 10 (API 29) / API 35
- Signed APK: `Maclean-Messaging-1.3.3-Signed.apk`

## Adaptive MMS scope

- The selected SIM supplies the real maximum encoded MMS bytes and maximum image dimensions.
- The image budget reserves 18% of the carrier envelope, bounded to 30–60 KiB, and expands that reserve when the exact fixed PDU footprint is larger.
- A 300 KiB transport therefore reserves 55,296 bytes and targets 251,904 bytes (246 KiB) for one image before final serialization.
- Multiple images share the available media budget; non-image attachments and long text automatically reduce it.
- Large photos use bounds-first sampled decoding, orientation-aware carrier dimensions, and thirteen paired dimension/JPEG-quality stages.
- Small compatible images remain byte-identical when they already fit the assigned budget and carrier dimensions.
- The complete MM1 Send.req is encoded and checked against the carrier limit before submission.

## Verification record

- `MmsImageFitPolicyTest.kt`: passed. It verifies the 300 KiB reserve and payload target, exact-fixed-overhead precedence, multi-image division, and monotonic dimension/quality stages.
- `MmsPduWriterTest.kt`: passed. It independently decodes the generated SMIL, UTF-8 text, and image parts and confirms the original media bytes are present in the serialized request.
- `MmsPduParserTest.kt`: passed for incoming Notification.ind and Retrieve.conf text/media parsing.
- Python host suite: 40/40 tests passed across release identity, carrier configuration, adaptive compression contracts, Android role/components, SMS/MMS persistence and callbacks, incoming recovery, scheduling, drafts, outbox, archive/pin, voice, and email actions.
- The complete production Kotlin source compiled for JVM 17 against Android API 35 with no compiler errors. Only pre-existing deprecation, parameter-name, and compact email-code warnings remain.
- Android Build Tools 35.0.1 successfully compiled/linked resources, generated release DEX, aligned the APK, and passed archive integrity checks.
- Manifest inspection reports application ID `com.macleanofduartenterprises.macleanmessaging`, version `1.3.3` (`10303`), minimum API 29, target API 35, expected launcher activity, and required SMS/MMS components.
- APK Signature Scheme v3 verification passed. Signer certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`, matching the supplied production lineage.

No host or static test is represented as a live carrier test. The source is intentionally dependency-complete for the included SDK build script rather than dependent on a Gradle plugin download, so verification uses full Kotlin compilation, AAPT2, D8, manifest, signature, alignment, archive, and host-test checks.

## Remaining device-specific verification

- Install over 1.3.2 without clearing app data and retain Maclean Messaging as the default SMS application.
- Send representative portrait, landscape, screenshot, PNG, and high-resolution camera images through the affected 300 KiB carrier profile to a second handset.
- Confirm text and media arrive together, compare delivered clarity with 1.3.2, and verify sender/recipient attachment management.
- Repeat with multiple images and with a carrier profile larger than 300 KiB where available.
