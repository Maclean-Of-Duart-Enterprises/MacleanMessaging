# Maclean Messaging 1.2.7 — Build Verification

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name: `1.2.7`
- Version code: `10207`
- Minimum Android API: 29
- Target/compile Android API: 35
- License: GNU AGPLv3 / `AGPL-3.0-only`

## Voice, reply, and link changes

- SMS/MMS bodies use Android link spans for web URLs, email addresses, and phone numbers, including multiple matches in one message.
- Individual SMS/MMS menus provide a quoted direct reply and six explicit carrier-compatible text reactions.
- Voice capture is a separate path from ordinary audio attachment: hold to record, slide left to cancel, slide up to lock, pause/resume, live waveform, elapsed time, preview, discard, and send are wired.
- The primary voice format is Ogg/Opus, mono, 48 kHz, approximately 32 kbps. If a device's public Android media stack rejects that configuration, capture retries as mono M4A/AAC and labels the fallback.
- Voice bubbles provide play/pause, seekable waveform, duration, 1×/1.5×/2× speed, and a process-level in-app player that is not released when a conversation view is rebuilt or another app screen is opened.
- Long press and overflow actions expose Save to device, Share, Forward, Reply, compatible reaction, Delete, and View details.
- The ordinary audio picker preserves the selected file and MIME type without converting it into a voice message.
- The MM1 Send.req encoder now embeds attachment bytes in its WSP multipart/mixed body; the former local content-URI placeholder is absent.

## Completed build checks

- All 59 Kotlin source files compiled without errors using Kotlin 1.9.24 and Java 17 against Android API 35.
- Full standalone Android lint completed with 0 errors and 41 non-blocking warnings: 29 conservative resource-close findings on Kotlin `.use` blocks, 9 programmatic localization labels, and one each for backup metadata, the supplied square launcher art, and a retained legacy XML resource.
- No lint findings remained for missing microphone permission, API level use, wrong constants, unsafe media calls, or touch-control click accessibility.
- Static release checks confirmed the Linkify mask, Ogg/Opus recorder constants, voice action strings, audio attachment separation, long-press handling, and absence of the former `[content-uri:…]` MMS payload.
- Android resources and manifest linked successfully with Build Tools 35.0.1; D8 release DEX generation completed successfully.
- APK archive integrity and four-byte ZIP alignment verified.
- Package metadata verified as version `1.2.7` / code `10207`, minimum API 29, target API 35, with `RECORD_AUDIO` declared.
- APK Signature Scheme v3 verified with one signer.
- Signing key: 4096-bit RSA.
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`.
- APK SHA-256: `3dbeaf05dfc9c6bf9feee2f36c66e826f3b813f28a2471b0d952df08971f8361`.
- APK size: 979,602 bytes.
- The signing password and keystore are absent from the release source and APK.
- Database version remains 5 and no table or column definition changed, preserving installed accounts, messages, settings, and upgrade data.

## Device-validation boundary

ADB reported no attached Android device or emulator. Installation, in-place upgrade, live microphone/touch interaction, media interruption, and SIM/MMSC transfer tests could not be executed here.

Real-device checks remain for:

- upgrading from 1.2.6 without losing accounts, messages, settings, backgrounds, notifications, or saved sorting;
- microphone permission grant/deny/re-enable behavior and hold/cancel/lock gestures across target screen densities;
- Opus output inspection on each target device and the labeled AAC fallback on devices that reject public Opus recording;
- pause/resume, preview, waveform seek, speed changes, audio focus, wired/Bluetooth routing, phone-call interruption, and playback continuity;
- saving, sharing, forwarding, replying to, deleting, and inspecting both sent and received voice messages;
- clickable URL edge cases and several links within one SMS/MMS across installed browser/email/dialer handlers;
- quoted reply and compatible reaction round trips with Android, iOS, and other SMS/MMS clients;
- live WSP multipart voice and ordinary audio transfer through each target carrier's MMSC, including carrier size and MIME restrictions;
- all previously listed notification, email-provider, Contacts, background, accessibility, and real SIM regression cases.

The APK is build-verified and correctly signed. It is not called production-verified until the relevant live device, carrier, and provider checks pass.
