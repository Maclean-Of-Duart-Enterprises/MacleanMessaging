# Maclean Messaging 1.3.7 — build verification

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name/code: `1.3.7` / `10307`
- Minimum/target SDK: Android 10 (API 29) / API 35
- Signed APK: `Maclean-Messaging-1.3.7-Signed.apk`
- APK size: 1,098,386 bytes
- APK SHA-256: `93860edab9a5dc81603a78c8e7f44fad62ed46afff4de41db556895c5296133d`

## Mark as read scope

- Every SMS, MMS, voice-message, email, and unified-inbox conversation overflow menu exposes an explicit **Mark as read** action.
- Bulk management menus expose **Mark selected as read** for selected unified conversations, selected SMS/MMS messages, and selected emails.
- SMS/MMS and email thread menus also expose complete-conversation Mark as read actions. The existing per-email Mark as unread action remains available.
- Device-message changes are grouped by SMS/MMS transport and updated in bounded 200-ID provider operations. Both Android `read` and `seen` columns are set.
- Email changes are loaded and written in bounded SQLite batches, grouped by account, and sent with one IMAP Seen operation per affected account. Local rows update only after the corresponding remote account operation succeeds.
- Each affected local email thread recalculates its unread count once, and the account unread notification is refreshed after the local commit.
- Successful actions clear only the affected selection and update the active recycled-list model without reloading complete bodies or attachments.
- Unified-inbox actions cover mixed device/email selections and refresh visible state after success or partial remote failure.

## Verification record

- All 69 production Kotlin source files compiled for JVM 17 against Android API 35 with no compiler errors.
- Android Build Tools 35.0.1 compiled and linked resources, generated release DEX, aligned the APK, and passed compressed-archive integrity checks.
- Python host suites passed 46/46 checks: 12 workflow/SQLite, 5 transport-state, and 29 release-contract tests.
- `ImapProtocolTest.kt`, `MmsImageFitPolicyTest.kt`, `MmsPduWriterTest.kt`, and `MmsPduParserTest.kt` all compiled and passed.
- Release contracts verify individual and bulk controls across inbox, SMS/MMS, voice-message, and email menus; bounded provider/database batching; per-account IMAP grouping; `read` plus `seen` writes; notification/thread refresh wiring; and version identity.
- Existing contracts continue to cover complete SMS/MMS histories, incremental complete-mailbox sync, SASL continuation authentication, recycled rows, shape-aware text wrapping, IME insets, reply-location persistence, SMS/MMS carrier paths, and durable workflows.
- Manifest inspection reports package `com.macleanofduartenterprises.macleanmessaging`, version `1.3.7` (`10307`), minimum API 29, target/compile API 35, and launcher activity `.ui.MainActivity`.
- APK Signature Scheme v3 verification passed with one signer.
- Signer certificate SHA-256 is `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`, matching the production signing lineage used for 1.3.5 and 1.3.6 and supporting an in-place update.
- ZIP alignment and archive-integrity checks passed.
- Compiler output contains only pre-existing email-code and Android deprecation warnings; the 1.3.7 changes introduce no compiler errors.

## Device/provider validation still required

This environment has no attached Android handset, active SIM, carrier service, configured email credential, or live mailbox authorization. The following checks are therefore not represented as completed:

- Install 1.3.7 directly over signed 1.3.6 without clearing data and confirm retained conversations, drafts, accounts, credentials, backgrounds, display profiles, and default-SMS role.
- On the target phone, mark one unread SMS and one unread MMS read, then mark a mixed selection read; confirm Android provider columns, unread badges, and persistent notifications clear correctly.
- Repeat individual and selected actions for voice-message rows and very large conversations, including selections spanning more than 200 device messages.
- With live IMAP accounts, mark one email, multiple emails, a whole thread, and a mixed multi-account inbox selection read; confirm remote `\\Seen`, local badges, notification totals, and offline/failure behavior.
- Recheck the retained 1.3.6 functionality with the real mailbox and SIM: IMAP/SMTP authentication, complete and incremental sync, real SMS/MMS sends and receives, attachments, voice, scheduling, callbacks, text wrapping, and keyboard-safe top/bottom reply placement.

These remaining checks require the user's device, mailbox credentials, or live carrier/provider infrastructure; the APK is build-verified, not represented as live-provider or production verified.
