# Maclean Messaging 1.2.12 — build verification

Built on 2026-09-12. This corrective release repairs terminal Outbox transitions and hardens end-to-end message state handling.

## Release identity

- Application/package ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name/code: `1.2.12` / `10212`
- Minimum/target Android API: 29 / 35
- Signed APK: `Maclean-Messaging-1.2.12-Signed.apk`
- APK size: 1,061,522 bytes
- APK SHA-256: `e334542bf6ea70a5de246b058946356aa800f9ac5e2e8e755666315e69cc96b6`
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`
- Signature: APK Signature Scheme v3, one 4096-bit RSA signer, matching 1.2.11.

The increasing version code, unchanged package ID, and unchanged signer support an in-place update without uninstalling or clearing app data.

## Corrective changes

- Carrier callbacks now use `goAsync()` and retain the process until local metadata, the Android SMS/MMS provider, and the durable Outbox are updated.
- Successful SMS, MMS, voice/file attachment, and email sends automatically leave Drafts & Outbox; failed sends remain reviewable.
- Multipart SMS sent and delivered callbacks are stored and aggregated idempotently; duplicate callbacks do not advance the count and one successful segment cannot complete the whole message.
- Out-of-order delivery/sent callbacks preserve the strongest known result instead of downgrading Delivered to Sent or Failed.
- New outgoing rows use canonical provider URIs. Startup reconciliation reapplies known terminal metadata to rows created by older releases and clears their completed workflow records.
- Scheduled outgoing MMS/voice/file sends and incoming-MMS retry jobs require cellular connectivity. Ordinary SMS scheduling remains independent of IP connectivity.
- Carrier failure states include actionable no-service, radio-off, fixed-dialing, limit, and MMS/APN guidance.
- Default-SMS role, permission, active-SIM, provider insertion, atomic scheduling, drafts, archive/pin, email server actions, MMS receive/import, and voice capture/playback behavior remain wired.

## Completed host checks

- All 62 Kotlin production files compiled with Kotlin 1.9.24, Java 17, Android API 35.
- AAPT2 manifest/resource linking, D8 release conversion, ZIP alignment, and APK ZIP integrity passed with Build Tools 35.0.1.
- APK badging confirms package/version, min/target APIs, launcher, and SMS/MMS/WAP/network/audio/notification permissions.
- Standalone Android lint over shipping sources completed with **0 errors and 44 warnings**. Remaining warnings are non-blocking localization, conservative resource-close analysis, deprecated API-compatible calls, backup metadata, one retained XML resource, and launcher-mask guidance.
- **12 workflow SQL tests passed**: due-time gating, atomic claim, alarm/job races, edit/cancel behavior, restart handling, Unicode payloads, stable job IDs, deletion, and independent archive/pin flags.
- **5 transport-state tests passed**: multipart completion, duplicate callbacks, part failure, callback/dispatcher ordering, successful cleanup, and failed-item retention.
- **10 release contracts passed**: modern SMS role, callback ordering/retention, saved continuation, due-time role checks, MMS upload/download wiring, cellular constraints, email server actions, and voice encoding.
- Synthetic MM1 Notification.ind and Retrieve.conf parser tests passed, including sender/content-location, UTF-8 text, and binary-part boundaries.
- APK Signature Scheme v3, one signer, certificate identity, four-byte alignment, and archive integrity were verified.
- Source audit found no APK, keystore, signing password, class, DEX, or JAR output in the source tree.

## Function coverage

| Function | Host-verified behavior | Live validation still required |
|---|---|---|
| Draft | Durable autosave, Unicode, recipients, SIM/account, reply/forward context, attachment snapshot, edit/discard | Process-kill/editor UI test |
| Send / schedule | Atomic one-time claim, reboot/update reconciliation, role/permission/SIM checks, exact/inexact alarm paths | Real scheduled dispatch under OEM power management |
| SMS | Provider threading, canonical row, multipart aggregation, Sent/Delivered/Failed transitions | Carrier round-trip and delivery reports |
| MMS / voice / files | MM1 multipart/related + SMIL, byte embedding, size gate, cellular jobs, provider transitions | APN/carrier upload and Android/iPhone interoperability |
| Incoming SMS | Default-handler delivery, provider Inbox insertion, notification, thread display | Real inbound multipart/Unicode SMS |
| Incoming MMS | WAP notification, carrier download, parser, dedupe, provider parts, retry, notification | Real carrier download and media rendering |
| Voice message | Ogg/Opus 48 kHz mono ~32 kbps, M4A fallback, pause/resume, waveform/playback/save/share wiring | Microphone/codec/touch and recipient playback |
| Email | SMTP new/reply/reply-all/forward, Sent persistence, IMAP Seen/delete, notifications | Real configured account/provider |
| Pin / archive | Independent persistent flags across SMS/MMS/email stable IDs and sorting/filtering | UI interaction after restart |
| Outbox | Success removal, failure retention, callback race closure, older terminal-row repair | Upgrade with real 1.2.11 rows |

## Device-only boundary

No Android device or emulator was attached. Live installation, upgrade migration, Android role and permission dialogs, real SIM/carrier SMS and MMS, APN/mobile-data behavior, dual-SIM routing, voice hardware/codecs, IMAP/SMTP/OAuth providers, incoming notifications, and Android/iPhone interoperability cannot be truthfully certified from this build host. Carrier acceptance also does not prove recipient-device delivery. Complete those checks on the affected phone before broad distribution.
