# Maclean Messaging 1.3.2 — build verification

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name/code: `1.3.2` / `10302`
- Minimum/target SDK: Android 10 (API 29) / API 35
- Signed APK: `Maclean-Messaging-1.3.2-Signed.apk`

## Corrective scope

- Outgoing MM1 Send.req uses Android-compatible multipart/related start and related-type parameters.
- Part Content-ID headers use quoted-string encoding and match the SMIL/Content-Location identifiers.
- SMIL, UTF-8 text, and every attachment are serialized as separately length-delimited parts.
- Selected-SIM carrier transport, APN handling, carrier size limits, source attachment limits, image preparation, provider rows, callbacks, incoming receivers, and message management are retained.

## Verification record

- `MmsPduWriterTest.kt`: passed. Independently decoded three parts (SMIL, UTF-8 text, JPEG), validated multipart tokens and quoted Content-IDs, consumed every declared byte, and matched the original JPEG payload exactly.
- `MmsPduParserTest.kt`: passed for Notification.ind and Retrieve.conf text/media parsing.
- Python host suite: 40/40 tests passed across release contracts, scheduling/draft state, atomic dispatch, carrier callbacks, multipart SMS aggregation, archive/pin behavior, provider persistence, incoming recovery, email actions, and voice encoding contracts.
- Full production Kotlin source compiled for JVM 17 against Android API 35. Only pre-existing compiler warnings for deprecated Android APIs, parameter names, and compact email code were emitted; there were no compiler errors.
- Resources compiled and linked with Android Build Tools 35.0.1; D8 release dexing, ZIP alignment, and APK archive integrity checks passed.
- APK manifest inspection reports application ID `com.macleanofduartenterprises.macleanmessaging`, version `1.3.2` (`10302`), minimum API 29, target API 35, the expected launcher activity, and SMS/MMS permissions/components.
- APK signature verification passed using APK Signature Scheme v3. The signer certificate SHA-256 is `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`, identical to the supplied 1.3.1 APK.
- APK ZIP integrity and `zipalign -c 4` checks passed.

No static or host test is represented as a live carrier test. Android standalone lint cannot accurately analyze this intentionally dependency-complete manual SDK source tree as a Gradle model; full compiler, AAPT2, D8, manifest, signature, alignment, archive, and host-test checks were used instead.

## Remaining device-specific verification

- Install over 1.3.1 without clearing app data, keep Maclean Messaging as the default SMS app, and send an image MMS to a second handset.
- Confirm text and image arrive together, the sender's conversation shows the attachment, and Save/Share/Forward/Delete can open the stored media.
- Reply with an MMS from the second handset and confirm incoming download, inline rendering, management, notification, and background stability.
- Repeat using the affected SIM/APN and, where available, another carrier. Carrier size policies and transcoding behavior are not reproducible without live service.
