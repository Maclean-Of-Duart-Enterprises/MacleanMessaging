# 1.4.2 — Immediate outgoing conversation updates

- Inserts a temporary outgoing SMS/MMS bubble into the currently open conversation synchronously when Send is tapped, so the first reply is visible without sending a second message or reopening the thread.
- Labels the temporary row **Sending…**, includes it in the visible message count, scrolls it into view according to the active conversation sort, and keeps provider-only actions disabled until Android assigns the canonical message ID.
- Dispatches immediate inline replies directly from their durable Outbox record instead of racing a zero-delay JobService for ownership.
- Automatically reloads the same open conversation after provider insertion, replacing the temporary row with the authoritative Android SMS/MMS row and its normal actions.
- Restores the typed reply if durable queueing fails and leaves transport failures reviewable in Drafts & Outbox.
- Preserves complete-history loading, progressive MMS hydration, keyboard-safe replies, standalone default-SMS operation, email, sharing, display/font profiles, and existing carrier callbacks.

# 1.4.1 — Standalone operation and smooth background loading

- Added a complete runtime-readiness check for Android's SMS role, messaging permissions, protected provider-write access, and required SMS/MMS components, with visible repair actions and a hard send guard when Android has not completed the handoff.
- Declared the Android messaging-app category and protected SMS provider permission while preserving the complete SMS_DELIVER, WAP_PUSH_DELIVER, SENDTO, and RESPOND_VIA_MESSAGE role surface.
- Replaced the unbounded cached executor with a bounded 2–4 worker pool and a separate serialized carrier/provider lane; optional email/network work cannot block incoming telephony commits.
- Added an atomic app-private unified-inbox snapshot for immediate cold-start paint, short-lived authoritative inbox caching, and bounded SMS/MMS and email thread caches.
- Replaced eager inbox view construction with recycled rows and split complete SMS/MMS history loading into a lightweight header pass followed by background MMS hydration, with no message-count limit.
- Deferred document metadata, linkification, image decoding, email attachment lookup, voice duration extraction, recording finalization, recorder release, and background-photo I/O; added bounded caches and duplicate-work guards.
- Prevented self-originated provider updates from tearing down the active conversation composer and removed unnecessary whole-list redraws after media probes complete.
- Preserved complete email synchronization, Android sharing, read/unread controls, keyboard-safe reply placement, fonts, contour text, scheduling, notifications, provider recovery, and carrier-aware MMS.

# 1.4.0 — Standalone SMS/MMS role recovery

- Makes standalone SMS/MMS ownership explicit in the main inbox: when Maclean Messaging is not Android's default SMS app, the app identifies that state and provides a direct role request instead of silently appearing to depend on Google Messages.
- Detects incomplete SMS/MMS permission state after role assignment and provides a direct permission recovery action.
- Incoming SMS and MMS receivers now defensively verify that Maclean Messaging still owns Android's SMS role before committing carrier traffic.
- Preserves email access independently of the Android SMS role.
- No Google Messages package, API, service, database, or application dependency is introduced or required by Maclean Messaging.

# Changelog

## 1.3.9 — Expanded system text styles

- Expanded Settings → Display & appearance → System text style to twelve choices, including two Cursive, two Calligraphy, and four Special styles alongside System sans, Serif, Monospace, and Condensed.
- Added a separate Text format selector with Regular, Bold, Italic, and Bold italic options.
- Persisted family and format independently for Sleek and Utility profiles, with Regular as the backward-compatible default for existing profiles.
- Added a live family/format preview and combined global formatting with semantic heading emphasis throughout app-rendered text, inputs, and controls.
- Kept the styles fully offline by using Android system families with safe platform fallback behavior.
- Preserved all 1.3.8 email, contour text, read/unread, attachment-sharing, performance, and reply-layout behavior.

## 1.3.8 — Email recovery, contour text, fonts, unread controls, and sharing

- Repaired direct TLS mail connections to carry an explicit peer host and SNI while retaining hostname verification and TLS 1.2/1.3, addressing virtual-hosted IMAP/SMTP servers.
- Replaced hidden IMAP `runCatching` failures with credential-safe stage, exception type, message, and stack diagnostics; account cards now show last successful sync and the actionable last error.
- Added Android 15 `JobService.onNetworkChanged()` handling and stopped immediate retry loops for credential/configuration failures while preserving periodic synchronization.
- Made Sync all now execute immediately and refresh every account card with a concrete completion or failure result.
- Added contour-aware panel and per-line text layout: headings, message/email lines, dates, and actions use calculated left/right insets that follow Square, Soft corners, Rounded, and Oval boundaries instead of one flat rectangular margin; linked text remains tappable.
- Added a separately persisted Text font setting to both Sleek and Utility display profiles, with System sans, Serif, Monospace, and Condensed choices applied throughout app-rendered text and controls.
- Added individual, selected/bulk, and complete-conversation Mark as unread actions directly below their Mark as read counterparts for unified conversations, SMS, MMS, voice messages, and email.
- Added Android `ACTION_SEND` and `ACTION_SEND_MULTIPLE` share targets for every MIME type. Shared text, subjects, and one or more attachments are safely imported and opened in a user-selected SMS/MMS or email composer.
- Preserved complete conversation/mailbox loading, bounded/recycled rendering, keyboard-safe top/bottom reply placement, package/data compatibility, and production signing lineage.

## 1.3.7 — Individual and bulk Mark as read

- Added an explicit Mark as read action to individual SMS, MMS, voice-message, email, and unified-inbox conversation menus.
- Added Mark selected as read to bulk conversation, SMS/MMS-message, and email-message management menus.
- Added conversation-level Mark as read actions inside device-message and email threads while retaining the email Mark as unread action.
- Batched Android provider read updates in bounded groups, setting both `read` and `seen` for SMS and MMS rows.
- Batched email read changes by account so selected emails require one IMAP Seen operation per account rather than one connection per message.
- Updated local email rows transactionally, recalculated each affected thread badge once, and refreshed the account's unread notification.
- Refreshed active recycled rows in place and cleared only the completed selection, without reloading full message bodies or attachments.
- Preserved the 1.3.6 complete-history, email-authentication, incremental-sync, shape-aware text, keyboard-safe reply, package, data, and signer behavior.

## 1.3.6 — Complete histories, faster sync, and email authentication repair

- Replaced the failing quoted IMAP `LOGIN` request identified in the supplied diagnostic with capability-aware SASL PLAIN or SASL LOGIN and correct continuation handling; XOAUTH2 now uses the same continuation-safe flow.
- Added explicit username and saved-password validation so missing account data produces an actionable local error instead of a malformed server command.
- Removed the 250-email synchronization window and imports every INBOX UID in bounded batches.
- Made subsequent email refreshes incremental by comparing server UIDs with lightweight local UID state, downloading only missing bodies, and synchronizing existing Seen flags without re-fetching message content.
- Isolated malformed MIME parsing by UID so one damaged email cannot prevent the remainder of the mailbox from synchronizing; the skipped UID remains eligible for a later retry.
- Removed the 50-message SMS/MMS conversation page and Load older control; complete device threads now load off the UI thread into the existing recycled list, with cached rows retained during provider refreshes.
- Added shape-aware content padding for Square, Soft corners, Rounded, and Oval message bubbles, cards, and input boxes.
- Added high-quality wrapping and hyphenation for message and email bodies, long links, multiline recipients, and compose text so content stays inside its selected surface.
- Preserved the 1.3.5 keyboard-safe reply position controls, application ID, database schema, stored accounts/messages, and production signing lineage.

## 1.3.5 — Keyboard-safe and configurable reply placement

- Added Android resize behavior and explicit IME/navigation-bar inset handling so the complete bottom reply panel stays above a docked on-screen keyboard on Android 15+.
- Added a Message reply location control under Display & appearance with Bottom of conversation and Top of conversation choices.
- Persisted reply placement independently for Sleek and Utility profiles, with Bottom retained as the default for existing users.
- Added a dedicated top reply host to SMS/MMS conversation pages while retaining the full reply composer, attachments, voice, SIM selection, scheduling, and draft behavior in either location.
- Preserved all 1.3.4 streamlined thread, selection, transport, provider, callback, MMS preparation, email, notification, appearance, and data behavior.

## 1.3.4 — Streamlined conversations and inline replies

- Added a compact SMS/MMS reply composer to the bottom of every open conversation with direct Send, attachments, audio files, voice recording, SIM selection when needed, scheduling, and draft saving.
- Kept immediate and scheduled replies on the conversation page instead of opening the separate new-message screen or navigating to Outbox.
- Routed quoted replies, compatible text reactions, and conversation Reply/Voice actions into the inline composer.
- Removed always-visible selection checkboxes from inbox, SMS/MMS, and email rows; long press and overflow menus retain individual selection, while contextual bulk controls appear only after selection.
- Removed the redundant per-conversation Open button because the full conversation card already opens the thread.
- Simplified thread toolbars by keeping management in the existing top-right menu and showing selection counts only when active.
- Preserved carrier-aware MMS compression, provider persistence, callbacks, scheduling, drafts/outbox, archive/pin, voice, email, notifications, appearance settings, package identity, database compatibility, and signing lineage.

## 1.3.3 — Intelligent carrier-aware MMS compression

- Reads the selected SIM's MMS message-size and maximum-image-dimension configuration as one carrier profile.
- Reserves 18% of the carrier envelope, bounded to 30–60 KiB, for text, recipients, SMIL, WSP/MM1 headers, and multipart overhead; a 300 KiB carrier receives a 54 KiB reserve and approximately 246 KiB image budget.
- Measures the exact fixed PDU footprint with image placeholders so long text, multiple recipients, and non-image attachments reduce the image budget automatically.
- Progressively reduces image dimensions and JPEG quality together across thirteen balanced stages, preserving substantially better visual detail than quality-only degradation.
- Uses bounds-first sampled decoding to avoid loading full-resolution camera photos unnecessarily and applies portrait/landscape carrier dimensions correctly.
- Preserves a compatible original image when it already fits both its allocated byte budget and the carrier's dimension bounds.
- Re-encodes and verifies the complete outgoing MMS against the carrier limit after preparation; an image that still cannot fit produces an actionable failure instead of a misleading send state.
- Preserves the 1.3.2 Android-compatible multipart/related encoder, carrier cellular path, provider rows, callbacks, incoming MMS, SMS, voice messages, scheduling, email, notifications, and display settings.

## 1.3.2 — Outgoing MMS multipart interoperability

- Replaced the outgoing binary writer with a deterministic MM1 Send.req encoder aligned to Android's PDU composer.
- Corrected the multipart/related root `type` parameter from the unrelated parameter token to the required related-type token (`0x89`).
- Encoded every MIME part Content-ID as a WSP quoted string while retaining stable matching SMIL sources and Content-Location names.
- Kept the selected SIM, Android cellular MMS service, carrier APN, carrier-advertised encoded size limit, 2 MiB source selection, and image preparation behavior intact.
- Added an independent PDU-structure regression test that decodes all part lengths and proves the SMIL, UTF-8 text, and original image bytes are present before carrier handoff.
- Preserved the 1.3.1 incoming SMS/MMS receiver and provider-part repairs and all existing messaging, scheduling, outbox, voice, email, display, and notification features.

## 1.3.1 — Incoming delivery and MMS-part recovery

- Fixed the Android 15 receiver crash found in the supplied report by acknowledging SMS_DELIVER and WAP_PUSH_DELIVER before `goAsync()` detaches the synchronous broadcast result.
- Correctly stores `text/plain`, `text/html`, and `application/smil` MMS parts in Android's inline text column; SMIL is presentation metadata and is no longer misclassified as a binary attachment.
- Made MMS binary-part persistence try independent output-stream, asset-descriptor, writable-descriptor, and truncate-descriptor strategies across canonical and vendor insertion URIs.
- Added durable app-private MMS attachment fallback storage when a vendor provider still refuses every binary stream, preserving open, preview, playback, save, share, forward, and delete behavior.
- Merges fallback attachments into conversation previews and message management and removes them with individual, thread, duplicate, and failed-transaction cleanup.
- Retains and recovers pending MMS notifications from 1.3.0 so successfully downloaded but previously unimportable attachments can be fetched and imported after update.
- Preserved carrier cellular-MMS routing and active-SIM limits, 2 MiB source selection, SMS multipart state, scheduling, drafts/outbox, archive/pin, voice messages, email, and display settings.

## 1.3.0 — Android-compliant SMS/MMS repair

- Confirmed from the supplied device report that Maclean Messaging held Android's SMS role and all SMS/MMS permissions; removed misleading role assumptions from the transport diagnosis.
- Repaired incoming MMS binary-part persistence with canonical provider file descriptors, vendor URI canonicalization, incomplete-part cleanup, explicit message-id fallback, serialized imports, retained-download recovery, and bounded retries.
- Removed the forced 2 MiB carrier override. The app still accepts source attachments up to 2 MiB, but encoded MMS now obeys the active SIM's carrier limit and automatically resizes/recompresses still images to fit.
- Made canonical outgoing provider persistence mandatory before carrier submission so sent SMS/MMS cannot silently disappear from conversation threads.
- Hardened SMS/MMS status broadcasts against background process crashes and corrected subscription-id extraction for incoming SMS on multi-SIM devices.
- Limited SMS/MMS provider observation to the visible activity and throttled refreshes to prevent the incoming-provider storm identified near the reported ANR.
- Preserved package ID, signer compatibility, SMS multipart callbacks, cellular MMS routing, scheduled sends, drafts/outbox, archive/pin, message management, voice notes, email, and existing presentation settings.

## 1.2.14 — Complete SMS/MMS transport recovery

- Raised the app-side MMS upload/download envelope to 2 MiB and supplies that override to Android's carrier MMS service, bypassing incorrect legacy 300 KiB vendor configuration while retaining carrier rejection reporting.
- Normalized SMS and MMS telephone recipients before carrier handoff and uses the broadly compatible single-part SMS API for ordinary texts.
- Isolated SMS and MMS provider scans, message counts, header loads, and MMS hydration so one malformed or inaccessible MMS can no longer blank ordinary SMS or the entire inbox.
- Recovers a completed MMS download after process death, preserves the originating SIM for retry, and re-arms previously exhausted durable downloads when the app/default role returns.
- Prevented a transient vendor provider-write failure from blocking carrier submission and hardened carrier callback receiver finalization.
- Retained canonical Android provider storage, MMS attachment viewing/saving/forwarding/deletion, cellular-only MMS retry/scheduling, and all existing message-management features.

## 1.2.13 — Incoming SMS/MMS receiver reliability

- Fixed the incoming MMS destination URI root mismatch that prevented Android's carrier service from writing downloaded attachment data.
- Added explicit cache/files URI namespaces to `PduContentProvider`, with safe backward-compatible resolution for temporary older URIs.
- Reworked SMS delivery around an asynchronous, atomic staging and provider-commit transaction with duplicate protection and persisted retry.
- Retained incoming MMS notification PDUs before parsing/downloading so failures survive background process death and can be retried.
- Hardened SMS/MMS notification, pending-broadcast, retry-job, and cold-start initialization paths against uncaught exceptions.
- Restored retained SMS/MMS deliveries at process start and when Maclean Messaging becomes the default SMS application.

## 1.2.12 — Outbox and end-to-end state repair

- Retained SMS/MMS carrier callback processing with `goAsync()` until provider, metadata, and Outbox commits finish.
- Successful sends now leave Drafts & Outbox automatically; rejected sends remain with actionable status.
- Added persistent, idempotent multipart SMS callback aggregation and out-of-order sent/delivered protection.
- Normalized outgoing provider URIs and added startup repair for older terminal rows left in system Outbox.
- Added cellular job constraints for scheduled and retried MMS, including voice and file attachments.
- Added transport-state race, duplicate callback, failure retention, email action, voice-format, and carrier-path regression contracts.

## 1.2.11 — Default SMS role and real MMS transport

- Replaced the legacy-only role check with Android RoleManager and fixed the discarded null-data role callback.
- Send/schedule operations are saved before role selection and automatically resume once Android confirms the role.
- Added dispatch-time role/permission checks and made failed SMS/MMS provider insertion actionable.
- Implemented incoming MMS carrier download, MM1/WSP parsing, provider import, attachment persistence, notification, deduplication, and bounded network retries.
- Replaced the minimal outgoing MMS body with multipart/related + SMIL and added carrier message-size validation.
- MMS status now distinguishes carrier acceptance from proof of handset delivery.

## 1.2.10 — Scheduling, compose menus, drafts, archive, pin, and resend
- Replaced the unreachable SMS delay field with a shared native date/time scheduling dialog for SMS, MMS, group messages, voice/file attachments, and email.
- Added a durable device-local Drafts & Outbox database, debounced autosave, explicit save/discard, rescheduling, cancellation, and visible send/failure history.
- Added persisted Android jobs and alarm wakeups, reboot/app-update/clock-change reconciliation, legacy schedule migration, and optional Alarms & reminders access.
- Guarded dispatch with an atomic claim so competing jobs and alarm triggers cannot both submit a queued item. Interrupted sends require review rather than automatic retransmission.
- Replaced global composer overflow options with actions for the current message or email.
- Wired local archive/unarchive and pin/unpin into inbox, bulk management, and conversation management; preserved pin priority for every inbox sort.
- Added resend-as-editable-copy to outgoing SMS/MMS and email messages and to completed/failed Outbox items. The original message remains intact.
- Preserved separate To/Cc/Bcc fields in new compose records. Older sent email lacking recipient-role metadata requires recipient review before resend.
- Stored durable attachment copies for drafts/schedules and independent outgoing email attachments for later forward/resend.
- Added attach-to-draft/schedule for recorded voice previews and preserved original file/audio bytes.
- Prevented unavailable draft attachments from crashing the composer and prevented silent account/SIM substitution when restoring a draft.
- Kept the existing application ID, signing certificate, main database version 5, display styles, backgrounds, contacts, and notification preferences.
- Added 12 SQLite regression cases and a reproducible SDK signing/build script without embedded credentials.

## 1.2.9 — Sleek and Utility display profiles
- Added Settings → Display style and appearance with independently persisted Sleek and Utility profiles.
- Made Sleek the fresh-install/default profile with rounded surfaces, pill controls, comfortable spacing, soft elevation, aligned 84%-width messages, and a subtle sent-message accent tint.
- Preserved the existing compact and outlined visual language as Utility with square controls and near-full-width messages.
- Added separate Square, Soft corners, Rounded, and Oval choices for message bubbles, general cards/panels, and buttons/controls.
- Added Compact, Comfortable, and Spacious density; 70–100% message width; 1–4 inbox preview lines; optional outlines; optional elevation; and adjustable sent-message tint.
- Added per-profile reset without deleting the other profile's saved choices.
- Expanded Custom palette management to background, surface, accent/toolbar, and text colors.
- Routed the selected display tokens through inbox cards, thread rows, SMS/MMS and email bubbles, settings cards, contacts, composers, inputs, toolbar controls, and shared action controls.
- Preserved the app-owned photo background, accessibility settings, package ID, signing continuity, database version, and all 1.2.8 performance and messaging behavior.

## 1.2.8 — Long-conversation ANR and memory repair
- Replaced eager SMS/MMS and email thread construction with native recycled lists that instantiate only visible rows.
- Added bounded SMS/MMS paging: 50 recent items load first and older pages are requested explicitly without losing the current scroll anchor.
- Deferred MMS address/part hydration until after the requested mixed SMS/MMS page is selected.
- Made individual and bulk selection updates refresh adapter state instead of rebuilding and re-querying the complete conversation.
- Made thread sorting reorder loaded model objects in place without reopening the conversation.
- Deferred email-attachment database reads until the owning row is visible.
- Limited MMS preview decoding to visible rows and added a bounded 24 MiB in-memory bitmap cache.
- Reused thread-local date formatters and rejected stale asynchronous results after screen navigation.
- Preserved application ID, signing continuity, database schema, sent/received threading, mail-server actions, notifications, backgrounds, contacts, Unicode, and all 1.2.7 voice/link functionality.

## 1.2.7 — Clickable links, direct replies, and voice messages
- Linkified all web links, email addresses, and phone numbers in SMS/MMS message bodies, including multiple links in one message.
- Added quoted per-message reply composition and text reactions that remain interoperable across ordinary carrier SMS/MMS.
- Added a distinct voice-message recorder with hold, slide-left cancel, slide-up lock, pause/resume, live waveform, elapsed duration, and preview-before-send.
- Made Ogg/Opus mono 48 kHz at approximately 32 kbps the primary recording format, with M4A/AAC fallback for devices that reject Opus through Android's public recorder API.
- Added compact voice bubbles with waveform seek, 1×/1.5×/2× playback, and playback continuity while conversation views are rebuilt or navigated.
- Added voice-message Save, Share, Forward, Reply, reaction, Delete, and View details actions through long press and overflow menus.
- Added a separate original-format audio attachment picker; ordinary M4A, MP3, WAV, FLAC, OGG, and other audio files are not converted into voice notes.
- Updated the MM1 encoder to put real attachment bytes into its WSP multipart body instead of serializing local content-URI placeholders.
- Preserved application identity, upgrade data, notification controls, email actions, backgrounds, contacts, sorting, MMS rendering, Unicode, and signing continuity.

## 1.2.6 — Notification controls
- Added an in-app Notifications settings page with master, SMS/MMS, and email alert controls.
- Added optional persistent unread notifications that stay visible until the related conversation is read or replied to.
- Added notification preview and SMS/MMS Quick reply controls.
- Added a direct link to Android's notification channels for per-channel sounds, vibration, lock-screen behavior, pop-ups, and badges.
- Added a control to clear currently posted message and email notifications.
- Prevented dismissed non-persistent email-count alerts from returning on routine sync when no new email arrived.
- Applied notification choices to active alerts and suppressed disabled categories immediately.
- Opened SMS/MMS notifications directly into their conversation when Android supplies the inserted message URI.

## 1.2.5 — Sent-thread persistence, real email actions, and new icon
- Persisted outgoing SMS in the Android SMS provider before transmission so sent and received messages share one provider thread.
- Added outgoing MMS provider rows, addresses, UTF-8 text, attachments, and sent/failed result updates.
- Routed notification replies through the same persisted message repository.
- Corrected IMAP sync accounting so a 250-message fetch window is no longer reported as 250 new messages on every sync.
- Recomputed email-thread unread totals from message rows and synchronized account notifications to the true unread count.
- Marked opened email threads read locally immediately and pushed the IMAP `\\Seen` flag without blocking rendering.
- Added per-email Mark read/Mark unread and conversation Mark unread controls backed by IMAP.
- Changed synchronized inbox deletion from device-only hiding to server-side IMAP deletion followed by local removal and tombstoning.
- Added RFC Message-ID, In-Reply-To, and References headers for SMTP mail; sent replies now remain in their source conversation.
- Normalized new outgoing email thread identity so a recipient reply joins the sent conversation.
- Replaced the app launcher icon with the supplied blue-message/green-envelope image byte-for-byte.
- Preserved package ID, production signing lineage, database schema, accounts, backgrounds, sorting, MMS rendering, contacts, and Unicode behavior.

## 1.2.4 — Faster startup, safe toolbar, and durable backgrounds
- Removed the duplicate initial inbox request and retained the last rendered inbox while resume refreshes run.
- Replaced full historical SMS/MMS materialization with lightweight thread-summary scans; only the newest MMS for each visible thread is hydrated for its address and preview.
- Replaced one Contacts query per participant with a short-lived bulk contact index.
- Added a white system-status safe area above the app toolbar on Android 15+, plus a slim white separator on earlier releases.
- Copied newly selected background photos to private app storage and added automatic migration for readable 1.2.3 photo URIs.
- Made the outer, scroll, and content layers explicitly transparent, allowing palette and photo backgrounds to appear on the main page and in SMS/MMS and email conversations.
- Cached sampled background bitmaps between screens to reduce repeated decoding.
- Added an Android 10/11 fallback for subscription-specific SMS/MMS managers found during release lint.
- Preserved application ID, production signing lineage, database schema, messages, contacts, email accounts, MMS visibility, Unicode handling, compact management, and saved sorting.

## 1.2.3 — Compact interface, background management, and conversation sorting
- Replaced large main-page and thread management grids with compact toolbar, filter, sort, and overflow menus.
- Added compact per-conversation and per-message action menus without removing bulk or individual delete, forward, UTF-8 download, copy, or paste workflows.
- Added coordinated Soft Cloud, Warm Sand, Quiet Sage, Ocean Mist, Soft Plum, and Midnight palettes plus a custom background color.
- Added local background-photo choose, preview, enable/disable, replace, and remove controls with persisted document permission.
- Added saved defaults for inbox transport, saved-contact status, inbox order, and individual-message order.
- Added per-conversation sorting by oldest, newest, received, sent, or message text.
- Added main-page sorting with SMS/MMS-first, email-first, saved-contact-first, and non-contact-first choices.
- Added contact-status metadata to unified conversations while continuing to resolve names and photos live from Android Contacts.
- Preserved package identity, signing lineage, database continuity, SMS/MMS and email functionality, MMS visibility, and Unicode handling.

## 1.2.2 — MMS visibility, Unicode, and Contacts repair
- Added real MMS-part loading instead of reducing media to attachment placeholders.
- Added inline MMS image rendering plus Open and Save actions for image, video, audio, contact-card, and file parts.
- Added MMS charset handling for UTF-8, UTF-16, ASCII, ISO-8859 variants, Shift-JIS, GB2312, Big5, and Windows-1252.
- Replaced the email MIME decoder with multipart, Base64, quoted-printable, declared-charset, RFC 2047, and raw UTF-8 header support.
- Added Unicode-safe outgoing email subject, body, and attachment filename encoding.
- Added a live Android Contacts directory with search, refresh, account-sync settings, and contact creation access.
- Added recipient autocomplete and multi-contact selection for phone numbers and To/Cc/Bcc email addresses.
- Preserved application ID, database continuity, existing messaging management, and production signing lineage.

## 1.2.1 — Unified search and message management
- Added unified inbox search by message text, contact, email address, and phone number.
- Added All, SMS/MMS, and Email filters plus six sorting modes.
- Added stable individual and bulk selection at conversation and message level.
- Added delete, forward, UTF-8 text download, and clipboard copy for individual and bulk selections.
- Added clipboard paste controls to inbox search and SMS/MMS and email composers.
- Added combined SMS and MMS thread reading and management.
- Added durable local email deletion records to prevent synchronized messages from reappearing after deletion.
- Preserved package identity, production signing continuity, dual-SIM messaging, scheduling, notifications, email accounts, and AGPLv3 access.

## 1.2.0 — Release-completion revision
- Completed the optional multi-account email subsystem to release-level UI integration.
- Added Android Keystore AES/GCM credential storage.
- Added IMAP TLS/STARTTLS synchronization and password/XOAUTH2 authentication.
- Added SMTP TLS/STARTTLS sending and password/XOAUTH2 authentication.
- Added OAuth2 Authorization Code + PKCE browser flow.
- Added Gmail, Microsoft, Yahoo and Fastmail provider presets.
- Added MIME parsing/building, Unicode, Base64, quoted-printable and multipart attachments.
- Added incoming attachment persistence/opening and outgoing multi-attachment selection.
- Added full email account management UI: add/edit/remove/enable/disable/default/sync/test.
- Added New Email, From/To/Cc/Bcc, Reply, Reply All and Forward UI.
- Added Sent-message persistence after SMTP success.
- Added per-account sync errors and notification behavior.
- Removed deliberate email protocol placeholders and disconnected email controls.
- Replaced destructive database migration behavior with an explicit migration.
- Added offline-readable GNU AGPLv3 license and release compliance/audit documents.

## Earlier 1.2.0 architecture
- Added first-class multiple email account architecture.
- Added default sender routing, per-account identity and unified inbox filtering.

## 1.1.0
- Added optional email integration architecture.

## 1.0.0
- Initial standalone Maclean Messaging architecture.
