# Maclean Messaging 1.3.0 — build verification

Built on 2026-09-13 from the supplied, checksum-verified 1.2.14 source and the supplied device bug report.

## Release identity

- Application/package ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name/code: `1.3.0` / `10300`
- Minimum/target Android API: 29 / 35
- Signed APK: `Maclean-Messaging-1.3.0-Signed.apk`
- APK size: 1,073,810 bytes
- APK SHA-256: `3f065a4f204b62cdc5c83e58303bed70f1f8eb57a2f341968e28c2045cc5d1fb`
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`
- Signature: APK Signature Scheme v3, one 4096-bit RSA signer, matching the supplied 1.2.14 APK.

The increasing version code, unchanged package ID, and unchanged signer support an in-place update without uninstalling or clearing application data.

## Device-report diagnosis

- Android reported `android.app.role.SMS` held by Maclean Messaging and all SMS/MMS runtime permissions granted.
- Maclean's outbound MMS request obtained the SIM-specific cellular MMS network, loaded the `ereseller` APN, reached the MMSC, and received Android result `-1` (success).
- Incoming carrier MMS downloads also completed, but all three imports failed at `IncomingMmsManager.insertPart` because the vendor MMS provider created an attachment row without returning a writable stream for that insertion URI.
- The SIM carrier bundle advertises `maxMessageSize=307200`, `maxImageWidth=640`, and `maxImageHeight=480`. Google Messages used this same carrier path successfully; the previous forced 2 MiB override did not change the MMSC's physical limit.
- The report also contains a MainActivity input-dispatch ANR during the repeated provider/download activity.

## Corrective implementation

- Binary incoming and outgoing MMS parts now use canonical `content://mms/part/{id}` file descriptors, with nested-URI canonicalization, incomplete-part deletion, and an explicit-`mid` collection fallback for vendor-provider compatibility.
- Completed downloads retained by 1.2.14 are imported after upgrade using the repaired provider writer.
- Incoming MMS provider commits are serialized, while notifications and retry records remain durable across process death.
- The app accepts selected attachment sources up to 2 MiB, reads Android's active-SIM carrier limit, prepares still images as compatible JPEG within 640×480, and iteratively adjusts quality/scale to fit the actual encoded PDU envelope.
- Empty per-operation overrides leave APN, MMSC, proxy, user agent, and maximum-message policy to Android's carrier MMS service.
- Outgoing provider persistence is mandatory before carrier handoff, preventing an SMS/MMS from being transmitted without appearing in the Android conversation.
- Incoming SMS extracts the standard subscription-index extra with a compatibility fallback; single/multipart SIM-specific send APIs and per-part callbacks remain intact.
- Carrier-status callback failures are contained and logged instead of crashing a background process.
- Provider observers are registered only while the activity is visible and refresh work is fixed-window throttled to prevent callback storms and background ANRs.

## Completed host checks

- All Kotlin production sources compiled with Kotlin 1.9.24, Java 17, and Android API 35.
- AAPT2 resource/manifest linking, D8 release conversion, ZIP alignment, and APK archive integrity passed with Build Tools 35.0.1.
- APK badging confirms package/version, API levels, launcher, and SMS/MMS/WAP/network/audio/notification permissions.
- Packaged-manifest inspection confirms the default-SMS role surface: protected SMS_DELIVER receiver, protected WAP_PUSH_DELIVER receiver, SENDTO activity for SMS/MMS schemes, and protected RESPOND_VIA_MESSAGE service.
- Standalone Android correctness/security/performance lint completed with no issues.
- 37 workflow, transport-state, role, provider, scheduling, notification, email, voice, and release-contract tests passed.
- Synthetic MM1 Notification.ind and Retrieve.conf parser tests passed, including UTF-8 text and binary JPEG attachment boundaries.
- APK Signature Scheme v3, expected signer/certificate identity, four-byte alignment, and ZIP integrity were verified.

## Device-only validation boundary

No Android handset, active SIM, or carrier MMSC was attached to the build host. Static validation cannot prove live carrier interoperability. After installing over 1.2.14, perform two-device tests for incoming/outgoing single and multipart SMS; picture, audio, group, and multi-attachment MMS; background/process-restart receipt; scheduling; dual-SIM selection; and carrier-limit preparation. Preserve a new bug report if any operation fails so the exact Android result and provider behavior can be compared.
