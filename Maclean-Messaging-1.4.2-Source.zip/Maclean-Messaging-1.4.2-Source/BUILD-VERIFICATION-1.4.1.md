# Maclean Messaging 1.4.1 — build verification

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name/code: `1.4.1` / `10401`
- Minimum/target SDK: Android 10 (API 29) / API 35
- Signed APK: `Maclean-Messaging-1.4.1-Signed.apk`
- APK size: 1,135,250 bytes
- APK SHA-256: `4bc5910827842f63fc9d11a38b26a473ca2146e49eba3821dac5b9655c41253d`

## Update scope

- Maclean Messaging remains a native Android default-SMS application. It sends SMS and MMS through the selected SIM's Android `SmsManager`, receives `SMS_DELIVER` and `WAP_PUSH_DELIVER`, and persists its own incoming/outgoing provider rows. It has no Google Messages package, API, service, or database dependency.
- Runtime readiness now verifies Android SMS-role ownership, SMS/MMS runtime permissions, the protected `android:write_sms` app-op, and the required activity/receiver/service components. Inbox and Settings provide role, permission, and default-app repair actions; dispatch stops with an actionable explanation if the operating-system handoff is incomplete.
- General I/O uses a bounded 2–4 worker pool. Live carrier/provider commits use an independent serial executor, while schedule and email/network reconciliation run outside that carrier lane.
- The inbox uses recycled rows and can paint an atomic last-known app-private snapshot before its authoritative provider/database refresh.
- Complete SMS/MMS threads have no paging or count limit. SMS rows and lightweight MMS headers paint first; MMS addresses, bodies, voice notes, images, and other parts hydrate in a second background pass.
- Short-lived inbox caching plus bounded SMS/MMS and email thread caches make warm navigation immediate while provider observers invalidate stale state.
- Document metadata, message linkification, visible-row MMS preview decode, email attachment lookup, voice-duration extraction, recording finalization/release, attachment import/save, and background-image decode run outside the UI thread. Bounded caches and in-flight guards prevent duplicate work.
- The app suppresses its own mark-read provider echo so opening a thread does not tear down its reply, attachment, or voice controls.
- Existing complete email synchronization/sending, sharing, read/unread controls, keyboard-safe top/bottom replies, display/font profiles, contour text, schedules, notifications, and carrier-aware MMS behavior remain present.

## Verification record

- All 73 production Kotlin files compiled for JVM 17 against Android API 35 with no compiler errors, producing 791 class files.
- Android Build Tools 35.0.1 compiled and linked resources, generated release DEX, ZIP-aligned the package, and passed compressed-archive integrity checks.
- Python host suites passed 51/51 checks: 12 workflow/SQLite, 5 transport-state, and 34 release-contract tests.
- `ImapProtocolTest.kt`, `MmsImageFitPolicyTest.kt`, `MmsPduWriterTest.kt`, and `MmsPduParserTest.kt` compiled and passed.
- Release contracts cover the bounded/serialized executors, standalone readiness gate, required role surface, snapshot-first inbox, recycled conversation rows, progressive complete-thread hydration, background voice finalization, and prior transport/workflow requirements.
- Compiled-manifest inspection reports package/version `com.macleanofduartenterprises.macleanmessaging` / `1.4.1` (`10401`), API 29–35, `adjustResize`, the messaging-app category, single/multiple share filters, `WRITE_SMS`, and the complete SMS_DELIVER, WAP_PUSH_DELIVER, SENDTO, and RESPOND_VIA_MESSAGE surface.
- Compiled DEX inspection found `SmsRuntimeReadiness`, `UnifiedInboxSnapshotStore`, `InboxConversationAdapter`, the standalone recovery copy, background-load copy, and voice-finalization copy. No Google Messages package reference is present.
- APK Signature Scheme v3 verification passed with one 4096-bit RSA signer.
- Signer certificate SHA-256 is `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`, exactly matching the signed 1.3.9 package for an in-place update.
- ZIP alignment and APK archive-integrity checks passed.
- Compiler output contains only existing compact email-code and Android API deprecation warnings; the earlier ambiguous nested background callback labels were made explicit.

## Device-specific validation still required

This environment has no attached Android handset, ADB runtime, active SIM, or configured live mailbox. The following checks are therefore not represented as completed:

- Install 1.4.1 over the currently signed release without clearing data and confirm retained conversations, drafts, schedules, email accounts, Keystore credentials, backgrounds, display profiles, and Android default-SMS role.
- Disable or remove Google Messages, select Maclean Messaging as the Android default SMS app, grant the requested permissions, and complete two-device inbound/outbound SMS, multipart SMS, text/picture/audio/group MMS, notification reply, and multi-SIM tests.
- Switch the default role away and back, revoke/restore permissions, and confirm the inbox and Settings recovery controls accurately restore provider access and carrier delivery.
- Time cold/warm startup and large inbox/thread opening on the target device. Stress simultaneous email sync, attachment/image loading, voice record/finalize/playback, and incoming carrier messages; confirm progressive paint, stable reply controls, bounded memory, and no ANR/jank.
- Recheck live IMAP/SMTP synchronization and sending, Android share-sheet attachment import, third-party keyboards, notification channels, schedules, photo backgrounds, accessibility, and every display/font profile on representative target devices.

The APK is source-, build-, archive-, signer-, and host-test-verified. It is not represented as live-device, carrier, mailbox-provider, or production verified.
