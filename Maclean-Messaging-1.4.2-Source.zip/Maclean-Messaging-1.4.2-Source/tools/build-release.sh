#!/usr/bin/env bash
set -euo pipefail

# Java 17, Kotlin compiler/stdlib 1.9.24, SDK platform 35, Build Tools 35.0.1,
# ripgrep and zip are required. Supply signing secrets only through the environment.
PROJECT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
: "${ANDROID_SDK_ROOT:?Set ANDROID_SDK_ROOT}"
: "${KOTLIN_LIB:?Set KOTLIN_LIB to the Kotlin compiler dependency directory}"
: "${KEYSTORE_PATH:?Set KEYSTORE_PATH to the existing release keystore}"
: "${MACLEAN_STORE_PASSWORD:?Set MACLEAN_STORE_PASSWORD}"
: "${MACLEAN_KEY_PASSWORD:?Set MACLEAN_KEY_PASSWORD}"
KEY_ALIAS=${KEY_ALIAS:-macleanphonerelease}
APP_BUILD_DIR=${APP_BUILD_DIR:-$(mktemp -d)}
APP_OUTPUT=${APP_OUTPUT:-$APP_BUILD_DIR/Maclean-Messaging-1.4.2-Signed.apk}
export MACLEAN_STORE_PASSWORD MACLEAN_KEY_PASSWORD
SDK_TOOLS="$ANDROID_SDK_ROOT/build-tools/35.0.1"
ANDROID_JAR="$ANDROID_SDK_ROOT/platforms/android-35/android.jar"
STDLIB="$KOTLIN_LIB/kotlin-stdlib-1.9.24.jar"
mkdir -p "$APP_BUILD_DIR/classes" "$APP_BUILD_DIR/dex" "$(dirname -- "$APP_OUTPUT")"
mapfile -t SOURCES < <(rg --files "$PROJECT_DIR/app/src/main/java" -g '*.kt')
java -cp "$KOTLIN_LIB/*" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler \
    -no-reflect -no-stdlib -jvm-target 17 -classpath "$ANDROID_JAR:$STDLIB" \
    -d "$APP_BUILD_DIR/classes" "${SOURCES[@]}"
(cd "$APP_BUILD_DIR/classes" && zip -qr "$APP_BUILD_DIR/classes.jar" .)
"$SDK_TOOLS/aapt2" compile --dir "$PROJECT_DIR/app/src/main/res" -o "$APP_BUILD_DIR/resources.zip"
"$SDK_TOOLS/aapt2" link -o "$APP_BUILD_DIR/unsigned.apk" \
    --manifest "$PROJECT_DIR/app/src/main/AndroidManifest.xml" -I "$ANDROID_JAR" \
    -A "$PROJECT_DIR/app/src/main/assets" "$APP_BUILD_DIR/resources.zip"
"$SDK_TOOLS/d8" --release --min-api 29 --lib "$ANDROID_JAR" \
    --output "$APP_BUILD_DIR/dex" "$APP_BUILD_DIR/classes.jar" "$STDLIB"
(cd "$APP_BUILD_DIR/dex" && zip -q "$APP_BUILD_DIR/unsigned.apk" classes*.dex)
"$SDK_TOOLS/zipalign" -f 4 "$APP_BUILD_DIR/unsigned.apk" "$APP_BUILD_DIR/aligned.apk"
"$SDK_TOOLS/apksigner" sign --ks "$KEYSTORE_PATH" --ks-key-alias "$KEY_ALIAS" \
    --ks-pass env:MACLEAN_STORE_PASSWORD --key-pass env:MACLEAN_KEY_PASSWORD \
    --out "$APP_OUTPUT" "$APP_BUILD_DIR/aligned.apk"
"$SDK_TOOLS/apksigner" verify --verbose --print-certs "$APP_OUTPUT"
"$SDK_TOOLS/zipalign" -c 4 "$APP_OUTPUT"
unzip -t "$APP_OUTPUT" | tail -1
sha256sum "$APP_OUTPUT"
