# Maclean Messaging 1.3.8 — build verification

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name/code: `1.3.8` / `10308`
- Minimum/target SDK: Android 10 (API 29) / API 35
- Signed APK: `Maclean-Messaging-1.3.8-Signed.apk`
- APK size: 1,114,770 bytes
- APK SHA-256: `95a377ed936bdb7d64c56f1029b6872b63bc314adec58af31b0db6e255d58927`

## Corrective scope

- Direct TLS now wraps a connected peer-host socket, sends SNI, permits TLS 1.2/1.3, and retains HTTPS-style hostname verification for IMAP and SMTP.
- IMAP connection, INBOX selection, UID discovery, flag refresh, body fetch, Seen changes, and delete operations report a credential-redacted operation stage, exception type, message, and stack trace. Account cards expose last successful sync and the stored safe error.
- Manual synchronization runs immediately and refreshes the account status. Android 15's `onNetworkChanged()` callback is implemented, and permanent credential/configuration failures wait for the next periodic/manual attempt instead of requesting an immediate retry loop.
- `ShapeContourLayout` calculates child-specific boundary insets from each child's vertical position, while `ContourTextView` uses `StaticLayout.setIndents` for independent left/right wrapping on every displayed message/email line and retains clickable link hit-testing.
- Each Sleek/Utility display profile persists System sans, Serif, Monospace, or Condensed and routes the selected typeface through app text, input, button, spinner, checkbox, toolbar, and recipient-suggestion factories.
- Unified conversations, SMS, MMS, voice messages, and email expose individual, selected/bulk, and whole-conversation Mark as unread immediately below matching Mark as read actions. Android rows retain `seen=1` when made unread; email state is grouped per account and synchronized over IMAP before local commit.
- The launcher activity accepts `ACTION_SEND` and `ACTION_SEND_MULTIPLE` for every MIME type, imports temporary content grants with a 50 MiB per-file bound, and seeds either an SMS/MMS or email composer.
- Complete SMS/MMS histories, full incremental mailboxes, recycled rows, background loading, and keyboard-safe top/bottom replies remain intact.

## Verification record

- All 71 production Kotlin source files compiled for JVM 17 against Android API 35 with no compiler errors.
- Android Build Tools 35.0.1 compiled and linked resources, generated release DEX, aligned the APK, and passed compressed-archive integrity checks.
- Python host suites passed 49/49 checks: 12 workflow/SQLite, 5 transport-state, and 32 release-contract tests.
- `ImapProtocolTest.kt`, `MmsImageFitPolicyTest.kt`, `MmsPduWriterTest.kt`, and `MmsPduParserTest.kt` compiled and passed.
- Release contracts cover the direct-TLS/SNI path, safe IMAP diagnostics, Android 15 network callback, visible sync status, font persistence/application, contour layout wiring, Android share filters/import, read/unread controls, complete histories, and prior transport/workflow behavior.
- Compiled-manifest inspection reports package `com.macleanofduartenterprises.macleanmessaging`, version `1.3.8` (`10308`), minimum API 29, target/compile API 35, and launcher activity `.ui.MainActivity`.
- APK Signature Scheme v3 verification passed with one signer.
- Signer certificate SHA-256 is `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`, matching the production lineage and supporting an in-place update.
- ZIP alignment and archive-integrity checks passed.
- Compiler output contains only pre-existing compact email-code and Android deprecation warnings; the 1.3.8 changes introduce no compiler errors.

## Device/provider validation still required

This environment has no attached Android handset, active SIM, configured mailbox credential, or authorization to the supplied private mail server. The following checks are therefore not represented as completed:

- Install 1.3.8 directly over signed 1.3.7 without clearing data and confirm retained conversations, drafts, accounts, Keystore credentials, backgrounds, display profiles, and default-SMS role.
- Exercise the supplied `mail.mcclainfamilies.net` account: confirm TLS/SNI negotiation, authentication, complete/incremental sync, SMTP send, last-success status, actionable redacted errors, and no rapid JobScheduler retry after a credential failure.
- On Android 15, change Wi-Fi/mobile networks during email sync and confirm the missing-`onNetworkChanged()` warning is absent and the job completes or reports a bounded retryable error.
- Mark individual, selected, and whole conversations read and unread for SMS, MMS, voice, and email; confirm provider/IMAP state, badges, selection clearing, and notifications on the real device/server.
- Share text, one file/photo, and multiple mixed attachments from representative Android apps; confirm Maclean Messaging is present in the chooser and both destination composers retain content after process/background transitions.
- Inspect Square, Soft corners, Rounded, and Oval panels with short/long messages, URLs, attachments, all four fonts, both styles, and every text scale; confirm contour spacing remains readable and accessible.
- Recheck live SMS/MMS sends/receives, carrier attachment limits, voice recording/playback, callbacks, schedules, and notification actions.

These remaining checks require the user's device, mailbox credentials, or live carrier/provider infrastructure. The APK is build-verified, not represented as live-provider or production verified.
