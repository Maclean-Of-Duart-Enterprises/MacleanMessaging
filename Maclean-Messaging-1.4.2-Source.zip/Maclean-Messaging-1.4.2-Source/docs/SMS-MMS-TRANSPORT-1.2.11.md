# SMS/MMS transport repair in 1.2.11

## Default-SMS role flow

Android's `RoleManager.ROLE_SMS` state is authoritative on supported Android versions. A Send now or Schedule send request that needs the role is first saved as a device-local draft. The role chooser is then launched. Its result is handled before any null-Intent guard because Android role results commonly contain no data. The role is rechecked on both callback and resume, and a single-use continuation resumes the exact saved action. Consuming the continuation before queuing prevents callback/resume double sends.

On a clean install, the role request precedes SMS-group runtime permissions. The app also rechecks the role, SMS permissions, provider write, and selected SIM when a scheduled item actually becomes due. If the role has changed, the item becomes a reviewable failure rather than silently dispatching from an inconsistent state.

## Outgoing MMS

Outgoing MMS uses an MM1 Send.req with a WSP `application/vnd.wap.multipart.related` body. A SMIL presentation is the root and every text/media attachment has a unique Content-ID, Content-Location, and sanitized name. Text is UTF-8. The generated PDU is checked against the selected subscription's carrier maximum before handoff to `SmsManager.sendMultimediaMessage`.

The app writes the outgoing row and parts into Android's MMS provider before carrier handoff so sent and received items share the provider thread. Provider write failures are fatal and visible. Android `RESULT_OK` is shown as `CARRIER_ACCEPTED`, not as proof that the recipient handset received the MMS.

## Incoming MMS

As the default SMS app, Maclean Messaging receives `WAP_PUSH_DELIVER`, decodes the carrier Notification.ind content location, and calls `SmsManager.downloadMultimediaMessage` on the notification's subscription. The downloaded Retrieve.conf is parsed into its sender, date, UTF-8 text, SMIL, and binary parts. A single MMS Inbox row, sender address, and all parts are then written to Android's MMS provider and the normal message notification is posted.

Deterministic notification tokens prevent duplicate import. Transient download failures retain the original notification and use network-constrained, persisted, exponentially delayed retries, capped at five attempts. The provider grants write access only to the private `incoming-mms` download directory; cached outgoing PDUs and other attachments remain read-only.

## Device validation boundary

Host tests validate compilation, manifest wiring, state contracts, synthetic Notification.ind/Retrieve.conf parsing, WSP part boundaries, and release packaging. A real SIM/carrier is still required to validate APN/carrier policy, mobile-data routing, carrier size limits, Android/iPhone media interoperability, and OEM background behavior.
