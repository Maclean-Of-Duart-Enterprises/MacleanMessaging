# Supplied device bug-report findings for 1.3.2

The supplied Android report shows Maclean Messaging 1.3.1 (`versionCode=10301`) initiating the reported MMS on subscription 1 at 08:18:48. Android's MMS service acquired a cellular network with the MMS capability, loaded the `ereseller` APN, posted to the AT&T MMSC, and reported `processResult: success` at 08:18:48.609 with no connection failure. The report therefore rules out the default-SMS role, selected SIM, cellular MMS network acquisition, APN selection, and MMSC HTTP upload as the immediate cause of this attempt.

The carrier configuration in the same transaction advertises a 307,200-byte encoded-message limit and 640×480 image bounds. The application correctly prepares supported still images to that real transport envelope; the 2 MiB setting remains the source-file selection ceiling, not a promise that the carrier accepts a 2 MiB encoded MMS.

Inspection of the outgoing 1.3.1 encoder found two multipart interoperability defects after the successful network handoff. Its multipart/related root used `0x83` for the `type` parameter, but Android's MMS PDU definitions require the related-type parameter token `0x89`. It also emitted Content-ID values as plain text, while Android's PDU composer writes Content-ID as a quoted string. An MMSC can accept such a malformed payload yet ignore or detach the media part, which matches the observed text-only delivery.

Version 1.3.2 replaces that path with a deterministic MM1 writer using multipart/related `start` (`0x8a`) and related-type (`0x89`) parameters, quoted Content-IDs, matching Content-Location and SMIL references, UTF-8 text, and exact uintvar part lengths. The new host regression independently walks the serialized part table and proves the generated request contains SMIL, text, and the original image bytes before Android's carrier service receives it.

The report can prove carrier handoff and expose encoding defects, but this environment has no physical SIM or second handset. Final MMSC acceptance and recipient rendering therefore remain an explicit two-device carrier test after installation.
