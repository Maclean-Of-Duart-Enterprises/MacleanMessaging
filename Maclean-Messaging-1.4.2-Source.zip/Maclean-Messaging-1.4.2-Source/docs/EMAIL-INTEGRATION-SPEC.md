# Optional Email Integration Specification

## User experience

Default installation:
- Maclean Messaging shows only SMS/MMS conversations.
- Email controls exist only in Settings.
- No inbox category, empty tab, or background email service is shown.

After account setup:
- email conversations appear directly in the main conversation list;
- each conversation carries a small transport indicator (`SMS`, `MMS`, `Email`);
- unified search can cover all enabled transports;
- composing chooses transport from participant/address context;
- users can still explicitly select a transport where ambiguity exists.

## Required email protocols

Initial production target:
- IMAP4rev1/modern IMAP subset for receiving/synchronization
- SMTP submission for sending
- TLS
- OAuth2 where provider supports/requires it
- password authentication for standards-compliant private/self-hosted servers

Future optional target:
- JMAP

## Account configuration

Required manual fields:
- account display name
- email address
- username
- incoming host/port/security
- outgoing host/port/security
- authentication method
- credential or OAuth authorization

Provider auto-discovery can be added later.

## Security

Never store:
- plaintext password in Room
- OAuth refresh token in Room
- TLS bypass flags as an invisible default

Secrets must be wrapped using Android Keystore-backed encryption.

## Unified conversation rules

Email and SMS/MMS share presentation concepts, not protocol behavior.

Common fields:
- stable ID
- participants
- title
- preview
- timestamp
- unread count
- pin/favorite/archive state
- attachments
- account/transport indicator

Protocol-specific behavior remains transport-owned.

## Reply behavior

SMS/MMS thread:
- Reply sends through selected SIM/subscription.

Email thread:
- Reply sends through originating email account.
- Reply-all preserves To/Cc semantics.
- Subject quoting/thread headers remain email-specific.

## Optionality invariant

Deleting or disabling the final email account must:
- remove email rows from the active unified inbox;
- stop email sync;
- stop email notifications;
- leave SMS/MMS intact;
- preserve SMS/MMS permissions and default-role behavior.
