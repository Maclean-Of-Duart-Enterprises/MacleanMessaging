# Compose and organization in 1.2.14

## Scheduling a message or email

1. Write the message, choose recipients and an active SIM or enabled email account, and add any attachments.
2. Select **Schedule send ▾** or the top-right **⋮ → Schedule send — date & time**.
3. Use **Date ▾** and **Time ▾** to open Android's native date and time pickers. The dialog follows the device's 12/24-hour preference and shows its time zone. A past time is rejected.
4. Select **Schedule**. The saved item appears in **Drafts & Outbox** with its requested time.
5. Use that item's **⋮** for reschedule, edit, send now, cancel schedule while keeping a draft, delete, or details. Editing pauses the existing schedule before opening the composer.

Scheduling applies to SMS, MMS/group MMS, attached voice messages/files, and emails with To/Cc/Bcc and attachments. A recorded preview must first be added using **Attach voice to draft / schedule**; an unattached preview is intentionally temporary.

The requested timestamp is an absolute instant selected in the device's current time zone; travelling does not reinterpret it as the same wall-clock time in another zone. Boot, app update, clock/time-zone changes, and app startup reconcile pending schedules. The existing SMS schedule preference format is migrated into the new queue.

Android may delay background work. On Android 12+, the dialog offers **Alarms & reminders settings** when precise-alarm access is absent; without it the app uses an inexact alarm. Email jobs wait for network availability. SMS/MMS requires the configured SIM, SMS permissions/default role, and carrier service. Force-stopping the app prevents scheduled work until it is opened again. Reboot restores schedules after the device is available. No exact delivery-time guarantee or network/carrier success is claimed.

Queue state meanings:

| State | Meaning and action |
| --- | --- |
| DRAFT | Unsent editable content. Open, send, schedule, or discard. |
| SCHEDULED | Saved and registered for future processing. Edit, cancel, or reschedule before sending starts. |
| SENDING | A single worker has claimed the item. Editing/cancellation is blocked after handoff begins. |
| SUBMITTED | SMS/MMS was handed to the carrier API; refresh to obtain available SENT/DELIVERED/FAILED metadata. This is not proof of recipient delivery. |
| CARRIER_ACCEPTED | Android reported that the carrier accepted an MMS submission. This is not a handset delivery receipt. |
| SENT | Email SMTP accepted the message, or carrier status reports sent. Recipient receipt is not guaranteed. |
| FAILED | Registration, preparation, SMTP, or carrier submission failed. The saved item and error remain available for review. |
| UNKNOWN | A previous process ended during sending. Check the conversation/recipient before resending; the server/carrier may already have accepted it. |

Competing triggers use a conditional SQLite update to claim an item only once. Terminal and interrupted items are never automatically resubmitted. Removing an Outbox history entry does not retract a sent message or delete its conversation.

## Drafts and the compose menu

Text and recipient edits are saved after a short debounce and when the Activity pauses; explicit **Save draft** waits for persistence before closing. Drafts store separate To/Cc/Bcc fields, subject/body, account/SIM choice, reply/forward source, and attachments. They are stored on this device, not uploaded to an IMAP Drafts folder. A process kill before a pending save finishes can still lose the most recent keystrokes; use explicit Save draft before a deliberate shutdown.

The top-right **⋮** inside either composer operates on that draft: Send now, Schedule send, Save draft & close, Attach file, Manage attachments, Copy message text, Paste into message, Select all message text, and Discard draft. Back offers Save draft, Discard, and Keep editing. Missing attachment files are shown as unavailable and can be removed or reattached.

Attachments are copied into private app storage without format conversion before scheduling or explicit draft completion. The local per-file copy limit is 50 MiB; carriers and email providers can impose smaller limits. Copy failure retains the draft text and an error instead of silently queueing an incomplete message. A removed SIM or account requires review and selection of an available replacement, rather than silently switching the sending identity.

## Archive and pin

Use the inbox conversation **⋮**, **Manage selected**, or conversation **⋮ → Archive / pin conversation**. Archive hides the conversation from the main Inbox. The **Archive** button/menu opens archived conversations, where Unarchive returns them to the Inbox. Pin keeps a conversation above unpinned items in the selected view and sort order. Filters still apply to pinned items.

These are app-local conversation flags for SMS/MMS and email. They do not delete messages, alter provider read state, or move messages into the email server's Archive folder. Email server folder synchronization is not added by this release. Pin state survives archive/unarchive and restarts.

## Resend and attachment retention

Open an outgoing message's **⋮ → Resend / edit a copy**. Outbox history and failures offer the same review-copy flow. Check recipients, text, selected SIM/account, and attachments, then explicitly select Send now or Schedule send. This retains the original and prevents an accidental second send from a single tap.

New email Outbox records retain separate recipient roles for accurate resend. Older messages without this information show the historical recipient list for reference and leave recipient fields empty for review; Bcc recipients are not silently promoted into visible To/Cc fields. If an older sent email advertises attachments whose files are unavailable, resend reports the missing files and asks for a new email with reattached files.

Outgoing email media is now copied separately into sent-message storage before SMTP dispatch and recorded as attachment entities. Removing a draft/Outbox copy therefore does not remove the sent email's attachment bytes. Existing formats, including Ogg/Opus voice messages, remain unchanged.

## Verification and remaining device checks

Run `python3 tests/workflow_sql_test.py` and `python3 tests/release_contract_test.py` from the project root. The SQLite tests exercise production schema/predicates, due-time gating, competing claims, edit/cancel races, interrupted-send recovery, retained IDs, Unicode payload persistence, and independent archive/pin flags. The contract suite protects the role callback order, resumable role flow, dispatch-time role check, and real MMS download/import wiring. `MmsPduParserTest.kt` covers synthetic Notification.ind and Retrieve.conf decoding. These tests do not execute Android framework carrier APIs or SMTP/IMAP.

On a test Android device, verify both display styles and these flows before broad distribution:

- Upgrade over 1.2.10 without uninstalling; verify accounts, messages, media, backgrounds, and notification settings remain available.
- On a clean install, approve the default-SMS role first, then approve the SMS permission group. Verify Settings reports the role as Active.
- While already the default app, send immediately and schedule an SMS; verify no false default-app message appears. Also grant the role from the in-app prompt and verify the pending action continues without a second tap.
- Exchange picture, audio, Ogg/Opus voice, and group MMS with both Android and iPhone on each supported carrier/SIM. Verify incoming text and all parts enter the same provider thread.
- Disable data, receive an MMS notification, then restore data and verify bounded background retrieval retry. Test an over-carrier-limit attachment and verify a size error rather than a false sent state.
- Create/reopen SMS, group MMS, voice, and email drafts with Unicode, attachments, To/Cc/Bcc, and reply/forward context; test Back, app backgrounding, process restart, and missing/revoked attachment access.
- Schedule each transport a few minutes ahead, test both date/time pickers, reject a past choice, and verify one outgoing copy in its conversation.
- Edit/reschedule/cancel before the due time; test simultaneous trigger timing without duplicate sends. Confirm cancelled items do not dispatch later.
- Reboot, change time zone, revoke precise-alarm access, go offline, remove the chosen SIM/account, and force-stop/reopen; check queue state and error recovery.
- Confirm no automatic retry after an ambiguous interrupted send; use a reviewed copy to resend.
- Archive/unarchive and pin/unpin individually and in bulk, across SMS/MMS/email and every active sort/filter; restart and confirm persistence.
- Delete Outbox history, then forward/resend a sent email with attachments and verify the independent sent copies still open.
- Confirm recipient privacy for new and historical email resends, plus exact attachment byte preservation.

Android scheduling behavior follows the platform's [alarm guidance](https://developer.android.com/develop/background-work/services/alarms) and [JobInfo configuration](https://developer.android.com/reference/android/app/job/JobInfo.Builder).
