# Multi-account Email Specification — Maclean Messaging 1.2.0

## Principle

Maclean Messaging supports zero, one, or many email accounts.

- Zero accounts: email remains invisible; SMS/MMS is unaffected.
- One account: email appears in the unified inbox.
- Multiple accounts: mail from all enabled accounts can appear together in the same unified inbox.

## Account identity

Every email object carries `accountId`.

This includes:
- threads
- messages
- notifications
- sync work
- drafts
- sent mail
- reply/reply-all context
- folders
- signatures
- account-specific settings

No email message may be sent without resolving an account.

## Default sending account

The user may choose a default sending account.

Rules:
1. the first configured account becomes default automatically;
2. replies use the account that received the original message;
3. new messages use the configured default account;
4. compose UI allows changing the From account;
5. disabling/removing the default account promotes another enabled account.

## Unified inbox

Default behavior:
- show SMS/MMS plus messages from all enabled email accounts;
- sort by pin state, then timestamp;
- retain account identity internally.

Filtering:
- All communications
- SMS/MMS only
- All email
- individual email account
- multiple selected email accounts

## Sync

Each account has independent:
- enabled state
- sync enabled state
- last sync timestamp
- credentials
- IMAP/SMTP endpoints
- authentication type
- folders

A sync failure on one account must not block other accounts.

## Notifications

Each email account should have its own notification channel or sub-policy so users can:
- mute one account
- choose account-specific sound/vibration
- keep another account active
- disable notifications without disabling sync

## Compose

From-account selection is required whenever two or more enabled accounts exist.

For replies:
- default to the original receiving account.

For new mail:
- default to the user's chosen default send account.

## Security

Credentials remain isolated per account and must be stored via Android Keystore-backed storage.
Room stores only `credentialAlias`, never plaintext secrets.

## Future Maclean Phone integration

The account model remains independent of the Maclean Phone package. During merge, the same account records and transport logic can be retained while the unified inbox adopts the parent application's navigation and CRM adapter.
