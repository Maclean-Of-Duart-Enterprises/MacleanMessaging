# Maclean Messaging — implementation specification

## Functional target

### SIM transport
- SMS send/receive over selected active SIM.
- Explicit subscription ID for dual-SIM correctness.
- Multipart SMS segmentation.
- status lifecycle: queued → sending → sent → delivered/failed.

### MMS
- 1:1 and group MMS.
- text plus image/video/audio/vCard and supported binary attachments.
- carrier APN/MMSC resolution.
- subscription-bound cellular network.
- MM1 encode/decode.
- upload/download retry and failure reporting.
- size policy based on carrier/device constraints.

### Conversation model
- threads derived from Android Telephony provider.
- local metadata keyed by stable message/thread identity.
- drafts, search, archive, pin, favorite, unread/read state.
- batch selection based on stable provider IDs.

### Actions
- reply, forward, copy.
- delete individual/bulk.
- mark read/unread.
- archive/unarchive.
- favorite/unfavorite.
- pin/unpin.
- share/export.

### Contacts / CRM
Standalone:
- Android ContactsContract lookup.

Future Maclean Phone integration:
- adapter interface to Maclean Contacts/CRM database.
- name, photo, all phone numbers, group/favorite metadata.
- no messaging module dependency on CRM storage implementation.

### Notifications
- MessagingStyle notifications.
- quick reply.
- mark read.
- mute per thread.
- per-thread sound/vibration.
- privacy controls for lock screen.

### Spam/blocking
- explicit local blocked list.
- optional Android blocked-number provider integration where permitted.
- local-only heuristic/model scoring.
- never silently delete suspected spam; quarantine by policy.

### Scheduling
- persistent WorkManager jobs.
- SIM selected at scheduling time with fallback policy if SIM disappears.
- user-visible failed-send notification.
- exact-time policy must respect Android background/exact-alarm restrictions.

### Backup
- versioned UTF-8 format.
- SMS first.
- MMS metadata + attachment bundle in later archive format.
- validate before import.
- duplicate detection.
- dry-run import summary.

### Accessibility / appearance
- TalkBack semantics.
- scalable text.
- large controls.
- high contrast.
- visual status indicators.
- configurable text/background/window colors.
- background image copied into private app storage, sampled for memory safety, and rendered below transparent screen content.
- system-status safe area above app toolbars on edge-to-edge Android releases.
- 1–100% opacity controls.
- do not encode status only by color.

### International text
- full Unicode storage/display.
- emoji.
- bidirectional/RTL-safe Compose layout.
- resource architecture for English, Russian, Spanish and additional locales.

### URI intents
Handle:
- sms:
- smsto:
- mms:
- mmsto:

### Emergency-safe behavior
- do not replace Wireless Emergency Alert / Cell Broadcast handling.
- do not present an SMS send as emergency calling.
- do not interfere with the default dialer/emergency call route.
- failures must remain visible to the user.
