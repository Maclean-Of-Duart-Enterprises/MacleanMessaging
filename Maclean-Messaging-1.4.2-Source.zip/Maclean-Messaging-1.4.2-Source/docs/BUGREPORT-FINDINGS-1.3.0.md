# Supplied device bug-report findings for 1.3.0

The report from the DOOGEE Android 15 device does not show a missing default-SMS role. Its role dump names `com.macleanofduartenterprises.macleanmessaging` as the SMS holder, and the package dump shows READ_SMS, RECEIVE_SMS, SEND_SMS, RECEIVE_MMS, and RECEIVE_WAP_PUSH granted.

At 23:55:43, the app's outgoing MMS request acquired Android's cellular MMS capability for subscription 1, loaded APN `ereseller`, contacted the carrier MMSC, and completed with result `-1` (success) at 23:55:47. The application status broadcast was delivered afterward. This confirms that Android's public `SmsManager.sendMultimediaMessage` path and mobile-data routing were active.

At 23:56:14, Android completed multiple incoming MMS downloads. Each application import then failed with `IllegalStateException: Android could not store an incoming MMS attachment` at `IncomingMmsManager.insertPart`. The failure occurred after the message row and part metadata were created, when the code tried `ContentResolver.openOutputStream` on the vendor provider's returned insertion URI. Version 1.3.0 replaces that operation with canonical MMS-part file descriptors and a vendor-compatible fallback.

The active carrier configuration reports a 307,200-byte maximum MMS size and 640×480 image bounds. A per-operation 2 MiB override can influence Android's request bundle but cannot make the carrier MMSC accept a larger payload. Version 1.3.0 therefore keeps a 2 MiB source-selection limit, prepares still images to fit the encoded carrier envelope, and lets Android retain the SIM/APN limits.

The report contains a MainActivity input-dispatch ANR during the burst of provider changes and concurrent MMS completion/import failures. Version 1.3.0 serializes provider imports, contains status callback failures, and observes/throttles provider refresh only while the activity is visible.
