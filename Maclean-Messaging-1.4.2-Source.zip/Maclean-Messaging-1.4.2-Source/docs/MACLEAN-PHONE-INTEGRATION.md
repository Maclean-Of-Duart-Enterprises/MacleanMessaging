# Maclean Phone integration notes

Maclean Messaging 1.2.9 deliberately keeps the stable application ID
`com.macleanofduartenterprises.macleanmessaging`, its database, Android SMS-role
components, and account storage intact. This keeps the current APK independently
updatable while an all-in-one Maclean Phone shell is developed.

## Existing entry points

- Android `ACTION_SENDTO` with `sms:`, `smsto:`, `mms:`, or `mmsto:` opens the
  SMS/MMS composer and accepts the standard `sms_body` extra.
- An explicit launch of `.ui.MainActivity` with a `mailto:` data URI opens the
  email composer. Keeping this explicit prevents the optional email feature from
  appearing as a system-wide handler before an account is configured.
- Contacts remain sourced from Android's aggregated Contacts provider, so a future
  phone shell and this app can share the same synchronized contact records without
  copying a second contact database.

## Recommended merger boundary

Keep telephony calling, Contacts-provider access, messaging repositories, and
email account/transport code as separate modules behind one Maclean Phone
navigation shell. Preserve the existing messaging database schema and signing
certificate during that migration. The bounded device-thread paging and recycled
conversation adapters in 1.2.9, bulk contact index, and centralized notification preferences are suitable boundaries for a combined phone shell.
The shared Sleek/Utility design-token layer can be reused by the future phone,
calling, contacts, messaging, and email shell while retaining separate per-style
shape, density, palette, durable app-owned background, text-scale, panel-opacity,
and safe-area behavior. The voice recorder,
single playback controller, and original-audio attachment route are also isolated
boundaries suitable for reuse in the combined shell.

Do not rename the package or recreate the database when embedding these features;
either retain this package as the installed messaging component or ship an
explicit, tested data migration and upgrade path.
