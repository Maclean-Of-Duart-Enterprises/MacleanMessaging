# Display styles

Maclean Messaging 1.2.9 exposes two independently persisted rendering profiles under **Settings → Display style and appearance**.

## Sleek

Sleek is the default profile. Its defaults use Comfortable spacing, Rounded message bubbles and cards, Oval controls, 84% message width, two inbox preview lines, soft elevation without hard outlines, and a 12% accent tint on sent messages.

## Utility

Utility preserves the existing compact, direct presentation. Its defaults use Compact spacing, Soft-corner message bubbles and cards, Square controls, 92% message width, two inbox preview lines, visible outlines, no elevation, and no sent-message tint.

## Per-profile controls

Each profile separately stores:

- message-bubble shape: Square, Soft corners, Rounded, or Oval;
- card and panel shape: Square, Soft corners, Rounded, or Oval;
- button and control shape: Square, Soft corners, Rounded, or Oval;
- Compact, Comfortable, or Spacious screen density;
- system text style: System sans, Serif, Monospace, Condensed, Cursive — Script, Cursive — Casual, Calligraphy — Classic, Calligraphy — Flourished, Special — Small caps, Special — Slab serif, Special — Light, or Special — Heavy;
- text format: Regular, Bold, Italic, or Bold italic;
- message width from 70% through 100%;
- one through four inbox preview lines;
- outlines on or off;
- elevation/shadows on or off;
- sent-message accent tint from 0% through 35%.

Selecting **Reset selected style to its defaults** changes only the chosen profile. It does not erase the other profile, palettes, a selected background photo, accessibility values, sort defaults, or notification preferences.

The active profile is consumed by shared rendering helpers, so its tokens apply consistently to the inbox, SMS/MMS and email conversations, settings, contacts, account management, composers, search/input fields, cards, and action controls. Font families are supplied by Android and remain available offline; if an OEM omits a named family, Android safely substitutes its platform fallback. Palette, photo background, text size, background strength, panel opacity, and high-contrast choices remain global and work with either rendering profile.
