# Maclean Messaging 1.2.5 — Build Verification

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name: `1.2.5`
- Version code: `10205`
- Minimum Android API: 29
- Target/compile Android API: 35
- License: GNU AGPLv3 / `AGPL-3.0-only`

## Repairs in this release

- Outgoing SMS is inserted into Android's outbox with the provider-generated thread ID before `SmsManager` transmission. Sent/failed callbacks update that same row, and notification replies now use the same repository path.
- Outgoing MMS receives a matching system-provider row with recipients, UTF-8 text, attachment parts, thread ID, subscription ID, and sent/failed state.
- IMAP synchronization now distinguishes genuinely new unread mail from already-ingested rows instead of reporting the whole fetch window as new.
- Email thread unread totals are rebuilt from the underlying message rows. Each account's existing notification ID now updates to the true unread count or is cancelled at zero.
- Opening an email thread marks its rows read immediately, updates the notification, and then pushes `\\Seen` to IMAP without blocking display. Per-message Mark read/Mark unread performs both the server and local update.
- Deleting synchronized INBOX email applies IMAP `\\Deleted` followed by `EXPUNGE` before removing and tombstoning the local row.
- SMTP Reply and Reply All emit Message-ID, In-Reply-To, and References headers and retain the sent copy in the source conversation. Forward continues through the configured SMTP composer.
- New outgoing-email thread keys include the sending account identity, matching later received replies.
- The supplied 1536 × 1536 icon is packaged byte-for-byte as the launcher icon.

## Completed build checks

- All 55 Kotlin source files compiled without errors using Kotlin 1.9.24 and Java 17 against Android API 35.
- Standalone Android lint completed with 0 errors and 8 non-blocking warnings. The warnings cover the API-inlined notification permission, Android backup metadata, two conservative output-stream checks, one resource reference that standalone lint cannot resolve through the custom provider, the supplied full-square launcher artwork, and two programmatic localization labels.
- Unicode/MIME regression tests passed for accented Latin text, Polish text, Cyrillic, Japanese, emoji, RFC 2047, raw UTF-8 headers, Base64 multipart content, quoted-printable content, ISO-8859-1, and a Unicode attachment filename.
- MIME regression coverage also verified emitted Message-ID, In-Reply-To, and References headers.
- Static regression-path inspection confirmed outgoing SMS/MMS provider insertion, provider thread-ID creation, notification-reply routing, IMAP Seen/Delete/Expunge commands, true sync counting, unread notification updates, and server-backed email action wiring.
- Android resources and manifest linked successfully with Build Tools 35.0.1; D8 release DEX generation completed successfully.
- APK archive integrity and four-byte ZIP alignment verified.
- Package metadata verified as version `1.2.5` / code `10205`, minimum API 29, and target API 35.
- APK Signature Scheme v3 verified with one signer.
- Signing key: 4096-bit RSA.
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`.
- APK SHA-256: `b0a662504a4a8678773ed081b5f98c2a2f2a8686d70789b6f2a4102c5513af7b`.
- APK size: 934,347 bytes.
- Supplied icon and packaged icon SHA-256: `bf1d31f9a3a8d5555417fb303b18d10e55cd404464c564f6ad024376ee39c72e`.
- The signing password and keystore are absent from the release source and APK.
- Database version remains 5 and no table or column definition changed, preserving the existing upgrade path and stored accounts/settings.

## Device/provider-validation boundary

ADB reported no attached Android device or emulator. Installation, in-place upgrade, launcher rendering, UI interaction, and notification lifecycle could therefore not be executed here.

Real-device checks remain for:

- normal, multipart, scheduled, respond-via-message, and notification-reply SMS thread persistence;
- outgoing MMS provider visibility, carrier delivery, media parts, and sent/failed callbacks;
- live IMAP Seen/unseen and permanent-delete behavior for each configured provider;
- SMTP Reply, Reply All, and Forward round trips and server-side threading;
- unread notification updates/cancellation on Android 13–15;
- the supplied icon under the launcher's OEM mask;
- existing dual-SIM, OAuth, contacts, background, accessibility, and carrier/provider behavior.

The APK is build-verified and correctly signed, but it is not called production-verified until these live device, carrier, and provider checks pass.
