# Maclean Messaging 1.3.1 — build verification

Built on 2026-09-13 from the supplied, checksum-verified Maclean Messaging 1.3.0 source and the supplied Android 15 device bug report.

## Release identity

- Application/package ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name/code: `1.3.1` / `10301`
- Minimum/target Android API: 29 / 35
- Signed APK: `Maclean-Messaging-1.3.1-Signed.apk`
- APK size: 1,082,002 bytes
- APK SHA-256: `e2451628f8e307fac425fdaff701821aa6cc8f4ff507b5cd799823b6cae3fcdb`
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`
- Signature: APK Signature Scheme v3, one 4096-bit RSA signer, matching the supplied 1.3.0 APK.

The increased version code, unchanged package ID, and unchanged signer support an in-place update without uninstalling or clearing application data.

## Device-report diagnosis

- The report confirms version code 10300 was installed, Maclean Messaging held Android's default SMS role, all SMS/MMS runtime permissions were granted, and the `write_sms` app-op was allowed.
- `MmsWapPushReceiver` crashed at 23:56:17 and `SmsDeliverReceiver` crashed at 00:23:02 with the same `IllegalStateException: Call while result is not pending`. Both called `setResultCode()` after `goAsync()` had detached the synchronous result.
- At 07:41:13, Android's carrier MMS service started three retained downloads on subscription 1, loaded the `ereseller` APN, obtained the cellular MMS network, and completed all three HTTP transfers successfully.
- At 07:44:22, all three imports failed at `MmsProviderWriter.insertBinaryPart`. The importer classified every part except plain text as binary, including `application/smil`; AOSP's `PduPersister` stores plain text, HTML, and SMIL directly in the MMS part table's `text` column.
- The report recorded successful outgoing SMS and MMS status broadcasts. It also confirms the active carrier's physical MMS envelope remains 307,200 bytes with 640×480 image limits.

## Corrective implementation

- Both protected telephony receivers now set the handled result while the synchronous broadcast result is valid, then call `goAsync()` for durable staging/import work.
- MMS plain text, HTML, and SMIL parts are stored inline; SMIL uses sequence `-1`, matching AOSP ordering, and is not shown as message body text or an attachment.
- Real binary parts try independent output-stream, asset-file, writable-file, and truncate-file strategies using both vendor-returned and canonical MMS part URIs.
- If a vendor MMS provider still refuses every binary stream, an atomic app-private fallback retains the exact bytes and metadata. The attachment remains visible and usable for preview/open/playback, save, share, forward, and deletion inside Maclean Messaging.
- Local fallback media is merged with provider parts and cleaned with message deletion, thread deletion, duplicate replacement, or failed transaction rollback.
- Retained incoming MMS notifications and completed downloads from earlier versions remain recoverable after installing 1.3.1.

## Completed host checks

- All Kotlin production sources compiled with Kotlin 1.9.24, Java 17, and Android API 35.
- 39 workflow, transport-state, role, provider, scheduling, notification, email, voice, receiver-order, MMS-part-policy, and release-contract tests passed.
- Synthetic MM1 Notification.ind and Retrieve.conf parser tests passed, including Unicode plain text, binary JPEG, and plain-text/HTML/SMIL classification.
- Standalone Android lint completed with 0 errors. Its remaining warnings are carried localization/deprecation/static-analysis warnings outside this corrective transport scope.
- AAPT2 resource/manifest linking, D8 release conversion, four-byte ZIP alignment, and APK archive integrity passed with Build Tools 35.0.1.
- APK badging confirms package/version, API levels, launcher, and SMS/MMS/WAP/network/audio/notification permissions.
- Packaged-manifest inspection confirms the protected SMS_DELIVER receiver, protected WAP_PUSH_DELIVER receiver, SENDTO activity for SMS/MMS schemes, and protected RESPOND_VIA_MESSAGE service required for the default-SMS role surface.
- APK Signature Scheme v3 and the expected production certificate were verified after final packaging.

## Device-only validation boundary

No Android handset, active SIM, or carrier MMSC was attached to the build host. The bug-report failures are directly repaired and the release passes host validation, but only a live carrier test can prove device/network interoperability. Install over 1.3.0 without clearing data, open the app once to reconcile retained MMS notifications, and test incoming/outgoing single and multipart SMS plus picture, audio/voice, and multi-attachment MMS in foreground and background. If a carrier operation still fails, capture a new report immediately after the test so the callback and provider logs are retained.
