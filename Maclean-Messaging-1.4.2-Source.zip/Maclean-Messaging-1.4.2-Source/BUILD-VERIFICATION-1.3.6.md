# Maclean Messaging 1.3.6 — build verification

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name/code: `1.3.6` / `10306`
- Minimum/target SDK: Android 10 (API 29) / API 35
- Signed APK: `Maclean-Messaging-1.3.6-Signed.apk`
- APK size: 1,090,194 bytes
- APK SHA-256: `b7316a66e2128048d683f971e0334986abd83a4e7721320a08a06650f7f76175`

## Supplied email failure and repair

- The shared diagnostic reported `IMAP LOGIN failed: A0001 BAD Missing ""` against the configured TLS IMAP account.
- The previous client serialized the username and password directly into one quoted IMAP `LOGIN` command. The replacement first reads server capabilities, prefers continuation-based SASL PLAIN, uses continuation-based SASL LOGIN when advertised, and retains quoted `LOGIN` only as the legacy fallback.
- Password, username, and Unicode/special-character bytes are Base64 encoded for SASL without entering IMAP quoted-string parsing. Host tests cover spaces, quotes, backslashes, Unicode, empty credentials, NUL rejection, UID parsing, flags, and batched UID sets.
- XOAUTH2 now also waits for the server continuation instead of assuming SASL initial-response support.
- Account save/test paths reject blank usernames and report an empty or missing saved password locally with an actionable message.

## Complete-history and performance scope

- IMAP no longer applies the previous newest-250 ceiling. `UID SEARCH ALL` discovers the complete INBOX.
- A fresh/full sync fetches missing messages twelve at a time and ingests every completed batch immediately, bounding memory and allowing the next job to resume from persisted UIDs.
- Routine sync reads a lightweight set of local remote UIDs, downloads only missing message bodies, and refreshes existing `Seen` state in metadata-only batches of up to 250 UIDs.
- A malformed MIME payload is isolated and logged by UID so other batches continue; because the failed UID is not persisted, a later sync can retry it.
- SMS/MMS conversations no longer use the 50-message page or expose Load older. Complete SMS and MMS provider queries plus per-row MMS hydration run on the background executor; an unreadable MMS row is isolated from the rest of the thread.
- The conversation remains a native recycled `ListView`, so complete model history does not create one Android view per message.
- Already-loaded rows are submitted immediately when the active thread refreshes, avoiding a blank conversation while the complete provider snapshot is rebuilt.
- Message sorting and selection continue to update the loaded adapter rather than re-querying the conversation.

## Shape-aware text scope

- Square, Soft corners, Rounded, and Oval selections now choose progressively larger safe content insets for message bubbles, cards/panels, and compose/account text fields.
- SMS/MMS and email bodies use multiline, non-horizontal scrolling, high-quality line breaking, and normal hyphenation. Long links, addresses, and unbroken content wrap instead of crossing the surface boundary.
- Multiline message/email fields and multi-recipient email fields use the same wrapping behavior.
- The 1.3.5 keyboard resize/inset behavior and the independently persisted Top/Bottom reply-location controls remain intact.

## Verification record

- All 69 production Kotlin source files compiled for JVM 17 against Android API 35 with no compiler errors.
- Android Build Tools 35.0.1 compiled and linked resources, generated release DEX, aligned the APK, and passed compressed-archive integrity checks.
- Python host suites passed 45/45 checks: 12 workflow/SQLite, 5 transport-state, and 28 release-contract tests.
- `ImapProtocolTest.kt`, `MmsImageFitPolicyTest.kt`, `MmsPduWriterTest.kt`, and `MmsPduParserTest.kt` all compiled and passed.
- Release contracts verify the absence of the 50-message UI/repository page and 250-email sync cap, complete-thread routing, recycled rows, SASL continuation auth, incremental UID/Seen synchronization, shape-aware padding, wrapping, keyboard insets, reply-location persistence, and version identity.
- Manifest inspection reports package `com.macleanofduartenterprises.macleanmessaging`, version `1.3.6` (`10306`), minimum API 29, target/compile API 35, and launcher activity `.ui.MainActivity`.
- APK Signature Scheme v3 verification passed with one signer.
- Signer certificate SHA-256 is `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`, exactly matching the signed 1.3.5 APK and supporting an in-place update.
- ZIP alignment and archive-integrity checks passed.
- Compiler output contains only pre-existing email-code and Android deprecation warnings; the 1.3.6 changes introduce no compiler errors.

## Device/provider validation still required

This environment has no attached Android handset, active SIM, carrier service, configured email credential, or live mailbox authorization. The following checks are therefore not represented as completed:

- Install 1.3.6 directly over signed 1.3.5 without clearing data and confirm retained conversations, drafts, accounts, credentials, backgrounds, display profiles, and default-SMS role.
- Test the supplied `mail.mcclainfamilies.net:993` TLS account with its real credential and confirm the reported `BAD Missing ""` response is gone; then test SMTP STARTTLS on port 587.
- On a mailbox with more than 250 messages, verify a fresh sync imports the oldest and newest mail, interruption resumes safely, and a second sync downloads only newly arrived bodies while reflecting remote read/unread changes.
- Time complete SMS/MMS histories, including a media-heavy thread, on the affected phone and confirm responsive open, sorting, selection, scrolling, image previews, and memory use.
- Inspect short text, long prose, long URLs, Unicode, email recipients, and compose bodies at every surface shape, width, text scale, and Sleek/Utility profile.
- Recheck bottom and top reply placement with the device's OEM keyboard in portrait/landscape, then exercise real SMS/MMS sends, receives, attachments, voice, scheduling, notifications, and carrier callbacks.

These remaining checks require the user's device, mailbox credentials, or live carrier/provider infrastructure; the APK is build-verified, not represented as live-provider or production verified.
