# Maclean Messaging 1.2.8 — Build Verification

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name: `1.2.8`
- Version code: `10208`
- Minimum Android API: 29
- Target/compile Android API: 35
- License: GNU AGPLv3 / `AGPL-3.0-only`

## Permanent long-thread repair

- SMS/MMS and email conversations use Android `ListView` adapters, so only visible rows are represented by view trees.
- SMS/MMS opens with the 50 newest mixed messages. `Load older messages` requests another bounded page and restores the visible-row anchor.
- SMS and MMS headers are merged chronologically before MMS address, text-part, attachment, size, and preview work is performed only for items in the requested page.
- Sorting reorders the loaded model list in the adapter; individual and bulk selection update adapter state without reopening or rebuilding the complete conversation.
- Email attachment queries are deferred until the corresponding email row is visible.
- MMS image previews are requested only while their rows are bound, guarded against recycled-view mismatch, and retained in a bounded 24 MiB cache.
- Date/time formatters are cached per worker thread, and screen-generation checks discard late asynchronous results after navigation.
- Full SMS/MMS history remains available for explicit copy/download/export operations; it is no longer materialized for ordinary conversation rendering.

## Completed build checks

- All 59 Kotlin source files compiled without errors using Kotlin 1.9.24 and Java 17 against Android API 35.
- Full standalone Android lint completed with 0 errors and 43 non-blocking warnings: conservative resource-close findings on Kotlin `.use` blocks, programmatic localization labels, backup metadata, supplied square launcher art, and a retained legacy XML resource.
- Static source checks confirmed that the former eager `renderDeviceThread` and `renderEmailThread` loops are absent; normal SMS/MMS thread opening calls the bounded `threadPage` path; the complete `thread` path remains only in explicit full-history export.
- Android resources and manifest linked successfully with Build Tools 35.0.1; D8 release DEX generation completed successfully as DEX version 039.
- APK archive integrity and four-byte ZIP alignment verified.
- Package metadata verified as version `1.2.8` / code `10208`, minimum API 29, target API 35.
- APK Signature Scheme v3 verified with one signer.
- Signing key: 4096-bit RSA.
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`.
- APK SHA-256: `2c29b3c0edf7640b64d3ee950428882c2df4bd7029d24631d74a9634ef2f441b`.
- APK size: 987,794 bytes.
- The signing password and keystore are absent from the release source and APK.
- Database version remains 5 and no table or column definition changed, preserving installed accounts, messages, settings, and upgrade data.

## Device-validation boundary

ADB reported no attached Android device or emulator. Installation, in-place upgrade, live ANR/memory profiling, UI interaction, SIM/MMSC transfer, and mail-provider tests could not be executed here.

Real-device checks remain for:

- upgrading from 1.2.7 without losing accounts, messages, notification choices, backgrounds, sorting, or voice data;
- reopening the exact high-volume thread from the supplied bug report and confirming bounded memory, responsive scrolling, selection, sorting, and older-page loading;
- receiving or sending a message while an older page is being loaded, then reopening the thread to confirm complete chronological history;
- scrolling a media-heavy MMS thread rapidly to confirm that recycled previews never display the wrong attachment;
- long email threads with attachments while background synchronization and server-backed read/delete/reply/forward actions are active;
- all previously listed real-device notification, voice, carrier, email-provider, Contacts, background, accessibility, link, Unicode, and OEM tests.

The APK is build-verified and correctly signed. It is not called production-verified until the relevant live device, carrier, and provider checks pass.
