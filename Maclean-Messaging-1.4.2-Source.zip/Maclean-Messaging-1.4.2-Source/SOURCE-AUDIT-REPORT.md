# Maclean Messaging 1.2.0 — Historical Source Audit Report

This document records the pre-build 1.2.0 audit. It is retained for provenance and is superseded for build status and later repair scope by the 1.2.1–1.2.9 changelogs and final verification reports.

## Audit basis

This release source was rebuilt from the preserved 52-file authoritative `Maclean-Messaging-1.2.0-source.zip`. The superseded reconstructed 1.3.0 branch was not used as the project base; only concrete email implementation work was reapplied to the 1.2.0 tree.

## Static source checks

- PASS — `package_identity`
- PASS — `version_1_2_0`
- PASS — `no_notimplementederror`
- PASS — `no_todo_calls`
- PASS — `no_destructive_migration`
- PASS — `keystore`
- PASS — `imap`
- PASS — `smtp`
- PASS — `oauth_pkce`
- PASS — `mime`
- PASS — `attachment_picker`
- PASS — `reply`
- PASS — `reply_all`
- PASS — `forward`
- PASS — `account_management`
- PASS — `oauth_redirect_manifest`
- PASS — `network_permissions`
- PASS — `license_asset`
- PASS — `license_file`

## Release-level email integration verified in source

The source contains reachable UI and implementation paths for:
- Settings → Email Integration → account management;
- add, edit, remove, enable and disable email accounts;
- per-account synchronization toggle;
- default sending account;
- connection testing;
- manual synchronization;
- provider auto-configuration;
- password/app-password credentials;
- OAuth2 Authorization Code + PKCE setup and browser sign-in;
- distributor-owned OAuth client configuration;
- IMAP TLS/STARTTLS and password/XOAUTH2 authentication;
- SMTP TLS/STARTTLS and password/XOAUTH2 authentication;
- MIME parsing and serialization;
- inbound attachment persistence and opening through FileProvider;
- outbound multiple-attachment picker and MIME transmission;
- unified inbox email navigation;
- New Email;
- From / To / Cc / Bcc / subject / body;
- Reply;
- Reply All;
- Forward;
- Sent-message persistence after successful SMTP submission;
- per-account background synchronization and errors;
- readable offline GNU AGPLv3 license.

## What was not falsely certified here

This environment does not have an Android SDK/Gradle wrapper configuration sufficient to produce and install the APK, and it does not have live SIMs, carrier MMS service, or real mail-provider/OAuth credentials.

Therefore the following remain **mandatory build/deployment validation**, not source omissions:
- Gradle/Kotlin/Compose/Room compilation and lint;
- APK signing, install and startup;
- Android default-SMS role;
- live SMS/MMS on target carriers/SIMs;
- live IMAP/SMTP interoperability;
- Gmail/Microsoft OAuth using Maclean-owned OAuth registrations;
- attachment interoperability across providers;
- upgrade migration on a real installed prior database;
- TalkBack/accessibility and device-specific UI validation.

The Work chat build prompt requires those checks before the APK may be described as production-verified.
