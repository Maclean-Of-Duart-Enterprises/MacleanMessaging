# Maclean Messaging 1.2.6 — Build Verification

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name: `1.2.6`
- Version code: `10206`
- Minimum Android API: 29
- Target/compile Android API: 35
- License: GNU AGPLv3 / `AGPL-3.0-only`

## Notification management in this release

- Added Settings → Notifications with a master switch and separate SMS/MMS and email switches.
- Added optional persistent unread alerts. Persistent SMS/MMS alerts clear when their conversation is opened or answered; email alerts continue to reflect the account's actual unread total and clear at zero.
- Added controls for notification previews and the SMS/MMS Quick reply action.
- Added a shortcut to Android's notification controls for per-channel sound, vibration, lock-screen, pop-up, and badge behavior.
- Added a Clear current notifications action.
- Applied persistence and enable/disable changes to already posted message and email notifications.
- Prevented a dismissed, non-persistent email notification from reappearing during routine synchronization unless genuinely new mail arrives.
- Added a direct SMS notification-to-thread route when Android provides the inserted message URI.
- Preserved all earlier SMS/MMS, email, background, contact, sorting, management, and launcher-icon repairs.

## Completed build checks

- All 56 Kotlin source files compiled without errors using Kotlin 1.9.24 and Java 17 against Android API 35.
- Standalone Android lint completed with 0 errors and 7 non-blocking warnings. The warnings cover Android backup metadata, two conservative output-stream checks, one resource reference that standalone lint cannot resolve through the custom provider, the supplied full-square launcher artwork, and two existing programmatic localization labels.
- Static notification-path checks confirmed persisted preferences, SMS/MMS and email suppression, persistent alert flags, no-new-mail repost prevention, Android notification-settings routing, active-alert clearing, and conversation-open cancellation.
- Unicode/MIME regression tests passed, including RFC threading headers and Unicode subject, body, sender, and attachment filename cases.
- Android resources and manifest linked successfully with Build Tools 35.0.1; D8 release DEX generation completed successfully.
- APK archive integrity and four-byte ZIP alignment verified.
- Package metadata verified as version `1.2.6` / code `10206`, minimum API 29, and target API 35.
- APK Signature Scheme v3 verified with one signer.
- Signing key: 4096-bit RSA.
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`.
- APK SHA-256: `e84421c5c4fc405203c5f2263dcd8cdeb353e5fb2c062afb49c4b8ccaa734780`.
- APK size: 938,419 bytes.
- The supplied launcher artwork remains packaged byte-for-byte with SHA-256 `bf1d31f9a3a8d5555417fb303b18d10e55cd404464c564f6ad024376ee39c72e`.
- The signing password and keystore are absent from the release source and APK.
- Database version remains 5 and no table or column definition changed, preserving installed accounts, messages, settings, and the existing upgrade path.

## Device-validation boundary

ADB reported no attached Android device or emulator. Installation, in-place upgrade, visual interaction, and live notification lifecycle tests could therefore not be executed here.

Real-device checks remain for:

- upgrading from 1.2.5 without losing accounts, backgrounds, conversations, or saved sorting;
- Android 13–15 notification permission grant, denial, and later re-enablement;
- swipe behavior with persistent alerts off and non-dismissible behavior with it on;
- clearing persistent SMS/MMS alerts by opening or replying to the associated conversation;
- email unread-count updates across new mail, read, unread, delete, dismissal, sync, and zero-unread states;
- preview and Quick reply controls on the target device's notification shade and lock screen;
- channel sound, vibration, lock-screen, pop-up, and badge choices through Android notification controls;
- live SIM SMS/MMS and configured email-provider behavior.

The APK is build-verified and correctly signed, but it is not called production-verified until these live device, carrier, and provider checks pass.
