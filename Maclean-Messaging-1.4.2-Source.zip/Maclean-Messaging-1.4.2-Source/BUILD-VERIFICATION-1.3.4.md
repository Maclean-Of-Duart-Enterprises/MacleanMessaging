# Maclean Messaging 1.3.4 — build verification

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name/code: `1.3.4` / `10304`
- Minimum/target SDK: Android 10 (API 29) / API 35
- Signed APK: `Maclean-Messaging-1.3.4-Signed.apk`
- APK SHA-256: `394aa6a5a7d0f4ea42a1dfbd800d2177bbda9e7991722118d4e3bb44ef4111f5`

## Streamlined interface scope

- SMS/MMS conversations now contain a compact reply composer on the same page.
- Inline replies retain immediate send, scheduling, draft saving, file/audio attachments, voice recording, and active-SIM selection.
- Quoted replies and compatible text reactions populate the inline composer.
- Permanent selection checkboxes were removed from inbox, SMS/MMS, and email rows.
- Long press and overflow menus retain individual selection; contextual bulk controls appear only while a selection exists.
- The redundant conversation-card Open button and duplicate visible thread-management buttons were removed. Card taps and the toolbar overflow retain those actions.
- Transport, provider, callback, MMS preparation, scheduling, email, notification, appearance, data, and package behavior outside this UI scope remain unchanged.

## Verification record

- All 68 production Kotlin source files compiled for JVM 17 against Android API 35 with no compiler errors.
- Android Build Tools 35.0.1 compiled and linked resources, generated release DEX, aligned the APK, and passed archive-integrity checks.
- Python host suites passed 41/41 checks: 12 workflow/SQLite, 5 transport-state, and 24 release-contract tests.
- `MmsImageFitPolicyTest.kt`, `MmsPduWriterTest.kt`, and `MmsPduParserTest.kt` all compiled and passed.
- The new release contract confirms the inline conversation composer, same-thread reply completion path, quoted-reply routing, absence of permanent selection boxes, and removal of the old visible Reply button.
- Manifest inspection reports package `com.macleanofduartenterprises.macleanmessaging`, version `1.3.4` (`10304`), minimum API 29, target/compile API 35, and launcher activity `.ui.MainActivity`.
- APK Signature Scheme v3 verification passed with one signer.
- Signer certificate SHA-256 is `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`, exactly matching the supplied signed 1.3.3 APK.
- ZIP alignment and compressed-archive integrity checks passed.
- Compiler output contains only the pre-existing email-code, Android deprecation, and parameter-name warnings; no new compile errors were introduced.

## Device-specific verification still required

This environment has no attached Android handset, active SIM, carrier service, microphone, or configured email provider. The following checks therefore remain device-specific and are not represented as completed:

- Install 1.3.4 directly over the signed 1.3.3 APK without clearing data, retain the default-SMS role, and confirm existing conversations/settings remain intact.
- Visually verify the compact inbox and bottom reply composer with the phone's font scale, keyboard, background image, Sleek/Utility styles, and portrait dimensions.
- Exercise tap-to-open, long-press selection, overflow selection, contextual bulk actions, sorting, and accessibility services.
- Send ordinary, multipart, scheduled, dual-SIM, image/file/audio MMS, quoted, reaction, notification, and recorded-voice replies from the inline composer.
- Confirm carrier callbacks, provider rows, Outbox cleanup/failure retention, received SMS/MMS, and email behavior on real services.

Host/static checks and successful compilation establish build integrity but do not substitute for live device, carrier, microphone, or provider testing.
