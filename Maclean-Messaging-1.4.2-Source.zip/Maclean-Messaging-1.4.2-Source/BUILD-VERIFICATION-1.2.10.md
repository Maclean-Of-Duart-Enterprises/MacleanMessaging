# Maclean Messaging 1.2.10 — verification

Built on 2026-09-10. This is a signed corrective release for scheduling, compose menus, drafts, archive/pin, and resend.

## Release identity

- Package/application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name/code: `1.2.10` / `10210`
- Minimum Android API: 29; target/compile API: 35
- APK: `Maclean-Messaging-1.2.10-Signed.apk`
- APK size: 1,036,946 bytes
- APK SHA-256: `d3c79263331569c266e21c62ce82beae656da5d24ac7649453852bc56b82b2f8`
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`
- Signature: APK Signature Scheme v3; one 4096-bit RSA signer, matching the prior documented release certificate.
- License: GNU AGPLv3 / `AGPL-3.0-only`; the offline license remains included.

The version and certificate support installation over the previous Maclean Messaging release without uninstalling it. An actual in-place installation was not performed here.

## Implemented changes

- Native date/time scheduling choices in both SMS/MMS and email composers, with future-time validation and the device's time format/time zone.
- Composer-specific upper-right overflow actions for send, schedule, save/discard draft, attachments, and text editing.
- Device-local autosaved drafts and a durable Outbox, including edit/reschedule/cancel/send-now, visible results, failure messages, and reviewed resend copies.
- Persisted Android jobs, alarm wakeups, optional precise-alarm settings, legacy SMS schedule migration, and reconciliation after boot, app update, or clock/time-zone changes.
- Atomic dispatch claim and guarded editing/deletion: competing triggers cannot both submit the same item. A previous process's interrupted send becomes UNKNOWN and requires user review rather than automatic resend.
- Independent archive and pin flags, reachable from individual, bulk, and conversation menus. Archive is explicitly local to this app, including for email; this release does not add IMAP Archive-folder synchronization.
- Resend from outgoing SMS/MMS and email, retaining originals and available attachments. Recipient fields from new email compose records remain separate; historical email with unknown recipient roles requires review before resend.
- Durable draft/schedule media and separate outgoing-email media copies. Recorded voice previews can be attached to drafts or schedules without transcoding.
- Missing draft attachments produce a repairable error instead of crashing the composer. Missing original SIMs/accounts cannot silently switch the sending identity.
- Schedule dialog surfaces follow the selected appearance so high-contrast text remains visible.

## Completed checks

- All 60 Kotlin source files compiled successfully using Kotlin 1.9.24, Java 17, and Android API 35.
- AAPT2 resource/manifest linking and D8 release bytecode conversion succeeded using Build Tools 35.0.1.
- Standalone Android lint on the shipping sources: **0 errors, 39 warnings**. No findings were suppressed for this release. Warnings comprise 32 localization notices for programmatic English text, three conservative `.use` stream-closure notices, one singleton Context notice (the store explicitly retains only `applicationContext`), and one each for backup metadata, supplied launcher-image shape, and retained unused XML.
- **12 host SQLite regression tests passed**: due-time gating, competing claims, edit/cancel and send races, restart recovery, terminal-state protection, late callbacks, Unicode/recipient payload persistence, stable/non-reused job IDs, deletion, and independent archive/pin persistence.
- Tests execute the production queue schema and guarded SQL predicates with real SQLite connections. They do not execute the Android framework or transport code.
- APK ZIP integrity, four-byte ZIP alignment, package/version/API metadata, and cryptographic signature verified.
- Main `LocalDatabase.kt` is byte-identical to 1.2.9, retaining database version 5. The new workflow database is additive and does not migrate or erase existing message/email tables.
- The supplied launcher icon remains byte-identical to 1.2.9. Display styles, backgrounds, notification preferences, and credential storage remain in the existing components.
- Source packaging excludes private keys, keystores, signing passwords, local SDK/compiler files, intermediate classes, and generated APKs. Source checksums are included in `SHA256SUMS.txt`.
- A reproducible SDK build/signing script is included at `tools/build-release.sh`; it reads signing credentials only from the environment.

## Device-only validation remaining

ADB reported **no attached device or emulator**. Installation/startup, visual picker/menu interaction, live carrier SMS/MMS, SMTP/IMAP operations, exact/inexact alarm timing, reboot/offline behavior, OEM background restrictions, and real attachment-provider tests could not be performed here. The complete focused device checklist is in `docs/COMPOSE-WORKFLOWS.md`.

Android restrictions, unavailable networks/SIMs, a powered-off phone, or force-stop can delay or prevent a scheduled send. SMTP acceptance/carrier submission does not prove recipient delivery. The Outbox distinguishes these states and retains errors for review.

The build and signature are verified; this is not a claim of production validation on the user's phone, carrier, or mail providers.
