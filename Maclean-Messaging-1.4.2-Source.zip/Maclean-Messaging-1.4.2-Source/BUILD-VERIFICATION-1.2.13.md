# Maclean Messaging 1.2.13 — build verification

Built on 2026-09-13. This corrective release repairs crash-safe incoming SMS/MMS delivery, durable carrier retry, and MMS attachment import.

## Release identity

- Application/package ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name/code: `1.2.13` / `10213`
- Minimum/target Android API: 29 / 35
- Signed APK: `Maclean-Messaging-1.2.13-Signed.apk`
- APK size: 1,069,714 bytes
- APK SHA-256: `79312e0561f65d502d45761c0b5060b3e5ff7284409e348464b0d69759413ca1`
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`
- Signature: APK Signature Scheme v3, one 4096-bit RSA signer, matching 1.2.12.

The increasing version code, unchanged package ID, and unchanged signer support an in-place update without uninstalling or clearing app data.

## Receiver repairs

- Fixed the carrier MMS destination URI defect: provider URIs now explicitly identify whether their content belongs in the cache or persistent incoming-MMS directory. Carrier writes can therefore reach the exact file supplied to `SmsManager.downloadMultimediaMessage` instead of being incorrectly redirected to cache and rejected.
- Incoming MMS WAP PDUs are atomically staged before parsing or starting a carrier download. Download, parse, provider-import, and notification failures retain the staged notification for bounded persisted retry rather than losing it or crashing the app.
- Startup and default-SMS-role reconciliation recover interrupted incoming MMS downloads after process death, app update, reboot/startup, or a temporary role/permission/network failure.
- MMS provider insertion is transactional at the application level: a partially inserted message is removed after failure, and incomplete duplicates are removed before a retry. Text, Unicode, image/audio/video, and generic attachment parts remain available to the conversation renderer and management actions.
- Incoming SMS delivery now uses `goAsync()` and moves provider, contact/block-list, and notification work off the broadcast main thread. Malformed PDUs and provider/notification failures are contained so they cannot terminate the process.
- Incoming SMS is atomically staged before provider insertion and is retried by a persisted job. Duplicate detection makes recovery idempotent, and successful provider insertion is retained even if notification posting fails.
- Background application initialization and both SMS/MMS notification paths are guarded so a notification-system problem cannot roll back or crash a successfully received message.

## Completed host checks

- All Kotlin production sources compiled with Kotlin 1.9.24, Java 17, and Android API 35.
- AAPT2 manifest/resource linking, D8 release conversion, ZIP alignment, and APK ZIP integrity passed with Build Tools 35.0.1.
- APK badging confirms package/version, API levels, launcher, and SMS/MMS/WAP/network/audio/notification permissions.
- Packaged manifest inspection confirms `SmsDeliverReceiver`, `MmsWapPushReceiver`, `MmsDownloadReceiver`, `IncomingSmsRetryJobService`, `MmsRetryJobService`, and `PduContentProvider`.
- Standalone Android lint over shipping sources completed with **0 errors and 75 warnings**. Remaining warnings are non-blocking localization, conservative resource-close analysis, backup metadata, one retained XML resource, a context singleton analysis, and launcher-mask guidance.
- **12 workflow SQL tests passed**.
- **5 transport-state tests passed**.
- **13 release-contract tests passed**, including asynchronous SMS delivery, durable SMS/MMS staging, retry services, and explicit provider-root routing.
- Synthetic MM1 Notification.ind and Retrieve.conf parser tests passed, including UTF-8 text and binary JPEG attachment boundaries.
- APK Signature Scheme v3, one signer, certificate identity, four-byte alignment, and archive integrity were verified.

## Device-only boundary

No Android device, active SIM, carrier MMSC, or emulator was attached to this build host. Live installation, role/permission dialogs, actual carrier SMS/MMS receipt, APN/mobile-data behavior, dual-SIM routing, OEM background-process behavior, attachment rendering on the affected handset, and sender/recipient interoperability cannot be truthfully certified here. The code, receiver lifecycle, persistence/retry behavior, parser, packaged components, and signed artifact were host-verified; complete a real inbound SMS plus image/audio MMS test on the affected phone before broad distribution.
