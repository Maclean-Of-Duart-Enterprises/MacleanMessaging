# Maclean Messaging 1.3.5 — build verification

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name/code: `1.3.5` / `10305`
- Minimum/target SDK: Android 10 (API 29) / API 35
- Signed APK: `Maclean-Messaging-1.3.5-Signed.apk`
- APK SHA-256: `1b6930602bd1e5774faaeed5e2d17e64c044f47c79630d7aed0f3833e2de0488`

## Reply-layout scope

- The activity declares `adjustResize` so Android delivers software-keyboard insets to the conversation layout.
- On Android 15+, the root conversation layout applies the larger of the current IME and navigation-bar bottom insets. A bottom reply panel therefore remains above a docked keyboard instead of being covered by it.
- Settings → Display & appearance now includes Message reply location with Bottom of conversation and Top of conversation choices.
- Sleek and Utility keep independent saved reply locations. Both default to Bottom of conversation when no preference exists, preserving the 1.3.4 layout on upgrade.
- The complete composer moves as one unit: message field, Send, attachment/audio choices, voice recorder, active-SIM selector, scheduling, and draft handling remain available in either position.
- All transport, provider, callback, MMS preparation, scheduling, selection, email, notification, appearance, and data code outside this focused change remains intact.

## Verification record

- All 68 production Kotlin source files compiled for JVM 17 against Android API 35 with no compiler errors.
- Android Build Tools 35.0.1 compiled and linked resources, generated release DEX, aligned the APK, and passed compressed-archive integrity checks.
- Python host suites passed 42/42 checks: 12 workflow/SQLite, 5 transport-state, and 25 release-contract tests.
- `MmsImageFitPolicyTest.kt`, `MmsPduWriterTest.kt`, and `MmsPduParserTest.kt` all compiled and passed.
- The release contract verifies `adjustResize`, Android IME inset handling, navigation-inset fallback, persisted top/bottom choices, Bottom as the compatibility default, top reply-host routing, and version identity.
- Manifest inspection reports package `com.macleanofduartenterprises.macleanmessaging`, version `1.3.5` (`10305`), minimum API 29, target/compile API 35, launcher activity `.ui.MainActivity`, and soft-input mode `adjustResize` (`0x10`).
- APK Signature Scheme v3 verification passed with one signer.
- Signer certificate SHA-256 is `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`, exactly matching the signed 1.3.4 APK and supporting an in-place update.
- ZIP alignment and archive-integrity checks passed.
- Compiler output contains only pre-existing email-code and Android deprecation warnings; the 1.3.5 change introduced no compiler errors.

## Device-specific verification still required

This environment has no attached Android handset, active SIM, carrier service, microphone, or configured email provider. The following checks therefore remain device-specific and are not represented as completed:

- Install 1.3.5 directly over signed 1.3.4 without clearing data, retain the default-SMS role, and confirm existing conversations, drafts, accounts, and settings remain intact.
- Open a conversation with Bottom selected, focus the reply field, and confirm the entire composer remains above the phone's docked keyboard in portrait and landscape.
- Switch both Sleek and Utility independently between Top and Bottom, restart the app, and confirm each profile retains its own choice and places the composer correctly.
- Test large font/display scaling, navigation modes, accessibility services, OEM keyboards, and floating/undocked keyboards. Android does not report an IME inset for floating keyboards, so their free-floating position must be checked visually.
- Send ordinary, multipart, scheduled, dual-SIM, image/file/audio MMS, quoted, reaction, notification, and recorded-voice replies from both locations.
- Confirm carrier callbacks, provider rows, Outbox cleanup/failure retention, received SMS/MMS, and email behavior on real services.

The source package does not include a Gradle wrapper or a locally resolved Android Gradle plugin distribution, so no Gradle-model lint result is claimed. Host/static checks and successful release compilation establish build integrity but do not substitute for live device, keyboard, carrier, microphone, or provider testing.
