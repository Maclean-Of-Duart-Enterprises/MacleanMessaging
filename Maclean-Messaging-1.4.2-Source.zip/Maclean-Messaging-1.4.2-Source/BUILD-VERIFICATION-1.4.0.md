# Maclean Messaging 1.4.0 — source verification

## Purpose
This update addresses the observed behavior where Maclean Messaging appeared to require Android/Google Messages. The native transport already existed in 1.3.9; 1.4.0 makes Android default-SMS ownership and required permissions explicit and recoverable from the inbox.

## Release identity
- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version: `1.4.0` (`10400`)
- Minimum SDK: 29
- Target SDK: 35

## Standalone transport contract
- SMS send: Android `SmsManager`
- SMS receive: `Telephony.SMS_DELIVER` receiver
- MMS send: Android `SmsManager.sendMultimediaMessage()`
- MMS receive: `Telephony.WAP_PUSH_DELIVER` receiver and native MMS retrieval/import
- Conversation storage: Android SMS/MMS providers while Maclean Messaging owns the default SMS role
- Google Messages dependency: none

## Device validation required
A real SIM/carrier test remains required. Set Maclean Messaging as Android's default SMS app, grant the requested messaging permissions, disable Google Messages, then verify inbound/outbound SMS and MMS.
