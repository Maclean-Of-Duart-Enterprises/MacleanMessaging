/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.telephony

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.telephony.SubscriptionManager
import com.macleanofduartenterprises.macleanmessaging.model.SimChoice

object SimRepository {
    fun active(context: Context): List<SimChoice> {
        if (context.checkSelfPermission(Manifest.permission.READ_PHONE_STATE)
            != PackageManager.PERMISSION_GRANTED) return emptyList()

        val sm = context.getSystemService(SubscriptionManager::class.java)
        return sm.activeSubscriptionInfoList.orEmpty().map {
            SimChoice(
                subscriptionId = it.subscriptionId,
                slotIndex = it.simSlotIndex,
                carrierName = it.carrierName?.toString().orEmpty(),
                displayName = it.displayName?.toString().orEmpty()
            )
        }
    }
}
