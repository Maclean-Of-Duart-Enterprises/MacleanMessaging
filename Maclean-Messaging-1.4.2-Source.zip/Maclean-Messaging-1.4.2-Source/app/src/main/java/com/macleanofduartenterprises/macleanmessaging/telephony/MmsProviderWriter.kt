/* Maclean Messaging — SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanmessaging.telephony

import android.content.ContentResolver
import android.content.ContentUris
import android.content.ContentValues
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.Log

/** Vendor-tolerant binary MMS-part persistence using Android's canonical MMS provider URIs. */
object MmsProviderWriter {
    private val PARTS_URI: Uri = Uri.parse("content://mms/part")

    fun insertBinaryPart(
        resolver: ContentResolver,
        messageId: Long,
        values: ContentValues,
        data: ByteArray
    ): Uri {
        val nested = Uri.parse("content://mms/$messageId/part")
        val first = resolver.insert(nested, ContentValues(values))
            ?: error("Android did not create an MMS attachment part.")
        if (writeToAny(resolver, candidateUris(first), data)) return canonical(first)

        // Some vendor providers return a nested insertion URI that cannot itself be opened. Remove
        // the incomplete part, then try the canonical part collection with an explicit message id.
        deletePart(resolver, first)
        val rootValues = ContentValues(values).apply { put("mid", messageId) }
        val second = resolver.insert(PARTS_URI, rootValues)
            ?: error("Android did not create a writable MMS attachment part after the nested URI failed.")
        if (writeToAny(resolver, candidateUris(second), data)) return canonical(second)
        deletePart(resolver, second)
        error("Android created an MMS attachment row but exposed no writable file descriptor.")
    }

    private fun writeToAny(
        resolver: ContentResolver,
        candidates: List<Uri>,
        data: ByteArray
    ): Boolean {
        candidates.distinct().forEach { uri ->
            // Keep each strategy independent. Several vendor providers throw from the direct file
            // descriptor API but work through ContentResolver.openOutputStream/asset descriptors.
            val strategies = listOf<() -> Boolean>(
                {
                    resolver.openOutputStream(uri, "w")?.use { it.write(data) } != null
                },
                {
                    resolver.openAssetFileDescriptor(uri, "w")?.use { descriptor ->
                        descriptor.createOutputStream().use { it.write(data) }
                    } != null
                },
                {
                    resolver.openFileDescriptor(uri, "w")?.let { descriptor ->
                        ParcelFileDescriptor.AutoCloseOutputStream(descriptor).use { it.write(data) }
                        true
                    } ?: false
                },
                {
                    resolver.openFileDescriptor(uri, "rwt")?.let { descriptor ->
                        ParcelFileDescriptor.AutoCloseOutputStream(descriptor).use { it.write(data) }
                        true
                    } ?: false
                }
            )
            strategies.forEachIndexed { index, strategy ->
                val completed = runCatching(strategy)
                    .onFailure { Log.w(TAG, "MMS part stream strategy $index failed for $uri", it) }
                    .getOrDefault(false)
                if (completed) return true
            }
        }
        return false
    }

    private fun candidateUris(inserted: Uri): List<Uri> = listOf(inserted, canonical(inserted))

    private fun canonical(inserted: Uri): Uri {
        val id = ContentUris.parseId(inserted)
        return ContentUris.withAppendedId(PARTS_URI, id)
    }

    private fun deletePart(resolver: ContentResolver, inserted: Uri) {
        runCatching { resolver.delete(canonical(inserted), null, null) }
        runCatching { resolver.delete(inserted, null, null) }
    }

    private const val TAG = "MmsProviderWriter"
}
