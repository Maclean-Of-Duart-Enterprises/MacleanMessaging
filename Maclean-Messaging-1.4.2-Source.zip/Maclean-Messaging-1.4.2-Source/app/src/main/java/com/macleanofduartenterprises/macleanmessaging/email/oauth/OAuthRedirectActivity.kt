/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.email.oauth
import android.app.Activity
import android.os.Bundle
import com.macleanofduartenterprises.macleanmessaging.data.LocalDatabase
import com.macleanofduartenterprises.macleanmessaging.util.Async

class OAuthRedirectActivity : Activity() {
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        val uri = intent?.data ?: return finish()
        Async.launch {
            OAuth2Manager(this@OAuthRedirectActivity).consumeRedirect(uri) {
                LocalDatabase.get(this@OAuthRedirectActivity).emailAccountDao().get(it)
            }
            Async.onMain { finish() }
        }
    }
}
