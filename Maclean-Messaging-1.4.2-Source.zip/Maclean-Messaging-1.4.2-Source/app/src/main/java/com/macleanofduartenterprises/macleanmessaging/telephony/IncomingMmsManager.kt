/* Maclean Messaging — SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanmessaging.telephony

import android.app.Activity
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PersistableBundle
import android.provider.Telephony
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import android.util.AtomicFile
import android.util.Log
import com.macleanofduartenterprises.macleanmessaging.blocking.BlockingRepository
import com.macleanofduartenterprises.macleanmessaging.data.DeviceMessageRepository
import com.macleanofduartenterprises.macleanmessaging.files.PduContentProvider
import com.macleanofduartenterprises.macleanmessaging.notifications.MessageNotifier
import com.macleanofduartenterprises.macleanmessaging.system.DefaultSmsRole
import com.macleanofduartenterprises.macleanmessaging.util.Async
import java.io.File
import java.security.MessageDigest

/** Downloads carrier MMS content, decodes it, and commits it to Android's MMS provider. */
object IncomingMmsManager {
    const val ACTION_DOWNLOAD_COMPLETE =
        "com.macleanofduartenterprises.macleanmessaging.MMS_DOWNLOAD_COMPLETE"

    fun receiveNotification(context: Context, pdu: ByteArray, requestedSubscriptionId: Int) {
        val subscriptionId = requestedSubscriptionId.takeIf { it >= 0 }
            ?: SubscriptionManager.getDefaultSmsSubscriptionId()
        val token = stableToken(subscriptionId.toString().toByteArray() + pdu)
        val directory = File(context.filesDir, "incoming-mms").apply { mkdirs() }
        val imported = File(directory, "$token.imported")
        if (imported.exists()) return
        val notificationFile = File(directory, "$token.notification.pdu")
        if (!notificationFile.isFile) writeAtomic(notificationFile, pdu)
        writeAtomic(File(directory, "$token.subscription"), subscriptionId.toString().toByteArray())

        try {
            check(DefaultSmsRole.isDefault(context)) { "Only the active default SMS app may receive MMS." }
            val notification = MmsPduParser.parseNotification(pdu)
            val blocked = notification.sender?.let { sender ->
                runCatching { BlockingRepository.isBlocked(context, sender) }
                    .onFailure { Log.e(TAG, "Blocked-number lookup failed; preserving MMS delivery", it) }
                    .getOrDefault(false)
            } == true
            if (blocked) {
                notificationFile.delete()
                return
            }

            val destination = File(directory, "$token.retrieve.pdu")
            if (destination.length() > 0L) {
                // Android can finish writing the PDU and then kill the process before delivering
                // our callback. Import that durable result instead of leaving it stranded.
                finishDownload(
                    context, token, subscriptionId, notification.sender,
                    Activity.RESULT_OK, 0
                )
                return
            }
            if (destination.exists() && System.currentTimeMillis() - destination.lastModified() < DOWNLOAD_TIMEOUT_MS) return
            writeAtomic(destination, ByteArray(0))

            @Suppress("DEPRECATION")
            val manager = if (Build.VERSION.SDK_INT >= 31) {
                context.getSystemService(SmsManager::class.java).createForSubscriptionId(subscriptionId)
            } else SmsManager.getSmsManagerForSubscriptionId(subscriptionId)
            val destinationUri = PduContentProvider.uriFor(context, destination)
            val completed = PendingIntent.getBroadcast(
                context,
                token.hashCode(),
                Intent(context, MmsDownloadReceiver::class.java).apply {
                    action = ACTION_DOWNLOAD_COMPLETE
                    putExtra(EXTRA_TOKEN, token)
                    putExtra(EXTRA_SUBSCRIPTION_ID, subscriptionId)
                    putExtra(EXTRA_FALLBACK_SENDER, notification.sender)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            manager.downloadMultimediaMessage(
                context,
                notification.contentLocation,
                destinationUri,
                MmsCarrierConfig.operationOverrides(),
                completed
            )
        } catch (error: Throwable) {
            File(directory, "$token.retrieve.pdu").delete()
            scheduleRetry(context, token, subscriptionId)
            throw error
        }
    }

    fun finishDownload(
        context: Context,
        token: String,
        subscriptionId: Int,
        fallbackSender: String?,
        resultCode: Int,
        httpStatus: Int
    ): Boolean = synchronized(IMPORT_LOCK) {
        finishDownloadLocked(context, token, subscriptionId, fallbackSender, resultCode, httpStatus)
    }

    private fun finishDownloadLocked(
        context: Context,
        token: String,
        subscriptionId: Int,
        fallbackSender: String?,
        resultCode: Int,
        httpStatus: Int
    ): Boolean {
        val directory = File(context.filesDir, "incoming-mms")
        val destination = File(directory, "$token.retrieve.pdu")
        if (resultCode != Activity.RESULT_OK) {
            destination.delete()
            File(directory, "$token.error.txt").writeText(
                "MMS download failed: result=$resultCode http=$httpStatus time=${System.currentTimeMillis()}"
            )
            scheduleRetry(context, token, subscriptionId)
            return false
        }
        require(destination.isFile && destination.length() > 0L) {
            "Android reported a successful MMS download but supplied an empty response."
        }
        require(destination.length() <= MmsCarrierConfig.APP_MAX_MESSAGE_BYTES.toLong()) {
            "The downloaded MMS is larger than the supported 2 MiB envelope."
        }
        val retrieved = MmsPduParser.parseRetrieveConf(destination.readBytes())
        val sender = retrieved.sender.ifBlank { fallbackSender.orEmpty() }.ifBlank { "Unknown MMS sender" }
        val blocked = runCatching { BlockingRepository.isBlocked(context, sender) }
            .onFailure { Log.e(TAG, "Blocked-number lookup failed; importing downloaded MMS", it) }
            .getOrDefault(false)
        if (blocked) {
            File(directory, "$token.imported").writeText("blocked")
            File(directory, "$token.notification.pdu").delete()
            destination.delete()
            File(directory, "$token.error.txt").delete()
            File(directory, "$token.retry").delete()
            File(directory, "$token.subscription").delete()
            context.getSystemService(JobScheduler::class.java).cancel(retryJobId(token))
            return true
        }
        val messageUri = insertIncoming(context, retrieved, sender, subscriptionId)
        DeviceMessageRepository.invalidateCaches()
        File(directory, "$token.imported").writeText(messageUri.toString())
        File(directory, "$token.notification.pdu").delete()
        destination.delete()
        File(directory, "$token.error.txt").delete()
        File(directory, "$token.retry").delete()
        File(directory, "$token.subscription").delete()
        context.getSystemService(JobScheduler::class.java).cancel(retryJobId(token))
        val preview = retrieved.text.ifBlank {
            "[MMS with ${retrieved.attachments.size} attachment${if (retrieved.attachments.size == 1) "" else "s"}]"
        }
        runCatching { MessageNotifier.notifyIncoming(context, sender, preview, messageUri.toString()) }
            .onFailure { Log.e(TAG, "Incoming MMS notification failed", it) }
        return true
    }

    fun retry(context: Context, token: String, subscriptionId: Int) {
        val notification = File(context.filesDir, "incoming-mms/$token.notification.pdu")
        if (!notification.isFile) return
        receiveNotification(context, notification.readBytes(), subscriptionId)
    }

    fun retryLater(context: Context, token: String, subscriptionId: Int) {
        File(context.filesDir, "incoming-mms/$token.retrieve.pdu").delete()
        scheduleRetry(context, token, subscriptionId)
    }

    /** Restores retained carrier notifications after process death, app update, or role changes. */
    fun reconcile(context: Context) {
        if (!DefaultSmsRole.isDefault(context)) return
        val directory = File(context.filesDir, "incoming-mms").apply { mkdirs() }
        directory.listFiles { file -> file.name.endsWith(".notification.pdu") }
            .orEmpty()
            .forEach { file ->
                val token = file.name.removeSuffix(".notification.pdu")
                if (!File(directory, "$token.imported").exists()) {
                    // Re-arm records that exhausted retries in an older process. Opening the app,
                    // installing an update, or restoring the default role is an explicit recovery
                    // opportunity and must not leave an MMS permanently stuck.
                    File(directory, "$token.retry").delete()
                    val savedSubscription = File(directory, "$token.subscription")
                        .takeIf(File::isFile)?.readText()?.trim()?.toIntOrNull()
                    scheduleRetry(
                        context.applicationContext,
                        token,
                        savedSubscription ?: SubscriptionManager.getDefaultSmsSubscriptionId()
                    )
                }
            }
    }

    private fun scheduleRetry(context: Context, token: String, subscriptionId: Int) {
        val directory = File(context.filesDir, "incoming-mms").apply { mkdirs() }
        if (!File(directory, "$token.notification.pdu").isFile) return
        val scheduler = context.getSystemService(JobScheduler::class.java)
        val jobId = retryJobId(token)
        if (runCatching { scheduler.allPendingJobs.any { it.id == jobId } }.getOrDefault(false)) return
        val counter = File(directory, "$token.retry")
        val attempt = counter.takeIf(File::isFile)?.readText()?.toIntOrNull()?.plus(1) ?: 1
        if (attempt > MAX_RETRIES) return
        counter.writeText(attempt.toString())
        val delay = RETRY_BASE_DELAY_MS * (1L shl (attempt - 1))
        val job = JobInfo.Builder(jobId, ComponentName(context, MmsRetryJobService::class.java))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_CELLULAR)
            .setMinimumLatency(delay)
            .setPersisted(true)
            .setExtras(PersistableBundle().apply {
                putString(EXTRA_TOKEN, token)
                putInt(EXTRA_SUBSCRIPTION_ID, subscriptionId)
            })
            .build()
        runCatching { scheduler.schedule(job) }
            .onFailure { Log.e(TAG, "Could not schedule incoming MMS retry", it) }
    }

    private fun retryJobId(token: String): Int = RETRY_JOB_BASE or (token.hashCode() and 0x00FFFFFF)

    private fun insertIncoming(
        context: Context,
        message: MmsPduParser.Retrieved,
        sender: String,
        subscriptionId: Int
    ): Uri {
        // A process can die after creating the MMS row but before all attachment parts are stored.
        // Because the private imported marker is absent on this path, replace any provider row for
        // the same carrier message/transaction rather than accepting a potentially partial MMS.
        removeIncompleteDuplicate(context, message)
        val threadId = Telephony.Threads.getOrCreateThreadId(context, sender)
        var inserted: Uri? = null
        var insertedMessageId: Long? = null
        try {
            inserted = context.contentResolver.insert(
                Telephony.Mms.Inbox.CONTENT_URI,
                ContentValues().apply {
                    put(Telephony.Mms.THREAD_ID, threadId)
                    put(Telephony.Mms.DATE, message.dateMillis / 1000L)
                    put(Telephony.Mms.READ, 0)
                    put(Telephony.Mms.SEEN, 0)
                    put(Telephony.Mms.MESSAGE_BOX, Telephony.Mms.MESSAGE_BOX_INBOX)
                    put("m_type", MMS_RETRIEVE_CONF)
                    put("v", MMS_VERSION_1_2)
                    put("ct_t", "application/vnd.wap.multipart.related")
                    put("sub_id", subscriptionId)
                    message.transactionId?.let { put("tr_id", it) }
                    message.messageId?.let { put("m_id", it) }
                    put("m_size", message.parts.sumOf { it.data.size })
                }
            ) ?: error("Android did not create the incoming MMS row.")
            val messageId = ContentUris.parseId(inserted).also { insertedMessageId = it }
            insertAddress(context, messageId, sender)
            message.parts.forEachIndexed { index, part -> insertPart(context, messageId, part, index) }
            return inserted
        } catch (error: Throwable) {
            insertedMessageId?.let { LocalMmsAttachmentStore.deleteMessage(context, it) }
            inserted?.let { runCatching { context.contentResolver.delete(it, null, null) } }
            throw error
        }
    }

    private fun removeIncompleteDuplicate(context: Context, message: MmsPduParser.Retrieved) {
        val identity = when {
            !message.messageId.isNullOrBlank() -> "m_id" to message.messageId
            !message.transactionId.isNullOrBlank() -> "tr_id" to message.transactionId
            else -> return
        }
        runCatching {
            val ids = mutableListOf<Long>()
            context.contentResolver.query(
                Telephony.Mms.CONTENT_URI,
                arrayOf(Telephony.Mms._ID),
                "${identity.first}=?",
                arrayOf(requireNotNull(identity.second)),
                null
            )?.use { cursor -> while (cursor.moveToNext()) ids += cursor.getLong(0) }
            ids.forEach { id ->
                context.contentResolver.delete(ContentUris.withAppendedId(Telephony.Mms.CONTENT_URI, id), null, null)
                LocalMmsAttachmentStore.deleteMessage(context, id)
            }
        }.onFailure { Log.e(TAG, "Could not remove an incomplete duplicate MMS", it) }
    }

    private fun insertAddress(context: Context, messageId: Long, sender: String) {
        context.contentResolver.insert(
            Uri.parse("content://mms/$messageId/addr"),
            ContentValues().apply {
                put("address", sender)
                put("type", MMS_FROM)
                put("charset", MMS_CHARSET_UTF8)
            }
        ) ?: error("Android did not create the incoming MMS sender row.")
    }

    private fun insertPart(
        context: Context,
        messageId: Long,
        part: MmsPduParser.RetrievedPart,
        sequence: Int
    ) {
        val isInlineText = MmsPduParser.isInlineTextPart(part.mimeType)
        val values = ContentValues().apply {
            put("ct", part.mimeType)
            put("name", part.name)
            put("fn", part.name)
            put("cl", part.name)
            part.contentId?.let { put("cid", "<$it>") }
            // AOSP PduPersister uses -1 so presentation.smil sorts before rendered parts.
            put("seq", if (part.mimeType.substringBefore(';').trim().equals("application/smil", true)) -1 else sequence)
            if (isInlineText) {
                put("chset", MMS_CHARSET_UTF8)
                put("text", part.data.toString(Charsets.UTF_8))
            }
        }
        if (isInlineText) {
            context.contentResolver.insert(Uri.parse("content://mms/$messageId/part"), values)
                ?: error("Android did not create an incoming MMS text part.")
        } else {
            runCatching {
                MmsProviderWriter.insertBinaryPart(
                    context.contentResolver, messageId, values, part.data
                )
            }.onFailure {
                Log.w(TAG, "Vendor MMS provider rejected binary part; using durable app storage", it)
            }.getOrElse {
                LocalMmsAttachmentStore.store(
                    context,
                    messageId,
                    sequence,
                    part.mimeType,
                    part.name,
                    part.data
                )
            }
        }
    }

    private fun writeAtomic(file: File, bytes: ByteArray) {
        val atomic = AtomicFile(file)
        val output = atomic.startWrite()
        try {
            output.write(bytes)
            output.fd.sync()
            atomic.finishWrite(output)
        } catch (error: Throwable) {
            atomic.failWrite(output)
            throw error
        }
    }

    private fun stableToken(value: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(value).take(12).joinToString("") { "%02x".format(it) }

    private const val EXTRA_TOKEN = "token"
    private const val EXTRA_SUBSCRIPTION_ID = "subscriptionId"
    private const val EXTRA_FALLBACK_SENDER = "fallbackSender"
    private const val DOWNLOAD_TIMEOUT_MS = 10L * 60L * 1000L
    private const val MMS_FROM = 137
    private const val MMS_RETRIEVE_CONF = 132
    private const val MMS_VERSION_1_2 = 0x12
    private const val MMS_CHARSET_UTF8 = 106
    private const val MAX_RETRIES = 5
    private const val RETRY_BASE_DELAY_MS = 30_000L
    private const val RETRY_JOB_BASE = 0x52000000
    private const val TAG = "IncomingMms"
    private val IMPORT_LOCK = Any()
}

class MmsDownloadReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != IncomingMmsManager.ACTION_DOWNLOAD_COMPLETE) return
        val token = intent.getStringExtra("token") ?: return
        val subscriptionId = intent.getIntExtra("subscriptionId", -1)
        val sender = intent.getStringExtra("fallbackSender")
        val status = resultCode
        val httpStatus = intent.getIntExtra(SmsManager.EXTRA_MMS_HTTP_STATUS, 0)
        val pending = goAsync()
        Async.launchSerial {
            try {
                runCatching {
                    IncomingMmsManager.finishDownload(
                        context.applicationContext, token, subscriptionId, sender, status, httpStatus
                    )
                }.onFailure {
                    // A malformed/truncated response remains available for diagnostics; the
                    // carrier notification is retried by the same bounded job path.
                    Log.e("IncomingMms", "Carrier MMS download could not be imported", it)
                    runCatching {
                        IncomingMmsManager.retryLater(context.applicationContext, token, subscriptionId)
                    }.onFailure { retryError ->
                        Log.e("IncomingMms", "Could not retain the MMS retry", retryError)
                    }
                }
            } finally {
                runCatching { pending.finish() }
                    .onFailure { Log.e("IncomingMms", "Could not finish MMS download callback", it) }
            }
        }
    }
}

class MmsRetryJobService : JobService() {
    @Volatile private var stopped = false

    override fun onStartJob(params: JobParameters): Boolean {
        val token = params.extras.getString("token") ?: return false
        val subscriptionId = params.extras.getInt("subscriptionId", -1)
        stopped = false
        Async.launchSerial {
            try { runCatching { IncomingMmsManager.retry(applicationContext, token, subscriptionId) } }
            finally {
                Async.onMain {
                    if (!stopped) runCatching { jobFinished(params, false) }
                        .onFailure { Log.e("IncomingMms", "Could not finish incoming MMS retry job", it) }
                }
            }
        }
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean {
        stopped = true
        return true
    }
}
