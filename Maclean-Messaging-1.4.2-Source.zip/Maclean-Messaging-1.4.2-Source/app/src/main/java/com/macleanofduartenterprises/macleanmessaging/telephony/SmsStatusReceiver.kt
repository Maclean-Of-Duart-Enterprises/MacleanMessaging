/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 */

package com.macleanofduartenterprises.macleanmessaging.telephony

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Telephony
import android.telephony.SmsManager
import android.util.Log
import com.macleanofduartenterprises.macleanmessaging.data.LocalDatabase
import com.macleanofduartenterprises.macleanmessaging.data.SmsPartAggregate
import com.macleanofduartenterprises.macleanmessaging.util.Async
import com.macleanofduartenterprises.macleanmessaging.workflow.ComposeStore

/** Owns carrier callbacks long enough to update metadata, provider rows, and Outbox atomically. */
class SmsStatusReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val token = intent.getStringExtra("token") ?: return
        val ok = resultCode == Activity.RESULT_OK
        val part = intent.getIntExtra("part", 0)
        val parts = intent.getIntExtra("parts", 1)
        val carrierResult = resultCode
        val pending = goAsync()

        Async.launch {
            try {
                runCatching {
                    val database = LocalDatabase.get(context)
                    val dao = database.messageMetaDao()
                    val previous = dao.get(token)
                    when (intent.action) {
                    SmsSender.ACTION_SENT -> when (database.recordSmsPartResult(
                        token, "SENT", part, parts, ok, carrierResult
                    ).state) {
                        SmsPartAggregate.State.PENDING -> Unit
                        SmsPartAggregate.State.COMPLETE -> {
                            val latestState = dao.get(token)?.state
                            val delivered = latestState == "DELIVERED"
                            val deliveryFailed = latestState == "DELIVERY_FAILED"
                            if (!delivered && !deliveryFailed) dao.updateState(token, "SENT")
                            updateSmsProvider(
                                context, previous?.systemUri, sent = true,
                                delivered = delivered, deliveryFailed = deliveryFailed
                            )
                            ComposeStore.get(context).applyTransportResult(token, "SENT")
                            database.clearSmsPartResults(token, "SENT")
                        }
                        SmsPartAggregate.State.FAILED -> {
                            val latestState = dao.get(token)?.state
                            if (latestState == "DELIVERED" || latestState == "DELIVERY_FAILED") {
                                updateSmsProvider(
                                    context, previous?.systemUri, sent = true,
                                    delivered = latestState == "DELIVERED",
                                    deliveryFailed = latestState == "DELIVERY_FAILED"
                                )
                                ComposeStore.get(context).applyTransportResult(token, "SENT")
                            } else {
                                val reason = smsFailure(carrierResult)
                                dao.updateState(token, "FAILED")
                                updateSmsProvider(context, previous?.systemUri, sent = false, delivered = false)
                                ComposeStore.get(context).applyTransportResult(token, "FAILED", reason)
                            }
                            database.clearSmsPartResults(token)
                        }
                    }

                    SmsSender.ACTION_DELIVERED -> when (database.recordSmsPartResult(
                        token, "DELIVERED", part, parts, ok, carrierResult
                    ).state) {
                        SmsPartAggregate.State.PENDING -> Unit
                        SmsPartAggregate.State.COMPLETE -> {
                            dao.updateState(token, "DELIVERED")
                            updateSmsProvider(context, previous?.systemUri, sent = true, delivered = true)
                            ComposeStore.get(context).applyTransportResult(token, "DELIVERED")
                            database.clearSmsPartResults(token)
                        }
                        SmsPartAggregate.State.FAILED -> {
                            // A delivery-report failure does not undo successful carrier submission.
                            dao.updateState(token, "DELIVERY_FAILED")
                            updateSmsProvider(
                                context, previous?.systemUri, sent = true,
                                delivered = false, deliveryFailed = true
                            )
                            database.clearSmsPartResults(token)
                        }
                    }

                    MmsTransport.ACTION_SENT -> {
                        // RESULT_OK confirms MMSC handoff, not recipient-device delivery.
                        val state = if (ok) "CARRIER_ACCEPTED" else "FAILED"
                        val reason = if (ok) null else mmsFailure(
                            carrierResult,
                            intent.getIntExtra(SmsManager.EXTRA_MMS_HTTP_STATUS, 0)
                        )
                        dao.updateState(token, state)
                        updateMmsProvider(context, previous?.systemUri, ok)
                        ComposeStore.get(context).applyTransportResult(token, state, reason)
                        MmsTransport.deleteCachedPdu(context, token)
                    }
                    }
                }.onFailure { error ->
                    // A carrier callback must never crash the process while the app is backgrounded.
                    // The Android provider row remains recoverable by startup reconciliation.
                    Log.e(TAG, "Could not persist carrier status for $token", error)
                }
            } finally {
                runCatching { pending.finish() }
            }
        }
    }

    private fun updateSmsProvider(
        context: Context,
        value: String?,
        sent: Boolean,
        delivered: Boolean,
        deliveryFailed: Boolean = false
    ) {
        val uri = canonicalUri(value, Telephony.Sms.CONTENT_URI) ?: return
        runCatching {
            context.contentResolver.update(uri, ContentValues().apply {
                put(
                    Telephony.Sms.TYPE,
                    if (sent) Telephony.Sms.MESSAGE_TYPE_SENT else Telephony.Sms.MESSAGE_TYPE_FAILED
                )
                put(Telephony.Sms.STATUS, when {
                    deliveryFailed -> Telephony.Sms.STATUS_FAILED
                    delivered -> Telephony.Sms.STATUS_COMPLETE
                    sent -> Telephony.Sms.STATUS_PENDING
                    else -> Telephony.Sms.STATUS_FAILED
                })
            }, null, null)
        }
    }

    private fun updateMmsProvider(context: Context, value: String?, sent: Boolean) {
        val uri = canonicalUri(value, Telephony.Mms.CONTENT_URI) ?: return
        runCatching {
            context.contentResolver.update(uri, ContentValues().apply {
                put(Telephony.Mms.MESSAGE_BOX, if (sent) Telephony.Mms.MESSAGE_BOX_SENT else MMS_BOX_FAILED)
            }, null, null)
        }
    }

    private fun smsFailure(code: Int): String = when (code) {
        SmsManager.RESULT_ERROR_NO_SERVICE -> "No cellular service was available."
        SmsManager.RESULT_ERROR_RADIO_OFF -> "The cellular radio was off."
        SmsManager.RESULT_ERROR_NULL_PDU -> "Android could not create the SMS payload."
        SmsManager.RESULT_ERROR_LIMIT_EXCEEDED -> "Android blocked the send because the SMS limit was exceeded."
        SmsManager.RESULT_ERROR_FDN_CHECK_FAILURE -> "The SIM fixed-dialing rules rejected the recipient."
        else -> "The carrier rejected the SMS (Android result $code)."
    }

    private fun mmsFailure(code: Int, http: Int): String = buildString {
        append("The carrier rejected the MMS (Android result ").append(code)
        if (http > 0) append(", HTTP ").append(http)
        append("). Check mobile data and the carrier APN, then retry.")
    }

    private fun canonicalUri(value: String?, base: Uri): Uri? {
        val original = value?.let(Uri::parse) ?: return null
        val id = runCatching { ContentUris.parseId(original) }.getOrNull() ?: return original
        return ContentUris.withAppendedId(base, id)
    }

    private companion object {
        const val TAG = "SmsStatus"
        const val MMS_BOX_FAILED = 5
    }
}
