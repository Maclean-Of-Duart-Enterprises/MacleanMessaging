/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 */

package com.macleanofduartenterprises.macleanmessaging.system

import android.Manifest
import android.app.AppOpsManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Process
import com.macleanofduartenterprises.macleanmessaging.telephony.MmsWapPushReceiver
import com.macleanofduartenterprises.macleanmessaging.telephony.RespondViaMessageService
import com.macleanofduartenterprises.macleanmessaging.telephony.SmsDeliverReceiver
import com.macleanofduartenterprises.macleanmessaging.ui.MainActivity

/** Verifies the complete local Android contract required for operation without another SMS app. */
data class SmsRuntimeReadiness(
    val roleHeld: Boolean,
    val missingPermissions: List<String>,
    val providerWriteAvailable: Boolean,
    val componentsEnabled: Boolean
) {
    val operational: Boolean
        get() = roleHeld && missingPermissions.isEmpty() && providerWriteAvailable && componentsEnabled

    val explanation: String
        get() = when {
            !roleHeld -> "Maclean Messaging is not the active Android SMS app."
            missingPermissions.isNotEmpty() -> "Messaging permissions are incomplete: ${missingPermissions.joinToString()}."
            !componentsEnabled -> "Android has disabled one or more required SMS/MMS components."
            !providerWriteAvailable -> "Android has not enabled SMS-provider write access for the selected default app."
            else -> "Ready. Maclean Messaging owns SMS/MMS delivery, storage, and sending without another messaging app."
        }

    companion object {
        private val requiredPermissions = listOf(
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.RECEIVE_MMS,
            Manifest.permission.RECEIVE_WAP_PUSH
        )

        fun inspect(context: Context): SmsRuntimeReadiness {
            val roleHeld = DefaultSmsRole.isDefault(context)
            val missing = requiredPermissions.filter {
                context.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
            }.map { it.substringAfterLast('.') }
            return SmsRuntimeReadiness(
                roleHeld = roleHeld,
                missingPermissions = missing,
                providerWriteAvailable = !roleHeld || writeSmsAppOpAvailable(context),
                componentsEnabled = requiredComponentsEnabled(context)
            )
        }

        private fun writeSmsAppOpAvailable(context: Context): Boolean {
            val manager = context.getSystemService(AppOpsManager::class.java) ?: return true
            val mode = runCatching {
                manager.unsafeCheckOpNoThrow(
                    WRITE_SMS_APP_OP,
                    Process.myUid(),
                    context.packageName
                )
            }.getOrDefault(AppOpsManager.MODE_DEFAULT)
            return mode != AppOpsManager.MODE_IGNORED && mode != AppOpsManager.MODE_ERRORED
        }

        @Suppress("DEPRECATION")
        private fun requiredComponentsEnabled(context: Context): Boolean {
            val manager = context.packageManager
            val components = listOf(
                ComponentName(context, MainActivity::class.java) to ComponentKind.ACTIVITY,
                ComponentName(context, SmsDeliverReceiver::class.java) to ComponentKind.RECEIVER,
                ComponentName(context, MmsWapPushReceiver::class.java) to ComponentKind.RECEIVER,
                ComponentName(context, RespondViaMessageService::class.java) to ComponentKind.SERVICE
            )
            return components.all { (component, kind) ->
                val declaredEnabled = runCatching {
                    when (kind) {
                        ComponentKind.ACTIVITY -> manager.getActivityInfo(component, 0).enabled
                        ComponentKind.RECEIVER -> manager.getReceiverInfo(component, 0).enabled
                        ComponentKind.SERVICE -> manager.getServiceInfo(component, 0).enabled
                    }
                }.getOrDefault(false)
                val state = manager.getComponentEnabledSetting(component)
                declaredEnabled && state != PackageManager.COMPONENT_ENABLED_STATE_DISABLED &&
                    state != PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER &&
                    state != PackageManager.COMPONENT_ENABLED_STATE_DISABLED_UNTIL_USED
            }
        }

        private enum class ComponentKind { ACTIVITY, RECEIVER, SERVICE }
        private const val WRITE_SMS_APP_OP = "android:write_sms"
    }
}
