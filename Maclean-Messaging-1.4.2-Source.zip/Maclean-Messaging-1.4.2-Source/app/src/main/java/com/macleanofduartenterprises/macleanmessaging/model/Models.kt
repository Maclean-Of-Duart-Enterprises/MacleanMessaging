/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.model

enum class Transport { SMS, MMS }
enum class Direction { INCOMING, OUTGOING }
enum class DeliveryState { DRAFT, QUEUED, SENDING, SENT, DELIVERED, FAILED, RECEIVED }

data class SimChoice(
    val subscriptionId: Int,
    val slotIndex: Int,
    val carrierName: String,
    val displayName: String
)

data class Attachment(
    val uri: String,
    val mimeType: String,
    val displayName: String? = null,
    val sizeBytes: Long? = null
)

data class OutgoingMessage(
    val recipients: List<String>,
    val body: String,
    val attachments: List<Attachment> = emptyList(),
    val subscriptionId: Int,
    val requestDeliveryReport: Boolean = true
) {
    val transport: Transport
        get() = if (attachments.isEmpty() && recipients.size == 1) Transport.SMS else Transport.MMS
}
