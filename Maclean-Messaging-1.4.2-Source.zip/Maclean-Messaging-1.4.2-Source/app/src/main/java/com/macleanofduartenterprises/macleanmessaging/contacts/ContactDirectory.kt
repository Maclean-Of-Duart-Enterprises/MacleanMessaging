/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 */

package com.macleanofduartenterprises.macleanmessaging.contacts

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.PhoneNumberUtils

data class ContactEntry(
    val id: Long,
    val displayName: String,
    val photoUri: Uri?,
    val phoneNumbers: List<String>,
    val emailAddresses: List<String>
) {
    val isMessageable: Boolean get() = phoneNumbers.isNotEmpty() || emailAddresses.isNotEmpty()
}

/**
 * Reads Android's aggregated Contacts provider on demand. Because this is not a private copy,
 * changes delivered by Google, Exchange, CardDAV, a SIM, or the system Contacts app appear on
 * the next refresh without an app-specific import or stale synchronization database.
 */
class ContactDirectory(private val context: Context) {
    fun all(): List<ContactEntry> {
        check(context.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            "Contacts permission is required to browse recipients."
        }

        val contacts = linkedMapOf<Long, MutableContact>()
        context.contentResolver.query(
            ContactsContract.Contacts.CONTENT_URI,
            arrayOf(
                ContactsContract.Contacts._ID,
                ContactsContract.Contacts.DISPLAY_NAME_PRIMARY,
                ContactsContract.Contacts.PHOTO_URI
            ),
            null,
            null,
            "${ContactsContract.Contacts.DISPLAY_NAME_PRIMARY} COLLATE LOCALIZED ASC"
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                val id = cursor.getLong(0)
                contacts[id] = MutableContact(
                    id = id,
                    displayName = cursor.getString(1).orEmpty().ifBlank { "Unnamed contact" },
                    photoUri = cursor.getString(2)?.let(Uri::parse)
                )
            }
        }

        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null,
            null,
            null
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                val number = cursor.getString(1).orEmpty().trim()
                if (number.isNotBlank()) contacts[cursor.getLong(0)]?.phones?.add(number)
            }
        }

        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Email.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Email.CONTACT_ID,
                ContactsContract.CommonDataKinds.Email.ADDRESS
            ),
            null,
            null,
            null
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                val address = cursor.getString(1).orEmpty().trim()
                if (address.isNotBlank()) contacts[cursor.getLong(0)]?.emails?.add(address)
            }
        }

        return contacts.values.map { contact ->
            ContactEntry(
                id = contact.id,
                displayName = contact.displayName,
                photoUri = contact.photoUri,
                phoneNumbers = contact.phones.distinctBy {
                    PhoneNumberUtils.normalizeNumber(it).ifBlank { it.lowercase() }
                },
                emailAddresses = contact.emails.distinctBy(String::lowercase)
            )
        }.filter(ContactEntry::isMessageable)
    }

    private data class MutableContact(
        val id: Long,
        val displayName: String,
        val photoUri: Uri?,
        val phones: MutableList<String> = mutableListOf(),
        val emails: MutableList<String> = mutableListOf()
    )
}
