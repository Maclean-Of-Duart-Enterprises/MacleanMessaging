/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.blocking

import android.content.Context
import android.telephony.PhoneNumberUtils
import com.macleanofduartenterprises.macleanmessaging.data.BlockedEntity
import com.macleanofduartenterprises.macleanmessaging.data.LocalDatabase

object BlockingRepository {
    private fun normalize(address: String): String =
        PhoneNumberUtils.normalizeNumber(address)

    fun isBlocked(context: Context, address: String): Boolean =
        LocalDatabase.get(context).blockedDao().contains(normalize(address))

    suspend fun block(context: Context, address: String, reason: String? = null) {
        LocalDatabase.get(context).blockedDao()
            .block(BlockedEntity(normalize(address), reason))
    }

    suspend fun unblock(context: Context, address: String) {
        LocalDatabase.get(context).blockedDao().unblock(normalize(address))
    }
}
