/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.email

import android.content.Context
import com.macleanofduartenterprises.macleanmessaging.data.LocalDatabase
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailAccountEntity
import com.macleanofduartenterprises.macleanmessaging.email.notifications.EmailNotifier
import com.macleanofduartenterprises.macleanmessaging.email.security.AndroidKeystoreCredentialStore
import com.macleanofduartenterprises.macleanmessaging.email.sync.EmailSyncWorker
import com.macleanofduartenterprises.macleanmessaging.email.transport.ImapTransport
import com.macleanofduartenterprises.macleanmessaging.email.transport.SmtpTransport
import java.util.UUID

data class NewEmailAccount(
    val displayName: String,
    val emailAddress: String,
    val incomingHost: String,
    val incomingPort: Int = 993,
    val incomingSecurity: String = "TLS",
    val outgoingHost: String,
    val outgoingPort: Int = 587,
    val outgoingSecurity: String = "STARTTLS",
    val username: String,
    val authType: String = "PASSWORD",
    val secret: CharArray? = null,
    val oauthClientId: String? = null,
    val oauthAuthorizeEndpoint: String? = null,
    val oauthTokenEndpoint: String? = null,
    val oauthScopes: String? = null,
    val signature: String? = null
)

class EmailAccountService(private val context: Context) {
    private val db = LocalDatabase.get(context)
    private val secrets = AndroidKeystoreCredentialStore(context)

    suspend fun listAll() = db.emailAccountDao().all()
    suspend fun listEnabled() = db.emailAccountDao().enabled()
    suspend fun get(id: String) = db.emailAccountDao().get(id)

    suspend fun add(request: NewEmailAccount): EmailAccountEntity {
        validate(request)
        val id = UUID.randomUUID().toString()
        val first = db.emailAccountDao().enabledCount() == 0
        val alias = when (request.authType) {
            "PASSWORD" -> {
                val value = requireNotNull(request.secret) { "Password/app password is required." }
                "password-$id".also { secrets.put(it, value) }
            }
            "OAUTH2" -> "oauth-$id"
            else -> error("Unsupported authentication type.")
        }
        val entity = EmailAccountEntity(
            id=id, displayName=request.displayName.trim(), emailAddress=request.emailAddress.trim(),
            incomingHost=request.incomingHost.trim(), incomingPort=request.incomingPort,
            incomingSecurity=request.incomingSecurity, outgoingHost=request.outgoingHost.trim(),
            outgoingPort=request.outgoingPort, outgoingSecurity=request.outgoingSecurity,
            username=request.username.trim(), authType=request.authType, credentialAlias=alias,
            oauthClientId=request.oauthClientId?.trim()?.takeIf(String::isNotEmpty),
            oauthAuthorizeEndpoint=request.oauthAuthorizeEndpoint?.trim()?.takeIf(String::isNotEmpty),
            oauthTokenEndpoint=request.oauthTokenEndpoint?.trim()?.takeIf(String::isNotEmpty),
            oauthScopes=request.oauthScopes?.trim()?.takeIf(String::isNotEmpty),
            enabled=true, syncEnabled=true, isDefaultSendAccount=first, signature=request.signature
        )
        db.emailAccountDao().upsert(entity)
        if (first) db.emailAccountDao().makeDefaultSendAccount(id)
        EmailSyncWorker.reconcile(context)
        return entity
    }

    suspend fun update(
        account: EmailAccountEntity,
        replacementSecret: CharArray? = null
    ) {
        validateEntity(account)
        if (replacementSecret != null) {
            val alias = account.credentialAlias ?: "password-${account.id}"
            secrets.put(alias, replacementSecret)
            db.emailAccountDao().upsert(account.copy(credentialAlias=alias))
        } else db.emailAccountDao().upsert(account)
        EmailSyncWorker.reconcile(context)
    }

    suspend fun test(accountId: String): Result<Unit> {
        val account = get(accountId)
            ?: return Result.failure(IllegalArgumentException("Email account no longer exists."))
        val i = ImapTransport(context).testConnection(account)
        if (i.isFailure) return i
        return SmtpTransport(context).testConnection(account)
    }

    suspend fun setDefaultSendAccount(id: String) {
        val account = requireNotNull(get(id))
        require(account.enabled) { "Enable this account before making it default." }
        db.emailAccountDao().makeDefaultSendAccount(id)
    }

    suspend fun setEnabled(id: String, value: Boolean) {
        val account = get(id) ?: return
        db.emailAccountDao().upsert(account.copy(enabled=value))
        if (!value && account.isDefaultSendAccount) {
            db.emailAccountDao().clearDefaultSendAccount()
            db.emailAccountDao().enabled().firstOrNull()?.let { db.emailAccountDao().makeDefaultSendAccount(it.id) }
        }
        EmailSyncWorker.reconcile(context)
    }

    suspend fun setSyncEnabled(id: String, value: Boolean) {
        val account = get(id) ?: return
        db.emailAccountDao().upsert(account.copy(syncEnabled=value))
        EmailSyncWorker.reconcile(context)
    }

    suspend fun remove(id: String) {
        val account = get(id) ?: return
        EmailNotifier.cancelAccount(context, id)
        account.credentialAlias?.let(secrets::remove)
        db.emailAttachmentDao().deleteForAccount(id)
        db.emailMessageDao().deleteForAccount(id)
        db.emailThreadDao().deleteForAccount(id)
        db.emailAccountDao().delete(id)
        if (account.isDefaultSendAccount) {
            db.emailAccountDao().enabled().firstOrNull()?.let { db.emailAccountDao().makeDefaultSendAccount(it.id) }
        }
        EmailSyncWorker.reconcile(context)
    }

    private fun validate(r: NewEmailAccount) {
        require(Regex("""^[^@\s]+@[^@\s]+\.[^@\s]+$""").matches(r.emailAddress.trim())) { "Enter a valid email address." }
        require(r.incomingHost.isNotBlank() && r.outgoingHost.isNotBlank()) { "IMAP and SMTP servers are required." }
        require(r.username.isNotBlank()) { "Email username is required." }
        require(r.incomingPort in 1..65535 && r.outgoingPort in 1..65535)
        require(r.incomingSecurity in setOf("TLS", "STARTTLS") && r.outgoingSecurity in setOf("TLS", "STARTTLS")) {
            "TLS or STARTTLS is required for email accounts."
        }
        require(r.authType in setOf("PASSWORD","OAUTH2"))
        if (r.authType == "OAUTH2") {
            require(!r.oauthClientId.isNullOrBlank()) { "OAuth client ID is required." }
            require(!r.oauthAuthorizeEndpoint.isNullOrBlank() && !r.oauthTokenEndpoint.isNullOrBlank())
        }
    }

    private fun validateEntity(a: EmailAccountEntity) {
        require(a.emailAddress.contains("@"))
        require(a.username.isNotBlank()) { "Email username is required." }
        require(a.incomingHost.isNotBlank() && a.outgoingHost.isNotBlank()) { "IMAP and SMTP servers are required." }
        require(a.incomingPort in 1..65535 && a.outgoingPort in 1..65535)
        require(a.incomingSecurity in setOf("TLS", "STARTTLS") && a.outgoingSecurity in setOf("TLS", "STARTTLS")) {
            "TLS or STARTTLS is required for email accounts."
        }
    }
}
