/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.unified

import android.content.Context
import com.macleanofduartenterprises.macleanmessaging.contacts.ContactIndex
import com.macleanofduartenterprises.macleanmessaging.data.DeviceMessageRepository
import com.macleanofduartenterprises.macleanmessaging.data.LocalDatabase
import org.json.JSONArray
import com.macleanofduartenterprises.macleanmessaging.workflow.ComposeStore

class UnifiedInboxRepository(private val context: Context) {

    suspend fun emailEnabled(): Boolean =
        LocalDatabase.get(context).emailAccountDao().enabledCount() > 0

    suspend fun conversations(
        includeArchived: Boolean = false,
        filter: UnifiedInboxFilter = UnifiedInboxFilter(),
        emailEnabledOverride: Boolean? = null
    ): List<UnifiedConversation> {
        val contacts = ContactIndex.load(context)
        val sms = loadSmsThreads(contacts)
        val email = if (emailEnabledOverride ?: emailEnabled()) {
            loadEmailThreads(includeArchived, contacts)
        } else emptyList()

        val flags = ComposeStore.get(context).flags()
        return (sms + email).map { item ->
            val saved = flags[item.stableId]
            item.copy(archived = saved?.first ?: item.archived, pinned = saved?.second ?: item.pinned)
        }
            .filter { includeArchived || !it.archived }
            .filter(filter::allows)
            .sortedWith(
                compareByDescending<UnifiedConversation> { it.pinned }
                    .thenByDescending { it.timestamp }
            )
    }

    private fun loadSmsThreads(contacts: ContactIndex): List<UnifiedConversation> {
        return DeviceMessageRepository(context).conversations().map { conversation ->
            val latest = conversation.latest
            val addresses = latest.address.split(',').map(String::trim).filter(String::isNotBlank)
            val participants = addresses.map { address ->
                val contact = contacts.resolve(address)
                UnifiedParticipant(
                    id = address,
                    displayName = contact?.displayName,
                    address = address,
                    photoUri = contact?.photoUri?.toString()
                )
            }
            val title = participants.joinToString(", ") { it.displayName ?: it.address }
            UnifiedConversation(
                stableId = "sms:${conversation.threadId}",
                transport = latest.transport,
                participants = participants,
                title = title.ifBlank { "Unknown sender" },
                preview = latest.body,
                timestamp = latest.date,
                unreadCount = conversation.unreadCount,
                hasSavedContact = participants.any { it.displayName != null }
            )
        }
    }

    private suspend fun loadEmailThreads(includeArchived: Boolean, contacts: ContactIndex): List<UnifiedConversation> {
        val db = LocalDatabase.get(context)
        val accounts = db.emailAccountDao().enabled()
        return buildList {
            for (account in accounts) {
                val threads = db.emailThreadDao().list(account.id, false) +
                    if (includeArchived) db.emailThreadDao().list(account.id, true) else emptyList()
                threads.forEach { thread ->
                    val addresses = parseAddresses(thread.participantsJson)
                    val contactNames = addresses
                        .filterNot { it.equals(account.emailAddress, true) }
                        .associateWith(contacts::resolve)
                    val participants = (addresses + account.emailAddress).distinctBy(String::lowercase).map { address ->
                        val contact = contactNames[address]
                        UnifiedParticipant(
                            id = address,
                            displayName = if (address.equals(account.emailAddress, true)) account.displayName else contact?.displayName,
                            address = address,
                            photoUri = contact?.photoUri?.toString()
                        )
                    }
                    add(
                        UnifiedConversation(
                            stableId = "email:${thread.stableId}",
                            transport = CommunicationTransport.EMAIL,
                            participants = participants,
                            title = thread.subject?.takeIf { it.isNotBlank() } ?: "(No subject)",
                            preview = thread.preview,
                            timestamp = thread.timestamp,
                            unreadCount = thread.unreadCount,
                            pinned = thread.pinned,
                            favorite = thread.favorite,
                            archived = thread.archived,
                            accountId = account.id,
                            hasSavedContact = contactNames.values.any { it != null }
                        )
                    )
                }
            }
        }
    }

    private fun parseAddresses(json: String): List<String> = runCatching {
        val array = JSONArray(json)
        (0 until array.length()).map { array.getString(it) }.filter(String::isNotBlank)
    }.getOrDefault(emptyList())
}
