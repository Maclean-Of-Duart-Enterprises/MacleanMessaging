/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.telephony

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.telephony.SubscriptionManager
import android.util.Log
import com.macleanofduartenterprises.macleanmessaging.system.DefaultSmsRole
import com.macleanofduartenterprises.macleanmessaging.util.Async

class SmsDeliverReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_DELIVER_ACTION) return
        if (!DefaultSmsRole.isDefault(context)) return
        val messages = runCatching { Telephony.Sms.Intents.getMessagesFromIntent(intent) }
            .onFailure { Log.e(TAG, "Android supplied an unreadable SMS delivery", it) }
            .getOrElse {
                setResultCode(Telephony.Sms.Intents.RESULT_SMS_GENERIC_ERROR)
                return
            }
        if (messages.isEmpty()) return

        val address = messages.first().displayOriginatingAddress.orEmpty()
        val body = messages.joinToString(separator = "") { it.displayMessageBody.orEmpty() }
        val subscriptionId = intent.getIntExtra(
            SubscriptionManager.EXTRA_SUBSCRIPTION_INDEX,
            intent.getIntExtra("subscription", SubscriptionManager.INVALID_SUBSCRIPTION_ID)
        )
        val timestamp = messages.minOf { it.timestampMillis }

        // Database, provider, contact, and notification work must not run on Android's broadcast
        // main thread. The manager stages the text before committing it to the SMS provider.
        // A broadcast's synchronous PendingResult is detached by goAsync(). Acknowledge it first;
        // calling setResultCode afterward crashes Android 15 with "result is not pending".
        setResultCode(Telephony.Sms.Intents.RESULT_SMS_HANDLED)
        val pending = goAsync()
        Async.launchSerial {
            try {
                runCatching {
                    IncomingSmsManager.accept(
                        context.applicationContext,
                        address,
                        body,
                        subscriptionId,
                        timestamp
                    )
                }.onFailure { Log.e(TAG, "Incoming SMS delivery failed before staging", it) }
            } finally {
                runCatching { pending.finish() }
                    .onFailure { Log.e(TAG, "Could not finish incoming SMS broadcast", it) }
            }
        }
    }

    private companion object {
        const val TAG = "SmsDeliverReceiver"
    }
}
