/* Maclean Messaging — SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanmessaging.workflow

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.provider.OpenableColumns
import com.macleanofduartenterprises.macleanmessaging.files.PduContentProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Reviewable compose data; transport credentials never enter this store. */
data class ComposePayload(
    val kind: String = "MESSAGE",
    val to: List<String> = emptyList(),
    val cc: List<String> = emptyList(),
    val bcc: List<String> = emptyList(),
    val subject: String = "",
    val body: String = "",
    val accountId: String? = null,
    val subscriptionId: Int = -1,
    val mode: String = "NEW",
    val sourceMessageId: String? = null,
    val attachments: List<String> = emptyList()
) {
    fun hasContent(): Boolean = (to + cc + bcc).isNotEmpty() || subject.isNotBlank() || body.isNotBlank() || attachments.isNotEmpty()
    fun validate() {
        require(to.isNotEmpty() || kind == "EMAIL" && (cc + bcc).isNotEmpty()) { "Enter at least one recipient." }
        if (kind == "EMAIL") {
            require(!accountId.isNullOrBlank()) { "Choose an enabled email account." }
            require((to + cc + bcc).all { android.util.Patterns.EMAIL_ADDRESS.matcher(it).matches() }) { "Check the email recipient addresses." }
        } else {
            require(subscriptionId >= 0) { "Choose an active SIM." }
            require(body.isNotBlank() || attachments.isNotEmpty()) { "Write a message or attach a file." }
        }
    }
    fun json(): String = JSONObject().put("kind", kind).put("to", JSONArray(to)).put("cc", JSONArray(cc))
        .put("bcc", JSONArray(bcc)).put("subject", subject).put("body", body).put("accountId", accountId)
        .put("subscriptionId", subscriptionId).put("mode", mode).put("sourceMessageId", sourceMessageId)
        .put("attachments", JSONArray(attachments)).toString()

    companion object {
        fun parse(value: String): ComposePayload {
            val o = JSONObject(value)
            fun list(key: String): List<String> = o.optJSONArray(key)?.let { a -> (0 until a.length()).map { a.getString(it) } }.orEmpty()
            return ComposePayload(o.optString("kind", "MESSAGE"), list("to"), list("cc"), list("bcc"),
                o.optString("subject"), o.optString("body"), o.optString("accountId").takeIf(String::isNotBlank),
                o.optInt("subscriptionId", -1), o.optString("mode", "NEW"),
                o.optString("sourceMessageId").takeIf(String::isNotBlank), list("attachments"))
        }
    }
}

data class ComposeRecord(val id: String, val jobId: Int, val payload: ComposePayload, val state: String,
    val runAt: Long, val updatedAt: Long, val error: String?, val resultToken: String?)

/** Separate additive database: existing provider and email tables are untouched. */
class ComposeStore private constructor(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "compose-workflows.db", null, 1) {
    private val context: Context = context.applicationContext
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE compose_items (jobId INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT UNIQUE NOT NULL, payload TEXT NOT NULL, state TEXT NOT NULL, runAt INTEGER NOT NULL DEFAULT 0, updatedAt INTEGER NOT NULL, error TEXT, owner TEXT, resultToken TEXT)")
        db.execSQL("CREATE INDEX compose_state_time ON compose_items(state,runAt)")
        db.execSQL("CREATE TABLE conversation_flags (id TEXT PRIMARY KEY NOT NULL, archived INTEGER, pinned INTEGER)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    @Synchronized fun saveDraft(id: String, payload: ComposePayload): ComposeRecord? {
        val previous = get(id)
        if (previous != null && previous.state != "DRAFT") return previous
        if (!payload.hasContent()) { delete(id); return null }
        // Commit the text and original URIs first so a failed copy never loses typed text.
        write(id, payload, "DRAFT", 0)
        try {
            val stable = payload.copy(attachments = payload.attachments.map { copyAttachment(id, it) })
            write(id, stable, "DRAFT", 0)
            cleanupFiles(id, stable.attachments)
        } catch (error: Exception) {
            writableDatabase.update("compose_items", ContentValues().apply { put("error", "Attachment copy failed: ${error.message}") }, "id=?", arrayOf(id))
            throw error
        }
        return get(id)
    }

    @Synchronized fun schedule(id: String, payload: ComposePayload, runAt: Long): ComposeRecord {
        payload.validate()
        require(runAt >= System.currentTimeMillis() - 5000) { "Choose a future date and time." }
        val saved = saveDraft(id, payload) ?: error("Draft is empty.")
        check(saved.state == "DRAFT") { "This item has already been queued. Open Outbox to manage it." }
        write(id, saved.payload, "SCHEDULED", runAt)
        return requireNotNull(get(id))
    }

    private fun write(id: String, payload: ComposePayload, state: String, runAt: Long) {
        val values = ContentValues().apply {
            put("id", id); put("payload", payload.json()); put("state", state); put("runAt", runAt)
            put("updatedAt", System.currentTimeMillis()); putNull("error"); putNull("owner"); putNull("resultToken")
        }
        if (writableDatabase.update("compose_items", values, "id=?", arrayOf(id)) == 0)
            writableDatabase.insertOrThrow("compose_items", null, values)
    }

    fun get(id: String): ComposeRecord? = query("id=?", arrayOf(id)).firstOrNull()
    fun all(): List<ComposeRecord> = query(null, null)
    private fun query(where: String?, args: Array<String>?): List<ComposeRecord> = readableDatabase.query(
        "compose_items", null, where, args, null, null, "updatedAt DESC"
    ).use { c -> buildList {
        fun s(key: String) = c.getString(c.getColumnIndexOrThrow(key))
        fun n(key: String) = c.getLong(c.getColumnIndexOrThrow(key))
        while (c.moveToNext()) add(ComposeRecord(s("id"), c.getInt(c.getColumnIndexOrThrow("jobId")),
            ComposePayload.parse(s("payload")), s("state"), n("runAt"), n("updatedAt"), s("error"), s("resultToken")))
    } }

    @Synchronized fun claim(id: String): ComposeRecord? {
        val count = writableDatabase.update("compose_items", ContentValues().apply {
            put("state", "SENDING"); put("owner", PROCESS_ID); put("updatedAt", System.currentTimeMillis())
        }, "id=? AND state='SCHEDULED' AND runAt<=?", arrayOf(id, System.currentTimeMillis().toString()))
        return if (count == 1) get(id) else null
    }
    fun finish(id: String, state: String, error: String? = null, token: String? = null) {
        writableDatabase.update("compose_items", ContentValues().apply {
            put("state", state); put("error", error?.take(600)); put("resultToken", token)
            put("updatedAt", System.currentTimeMillis()); putNull("owner")
        }, "id=? AND state IN ('SENDING','UNKNOWN','SCHEDULED')", arrayOf(id))
    }

    /**
     * Reconciles an asynchronous carrier callback with the durable compose queue. Successful
     * handoff is terminal for Outbox; failures remain visible and reviewable for explicit retry.
     * This is called from both dispatcher and callback sides to close their ordering race.
     */
    @Synchronized fun applyTransportResult(token: String, state: String, error: String? = null): Boolean {
        val items = query("resultToken=?", arrayOf(token))
        if (items.isEmpty()) return false
        if (state in SUCCESSFUL_TRANSPORT_STATES) {
            items.forEach { deleteCompleted(it.id) }
            return true
        }
        if (state == "FAILED") {
            writableDatabase.update("compose_items", ContentValues().apply {
                put("state", "FAILED")
                put("error", error?.take(600) ?: "The network or carrier rejected this send.")
                put("updatedAt", System.currentTimeMillis())
                putNull("owner")
            }, "resultToken=? AND state IN ('SENDING','SUBMITTED','UNKNOWN')", arrayOf(token))
            return true
        }
        return false
    }

    /** Removes a synchronous email send after SMTP acceptance and local Sent-copy persistence. */
    @Synchronized fun completeEmail(id: String): Boolean = deleteCompleted(id)

    private fun deleteCompleted(id: String): Boolean {
        val removed = writableDatabase.delete(
            "compose_items", "id=? AND state IN ('SENT','SUBMITTED','SENDING')", arrayOf(id)
        ) > 0
        if (removed) cleanupFiles(id, emptyList())
        return removed
    }
    fun recoverInterrupted() {
        writableDatabase.execSQL("UPDATE compose_items SET state='UNKNOWN',error='Sending was interrupted. Check the conversation or recipient before resending to avoid a duplicate.' WHERE state='SENDING' AND (owner IS NULL OR owner<>?)", arrayOf(PROCESS_ID))
    }
    @Synchronized fun pauseForEdit(id: String): Boolean = writableDatabase.update("compose_items", ContentValues().apply {
        put("state", "DRAFT"); put("runAt", 0); putNull("error"); putNull("owner"); put("updatedAt", System.currentTimeMillis())
    }, "id=? AND state IN ('DRAFT','SCHEDULED')", arrayOf(id)) == 1
    @Synchronized fun reschedule(id: String, runAt: Long): ComposeRecord {
        val current = get(id) ?: error("This saved item no longer exists.")
        check(current.state in setOf("DRAFT", "SCHEDULED")) { "Sending already started or this item changed. Refresh Outbox." }
        current.payload.validate()
        require(runAt >= System.currentTimeMillis() - 5000) { "Choose a future date and time." }
        check(pauseForEdit(id))
        return schedule(id, current.payload, runAt)
    }
    @Synchronized fun delete(id: String): Boolean {
        if (get(id)?.state == "SENDING") return false
        val removed = writableDatabase.delete("compose_items", "id=? AND state<>'SENDING'", arrayOf(id)) > 0
        if (removed) cleanupFiles(id, emptyList())
        return removed
    }

    fun flags(): Map<String, Pair<Boolean?, Boolean?>> = readableDatabase.query("conversation_flags", null, null, null, null, null, null).use { c ->
        buildMap { while (c.moveToNext()) put(c.getString(0),
            (if (c.isNull(1)) null else c.getInt(1) != 0) to (if (c.isNull(2)) null else c.getInt(2) != 0)) }
    }
    fun setFlag(ids: Collection<String>, flag: String, value: Boolean) {
        require(flag in setOf("archived", "pinned"))
        writableDatabase.beginTransaction()
        try {
            ids.distinct().forEach { id ->
                writableDatabase.execSQL("INSERT OR IGNORE INTO conversation_flags(id) VALUES(?)", arrayOf(id))
                writableDatabase.update("conversation_flags", ContentValues().apply { put(flag, if (value) 1 else 0) }, "id=?", arrayOf(id))
            }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }

    private fun attachmentDir(id: String): File {
        require(id.matches(Regex("[A-Za-z0-9-]+")))
        return File(context.filesDir, "compose-media/$id").apply { mkdirs() }
    }
    private fun copyAttachment(id: String, value: String): String {
        val uri = Uri.parse(value)
        val dir = attachmentDir(id)
        val prefix = PduContentProvider.uriFor(context, File(dir, "placeholder")).toString().substringBeforeLast('/') + "/"
        if (value.startsWith(prefix)) {
            context.contentResolver.openInputStream(uri)?.use { } ?: error("A draft attachment is unavailable.")
            return value
        }
        val name = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: uri.lastPathSegment ?: "attachment"
        var safe = name.replace(Regex("[^\\p{L}\\p{N}._ -]"), "_").takeLast(120).ifBlank { "attachment" }
        if (android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(safe.substringAfterLast('.', "").lowercase()) == null) {
            val ext = context.contentResolver.getType(uri)?.substringBefore(';')?.let {
                android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(it)
            }
            if (!ext.isNullOrBlank()) safe += ".$ext"
        }
        val key = java.security.MessageDigest.getInstance("SHA-256").digest(value.toByteArray())
            .take(8).joinToString("") { "%02x".format(it) }
        val file = File(dir, "$key-$safe")
        if (!file.isFile) {
            val temp = File(dir, "$key.part")
            try {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    temp.outputStream().use { output ->
                        val buffer = ByteArray(32 * 1024); var total = 0L
                        while (true) { val read = input.read(buffer); if (read < 0) break
                            total += read; require(total <= 50L * 1024 * 1024) { "Attachment exceeds the 50 MiB local draft limit." }
                            output.write(buffer, 0, read)
                        }
                    }
                } ?: error("Cannot read $name")
                check(temp.renameTo(file)) { "Could not save $name" }
            } finally { temp.delete() }
        }
        return PduContentProvider.uriFor(context, file).toString()
    }
    private fun cleanupFiles(id: String, keep: List<String>) {
        val dir = attachmentDir(id)
        dir.listFiles()?.filter { it.isFile && PduContentProvider.uriFor(context, it).toString() !in keep }?.forEach { it.delete() }
        if (keep.isEmpty()) dir.delete()
    }
    companion object {
        private val SUCCESSFUL_TRANSPORT_STATES = setOf("SENT", "DELIVERED", "CARRIER_ACCEPTED")
        private val PROCESS_ID = UUID.randomUUID().toString()
        @Volatile private var instance: ComposeStore? = null
        fun get(context: Context): ComposeStore = instance ?: synchronized(this) {
            instance ?: ComposeStore(context.applicationContext).also { instance = it }
        }
    }
}
