/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.email.oauth

import android.content.Context
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailAccountEntity

object OAuthUiLauncher {
    fun launch(context: Context, account: EmailAccountEntity) {
        context.startActivity(OAuth2Manager(context).buildAuthorizationIntent(account))
    }
}
