/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 */

package com.macleanofduartenterprises.macleanmessaging.email.mime

import android.text.Html
import java.nio.charset.Charset
import java.text.SimpleDateFormat
import java.util.Base64
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

data class ParsedMimeMessage(
    val messageId: String?,
    val from: String,
    val to: List<String>,
    val cc: List<String>,
    val subject: String?,
    val dateMillis: Long,
    val textBody: String,
    val htmlBody: String?,
    val attachmentCount: Int
)

/** Minimal dependency-free MIME reader/writer with explicit Unicode handling. */
object MimeCodec {
    fun parse(raw: ByteArray): ParsedMimeMessage {
        val root = entity(raw)
        val collected = Collected()
        collect(root, collected)
        val html = collected.html.firstOrNull(String::isNotBlank)
        val plain = collected.plain.filter(String::isNotBlank).joinToString("\n\n")
        val textBody = plain.ifBlank {
            html?.let { Html.fromHtml(it, Html.FROM_HTML_MODE_LEGACY).toString().trim() }.orEmpty()
        }
        return ParsedMimeMessage(
            messageId = root.headers["message-id"]?.trim()?.trim('<', '>'),
            from = decodeHeader(root.headers["from"].orEmpty()),
            to = addresses(decodeHeader(root.headers["to"].orEmpty())),
            cc = addresses(decodeHeader(root.headers["cc"].orEmpty())),
            subject = root.headers["subject"]?.let(::decodeHeader),
            dateMillis = parseDate(root.headers["date"]),
            textBody = textBody,
            htmlBody = html,
            attachmentCount = collected.attachments
        )
    }

    @Suppress("UNUSED_PARAMETER")
    fun build(
        from: String,
        to: List<String>,
        cc: List<String>,
        bcc: List<String>,
        subject: String,
        body: String,
        attachments: List<Pair<String, ByteArray>> = emptyList(),
        signature: String? = null,
        messageId: String? = null,
        inReplyTo: String? = null,
        references: List<String> = emptyList()
    ): ByteArray {
        val boundary = "=_Maclean_${UUID.randomUUID()}"
        val fullBody = if (signature.isNullOrBlank()) body else "$body\r\n\r\n$signature"
        val out = StringBuilder()
            .append("From: ${encodeMailbox(from)}\r\n")
            .append("To: ${to.joinToString(", ", transform = ::encodeMailbox)}\r\n")
        if (cc.isNotEmpty()) out.append("Cc: ${cc.joinToString(", ", transform = ::encodeMailbox)}\r\n")
        out.append("Subject: ${encodeHeader(subject)}\r\n")
            .append("Date: ${formatDate(System.currentTimeMillis())}\r\n")
        messageId?.let { out.append("Message-ID: ${messageIdHeader(it)}\r\n") }
        inReplyTo?.let { out.append("In-Reply-To: ${messageIdHeader(it)}\r\n") }
        references.filter(String::isNotBlank).takeIf(List<String>::isNotEmpty)?.let { ids ->
            out.append("References: ${ids.joinToString(" ", transform = ::messageIdHeader)}\r\n")
        }
        out.append("MIME-Version: 1.0\r\n")

        if (attachments.isEmpty()) {
            out.append("Content-Type: text/plain; charset=UTF-8\r\n")
                .append("Content-Transfer-Encoding: base64\r\n\r\n")
                .append(base64Lines(fullBody.toByteArray(Charsets.UTF_8)))
                .append("\r\n")
        } else {
            out.append("Content-Type: multipart/mixed; boundary=\"").append(boundary).append("\"\r\n\r\n")
                .append("--").append(boundary).append("\r\n")
                .append("Content-Type: text/plain; charset=UTF-8\r\n")
                .append("Content-Transfer-Encoding: base64\r\n\r\n")
                .append(base64Lines(fullBody.toByteArray(Charsets.UTF_8))).append("\r\n")
            attachments.forEach { (name, bytes) ->
                val fallback = name.replace(Regex("[^A-Za-z0-9._ -]+"), "_").take(80).ifBlank { "attachment" }
                    .replace("\\", "_").replace("\"", "_")
                out.append("--").append(boundary).append("\r\n")
                    .append("Content-Type: application/octet-stream; name=\"").append(fallback).append("\"\r\n")
                    .append("Content-Disposition: attachment; filename=\"").append(fallback)
                    .append("\"; filename*=UTF-8''").append(rfc5987(name)).append("\r\n")
                    .append("Content-Transfer-Encoding: base64\r\n\r\n")
                    .append(base64Lines(bytes)).append("\r\n")
            }
            out.append("--").append(boundary).append("--\r\n")
        }
        return out.toString().toByteArray(Charsets.US_ASCII)
    }

    private fun collect(part: MimeEntity, out: Collected) {
        val contentTypeHeader = part.headers["content-type"].orEmpty()
        val contentType = contentTypeHeader.substringBefore(';').trim().lowercase(Locale.US)
            .ifBlank { "text/plain" }
        val disposition = part.headers["content-disposition"].orEmpty().lowercase(Locale.US)
        val isAttachment = disposition.contains("attachment") ||
            disposition.contains("filename=") || contentTypeHeader.contains("name=", ignoreCase = true)

        if (contentType.startsWith("multipart/")) {
            val boundary = parameter(contentTypeHeader, "boundary") ?: return
            multipart(part.body, boundary).forEach { collect(entity(it), out) }
            return
        }

        if (isAttachment) {
            out.attachments++
            return
        }

        when (contentType) {
            "text/plain" -> out.plain += decodeText(part)
            "text/html" -> out.html += decodeText(part)
            "message/rfc822" -> collect(entity(decodeTransfer(part)), out)
            else -> if (contentType != "application/smil") out.attachments++
        }
    }

    private fun entity(bytes: ByteArray): MimeEntity {
        val asLatin1 = bytes.toString(Charsets.ISO_8859_1)
        val crlf = asLatin1.indexOf("\r\n\r\n")
        val lf = asLatin1.indexOf("\n\n")
        val split = when {
            crlf >= 0 && (lf < 0 || crlf <= lf) -> crlf to 4
            lf >= 0 -> lf to 2
            else -> asLatin1.length to 0
        }
        val headers = parseHeaders(asLatin1.substring(0, split.first))
        val bodyStart = (split.first + split.second).coerceAtMost(bytes.size)
        return MimeEntity(headers, bytes.copyOfRange(bodyStart, bytes.size))
    }

    private fun parseHeaders(value: String): Map<String, String> {
        val unfolded = value.replace(Regex("\\r?\\n[ \\t]+"), " ")
        val result = linkedMapOf<String, String>()
        unfolded.split(Regex("\\r?\\n")).forEach { line ->
            val separator = line.indexOf(':')
            if (separator > 0) {
                val name = line.substring(0, separator).trim().lowercase(Locale.US)
                val headerValue = line.substring(separator + 1).trim()
                result[name] = result[name]?.let { "$it, $headerValue" } ?: headerValue
            }
        }
        return result
    }

    private fun multipart(body: ByteArray, boundary: String): List<ByteArray> {
        val value = body.toString(Charsets.ISO_8859_1)
        val markers = Regex("(?m)^--${Regex.escape(boundary)}(--)?[ \\t]*\\r?$").findAll(value).toList()
        if (markers.isEmpty()) return emptyList()
        val result = mutableListOf<ByteArray>()
        for (index in markers.indices) {
            if (markers[index].groupValues[1] == "--") break
            val next = markers.getOrNull(index + 1) ?: break
            var start = markers[index].range.last + 1
            if (value.getOrNull(start) == '\r') start++
            if (value.getOrNull(start) == '\n') start++
            var end = next.range.first
            while (end > start && (value[end - 1] == '\r' || value[end - 1] == '\n')) end--
            if (end > start) result += value.substring(start, end).toByteArray(Charsets.ISO_8859_1)
        }
        return result
    }

    private fun decodeText(part: MimeEntity): String {
        val bytes = decodeTransfer(part)
        val charsetName = parameter(part.headers["content-type"].orEmpty(), "charset") ?: "UTF-8"
        val charset = runCatching { Charset.forName(charsetName) }.getOrDefault(Charsets.UTF_8)
        return bytes.toString(charset).trimEnd('\r', '\n')
    }

    private fun decodeTransfer(part: MimeEntity): ByteArray = when (
        part.headers["content-transfer-encoding"]?.trim()?.lowercase(Locale.US)
    ) {
        "base64" -> runCatching { Base64.getMimeDecoder().decode(part.body) }.getOrDefault(part.body)
        "quoted-printable" -> quotedPrintable(part.body, false)
        else -> part.body
    }

    private fun quotedPrintable(bytes: ByteArray, encodedWord: Boolean): ByteArray {
        val out = ArrayList<Byte>(bytes.size)
        var index = 0
        while (index < bytes.size) {
            val current = bytes[index].toInt() and 0xff
            when {
                encodedWord && current == '_'.code -> {
                    out += ' '.code.toByte()
                    index++
                }
                current == '='.code && index + 1 < bytes.size && bytes[index + 1] == '\n'.code.toByte() -> index += 2
                current == '='.code && index + 2 < bytes.size &&
                    bytes[index + 1] == '\r'.code.toByte() && bytes[index + 2] == '\n'.code.toByte() -> index += 3
                current == '='.code && index + 2 < bytes.size -> {
                    val high = hex(bytes[index + 1].toInt().toChar())
                    val low = hex(bytes[index + 2].toInt().toChar())
                    if (high >= 0 && low >= 0) {
                        out += ((high shl 4) or low).toByte()
                        index += 3
                    } else {
                        out += bytes[index++]
                    }
                }
                else -> out += bytes[index++]
            }
        }
        return out.toByteArray()
    }

    private fun decodeHeader(value: String): String {
        val matches = ENCODED_WORD.findAll(value).toList()
        if (matches.isEmpty()) return decodeRawUtf8Header(value)
        val out = StringBuilder()
        var end = 0
        var previousWasEncoded = false
        matches.forEach { match ->
            val gap = value.substring(end, match.range.first)
            if (!(previousWasEncoded && gap.isBlank())) out.append(gap)
            val charset = runCatching { Charset.forName(match.groupValues[1]) }.getOrDefault(Charsets.UTF_8)
            val bytes = if (match.groupValues[2].equals("B", true)) {
                runCatching { Base64.getDecoder().decode(match.groupValues[3]) }
                    .getOrDefault(match.groupValues[3].toByteArray(Charsets.ISO_8859_1))
            } else {
                quotedPrintable(match.groupValues[3].toByteArray(Charsets.ISO_8859_1), true)
            }
            out.append(bytes.toString(charset))
            end = match.range.last + 1
            previousWasEncoded = true
        }
        out.append(value.substring(end))
        return decodeRawUtf8Header(out.toString())
    }

    /** RFC 6532 permits raw UTF-8 headers; the structural parser intentionally uses Latin-1. */
    private fun decodeRawUtf8Header(value: String): String {
        if (value.none { it.code in 128..255 }) return value
        val candidate = value.toByteArray(Charsets.ISO_8859_1).toString(Charsets.UTF_8)
        return if ('\uFFFD' !in candidate) candidate else value
    }

    private fun parameter(header: String, name: String): String? {
        val expression = Regex("(?i)(?:^|;)\\s*${Regex.escape(name)}\\*?\\s*=\\s*(?:\"([^\"]*)\"|([^;\\s]*))")
        val match = expression.find(header) ?: return null
        return (match.groupValues[1].ifBlank { match.groupValues[2] }).trim().trim('"')
    }

    private fun addresses(value: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var quoted = false
        var angleDepth = 0
        value.forEach { character ->
            when (character) {
                '"' -> quoted = !quoted
                '<' -> if (!quoted) angleDepth++
                '>' -> if (!quoted && angleDepth > 0) angleDepth--
            }
            if (character == ',' && !quoted && angleDepth == 0) {
                current.toString().trim().takeIf(String::isNotBlank)?.let(result::add)
                current.clear()
            } else current.append(character)
        }
        current.toString().trim().takeIf(String::isNotBlank)?.let(result::add)
        return result
    }

    private fun encodeMailbox(value: String): String {
        val clean = value.replace(Regex("[\\r\\n]+"), " ").trim()
        val angle = clean.lastIndexOf('<')
        return if (angle > 0 && clean.endsWith('>')) {
            "${encodeHeader(clean.substring(0, angle).trim())} ${clean.substring(angle)}"
        } else if (clean.all { it.code in 32..126 }) clean else encodeHeader(clean)
    }

    private fun encodeHeader(value: String): String {
        val clean = value.replace(Regex("[\\r\\n]+"), " ")
        return if (clean.all { it.code in 32..126 }) clean
        else "=?UTF-8?B?${Base64.getEncoder().encodeToString(clean.toByteArray(Charsets.UTF_8))}?="
    }

    private fun messageIdHeader(value: String): String {
        val clean = value.replace(Regex("[\\r\\n<>]+"), "").trim()
        return "<$clean>"
    }

    private fun base64Lines(bytes: ByteArray): String =
        Base64.getEncoder().encodeToString(bytes).chunked(76).joinToString("\r\n")

    private fun rfc5987(value: String): String = buildString {
        value.toByteArray(Charsets.UTF_8).forEach { byte ->
            val unsigned = byte.toInt() and 0xff
            val safe = unsigned in 'A'.code..'Z'.code || unsigned in 'a'.code..'z'.code ||
                unsigned in '0'.code..'9'.code || unsigned in "!#$&+-.^_`|~".map(Char::code)
            if (safe) append(unsigned.toChar()) else append('%').append("%02X".format(Locale.US, unsigned))
        }
    }

    private fun parseDate(value: String?): Long {
        if (value.isNullOrBlank()) return System.currentTimeMillis()
        val clean = value.replace(Regex("\\s*\\([^)]*\\)\\s*$"), "").trim()
        DATE_PATTERNS.forEach { pattern ->
            runCatching {
                SimpleDateFormat(pattern, Locale.US).apply { isLenient = true }.parse(clean)?.time
            }.getOrNull()?.let { return it }
        }
        return System.currentTimeMillis()
    }

    private fun formatDate(timestamp: Long): String =
        SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }.format(Date(timestamp))

    private fun hex(value: Char): Int = when (value) {
        in '0'..'9' -> value - '0'
        in 'a'..'f' -> value - 'a' + 10
        in 'A'..'F' -> value - 'A' + 10
        else -> -1
    }

    private data class MimeEntity(val headers: Map<String, String>, val body: ByteArray)
    private data class Collected(
        val plain: MutableList<String> = mutableListOf(),
        val html: MutableList<String> = mutableListOf(),
        var attachments: Int = 0
    )

    private val ENCODED_WORD = Regex("=\\?([^?]+)\\?([bBqQ])\\?([^?]*)\\?=")
    private val DATE_PATTERNS = listOf(
        "EEE, d MMM yyyy HH:mm:ss Z",
        "EEE, d MMM yyyy HH:mm Z",
        "d MMM yyyy HH:mm:ss Z",
        "d MMM yyyy HH:mm Z"
    )
}
