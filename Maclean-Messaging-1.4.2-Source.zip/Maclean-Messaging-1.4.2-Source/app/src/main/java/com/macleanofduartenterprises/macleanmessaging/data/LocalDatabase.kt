/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 */

package com.macleanofduartenterprises.macleanmessaging.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailAccountDao
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailAccountEntity
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailAttachmentDao
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailAttachmentEntity
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailMessageDao
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailMessageEntity
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailThreadDao
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailThreadEntity
import java.io.File

data class MessageMetaEntity(
    val token: String,
    val systemUri: String?,
    val state: String,
    val scheduledAt: Long? = null,
    val archived: Boolean = false,
    val pinned: Boolean = false,
    val favorite: Boolean = false
)

data class ThreadPrefsEntity(
    val threadKey: String,
    val muted: Boolean = false,
    val ringtone: String? = null,
    val vibration: Boolean = true
)

data class BlockedEntity(val normalizedAddress: String, val reason: String? = null)

interface MessageMetaDao {
    fun upsert(entity: MessageMetaEntity)
    fun updateState(token: String, state: String)
    fun get(token: String): MessageMetaEntity?
    fun all(): List<MessageMetaEntity>
}

data class SmsPartAggregate(val state: State, val resultCode: Int? = null) {
    enum class State { PENDING, COMPLETE, FAILED }
}

interface ThreadPrefsDao {
    fun get(key: String): ThreadPrefsEntity?
    fun upsert(value: ThreadPrefsEntity)
}

interface BlockedDao {
    fun contains(address: String): Boolean
    fun block(value: BlockedEntity)
    fun unblock(address: String)
}

/**
 * SQLite implementation with the same schema used by the Room-backed release
 * source. It keeps existing installations upgrade-compatible while allowing a
 * dependency-complete offline Android SDK build.
 */
class LocalDatabase private constructor(context: Context) :
    SQLiteOpenHelper(context.applicationContext, DATABASE_NAME, null, DATABASE_VERSION) {

    private val messageMeta = MessageMetaDaoImpl()
    private val threadPrefs = ThreadPrefsDaoImpl()
    private val blocked = BlockedDaoImpl()
    private val emailAccounts = EmailAccountDaoImpl()
    private val emailThreads = EmailThreadDaoImpl()
    private val emailMessages = EmailMessageDaoImpl()
    private val emailAttachments = EmailAttachmentDaoImpl()

    override fun onCreate(db: SQLiteDatabase) = createSchema(db)

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        createSchema(db)
        ensureColumn(db, "email_accounts", "oauthClientId", "TEXT")
        ensureColumn(db, "email_accounts", "oauthAuthorizeEndpoint", "TEXT")
        ensureColumn(db, "email_accounts", "oauthTokenEndpoint", "TEXT")
        ensureColumn(db, "email_accounts", "oauthScopes", "TEXT")
        ensureColumn(db, "email_accounts", "lastSyncError", "TEXT")
    }

    override fun onOpen(db: SQLiteDatabase) {
        super.onOpen(db)
        createSchema(db)
    }

    fun messageMetaDao(): MessageMetaDao = messageMeta
    fun threadPrefsDao(): ThreadPrefsDao = threadPrefs
    fun blockedDao(): BlockedDao = blocked
    fun emailAccountDao(): EmailAccountDao = emailAccounts
    fun emailThreadDao(): EmailThreadDao = emailThreads
    fun emailMessageDao(): EmailMessageDao = emailMessages
    fun emailAttachmentDao(): EmailAttachmentDao = emailAttachments

    private fun createSchema(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS message_meta (token TEXT NOT NULL PRIMARY KEY, systemUri TEXT, state TEXT NOT NULL, scheduledAt INTEGER, archived INTEGER NOT NULL DEFAULT 0, pinned INTEGER NOT NULL DEFAULT 0, favorite INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE IF NOT EXISTS thread_prefs (threadKey TEXT NOT NULL PRIMARY KEY, muted INTEGER NOT NULL DEFAULT 0, ringtone TEXT, vibration INTEGER NOT NULL DEFAULT 1)")
        db.execSQL("CREATE TABLE IF NOT EXISTS blocked (normalizedAddress TEXT NOT NULL PRIMARY KEY, reason TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS email_accounts (id TEXT NOT NULL PRIMARY KEY, displayName TEXT NOT NULL, emailAddress TEXT NOT NULL, incomingHost TEXT NOT NULL, incomingPort INTEGER NOT NULL, incomingSecurity TEXT NOT NULL, outgoingHost TEXT NOT NULL, outgoingPort INTEGER NOT NULL, outgoingSecurity TEXT NOT NULL, username TEXT NOT NULL, authType TEXT NOT NULL, credentialAlias TEXT, oauthClientId TEXT, oauthAuthorizeEndpoint TEXT, oauthTokenEndpoint TEXT, oauthScopes TEXT, enabled INTEGER NOT NULL DEFAULT 1, syncEnabled INTEGER NOT NULL DEFAULT 1, isDefaultSendAccount INTEGER NOT NULL DEFAULT 0, accountColorArgb INTEGER, signature TEXT, lastSyncAt INTEGER, lastSyncError TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS email_threads (stableId TEXT NOT NULL PRIMARY KEY, accountId TEXT NOT NULL, remoteThreadId TEXT, subject TEXT, participantsJson TEXT NOT NULL, preview TEXT NOT NULL, timestamp INTEGER NOT NULL, unreadCount INTEGER NOT NULL, pinned INTEGER NOT NULL DEFAULT 0, favorite INTEGER NOT NULL DEFAULT 0, archived INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_email_threads_accountId ON email_threads(accountId)")
        db.execSQL("CREATE TABLE IF NOT EXISTS email_messages (stableId TEXT NOT NULL PRIMARY KEY, accountId TEXT NOT NULL, threadId TEXT NOT NULL, remoteMessageId TEXT, sender TEXT NOT NULL, recipientsJson TEXT NOT NULL, subject TEXT, bodyText TEXT NOT NULL, bodyHtml TEXT, timestamp INTEGER NOT NULL, incoming INTEGER NOT NULL, unread INTEGER NOT NULL, folder TEXT NOT NULL, attachmentCount INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_email_messages_threadId ON email_messages(threadId)")
        db.execSQL("CREATE TABLE IF NOT EXISTS email_attachments (id TEXT NOT NULL PRIMARY KEY, messageId TEXT NOT NULL, accountId TEXT NOT NULL, fileName TEXT, mimeType TEXT NOT NULL, sizeBytes INTEGER NOT NULL, localPath TEXT NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_email_attachments_messageId ON email_attachments(messageId)")
        db.execSQL("CREATE TABLE IF NOT EXISTS deleted_email_messages (stableId TEXT NOT NULL PRIMARY KEY, deletedAt INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS sms_part_results (token TEXT NOT NULL, phase TEXT NOT NULL, part INTEGER NOT NULL, ok INTEGER NOT NULL, resultCode INTEGER NOT NULL, PRIMARY KEY(token,phase,part))")
    }

    /** Idempotently aggregates multipart carrier callbacks across duplicate delivery/process death. */
    @Synchronized fun recordSmsPartResult(
        token: String,
        phase: String,
        part: Int,
        totalParts: Int,
        ok: Boolean,
        resultCode: Int
    ): SmsPartAggregate {
        require(phase == "SENT" || phase == "DELIVERED")
        require(totalParts in 1..MAX_SMS_PARTS && part in 0 until totalParts)
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.insertWithOnConflict("sms_part_results", null, ContentValues().apply {
                put("token", token); put("phase", phase); put("part", part)
                put("ok", ok.int); put("resultCode", resultCode)
            }, SQLiteDatabase.CONFLICT_REPLACE)
            val rows = db.query(
                "sms_part_results", arrayOf("ok", "resultCode"),
                "token=? AND phase=?", arrayOf(token, phase), null, null, null
            ).use { cursor ->
                buildList { while (cursor.moveToNext()) add((cursor.getInt(0) != 0) to cursor.getInt(1)) }
            }
            val result = when {
                rows.any { !it.first } -> SmsPartAggregate(SmsPartAggregate.State.FAILED, rows.first { !it.first }.second)
                rows.size >= totalParts -> SmsPartAggregate(SmsPartAggregate.State.COMPLETE)
                else -> SmsPartAggregate(SmsPartAggregate.State.PENDING)
            }
            db.setTransactionSuccessful()
            return result
        } finally { db.endTransaction() }
    }

    fun clearSmsPartResults(token: String, phase: String? = null) {
        if (phase == null) writableDatabase.delete("sms_part_results", "token=?", arrayOf(token))
        else writableDatabase.delete("sms_part_results", "token=? AND phase=?", arrayOf(token, phase))
    }

    private fun ensureColumn(db: SQLiteDatabase, table: String, column: String, type: String) {
        val exists = db.rawQuery("PRAGMA table_info($table)", null).use { cursor ->
            var found = false
            while (cursor.moveToNext()) {
                if (cursor.getString(cursor.getColumnIndexOrThrow("name")) == column) found = true
            }
            found
        }
        if (!exists) db.execSQL("ALTER TABLE $table ADD COLUMN $column $type")
    }

    private inner class MessageMetaDaoImpl : MessageMetaDao {
        override fun upsert(entity: MessageMetaEntity) {
            writableDatabase.insertWithOnConflict("message_meta", null, ContentValues().apply {
                put("token", entity.token); put("systemUri", entity.systemUri); put("state", entity.state)
                putNullable("scheduledAt", entity.scheduledAt); put("archived", entity.archived.int)
                put("pinned", entity.pinned.int); put("favorite", entity.favorite.int)
            }, SQLiteDatabase.CONFLICT_REPLACE)
        }

        override fun updateState(token: String, state: String) {
            writableDatabase.update("message_meta", ContentValues().apply { put("state", state) }, "token=?", arrayOf(token))
        }

        override fun get(token: String): MessageMetaEntity? = readableDatabase.query(
            "message_meta", null, "token=?", arrayOf(token), null, null, null, "1"
        ).use { c -> if (c.moveToFirst()) c.toMessageMeta() else null }

        override fun all(): List<MessageMetaEntity> = readableDatabase.query(
            "message_meta", null, null, null, null, null, null
        ).use { c -> buildList { while (c.moveToNext()) add(c.toMessageMeta()) } }
    }

    private inner class ThreadPrefsDaoImpl : ThreadPrefsDao {
        override fun get(key: String): ThreadPrefsEntity? = readableDatabase.query(
            "thread_prefs", null, "threadKey=?", arrayOf(key), null, null, null, "1"
        ).use { c -> if (c.moveToFirst()) ThreadPrefsEntity(c.s("threadKey"), c.b("muted"), c.ns("ringtone"), c.b("vibration")) else null }

        override fun upsert(value: ThreadPrefsEntity) {
            writableDatabase.insertWithOnConflict("thread_prefs", null, ContentValues().apply {
                put("threadKey", value.threadKey); put("muted", value.muted.int); put("ringtone", value.ringtone); put("vibration", value.vibration.int)
            }, SQLiteDatabase.CONFLICT_REPLACE)
        }
    }

    private inner class BlockedDaoImpl : BlockedDao {
        override fun contains(address: String): Boolean = readableDatabase.rawQuery(
            "SELECT EXISTS(SELECT 1 FROM blocked WHERE normalizedAddress=?)", arrayOf(address)
        ).use { it.moveToFirst() && it.getInt(0) != 0 }

        override fun block(value: BlockedEntity) {
            writableDatabase.insertWithOnConflict("blocked", null, ContentValues().apply {
                put("normalizedAddress", value.normalizedAddress); put("reason", value.reason)
            }, SQLiteDatabase.CONFLICT_REPLACE)
        }

        override fun unblock(address: String) {
            writableDatabase.delete("blocked", "normalizedAddress=?", arrayOf(address))
        }
    }

    private inner class EmailAccountDaoImpl : EmailAccountDao {
        override fun all(): List<EmailAccountEntity> = accountQuery(null, null, "displayName COLLATE NOCASE")
        override fun enabled(): List<EmailAccountEntity> = accountQuery("enabled=1", null, "displayName COLLATE NOCASE")
        override fun enabledCount(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM email_accounts WHERE enabled=1", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
        override fun get(id: String): EmailAccountEntity? = accountQuery("id=?", arrayOf(id), null, "1").firstOrNull()
        override fun defaultSendAccount(): EmailAccountEntity? = accountQuery("enabled=1 AND isDefaultSendAccount=1", null, null, "1").firstOrNull()
        override fun clearDefaultSendAccount() { writableDatabase.execSQL("UPDATE email_accounts SET isDefaultSendAccount=0") }
        override fun setDefaultSendAccountFlag(id: String) { writableDatabase.update("email_accounts", ContentValues().apply { put("isDefaultSendAccount", 1) }, "id=?", arrayOf(id)) }
        override fun updateSyncStatus(id: String, time: Long?, error: String?) {
            writableDatabase.update("email_accounts", ContentValues().apply { putNullable("lastSyncAt", time); put("lastSyncError", error) }, "id=?", arrayOf(id))
        }

        override fun upsert(account: EmailAccountEntity) {
            writableDatabase.insertWithOnConflict("email_accounts", null, account.values(), SQLiteDatabase.CONFLICT_REPLACE)
        }

        override fun delete(id: String) { writableDatabase.delete("email_accounts", "id=?", arrayOf(id)) }
        override fun makeDefaultSendAccount(id: String) {
            val db = writableDatabase
            db.beginTransaction()
            try {
                db.execSQL("UPDATE email_accounts SET isDefaultSendAccount=0")
                db.update("email_accounts", ContentValues().apply { put("isDefaultSendAccount", 1) }, "id=?", arrayOf(id))
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
        }
    }

    private inner class EmailThreadDaoImpl : EmailThreadDao {
        override fun list(accountId: String, archived: Boolean): List<EmailThreadEntity> = threadQuery("accountId=? AND archived=?", arrayOf(accountId, archived.int.toString()), "pinned DESC,timestamp DESC")
        override fun listAllAccounts(archived: Boolean): List<EmailThreadEntity> = threadQuery("archived=?", arrayOf(archived.int.toString()), "pinned DESC,timestamp DESC")
        override fun search(pattern: String, limit: Int): List<EmailThreadEntity> = threadQuery("subject LIKE ? OR preview LIKE ?", arrayOf(pattern, pattern), "timestamp DESC", limit.toString())
        override fun get(id: String): EmailThreadEntity? = threadQuery("stableId=?", arrayOf(id), null, "1").firstOrNull()
        override fun upsert(value: EmailThreadEntity) { writableDatabase.insertWithOnConflict("email_threads", null, value.values(), SQLiteDatabase.CONFLICT_REPLACE) }
        override fun upsertAll(values: List<EmailThreadEntity>) = transaction { values.forEach(::upsert) }
        override fun delete(id: String) { writableDatabase.delete("email_threads", "stableId=?", arrayOf(id)) }
        override fun deleteForAccount(accountId: String) { writableDatabase.delete("email_threads", "accountId=?", arrayOf(accountId)) }
        override fun setArchived(id: String, value: Boolean) = updateFlag("email_threads", "archived", id, value)
        override fun setPinned(id: String, value: Boolean) = updateFlag("email_threads", "pinned", id, value)
        override fun setFavorite(id: String, value: Boolean) = updateFlag("email_threads", "favorite", id, value)
    }

    private inner class EmailMessageDaoImpl : EmailMessageDao {
        override fun forThread(threadId: String): List<EmailMessageEntity> = messageQuery("threadId=?", arrayOf(threadId), "timestamp ASC")
        override fun get(id: String): EmailMessageEntity? = messageQuery("stableId=?", arrayOf(id), null, "1").firstOrNull()
        override fun upsert(value: EmailMessageEntity) { writableDatabase.insertWithOnConflict("email_messages", null, value.values(), SQLiteDatabase.CONFLICT_REPLACE) }
        override fun upsertAll(values: List<EmailMessageEntity>) = transaction { values.forEach(::upsert) }
        override fun delete(id: String) { writableDatabase.delete("email_messages", "stableId=?", arrayOf(id)) }
        override fun deleteForAccount(accountId: String) { writableDatabase.delete("email_messages", "accountId=?", arrayOf(accountId)) }
        override fun setUnread(id: String, unread: Boolean) = updateFlag("email_messages", "unread", id, unread)
        override fun moveToFolder(id: String, folder: String) { writableDatabase.update("email_messages", ContentValues().apply { put("folder", folder) }, "stableId=?", arrayOf(id)) }
    }

    private inner class EmailAttachmentDaoImpl : EmailAttachmentDao {
        override fun forMessage(messageId: String): List<EmailAttachmentEntity> = readableDatabase.query(
            "email_attachments", null, "messageId=?", arrayOf(messageId), null, null, "fileName COLLATE NOCASE"
        ).use { c -> buildList { while (c.moveToNext()) add(c.toAttachment()) } }
        override fun upsertAll(values: List<EmailAttachmentEntity>) = transaction {
            values.forEach { writableDatabase.insertWithOnConflict("email_attachments", null, it.values(), SQLiteDatabase.CONFLICT_REPLACE) }
        }
        override fun deleteForMessage(messageId: String) { writableDatabase.delete("email_attachments", "messageId=?", arrayOf(messageId)) }
        override fun deleteForAccount(accountId: String) { writableDatabase.delete("email_attachments", "accountId=?", arrayOf(accountId)) }
    }

    fun isEmailMessageDeleted(stableId: String): Boolean = readableDatabase.rawQuery(
        "SELECT EXISTS(SELECT 1 FROM deleted_email_messages WHERE stableId=?)",
        arrayOf(stableId)
    ).use { it.moveToFirst() && it.getInt(0) != 0 }

    fun markEmailThreadRead(threadId: String) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.update(
                "email_messages",
                ContentValues().apply { put("unread", 0) },
                "threadId=? AND unread=1",
                arrayOf(threadId)
            )
            db.update(
                "email_threads",
                ContentValues().apply { put("unreadCount", 0) },
                "stableId=?",
                arrayOf(threadId)
            )
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun setEmailMessageUnread(stableId: String, unread: Boolean) {
        val message = emailMessageDao().get(stableId) ?: return
        emailMessageDao().setUnread(stableId, unread)
        refreshEmailThread(message.threadId)
    }

    /** Loads selected message rows in bounded queries below SQLite's bind-variable limit. */
    fun emailMessages(stableIds: Collection<String>): List<EmailMessageEntity> =
        stableIds.distinct().chunked(SQLITE_BIND_CHUNK_SIZE).flatMap { ids ->
            val placeholders = ids.joinToString(",") { "?" }
            messageQuery("stableId IN ($placeholders)", ids.toTypedArray(), null)
        }

    /** Updates selected rows together, then recalculates each affected conversation only once. */
    fun setEmailMessagesUnread(stableIds: Collection<String>, unread: Boolean): Int {
        val messages = emailMessages(stableIds)
        if (messages.isEmpty()) return 0
        val values = ContentValues().apply { put("unread", unread.int) }
        transaction {
            messages.map(EmailMessageEntity::stableId).chunked(SQLITE_BIND_CHUNK_SIZE).forEach { ids ->
                val placeholders = ids.joinToString(",") { "?" }
                writableDatabase.update(
                    "email_messages",
                    values,
                    "stableId IN ($placeholders)",
                    ids.toTypedArray()
                )
            }
        }
        messages.map(EmailMessageEntity::threadId).distinct().forEach(::refreshEmailThread)
        return messages.size
    }

    fun emailUnreadCount(accountId: String): Int = readableDatabase.rawQuery(
        "SELECT COUNT(*) FROM email_messages WHERE accountId=? AND unread=1",
        arrayOf(accountId)
    ).use { if (it.moveToFirst()) it.getInt(0) else 0 }

    /**
     * Returns every IMAP UID already persisted for an account without materializing message
     * subjects or bodies. Keeping this lookup lightweight makes an ordinary sync proportional to
     * newly-arrived mail instead of repeatedly downloading the whole mailbox.
     */
    fun knownEmailUids(accountId: String, folder: String = "INBOX"): Set<Long> =
        readableDatabase.query(
            "email_messages",
            arrayOf("remoteMessageId"),
            "accountId=? AND folder=? AND remoteMessageId IS NOT NULL",
            arrayOf(accountId, folder),
            null,
            null,
            null
        ).use { cursor ->
            buildSet {
                while (cursor.moveToNext()) cursor.getString(0)?.toLongOrNull()?.let(::add)
            }
        }

    /** Applies server Seen flags to existing rows in one transaction and refreshes only touched threads. */
    fun applyEmailSeenFlags(
        accountId: String,
        flagsByUid: Map<Long, Set<String>>,
        folder: String = "INBOX"
    ): Int {
        if (flagsByUid.isEmpty()) return 0
        val changes = mutableListOf<Pair<String, Boolean>>()
        val touchedThreads = linkedSetOf<String>()
        readableDatabase.query(
            "email_messages",
            arrayOf("stableId", "threadId", "remoteMessageId", "unread"),
            "accountId=? AND folder=? AND remoteMessageId IS NOT NULL",
            arrayOf(accountId, folder),
            null,
            null,
            null
        ).use { cursor ->
            while (cursor.moveToNext()) {
                val flags = cursor.getString(2)?.toLongOrNull()?.let(flagsByUid::get) ?: continue
                val unread = flags.none { it.equals("\\Seen", ignoreCase = true) }
                if (unread != (cursor.getInt(3) != 0)) {
                    changes += cursor.getString(0) to unread
                    touchedThreads += cursor.getString(1)
                }
            }
        }
        if (changes.isEmpty()) return 0
        transaction {
            changes.forEach { (stableId, unread) ->
                writableDatabase.update(
                    "email_messages",
                    ContentValues().apply { put("unread", unread.int) },
                    "stableId=?",
                    arrayOf(stableId)
                )
            }
        }
        touchedThreads.forEach(::refreshEmailThread)
        return changes.size
    }

    /** Rebuilds the visible thread preview and unread badge from its message rows. */
    fun refreshEmailThread(threadId: String) {
        val remaining = emailMessageDao().forThread(threadId)
        if (remaining.isEmpty()) return
        val latest = remaining.maxByOrNull(EmailMessageEntity::timestamp) ?: return
        val previous = emailThreadDao().get(threadId) ?: return
        emailThreadDao().upsert(previous.copy(
            subject = latest.subject,
            preview = latest.bodyText.replace(Regex("\\s+"), " ").take(240),
            timestamp = latest.timestamp,
            unreadCount = remaining.count(EmailMessageEntity::unread)
        ))
    }

    fun deleteEmailMessage(stableId: String) {
        val message = emailMessageDao().get(stableId) ?: return
        val attachments = emailAttachmentDao().forMessage(stableId)
        val db = writableDatabase
        db.beginTransaction()
        try {
            rememberEmailDeletion(db, stableId)
            emailAttachmentDao().deleteForMessage(stableId)
            emailMessageDao().delete(stableId)
            val remaining = emailMessageDao().forThread(message.threadId)
            if (remaining.isEmpty()) {
                emailThreadDao().delete(message.threadId)
            } else {
                val latest = remaining.maxByOrNull(EmailMessageEntity::timestamp)!!
                val previous = emailThreadDao().get(message.threadId)
                if (previous != null) {
                    emailThreadDao().upsert(previous.copy(
                        subject = latest.subject,
                        preview = latest.bodyText.replace(Regex("\\s+"), " ").take(240),
                        timestamp = latest.timestamp,
                        unreadCount = remaining.count(EmailMessageEntity::unread)
                    ))
                }
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        attachments.forEach { runCatching { File(it.localPath).delete() } }
    }

    fun deleteEmailThread(threadId: String) {
        val messages = emailMessageDao().forThread(threadId)
        val attachments = messages.flatMap { emailAttachmentDao().forMessage(it.stableId) }
        val db = writableDatabase
        db.beginTransaction()
        try {
            messages.forEach { message ->
                rememberEmailDeletion(db, message.stableId)
                emailAttachmentDao().deleteForMessage(message.stableId)
                emailMessageDao().delete(message.stableId)
            }
            emailThreadDao().delete(threadId)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        attachments.forEach { runCatching { File(it.localPath).delete() } }
    }

    private fun rememberEmailDeletion(db: SQLiteDatabase, stableId: String) {
        db.insertWithOnConflict("deleted_email_messages", null, ContentValues().apply {
            put("stableId", stableId)
            put("deletedAt", System.currentTimeMillis())
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    private fun accountQuery(selection: String?, args: Array<String>?, order: String?, limit: String? = null): List<EmailAccountEntity> =
        readableDatabase.query("email_accounts", null, selection, args, null, null, order, limit).use { c -> buildList { while (c.moveToNext()) add(c.toAccount()) } }

    private fun threadQuery(selection: String?, args: Array<String>?, order: String?, limit: String? = null): List<EmailThreadEntity> =
        readableDatabase.query("email_threads", null, selection, args, null, null, order, limit).use { c -> buildList { while (c.moveToNext()) add(c.toThread()) } }

    private fun messageQuery(selection: String?, args: Array<String>?, order: String?, limit: String? = null): List<EmailMessageEntity> =
        readableDatabase.query("email_messages", null, selection, args, null, null, order, limit).use { c -> buildList { while (c.moveToNext()) add(c.toMessage()) } }

    private fun updateFlag(table: String, column: String, id: String, value: Boolean) {
        writableDatabase.update(table, ContentValues().apply { put(column, value.int) }, "stableId=?", arrayOf(id))
    }

    private fun transaction(block: () -> Unit) {
        val db = writableDatabase
        db.beginTransaction()
        try { block(); db.setTransactionSuccessful() } finally { db.endTransaction() }
    }

    private fun Cursor.toMessageMeta() = MessageMetaEntity(s("token"), ns("systemUri"), s("state"), nl("scheduledAt"), b("archived"), b("pinned"), b("favorite"))
    private fun Cursor.toAccount() = EmailAccountEntity(
        s("id"), s("displayName"), s("emailAddress"), s("incomingHost"), i("incomingPort"), s("incomingSecurity"),
        s("outgoingHost"), i("outgoingPort"), s("outgoingSecurity"), s("username"), s("authType"), ns("credentialAlias"),
        ns("oauthClientId"), ns("oauthAuthorizeEndpoint"), ns("oauthTokenEndpoint"), ns("oauthScopes"), b("enabled"), b("syncEnabled"),
        b("isDefaultSendAccount"), nl("accountColorArgb"), ns("signature"), nl("lastSyncAt"), ns("lastSyncError")
    )
    private fun Cursor.toThread() = EmailThreadEntity(s("stableId"), s("accountId"), ns("remoteThreadId"), ns("subject"), s("participantsJson"), s("preview"), l("timestamp"), i("unreadCount"), b("pinned"), b("favorite"), b("archived"))
    private fun Cursor.toMessage() = EmailMessageEntity(s("stableId"), s("accountId"), s("threadId"), ns("remoteMessageId"), s("sender"), s("recipientsJson"), ns("subject"), s("bodyText"), ns("bodyHtml"), l("timestamp"), b("incoming"), b("unread"), s("folder"), i("attachmentCount"))
    private fun Cursor.toAttachment() = EmailAttachmentEntity(s("id"), s("messageId"), s("accountId"), ns("fileName"), s("mimeType"), l("sizeBytes"), s("localPath"))

    private fun EmailAccountEntity.values() = ContentValues().apply {
        put("id", id); put("displayName", displayName); put("emailAddress", emailAddress); put("incomingHost", incomingHost); put("incomingPort", incomingPort); put("incomingSecurity", incomingSecurity)
        put("outgoingHost", outgoingHost); put("outgoingPort", outgoingPort); put("outgoingSecurity", outgoingSecurity); put("username", username); put("authType", authType); put("credentialAlias", credentialAlias)
        put("oauthClientId", oauthClientId); put("oauthAuthorizeEndpoint", oauthAuthorizeEndpoint); put("oauthTokenEndpoint", oauthTokenEndpoint); put("oauthScopes", oauthScopes)
        put("enabled", enabled.int); put("syncEnabled", syncEnabled.int); put("isDefaultSendAccount", isDefaultSendAccount.int); putNullable("accountColorArgb", accountColorArgb)
        put("signature", signature); putNullable("lastSyncAt", lastSyncAt); put("lastSyncError", lastSyncError)
    }
    private fun EmailThreadEntity.values() = ContentValues().apply {
        put("stableId", stableId); put("accountId", accountId); put("remoteThreadId", remoteThreadId); put("subject", subject); put("participantsJson", participantsJson); put("preview", preview); put("timestamp", timestamp); put("unreadCount", unreadCount); put("pinned", pinned.int); put("favorite", favorite.int); put("archived", archived.int)
    }
    private fun EmailMessageEntity.values() = ContentValues().apply {
        put("stableId", stableId); put("accountId", accountId); put("threadId", threadId); put("remoteMessageId", remoteMessageId); put("sender", sender); put("recipientsJson", recipientsJson); put("subject", subject); put("bodyText", bodyText); put("bodyHtml", bodyHtml); put("timestamp", timestamp); put("incoming", incoming.int); put("unread", unread.int); put("folder", folder); put("attachmentCount", attachmentCount)
    }
    private fun EmailAttachmentEntity.values() = ContentValues().apply {
        put("id", id); put("messageId", messageId); put("accountId", accountId); put("fileName", fileName); put("mimeType", mimeType); put("sizeBytes", sizeBytes); put("localPath", localPath)
    }

    private val Boolean.int get() = if (this) 1 else 0
    private fun ContentValues.putNullable(key: String, value: Long?) { if (value == null) putNull(key) else put(key, value) }
    private fun Cursor.index(name: String) = getColumnIndexOrThrow(name)
    private fun Cursor.s(name: String) = getString(index(name))
    private fun Cursor.ns(name: String): String? = index(name).let { if (isNull(it)) null else getString(it) }
    private fun Cursor.i(name: String) = getInt(index(name))
    private fun Cursor.l(name: String) = getLong(index(name))
    private fun Cursor.nl(name: String): Long? = index(name).let { if (isNull(it)) null else getLong(it) }
    private fun Cursor.b(name: String) = getInt(index(name)) != 0

    companion object {
        private const val DATABASE_NAME = "maclean-messaging.db"
        private const val DATABASE_VERSION = 6
        private const val MAX_SMS_PARTS = 255
        private const val SQLITE_BIND_CHUNK_SIZE = 400
        @Volatile private var instance: LocalDatabase? = null

        fun get(context: Context): LocalDatabase = instance ?: synchronized(this) {
            instance ?: LocalDatabase(context).also { instance = it }
        }
    }
}
