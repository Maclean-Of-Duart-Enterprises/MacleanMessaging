/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.email.transport
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailAccountEntity
data class EmailDraft(
    val to:List<String>,
    val cc:List<String> = emptyList(),
    val bcc:List<String> = emptyList(),
    val subject:String="",
    val plainTextBody:String,
    val attachmentUris:List<String> = emptyList(),
    val messageId:String? = null,
    val inReplyTo:String? = null,
    val references:List<String> = emptyList()
)
data class SyncResult(val newMessages:Int,val updatedMessages:Int,val foldersUpdated:Int)
interface IncomingEmailTransport{ suspend fun testConnection(account:EmailAccountEntity):Result<Unit>; suspend fun sync(account:EmailAccountEntity):Result<SyncResult> }
interface OutgoingEmailTransport{ suspend fun testConnection(account:EmailAccountEntity):Result<Unit>; suspend fun send(account:EmailAccountEntity,draft:EmailDraft):Result<String> }
sealed interface AuthCredential{data class Password(val value:String):AuthCredential;data class OAuth(val accessToken:String):AuthCredential}
