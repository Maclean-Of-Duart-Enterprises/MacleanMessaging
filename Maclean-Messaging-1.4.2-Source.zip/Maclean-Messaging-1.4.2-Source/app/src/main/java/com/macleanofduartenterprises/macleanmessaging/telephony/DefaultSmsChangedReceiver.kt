/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.telephony

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.macleanofduartenterprises.macleanmessaging.schedule.ScheduleCoordinator
import com.macleanofduartenterprises.macleanmessaging.util.Async

class DefaultSmsChangedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "android.provider.action.DEFAULT_SMS_PACKAGE_CHANGED") return
        val pending = goAsync()
        Async.launchSerial {
            try {
                ScheduleCoordinator.reconcile(context.applicationContext)
                IncomingSmsManager.reconcile(context.applicationContext)
                IncomingMmsManager.reconcile(context.applicationContext)
            }
            finally { pending.finish() }
        }
    }
}
