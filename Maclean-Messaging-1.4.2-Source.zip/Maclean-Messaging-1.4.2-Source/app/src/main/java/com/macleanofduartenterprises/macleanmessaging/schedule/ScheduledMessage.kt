/* Maclean Messaging — SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanmessaging.schedule

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PersistableBundle
import com.macleanofduartenterprises.macleanmessaging.data.SystemMessageRepository
import com.macleanofduartenterprises.macleanmessaging.data.LocalDatabase
import com.macleanofduartenterprises.macleanmessaging.email.compose.ComposeMode
import com.macleanofduartenterprises.macleanmessaging.email.compose.EmailComposeCoordinator
import com.macleanofduartenterprises.macleanmessaging.email.sync.EmailSyncWorker
import com.macleanofduartenterprises.macleanmessaging.email.transport.EmailDraft
import com.macleanofduartenterprises.macleanmessaging.system.DefaultSmsRole
import com.macleanofduartenterprises.macleanmessaging.model.Attachment
import com.macleanofduartenterprises.macleanmessaging.model.OutgoingMessage
import com.macleanofduartenterprises.macleanmessaging.util.Async
import com.macleanofduartenterprises.macleanmessaging.workflow.ComposePayload
import com.macleanofduartenterprises.macleanmessaging.workflow.ComposeRecord
import com.macleanofduartenterprises.macleanmessaging.workflow.ComposeStore
import com.macleanofduartenterprises.macleanmessaging.telephony.SimRepository
import org.json.JSONObject

/** Durable user-initiated outbox. Only one worker can claim a record for sending. */
object ScheduleCoordinator {
    private const val JOB_BASE = 0x60000000
    fun exactAllowed(context: Context): Boolean = Build.VERSION.SDK_INT < 31 ||
        context.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    fun reconcile(context: Context) {
        val store = ComposeStore.get(context)
        store.recoverInterrupted()
        migrateLegacy(context, store)
        reconcileTransportResults(context, store)
        store.all().filter { it.state == "SCHEDULED" }.forEach { item ->
            runCatching { arm(context, item) }.onFailure {
                store.finish(item.id, "FAILED", "Could not register schedule: ${it.message}")
            }
        }
    }

    fun arm(context: Context, item: ComposeRecord) {
        check(item.state == "SCHEDULED")
        registerJob(context, item)
        val alarm = context.getSystemService(AlarmManager::class.java)
        val pending = pending(context, item.id)
        val time = item.runAt.coerceAtLeast(System.currentTimeMillis())
        if (exactAllowed(context)) {
            try { alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pending) }
            catch (_: SecurityException) { alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pending) }
        } else alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pending)
    }

    internal fun registerJob(context: Context, item: ComposeRecord) {
        val job = JobInfo.Builder(JOB_BASE + item.jobId, ComponentName(context, ScheduledSendJobService::class.java))
            .setExtras(PersistableBundle().apply { putString("id", item.id) })
            .setPersisted(true)
            .setMinimumLatency((item.runAt - System.currentTimeMillis()).coerceAtLeast(0))
        // Do not set a deadline: deadlines may override the network constraint.
        when {
            item.payload.kind == "EMAIL" -> job.setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            item.payload.attachments.isNotEmpty() || item.payload.to.size > 1 ->
                job.setRequiredNetworkType(JobInfo.NETWORK_TYPE_CELLULAR)
        }
        check(context.getSystemService(JobScheduler::class.java).schedule(job.build()) == JobScheduler.RESULT_SUCCESS) {
            "Android rejected this schedule. Free an Outbox slot and try again."
        }
    }

    fun cancelRegistration(context: Context, item: ComposeRecord) {
        context.getSystemService(AlarmManager::class.java).cancel(pending(context, item.id))
        context.getSystemService(JobScheduler::class.java).cancel(JOB_BASE + item.jobId)
    }

    private fun pending(context: Context, id: String): PendingIntent = PendingIntent.getBroadcast(context, 0,
        Intent(context, ScheduledSendReceiver::class.java).setData(Uri.parse("maclean-schedule:$id")).putExtra("id", id),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun migrateLegacy(context: Context, store: ComposeStore) {
        val old = context.getSharedPreferences("scheduled_messages", Context.MODE_PRIVATE)
        old.all.forEach { (key, value) ->
            runCatching {
                val o = JSONObject(value as String)
                val id = o.getString("token")
                if (store.get(id) == null) store.schedule(id, ComposePayload(to = listOf(o.getString("address")),
                    body = o.getString("body"), subscriptionId = o.getInt("subscriptionId")),
                    o.getLong("runAt").coerceAtLeast(System.currentTimeMillis()))
                val legacy = PendingIntent.getBroadcast(context, id.hashCode(), Intent(context, ScheduledSendReceiver::class.java),
                    PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
                if (legacy != null) { context.getSystemService(AlarmManager::class.java).cancel(legacy); legacy.cancel() }
                old.edit().remove(key).commit()
            }
        }
    }

    /** Cleans terminal records left by an older build or a callback/dispatcher ordering race. */
    fun reconcileTransportResults(context: Context, store: ComposeStore = ComposeStore.get(context)) {
        val metadata = LocalDatabase.get(context).messageMetaDao()
        val repository = SystemMessageRepository(context)
        metadata.all().forEach(repository::reconcileProvider)
        store.all().filter { it.state == "SUBMITTED" && !it.resultToken.isNullOrBlank() }.forEach { item ->
            val token = requireNotNull(item.resultToken)
            metadata.get(token)?.let { store.applyTransportResult(token, it.state) }
        }
        // SMTP is synchronous; an existing SENT queue row means both server acceptance and local
        // Sent-copy persistence completed before a previous process stopped.
        store.all().filter { it.state == "SENT" && it.payload.kind == "EMAIL" }
            .forEach { store.completeEmail(it.id) }
    }

    suspend fun perform(context: Context, id: String) {
        val store = ComposeStore.get(context)
        val item = store.claim(id) ?: return
        try {
            val p = item.payload
            p.validate()
            val token = if (p.kind == "EMAIL") {
                EmailComposeCoordinator(context).send(requireNotNull(p.accountId), EmailDraft(p.to, p.cc, p.bcc,
                    p.subject, p.body, p.attachments), ComposeMode.valueOf(p.mode), p.sourceMessageId).getOrThrow()
            } else {
                check(DefaultSmsRole.isDefault(context)) {
                    "Maclean Messaging is no longer the default SMS app. Restore the role, then resend from Drafts & Outbox."
                }
                check(context.checkSelfPermission(android.Manifest.permission.SEND_SMS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    "Android SMS permission is not granted. Open the app and restore messaging permission."
                }
                check(SimRepository.active(context).any { it.subscriptionId == p.subscriptionId }) {
                    "The selected SIM is unavailable. Edit a copy and choose an active SIM."
                }
                SystemMessageRepository(context).send(OutgoingMessage(p.to, p.body, p.attachments.map { value ->
                    val uri = Uri.parse(value)
                    Attachment(value, context.contentResolver.getType(uri) ?: "application/octet-stream", uri.lastPathSegment)
                }, p.subscriptionId))
            }
            if (p.kind == "EMAIL") {
                store.finish(id, "SENT", token = token)
                store.completeEmail(id)
            } else {
                store.finish(id, "SUBMITTED", token = token)
                // A fast carrier callback may have completed before resultToken was committed.
                LocalDatabase.get(context).messageMetaDao().get(token)?.let {
                    store.applyTransportResult(token, it.state)
                }
            }
        } catch (error: Exception) {
            store.finish(id, "FAILED", "${error.message ?: "Send failed"}. Check the conversation before retrying; the carrier/server may have accepted the message.")
        }
    }
}

class ScheduledSendReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra("id")
        val pending = goAsync()
        Async.launch {
            try {
                if (id == null) ScheduleCoordinator.reconcile(context)
                else ComposeStore.get(context).get(id)?.takeIf { it.state == "SCHEDULED" }?.let {
                    runCatching { ScheduleCoordinator.registerJob(context, it) }.onFailure { error ->
                        ComposeStore.get(context).finish(id, "FAILED", error.message)
                    }
                }
            } finally { pending.finish() }
        }
    }
}

class ScheduledSendJobService : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        val id = params.extras.getString("id") ?: return false
        Async.launch {
            try { ScheduleCoordinator.perform(applicationContext, id) }
            finally { Async.onMain { jobFinished(params, false) } }
        }
        return true
    }
    override fun onStopJob(params: JobParameters): Boolean {
        // Atomic claiming prevents a second dispatch; interrupted sends require user review.
        return true
    }
}

class RestoreSchedulesReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action !in setOf(Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED,
                Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED,
                "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED")) return
        val pending = goAsync()
        Async.launch {
            try { ScheduleCoordinator.reconcile(context); EmailSyncWorker.reconcile(context) }
            finally { pending.finish() }
        }
    }
}
