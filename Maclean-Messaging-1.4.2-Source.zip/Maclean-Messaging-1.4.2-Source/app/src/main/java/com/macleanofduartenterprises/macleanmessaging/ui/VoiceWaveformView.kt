/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 */

package com.macleanofduartenterprises.macleanmessaging.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.max

/** Compact, seekable waveform used by recorder previews and MMS voice-message bubbles. */
class VoiceWaveformView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var samples = floatArrayOf(0.16f, 0.32f, 0.58f, 0.26f, 0.72f, 0.44f, 0.2f, 0.5f)
    private var playedColor = Color.rgb(25, 105, 155)
    private var remainingColor = Color.rgb(155, 166, 176)
    private var seekListener: ((Float) -> Unit)? = null

    var progress: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            invalidate()
        }

    init {
        isClickable = true
        contentDescription = "Voice message waveform. Swipe or tap to seek."
        minimumHeight = dp(42)
    }

    fun setSamples(values: FloatArray) {
        samples = values.takeIf { it.isNotEmpty() }?.copyOf() ?: floatArrayOf(0.08f)
        invalidate()
    }

    fun setWaveformColors(played: Int, remaining: Int) {
        playedColor = played
        remainingColor = remaining
        invalidate()
    }

    fun setOnSeek(listener: (Float) -> Unit) {
        seekListener = listener
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(
            resolveSize(dp(220), widthMeasureSpec),
            resolveSize(dp(48), heightMeasureSpec)
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return
        val gap = dp(2).toFloat()
        val barWidth = max(dp(2).toFloat(), width / 84f)
        val count = max(1, (width / (barWidth + gap)).toInt())
        val center = height / 2f
        val maxBar = height * 0.86f
        for (index in 0 until count) {
            val sourceIndex = ((index.toFloat() / count) * samples.size).toInt().coerceIn(0, samples.lastIndex)
            val amplitude = samples[sourceIndex].coerceIn(0.08f, 1f)
            val barHeight = max(dp(4).toFloat(), maxBar * amplitude)
            val left = index * (barWidth + gap)
            if (left >= width) break
            paint.color = if ((left + barWidth / 2f) / width <= progress) playedColor else remainingColor
            val radius = barWidth / 2f
            canvas.drawRoundRect(left, center - barHeight / 2f, left + barWidth, center + barHeight / 2f, radius, radius, paint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isEnabled) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                seekListener?.invoke((event.x / width.coerceAtLeast(1)).coerceIn(0f, 1f))
                return true
            }
            MotionEvent.ACTION_UP -> {
                seekListener?.invoke((event.x / width.coerceAtLeast(1)).coerceIn(0f, 1f))
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    companion object {
        fun placeholder(seed: String, count: Int = 72): FloatArray {
            var value = seed.hashCode().toLong().let { if (it == 0L) 0x45D9F3BL else it }
            return FloatArray(count) {
                value = value * 1_103_515_245L + 12_345L
                0.12f + (((value ushr 16) and 0x7fff).toFloat() / 0x7fff) * 0.82f
            }
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
