/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.telephony

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.telephony.SubscriptionManager
import android.util.Log
import com.macleanofduartenterprises.macleanmessaging.system.DefaultSmsRole
import com.macleanofduartenterprises.macleanmessaging.util.Async

/**
 * Receives carrier WAP push notification for MMS.
 *
 * The notification's content location is handed to SmsManager for carrier-network retrieval;
 * the downloaded Retrieve.conf is then decoded and committed to Android's MMS provider.
 */
class MmsWapPushReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.WAP_PUSH_DELIVER_ACTION) return
        if (!DefaultSmsRole.isDefault(context)) return
        val data = intent.getByteArrayExtra("data") ?: return
        val subId = intent.getIntExtra(
            "subscription",
            intent.getIntExtra(SubscriptionManager.EXTRA_SUBSCRIPTION_INDEX, -1)
        )
        // A broadcast's synchronous PendingResult is detached by goAsync(). Acknowledge it first;
        // calling setResultCode afterward crashes Android 15 with "result is not pending".
        setResultCode(Telephony.Sms.Intents.RESULT_SMS_HANDLED)
        val pending = goAsync()
        Async.launchSerial {
            try {
                runCatching { IncomingMmsManager.receiveNotification(context.applicationContext, data, subId) }
                    .onFailure { Log.e(TAG, "Incoming MMS was retained for retry", it) }
            } finally {
                runCatching { pending.finish() }
                    .onFailure { Log.e(TAG, "Could not finish incoming MMS broadcast", it) }
            }
        }
    }

    private companion object {
        const val TAG = "MmsWapPushReceiver"
    }
}
