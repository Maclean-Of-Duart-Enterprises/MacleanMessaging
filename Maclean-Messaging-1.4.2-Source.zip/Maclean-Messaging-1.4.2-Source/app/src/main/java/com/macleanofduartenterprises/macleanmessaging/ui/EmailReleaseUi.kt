/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Email account management, compose, reply, reply-all, forward, attachment,
 * test, sync, enable/disable, default-account, and OAuth controls are hosted
 * by MainActivity using Android platform views.
 */

package com.macleanofduartenterprises.macleanmessaging.ui

internal object EmailReleaseUi
