/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.email.notifications

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailAccountEntity
import com.macleanofduartenterprises.macleanmessaging.notifications.NotificationController
import com.macleanofduartenterprises.macleanmessaging.settings.UserSettings
import com.macleanofduartenterprises.macleanmessaging.ui.MainActivity

/** Keeps one account-level notification synchronized with the actual unread row count. */
object EmailNotifier {
    fun updateUnread(
        context: Context,
        account: EmailAccountEntity,
        unreadCount: Int,
        alert: Boolean = false
    ) {
        val manager = context.getSystemService(NotificationManager::class.java)
        val notificationId = EmailNotificationKey.accountNotificationId(account.id)
        val settings = UserSettings(context).notifications
        if (!settings.enabled || !settings.emailNotifications) {
            manager.cancel(notificationId)
            return
        }
        if (unreadCount <= 0) {
            manager.cancel(notificationId)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        if (!settings.persistentUnread && !alert &&
            !NotificationController.isPosted(context, notificationId, Notification.CATEGORY_EMAIL)
        ) return

        val channelId = EmailNotificationKey.accountChannelId(account.id)
        manager.createNotificationChannel(
            NotificationChannel(
                channelId,
                "Email — ${account.displayName}",
                NotificationManager.IMPORTANCE_DEFAULT
            )
        )
        val open = PendingIntent.getActivity(
            context,
            notificationId,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        manager.notify(
            notificationId,
            Notification.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.sym_action_email)
                .setContentTitle(if (settings.showPreviews) account.displayName else "New email")
                .setContentText(if (settings.showPreviews) {
                    "$unreadCount unread email message${if (unreadCount == 1) "" else "s"}"
                } else {
                    "Open Maclean Messaging to view it."
                })
                .setNumber(unreadCount)
                .setContentIntent(open)
                .setAutoCancel(!settings.persistentUnread)
                .setOngoing(settings.persistentUnread)
                .setOnlyAlertOnce(!alert)
                .setVisibility(if (settings.showPreviews) Notification.VISIBILITY_PRIVATE else Notification.VISIBILITY_SECRET)
                .setCategory(Notification.CATEGORY_EMAIL)
                .build()
        )
    }

    fun cancelAccount(context: Context, accountId: String) {
        context.getSystemService(NotificationManager::class.java)
            .cancel(EmailNotificationKey.accountNotificationId(accountId))
    }
}
