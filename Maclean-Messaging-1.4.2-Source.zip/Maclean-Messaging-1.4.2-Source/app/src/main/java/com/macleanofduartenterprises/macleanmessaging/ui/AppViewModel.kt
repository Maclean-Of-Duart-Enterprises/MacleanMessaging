/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 */

package com.macleanofduartenterprises.macleanmessaging.ui

import android.content.Context
import com.macleanofduartenterprises.macleanmessaging.data.LocalDatabase
import com.macleanofduartenterprises.macleanmessaging.unified.UnifiedConversation
import com.macleanofduartenterprises.macleanmessaging.unified.UnifiedInboxRepository

data class AppUiState(
    val loading: Boolean = true,
    val emailConfigured: Boolean = false,
    val emailAccountCount: Int = 0,
    val conversations: List<UnifiedConversation> = emptyList()
)

class AppViewModel(private val context: Context) {
    suspend fun load(): AppUiState {
        val repository = UnifiedInboxRepository(context)
        return AppUiState(
            loading = false,
            emailConfigured = repository.emailEnabled(),
            emailAccountCount = LocalDatabase.get(context).emailAccountDao().enabledCount(),
            conversations = repository.conversations()
        )
    }
}
