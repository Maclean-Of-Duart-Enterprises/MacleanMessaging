/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging

import android.app.Application
import android.util.Log
import com.macleanofduartenterprises.macleanmessaging.data.LocalDatabase
import com.macleanofduartenterprises.macleanmessaging.email.sync.EmailSyncWorker
import com.macleanofduartenterprises.macleanmessaging.notifications.NotificationChannels
import com.macleanofduartenterprises.macleanmessaging.notifications.NotificationController
import com.macleanofduartenterprises.macleanmessaging.schedule.ScheduleCoordinator
import com.macleanofduartenterprises.macleanmessaging.telephony.IncomingMmsManager
import com.macleanofduartenterprises.macleanmessaging.telephony.IncomingSmsManager
import com.macleanofduartenterprises.macleanmessaging.util.Async

class MacleanMessagingApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // A telephony broadcast may cold-start the process. Optional notification setup must not
        // prevent the SMS/MMS receiver from being constructed on vendor Android builds.
        runCatching { NotificationChannels.create(this) }
            .onFailure { Log.e(TAG, "Notification channel initialization failed", it) }

        // Schedule/database reconciliation is independent of the live carrier lane. A cold-start
        // SMS/MMS broadcast must never wait behind an Outbox scan.
        Async.launch {
            runCatching { ScheduleCoordinator.reconcile(this@MacleanMessagingApp) }
                .onFailure { Log.e(TAG, "Schedule reconciliation failed", it) }
        }

        // Pending carrier records are quick to inspect and remain ordered with live receiver work.
        Async.launchSerial {
            runCatching { IncomingSmsManager.reconcile(this@MacleanMessagingApp) }
                .onFailure { Log.e(TAG, "Incoming SMS reconciliation failed", it) }
            runCatching { IncomingMmsManager.reconcile(this@MacleanMessagingApp) }
                .onFailure { Log.e(TAG, "Incoming MMS reconciliation failed", it) }
        }

        Async.launch {
            runCatching { NotificationController.applyPreferences(this@MacleanMessagingApp) }
                .onFailure { Log.e(TAG, "Notification preference initialization failed", it) }
            val configured = runCatching {
                LocalDatabase.get(this@MacleanMessagingApp).emailAccountDao().enabledCount() > 0
            }.onFailure { Log.e(TAG, "Email account lookup failed", it) }.getOrDefault(false)

            if (configured) {
                runCatching { EmailSyncWorker.reconcile(this@MacleanMessagingApp) }
                    .onFailure { Log.e(TAG, "Email synchronization reconciliation failed", it) }
            } else {
                runCatching { EmailSyncWorker.disable(this@MacleanMessagingApp) }
                    .onFailure { Log.e(TAG, "Email synchronization disable failed", it) }
            }
        }
    }

    private companion object {
        const val TAG = "MacleanMessagingApp"
    }
}
