/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 */

package com.macleanofduartenterprises.macleanmessaging.telephony

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.provider.Telephony
import android.util.AtomicFile
import android.util.Log
import com.macleanofduartenterprises.macleanmessaging.blocking.BlockingRepository
import com.macleanofduartenterprises.macleanmessaging.data.DeviceMessageRepository
import com.macleanofduartenterprises.macleanmessaging.notifications.MessageNotifier
import com.macleanofduartenterprises.macleanmessaging.util.Async
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/**
 * Durable incoming-SMS transaction boundary.
 *
 * The telephony broadcast is acknowledged quickly, while provider/database/contact work runs off
 * the receiver thread. A private atomic staging record remains until the canonical Android SMS
 * row exists, so a provider or vendor failure can be retried without losing the received text.
 */
object IncomingSmsManager {
    fun accept(
        context: Context,
        address: String,
        body: String,
        subscriptionId: Int,
        timestamp: Long
    ) {
        val app = context.applicationContext
        val pending = PendingSms(address, body, subscriptionId, timestamp)
        val file = pendingFile(app, pending.token)
        writeAtomic(file, pending.toJson().toString().toByteArray(Charsets.UTF_8))
        try {
            commit(app, pending)
            file.delete()
        } catch (error: Throwable) {
            Log.e(TAG, "Incoming SMS ${pending.token} was staged for retry", error)
            scheduleRetry(app)
        }
    }

    /** Returns true when at least one staged SMS still needs another provider retry. */
    fun retryPending(context: Context): Boolean {
        val app = context.applicationContext
        var retry = false
        pendingDirectory(app).listFiles { file -> file.extension == "json" }
            .orEmpty()
            .sortedBy(File::lastModified)
            .forEach { file ->
                val pending = runCatching { PendingSms.fromJson(JSONObject(file.readText())) }
                    .onFailure { Log.e(TAG, "Invalid incoming SMS staging record ${file.name}", it) }
                    .getOrNull()
                if (pending == null) {
                    file.renameTo(File(file.parentFile, file.nameWithoutExtension + ".invalid"))
                    return@forEach
                }
                runCatching { commit(app, pending) }
                    .onSuccess { file.delete() }
                    .onFailure {
                        retry = true
                        Log.e(TAG, "Incoming SMS ${pending.token} retry failed", it)
                    }
            }
        return retry
    }

    fun reconcile(context: Context) {
        if (pendingDirectory(context).listFiles { file -> file.extension == "json" }.orEmpty().isNotEmpty()) {
            scheduleRetry(context.applicationContext)
        }
    }

    private fun commit(context: Context, pending: PendingSms) {
        val blocked = runCatching { BlockingRepository.isBlocked(context, pending.address) }
            .onFailure { Log.e(TAG, "Blocked-number lookup failed; preserving SMS delivery", it) }
            .getOrDefault(false)
        if (blocked) return

        val existing = findExisting(context, pending)
        val messageUri = existing ?: context.contentResolver.insert(
            Telephony.Sms.Inbox.CONTENT_URI,
            ContentValues().apply {
                put(Telephony.Sms.ADDRESS, pending.address)
                put(Telephony.Sms.BODY, pending.body)
                put(Telephony.Sms.DATE, pending.timestamp)
                put(Telephony.Sms.DATE_SENT, pending.timestamp)
                put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_INBOX)
                put(Telephony.Sms.READ, 0)
                put(Telephony.Sms.SEEN, 0)
                put(Telephony.Sms.SUBSCRIPTION_ID, pending.subscriptionId)
            }
        ) ?: error("Android did not create the incoming SMS row.")
        DeviceMessageRepository.invalidateCaches()

        // A notification failure must never roll back or crash a successfully received message.
        runCatching {
            MessageNotifier.notifyIncoming(context, pending.address, pending.body, messageUri.toString())
        }.onFailure { Log.e(TAG, "Incoming SMS notification failed", it) }
    }

    private fun findExisting(context: Context, pending: PendingSms) = runCatching {
        context.contentResolver.query(
            Telephony.Sms.Inbox.CONTENT_URI,
            arrayOf(Telephony.Sms._ID),
            "${Telephony.Sms.ADDRESS}=? AND ${Telephony.Sms.DATE}=? AND ${Telephony.Sms.BODY}=?",
            arrayOf(pending.address, pending.timestamp.toString(), pending.body),
            "${Telephony.Sms._ID} DESC"
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                ContentUris.withAppendedId(Telephony.Sms.CONTENT_URI, cursor.getLong(0))
            } else null
        }
    }.getOrNull()

    private fun scheduleRetry(context: Context) {
        val scheduler = context.getSystemService(JobScheduler::class.java)
        if (runCatching { scheduler.allPendingJobs.any { it.id == JOB_ID } }.getOrDefault(false)) return
        val job = JobInfo.Builder(JOB_ID, ComponentName(context, IncomingSmsRetryJobService::class.java))
            .setMinimumLatency(RETRY_DELAY_MS)
            .setOverrideDeadline(RETRY_DEADLINE_MS)
            .setPersisted(true)
            .setBackoffCriteria(RETRY_DELAY_MS, JobInfo.BACKOFF_POLICY_EXPONENTIAL)
            .build()
        runCatching { scheduler.schedule(job) }
            .onFailure { Log.e(TAG, "Could not schedule incoming SMS retry", it) }
    }

    private fun pendingDirectory(context: Context) =
        File(context.filesDir, "incoming-sms-pending").apply { mkdirs() }

    private fun pendingFile(context: Context, token: String) = File(pendingDirectory(context), "$token.json")

    private fun writeAtomic(file: File, bytes: ByteArray) {
        val atomic = AtomicFile(file)
        val output = atomic.startWrite()
        try {
            output.write(bytes)
            output.fd.sync()
            atomic.finishWrite(output)
        } catch (error: Throwable) {
            atomic.failWrite(output)
            throw error
        }
    }

    private data class PendingSms(
        val address: String,
        val body: String,
        val subscriptionId: Int,
        val timestamp: Long
    ) {
        val token: String get() = stableToken("$address\n$timestamp\n$subscriptionId\n$body")

        fun toJson() = JSONObject()
            .put("address", address)
            .put("body", body)
            .put("subscriptionId", subscriptionId)
            .put("timestamp", timestamp)

        companion object {
            fun fromJson(value: JSONObject) = PendingSms(
                value.getString("address"),
                value.getString("body"),
                value.optInt("subscriptionId", -1),
                value.getLong("timestamp")
            )
        }
    }

    private fun stableToken(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).take(16).joinToString("") { "%02x".format(it) }

    private const val TAG = "IncomingSms"
    private const val JOB_ID = 0x4D5313
    private const val RETRY_DELAY_MS = 30_000L
    private const val RETRY_DEADLINE_MS = 2 * 60_000L
}

class IncomingSmsRetryJobService : JobService() {
    @Volatile private var stopped = false

    override fun onStartJob(params: JobParameters): Boolean {
        stopped = false
        Async.launchSerial {
            val retry = runCatching { IncomingSmsManager.retryPending(applicationContext) }
                .onFailure { Log.e("IncomingSms", "Incoming SMS retry job failed", it) }
                .getOrDefault(true)
            Async.onMain {
                if (!stopped) runCatching { jobFinished(params, retry) }
                    .onFailure { Log.e("IncomingSms", "Could not finish incoming SMS retry job", it) }
            }
        }
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean {
        stopped = true
        return true
    }
}
