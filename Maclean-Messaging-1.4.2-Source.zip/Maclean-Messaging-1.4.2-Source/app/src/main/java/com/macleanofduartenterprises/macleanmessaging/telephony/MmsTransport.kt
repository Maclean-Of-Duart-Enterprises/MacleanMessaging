/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.telephony

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import android.util.Log
import com.macleanofduartenterprises.macleanmessaging.files.PduContentProvider
import com.macleanofduartenterprises.macleanmessaging.model.OutgoingMessage
import java.io.File

/**
 * Carrier MMS transport boundary.
 *
 * Android's public SmsManager API accepts an already-encoded MMS PDU through
 * sendMultimediaMessage(). MmsPduCodec owns MM1 encoding/decoding so it can be
 * tested independently and replaced without touching UI/domain code.
 */
object MmsTransport {
    const val ACTION_SENT = "com.macleanofduartenterprises.macleanmessaging.MMS_SENT"

    fun send(context: Context, message: OutgoingMessage, token: String) {
        require(message.attachments.isNotEmpty() || message.recipients.size > 1)
        require(message.subscriptionId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
            "Select an active SIM before sending MMS."
        }

        val carrier = MmsCarrierConfig.profile(context, message.subscriptionId)
        val pdu = MmsPduCodec.encodeSendReq(context, message, carrier)
        require(pdu.size <= carrier.maxMessageBytes) {
            "This carrier accepts ${formatSize(carrier.maxMessageBytes)} MMS messages. Reduce non-image attachments and try again."
        }
        Log.i(
            TAG,
            "Submitting encoded MMS: attachments=${message.attachments.size}, " +
                "bytes=${pdu.size}, carrierLimit=${carrier.maxMessageBytes}, " +
                "imageBounds=${carrier.maxImageWidth}x${carrier.maxImageHeight}, " +
                "subscription=${message.subscriptionId}"
        )
        val file = File(context.cacheDir, "mms-$token.pdu").apply { writeBytes(pdu) }
        val uri: Uri = PduContentProvider.uriFor(context, file)

        @Suppress("DEPRECATION")
        val manager = if (Build.VERSION.SDK_INT >= 31) {
            context.getSystemService(SmsManager::class.java).createForSubscriptionId(message.subscriptionId)
        } else SmsManager.getSmsManagerForSubscriptionId(message.subscriptionId)

        val sent = PendingIntent.getBroadcast(
            context,
            token.hashCode(),
            Intent(context, SmsStatusReceiver::class.java).apply {
                action = ACTION_SENT
                data = Uri.parse("maclean-mms-status:$token/sent")
                putExtra("token", token)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        manager.sendMultimediaMessage(
            context,
            uri,
            null,
            MmsCarrierConfig.operationOverrides(),
            sent
        )
    }

    fun deleteCachedPdu(context: Context, token: String) {
        File(context.cacheDir, "mms-$token.pdu").delete()
    }

    private fun formatSize(bytes: Int): String = if (bytes >= 1024 * 1024) {
        String.format(java.util.Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
    } else "${(bytes + 1023) / 1024} KB"

    private const val TAG = "MacleanMmsTransport"
}
