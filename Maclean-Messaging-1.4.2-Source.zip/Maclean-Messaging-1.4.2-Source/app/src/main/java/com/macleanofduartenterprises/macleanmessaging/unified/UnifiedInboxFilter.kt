/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.unified

data class UnifiedInboxFilter(
    val includeSmsMms: Boolean = true,
    val emailAccountIds: Set<String> = emptySet()
) {
    /**
     * Empty emailAccountIds means "all enabled email accounts."
     */
    fun allows(conversation: UnifiedConversation): Boolean =
        when (conversation.transport) {
            CommunicationTransport.SMS,
            CommunicationTransport.MMS -> includeSmsMms
            CommunicationTransport.EMAIL ->
                emailAccountIds.isEmpty() || conversation.accountId in emailAccountIds
        }
}
