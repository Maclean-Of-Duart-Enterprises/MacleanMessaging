/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 */

package com.macleanofduartenterprises.macleanmessaging.notifications

import android.Manifest
import android.app.Notification
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.macleanofduartenterprises.macleanmessaging.settings.NotificationSettings
import com.macleanofduartenterprises.macleanmessaging.settings.UserSettings

/** Applies the in-app notification choices to both future and currently posted alerts. */
object NotificationController {
    fun systemNotificationsAllowed(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        return context.getSystemService(NotificationManager::class.java).areNotificationsEnabled()
    }

    fun applyPreferences(context: Context, value: NotificationSettings = UserSettings(context).notifications) {
        val manager = context.getSystemService(NotificationManager::class.java)
        if (!value.enabled) {
            manager.cancelAll()
            return
        }

        manager.activeNotifications.forEach { posted ->
            val category = posted.notification.category
            val enabledForCategory = when (category) {
                Notification.CATEGORY_MESSAGE -> value.messageNotifications
                Notification.CATEGORY_EMAIL -> value.emailNotifications
                else -> true
            }
            if (!enabledForCategory) {
                manager.cancel(posted.tag, posted.id)
            } else if (category == Notification.CATEGORY_MESSAGE || category == Notification.CATEGORY_EMAIL) {
                runCatching {
                    val refreshed = Notification.Builder.recoverBuilder(context, posted.notification)
                        .setOngoing(value.persistentUnread)
                        .setAutoCancel(!value.persistentUnread)
                        .setOnlyAlertOnce(true)
                        .build()
                    manager.notify(posted.tag, posted.id, refreshed)
                }
            }
        }
    }

    fun clearManaged(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.activeNotifications.forEach { posted ->
            if (posted.notification.category in MANAGED_CATEGORIES) {
                manager.cancel(posted.tag, posted.id)
            }
        }
    }

    fun isPosted(context: Context, notificationId: Int, category: String): Boolean =
        context.getSystemService(NotificationManager::class.java)
            .activeNotifications
            .any { it.id == notificationId && it.notification.category == category }

    private val MANAGED_CATEGORIES = setOf(Notification.CATEGORY_MESSAGE, Notification.CATEGORY_EMAIL)
}
