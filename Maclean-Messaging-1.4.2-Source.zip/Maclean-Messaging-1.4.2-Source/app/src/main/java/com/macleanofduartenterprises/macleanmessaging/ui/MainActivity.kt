/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 */

package com.macleanofduartenterprises.macleanmessaging.ui

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.database.ContentObserver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Environment
import android.os.SystemClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.provider.Telephony
import android.text.InputType
import android.text.Layout
import android.text.SpannableString
import android.text.TextUtils
import android.text.TextWatcher
import android.text.Editable
import android.text.util.Linkify
import android.util.LruCache
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Filter
import android.widget.Filterable
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.MultiAutoCompleteTextView
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Space
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import com.macleanofduartenterprises.macleanmessaging.contacts.ContactDirectory
import com.macleanofduartenterprises.macleanmessaging.contacts.ContactEntry
import com.macleanofduartenterprises.macleanmessaging.data.DeviceAttachment
import com.macleanofduartenterprises.macleanmessaging.data.LocalDatabase
import com.macleanofduartenterprises.macleanmessaging.data.DeviceMessage
import com.macleanofduartenterprises.macleanmessaging.data.DeviceMessageRepository
import com.macleanofduartenterprises.macleanmessaging.data.SystemMessageRepository
import com.macleanofduartenterprises.macleanmessaging.email.EmailAccountService
import com.macleanofduartenterprises.macleanmessaging.email.EmailProviderCatalog
import com.macleanofduartenterprises.macleanmessaging.email.NewEmailAccount
import com.macleanofduartenterprises.macleanmessaging.email.compose.ComposeMode
import com.macleanofduartenterprises.macleanmessaging.email.compose.ComposeSeed
import com.macleanofduartenterprises.macleanmessaging.email.compose.EmailActionService
import com.macleanofduartenterprises.macleanmessaging.email.compose.EmailComposeCoordinator
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailAccountEntity
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailAttachmentEntity
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailMessageEntity
import com.macleanofduartenterprises.macleanmessaging.email.oauth.OAuthUiLauncher
import com.macleanofduartenterprises.macleanmessaging.email.sync.EmailSyncWorker
import com.macleanofduartenterprises.macleanmessaging.email.transport.EmailDraft
import com.macleanofduartenterprises.macleanmessaging.files.PduContentProvider
import com.macleanofduartenterprises.macleanmessaging.model.Attachment
import com.macleanofduartenterprises.macleanmessaging.model.OutgoingMessage
import com.macleanofduartenterprises.macleanmessaging.notifications.MessageNotifier
import com.macleanofduartenterprises.macleanmessaging.notifications.NotificationChannels
import com.macleanofduartenterprises.macleanmessaging.notifications.NotificationController
import com.macleanofduartenterprises.macleanmessaging.schedule.ScheduleCoordinator
import com.macleanofduartenterprises.macleanmessaging.settings.AppearanceSettings
import com.macleanofduartenterprises.macleanmessaging.settings.DisplaySettings
import com.macleanofduartenterprises.macleanmessaging.settings.NotificationSettings
import com.macleanofduartenterprises.macleanmessaging.settings.SortingSettings
import com.macleanofduartenterprises.macleanmessaging.settings.UserSettings
import com.macleanofduartenterprises.macleanmessaging.system.DefaultSmsRole
import com.macleanofduartenterprises.macleanmessaging.system.SmsRuntimeReadiness
import com.macleanofduartenterprises.macleanmessaging.telephony.SimRepository
import com.macleanofduartenterprises.macleanmessaging.unified.CommunicationTransport
import com.macleanofduartenterprises.macleanmessaging.unified.UnifiedConversation
import com.macleanofduartenterprises.macleanmessaging.unified.UnifiedInboxRepository
import com.macleanofduartenterprises.macleanmessaging.unified.UnifiedInboxSnapshotStore
import com.macleanofduartenterprises.macleanmessaging.unified.UnifiedParticipant
import com.macleanofduartenterprises.macleanmessaging.util.Async
import com.macleanofduartenterprises.macleanmessaging.voice.VoiceDraft
import com.macleanofduartenterprises.macleanmessaging.voice.VoiceMedia
import com.macleanofduartenterprises.macleanmessaging.voice.VoicePlaybackController
import com.macleanofduartenterprises.macleanmessaging.voice.VoiceRecorder
import com.macleanofduartenterprises.macleanmessaging.workflow.ComposePayload
import com.macleanofduartenterprises.macleanmessaging.workflow.ComposeRecord
import com.macleanofduartenterprises.macleanmessaging.workflow.ComposeStore
import java.io.File
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Calendar
import java.util.UUID
import java.util.concurrent.Executors
import org.json.JSONArray

class MainActivity : Activity() {
    private data class PendingSmsRoleAction(
        val itemId: String,
        val runAt: Long?,
        val origin: String
    )

    private val emailAttachmentUris = mutableListOf<Uri>()
    private val messageAttachmentUris = mutableListOf<Uri>()
    private var attachmentSummary: TextView? = null
    private var attachmentTarget = ATTACH_NONE
    private var currentPage = PAGE_INBOX
    private lateinit var appearance: AppearanceSettings
    private val inboxSelected = linkedSetOf<String>()
    private val deviceMessageSelected = linkedSetOf<String>()
    private val emailMessageSelected = linkedSetOf<String>()
    private var activeDeviceThreadId: Long? = null
    private var activeEmailThreadId: String? = null
    private var inboxQuery = ""
    private var inboxArchived = false
    private var activeDraftId: String? = null
    private var composeSnapshot: (() -> ComposePayload)? = null
    private var composeBody: EditText? = null
    private var composeBusy = false
    private var composeStatus: TextView? = null
    private var composeContainer: ViewGroup? = null
    private var inlineReplyThreadId: Long? = null
    private var inlineReplyAddress: String = ""
    private var inlineReplyBody: EditText? = null
    private var inlineVoicePanel: View? = null
    private var pendingSmsRoleAction: PendingSmsRoleAction? = null
    private var smsPermissionRequestActive = false
    private val draftHandler = Handler(Looper.getMainLooper())
    private val autosave = Runnable { saveDraftQuietly() }
    private val messageProviderRefresh = Runnable {
        messageProviderRefreshScheduled = false
        if (isFinishing || isDestroyed || !hasWindowFocus()) return@Runnable
        messageProviderRefreshNotBefore = SystemClock.elapsedRealtime() + MESSAGE_PROVIDER_REFRESH_THROTTLE_MS
        when {
            currentPage == PAGE_INBOX -> showInbox()
            currentPage == PAGE_THREAD && activeEmailThreadId == null -> {
                val draft = composeSnapshot?.invoke()
                val replyInProgress = inlineReplyThreadId != null &&
                    (draft?.body?.isNotBlank() == true || draft?.attachments?.isNotEmpty() == true ||
                        activeVoiceRecorder != null || pendingVoiceDraft != null)
                if (replyInProgress) saveDraftQuietly()
                else activeDeviceThreadId?.let { showSmsThread(it, activeDeviceAddress) }
            }
        }
    }
    private val messageProviderObserver = object : ContentObserver(draftHandler) {
        override fun onChange(selfChange: Boolean) {
            if (!messageProviderObserverRegistered || messageProviderRefreshScheduled) return
            if (SystemClock.elapsedRealtime() < messageProviderIgnoreUntil) return
            DeviceMessageRepository.invalidateCaches()
            messageProviderRefreshScheduled = true
            val delay = (messageProviderRefreshNotBefore - SystemClock.elapsedRealtime())
                .coerceAtLeast(MESSAGE_PROVIDER_REFRESH_DELAY_MS)
            draftHandler.postDelayed(messageProviderRefresh, delay)
        }
    }
    private var messageProviderObserverRegistered = false
    private var messageProviderRefreshScheduled = false
    private var messageProviderRefreshNotBefore = 0L
    private var messageProviderIgnoreUntil = 0L
    private var inboxFilter = FILTER_ALL
    private var inboxContactFilter = CONTACT_ALL
    private var inboxSort = SORT_NEWEST
    private var contactQuery = ""
    private var activeInboxState: InboxState? = null
    private var activeDeviceMessages: List<DeviceMessage> = emptyList()
    private var activeDeviceAddress: String = ""
    private var activeEmailState: ThreadState? = null
    private var activeInboxAdapter: InboxConversationAdapter? = null
    private var activeDeviceAdapter: DeviceMessageAdapter? = null
    private var activeDeviceList: ListView? = null
    private var activeDeviceStatus: TextView? = null
    private var activeDeviceLoading = false
    private var activeDeviceSort = THREAD_OLDEST
    private var activeEmailAdapter: EmailMessageAdapter? = null
    private var activeEmailStatus: TextView? = null
    private var activeEmailSort = THREAD_OLDEST
    private val emailAttachmentsLoading = linkedSetOf<String>()
    private var threadScreenGeneration = 0
    private var firstResumePending = true
    private var inboxLoadGeneration = 0
    private var cachedBackgroundKey: String? = null
    private var cachedBackgroundBitmap: Bitmap? = null
    private var activeVoiceRecorder: VoiceRecorder? = null
    private var pendingVoiceDraft: VoiceDraft? = null
    private var voicePermissionStatus: TextView? = null
    private val dateTimeFormat = ThreadLocal.withInitial { DateFormat.getDateTimeInstance() }
    private val shortDateTimeFormat = ThreadLocal.withInitial {
        DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
    }
    private val mmsPreviewCache = object : LruCache<String, Bitmap>(MMS_PREVIEW_CACHE_KIB) {
        override fun sizeOf(key: String, value: Bitmap): Int = (value.byteCount / 1024).coerceAtLeast(1)
    }
    private val attachmentMetadataCache = object : LruCache<String, Attachment>(ATTACHMENT_METADATA_CACHE_ITEMS) {}
    private val voiceDurationCache = object : LruCache<String, Long>(VOICE_DURATION_CACHE_ITEMS) {}
    private val emailThreadCache = object : LruCache<String, ThreadState>(EMAIL_THREAD_CACHE_ITEMS) {}
    private val linkedTextCache = object : LruCache<String, CharSequence>(LINKED_TEXT_CACHE_CHARS) {
        override fun sizeOf(key: String, value: CharSequence): Int = value.length.coerceAtLeast(1)
    }
    private val voiceDurationLoading = linkedSetOf<String>()
    private val mmsPreviewLoading = linkedSetOf<String>()
    private val linkedTextLoading = linkedSetOf<String>()
    private val typefaceCache = mutableMapOf<String, Typeface>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingSmsRoleAction = savedInstanceState?.takeIf { it.containsKey(STATE_SMS_ROLE_ITEM_ID) }?.let {
            PendingSmsRoleAction(
                itemId = it.getString(STATE_SMS_ROLE_ITEM_ID).orEmpty(),
                runAt = it.getLong(STATE_SMS_ROLE_RUN_AT, NO_SCHEDULE_TIME).takeUnless { value -> value == NO_SCHEDULE_TIME },
                origin = it.getString(STATE_SMS_ROLE_ORIGIN).orEmpty()
            )
        }?.takeIf { it.itemId.isNotBlank() && it.origin in setOf(ROLE_ORIGIN_COMPOSER, ROLE_ORIGIN_WORKFLOW) }
        UserSettings(this).sorting.let { defaults ->
            inboxFilter = defaults.inboxTransportFilter
            inboxContactFilter = defaults.inboxContactFilter
            inboxSort = defaults.inboxSort
        }
        // Android requires the default-handler request before SMS-group permissions. Existing
        // default users can request everything immediately; new users see the role chooser first.
        if (DefaultSmsRole.isDefault(this)) requestCorePermissions()
        else if (savedInstanceState == null) DefaultSmsRole.request(this, REQUEST_DEFAULT_SMS_ROLE)
        handleLaunchIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        if (!messageProviderObserverRegistered) {
            messageProviderObserverRegistered = runCatching {
                contentResolver.registerContentObserver(Telephony.Sms.CONTENT_URI, true, messageProviderObserver)
                contentResolver.registerContentObserver(Telephony.Mms.CONTENT_URI, true, messageProviderObserver)
                true
            }.getOrDefault(false)
        }
    }

    override fun onStop() {
        draftHandler.removeCallbacks(messageProviderRefresh)
        messageProviderRefreshScheduled = false
        if (messageProviderObserverRegistered) runCatching {
            contentResolver.unregisterContentObserver(messageProviderObserver)
        }
        messageProviderObserverRegistered = false
        super.onStop()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        pendingSmsRoleAction?.let {
            outState.putString(STATE_SMS_ROLE_ITEM_ID, it.itemId)
            outState.putLong(STATE_SMS_ROLE_RUN_AT, it.runAt ?: NO_SCHEDULE_TIME)
            outState.putString(STATE_SMS_ROLE_ORIGIN, it.origin)
        }
        super.onSaveInstanceState(outState)
    }

    override fun onNewIntent(intent: Intent) {
        saveDraftQuietly()
        super.onNewIntent(intent)
        setIntent(intent)
        handleLaunchIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        resumePendingSmsRoleAction()
        if (firstResumePending) {
            firstResumePending = false
            return
        }
        when (currentPage) {
            PAGE_INBOX -> showInbox()
            PAGE_CONTACTS -> showContacts()
            PAGE_WORKFLOWS -> showWorkflows()
        }
    }

    override fun onPause() {
        saveDraftQuietly()
        super.onPause()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_SMS_SEND_PERMISSIONS) {
            smsPermissionRequestActive = false
            if (hasSmsRolePermissions()) {
                if (pendingSmsRoleAction != null) resumePendingSmsRoleAction() else refreshMessagingPage()
            }
            else {
                pendingSmsRoleAction = null
                setComposeBusy(false)
                composeStatus?.text = "SMS permission was not granted. The draft remains saved."
                toast("SMS permission is required to send or schedule messages.")
            }
        } else if (requestCode == REQUEST_PERMISSIONS && DefaultSmsRole.isDefault(this) && hasSmsRolePermissions()) {
            if (pendingSmsRoleAction != null) resumePendingSmsRoleAction() else refreshMessagingPage()
        } else if (requestCode == REQUEST_RECORD_AUDIO) {
            voicePermissionStatus?.text = if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                "Microphone ready. Hold the microphone again to record."
            } else {
                "Microphone permission is required to record a voice message."
            }
        } else if (requestCode == REQUEST_PERMISSIONS && currentPage == PAGE_CONTACTS &&
            checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        ) showContacts()
        else if (requestCode == REQUEST_PERMISSIONS && currentPage == PAGE_INBOX) showInbox()
        else if (requestCode == REQUEST_PERMISSIONS && currentPage == PAGE_NOTIFICATION_SETTINGS) showNotificationSettings()
    }

    override fun onDestroy() {
        draftHandler.removeCallbacks(messageProviderRefresh)
        if (messageProviderObserverRegistered) runCatching {
            contentResolver.unregisterContentObserver(messageProviderObserver)
        }
        messageProviderObserverRegistered = false
        activeVoiceRecorder?.cancel()
        activeVoiceRecorder = null
        pendingVoiceDraft?.let { draft ->
            VoicePlaybackController.stopIfKey("draft:${draft.file.absolutePath}")
            draft.file.delete()
        }
        pendingVoiceDraft = null
        if (isFinishing) {
            VoicePlaybackController.release()
            mmsPreviewCache.evictAll()
        }
        super.onDestroy()
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        when (currentPage) {
            PAGE_INBOX -> super.onBackPressed()
            PAGE_COMPOSE -> leaveComposer()
            PAGE_THREAD -> if (activeDeviceThreadId != null && inlineReplyThreadId != null) leaveSmsThread() else showInbox()
            PAGE_APPEARANCE, PAGE_SORT_SETTINGS, PAGE_NOTIFICATION_SETTINGS, PAGE_ACCOUNTS, PAGE_LICENSE -> showSettings()
            PAGE_ACCOUNT_EDIT -> showAccounts()
            else -> showInbox()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_DEFAULT_SMS_ROLE) {
            // Role chooser results commonly contain no Intent data, and some vendor builds report
            // RESULT_CANCELED after changing the role. Always re-check the authoritative role state.
            if (DefaultSmsRole.isDefault(this)) {
                if (!requestCorePermissions()) {
                    if (pendingSmsRoleAction != null) resumePendingSmsRoleAction()
                    else refreshMessagingPage()
                }
            }
            else draftHandler.postDelayed({
                if (DefaultSmsRole.isDefault(this)) {
                    if (!requestCorePermissions()) {
                        if (pendingSmsRoleAction != null) resumePendingSmsRoleAction()
                        else refreshMessagingPage()
                    }
                }
                else {
                    if (pendingSmsRoleAction != null) {
                        pendingSmsRoleAction = null
                        setComposeBusy(false)
                        composeStatus?.text = "Maclean Messaging is not the active default SMS app. The draft remains saved."
                        toast("Default SMS access was not granted. Nothing was sent.")
                    } else if (currentPage == PAGE_SETTINGS) showSettings()
                }
            }, 350)
            return
        }
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == REQUEST_BACKGROUND) {
            val uri = data.data ?: return
            runCatching {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            work({
                val name = displayName(uri)
                val file = importBackgroundPhoto(uri)
                UserSettings(this).setBackgroundPhoto(uri.toString(), file.absolutePath, name)
                removeUnusedBackgroundFiles(file)
                file
            }) { result ->
                result.fold(
                    onSuccess = {
                        cachedBackgroundKey = null
                        cachedBackgroundBitmap = null
                        toast("Background photo selected.")
                        showAppearanceSettings()
                    },
                    onFailure = { toast(it.message ?: "Unable to save the background photo.") }
                )
            }
            return
        }
        if (requestCode != REQUEST_ATTACHMENTS) return
        val selected = buildList {
            data.data?.let(::add)
            data.clipData?.let { clip -> for (index in 0 until clip.itemCount) add(clip.getItemAt(index).uri) }
        }
        selected.forEach { uri ->
            runCatching {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        val target = if (attachmentTarget == ATTACH_EMAIL) emailAttachmentUris else messageAttachmentUris
        target += selected.filterNot { it in target }
        refreshAttachmentSummary(target)
        queueDraftSave()
    }

    /** Returns true when a permission dialog was launched. */
    private fun requestCorePermissions(): Boolean {
        val permissions = mutableListOf(
            Manifest.permission.READ_SMS,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_MMS,
            Manifest.permission.RECEIVE_WAP_PUSH,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_PHONE_NUMBERS,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33 && UserSettings(this).notifications.enabled) {
            permissions += Manifest.permission.POST_NOTIFICATIONS
        }
        val missing = permissions.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), REQUEST_PERMISSIONS)
            return true
        }
        return false
    }

    private fun handleLaunchIntent(launch: Intent?) {
        val data = launch?.data
        val notificationAddress = launch?.getStringExtra(EXTRA_NOTIFICATION_ADDRESS).orEmpty()
        val notificationThreadId = launch?.takeIf { it.hasExtra(EXTRA_NOTIFICATION_THREAD_ID) }
            ?.getLongExtra(EXTRA_NOTIFICATION_THREAD_ID, -1L)
            ?.takeIf { it >= 0L }
            ?: notificationThreadId(launch?.getStringExtra(EXTRA_NOTIFICATION_MESSAGE_URI))
        if (notificationAddress.isNotBlank() && notificationThreadId != null) {
            showSmsThread(notificationThreadId, notificationAddress)
        } else if (launch?.action == Intent.ACTION_SEND || launch?.action == Intent.ACTION_SEND_MULTIPLE) {
            val shared = SharedLaunch(
                text = launch.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString().orEmpty(),
                subject = launch.getStringExtra(Intent.EXTRA_SUBJECT).orEmpty(),
                uris = sharedUris(launch)
            )
            // Consume the external intent immediately so rotation/resume cannot duplicate files.
            setIntent(Intent(this, MainActivity::class.java))
            showInbox()
            importAndComposeSharedContent(shared)
        } else if (data?.scheme in setOf("sms", "smsto", "mms", "mmsto")) {
            val address = data?.schemeSpecificPart?.substringBefore("?").orEmpty()
            val body = launch?.getStringExtra("sms_body").orEmpty()
            showMessageComposer(address, body)
        } else if (data?.scheme == "mailto") {
            val recipient = data.schemeSpecificPart.substringBefore("?")
            showEmailCompose(ComposeSeed(mode = ComposeMode.NEW, accountId = null, to = listOf(recipient).filter(String::isNotBlank)))
        } else {
            showInbox()
        }
    }

    private fun sharedUris(launch: Intent): List<Uri> = buildList {
        if (Build.VERSION.SDK_INT >= 33) {
            launch.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)?.let(::add)
            launch.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)?.let(::addAll)
        } else {
            @Suppress("DEPRECATION")
            (launch.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri)?.let(::add)
            @Suppress("DEPRECATION")
            (launch.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM))?.let(::addAll)
        }
        launch.clipData?.let { clip ->
            for (index in 0 until clip.itemCount) clip.getItemAt(index).uri?.let(::add)
        }
    }.distinct()

    private fun importAndComposeSharedContent(shared: SharedLaunch) {
        if (shared.text.isBlank() && shared.subject.isBlank() && shared.uris.isEmpty()) {
            toast("The sharing app did not provide text or an attachment.")
            return
        }
        work({
            SharedContent(
                text = shared.text,
                subject = shared.subject,
                attachments = shared.uris.map(::importSharedAttachment),
                emailAvailable = LocalDatabase.get(this).emailAccountDao().enabledCount() > 0
            )
        }) { result ->
            result.fold(
                onSuccess = ::chooseSharedDestination,
                onFailure = { toast(it.message ?: "Unable to import the shared attachment.") }
            )
        }
    }

    @Synchronized
    private fun importSharedAttachment(uri: Uri): Uri {
        val sourceName = runCatching { displayName(uri) }.getOrDefault("attachment")
        var safeName = sourceName
            .replace(Regex("[^\\p{L}\\p{N}._ -]"), "_")
            .takeLast(120)
            .ifBlank { "attachment" }
        if (!safeName.contains('.')) {
            val extension = contentResolver.getType(uri)?.substringBefore(';')?.let {
                android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(it)
            }
            if (!extension.isNullOrBlank()) safeName += ".$extension"
        }
        val directory = File(cacheDir, "shared-imports").apply { mkdirs() }
        val target = File(directory, "${UUID.randomUUID()}-$safeName")
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                target.outputStream().use { output ->
                    val buffer = ByteArray(32 * 1024)
                    var total = 0L
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        total += read
                        require(total <= MAX_SHARED_ATTACHMENT_BYTES) {
                            "Shared attachment exceeds the 50 MiB local limit."
                        }
                        output.write(buffer, 0, read)
                    }
                }
            } ?: error("Android could not open $sourceName.")
            return PduContentProvider.uriFor(this, target)
        } catch (error: Throwable) {
            target.delete()
            throw error
        }
    }

    private fun chooseSharedDestination(shared: SharedContent) {
        val openMessage = {
            showMessageComposer("", shared.text.ifBlank { shared.subject }, initialAttachments = shared.attachments)
        }
        val openEmail = {
            showEmailCompose(
                ComposeSeed(ComposeMode.NEW, null, subject = shared.subject, body = shared.text),
                initialAttachments = shared.attachments
            )
        }
        if (!shared.emailAvailable) {
            openMessage()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Share with Maclean Messaging")
            .setItems(arrayOf("SMS / MMS", "Email")) { _, which ->
                if (which == 0) openMessage() else openEmail()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun notificationThreadId(value: String?): Long? {
        val uri = value?.takeIf(String::isNotBlank)?.let(Uri::parse) ?: return null
        return runCatching {
            contentResolver.query(uri, arrayOf(Telephony.Sms.THREAD_ID), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getLong(0) else null
            }
        }.getOrNull()
    }

    private fun showInbox() {
        currentPage = PAGE_INBOX
        activeDeviceThreadId = null
        activeEmailThreadId = null
        attachmentTarget = ATTACH_NONE
        val screen = recycledInboxScreen(
            if (inboxArchived) "Archived conversations" else "Maclean Messaging",
            onMenu = ::showInboxMenu
        )
        val adapter = InboxConversationAdapter {
            activeInboxState?.let { renderInbox(screen, it) }
        }
        screen.list.adapter = adapter
        activeInboxAdapter = adapter
        val cachedState = activeInboxState
        val generation = ++inboxLoadGeneration
        if (cachedState == null) {
            screen.controls.removeAllViews()
            addStandaloneStatus(screen.controls)
            screen.controls.addView(text("Loading conversations in the background…"))
            work({ UnifiedInboxSnapshotStore.load(this) }) snapshot@ { result ->
                if (generation != inboxLoadGeneration || currentPage != PAGE_INBOX || activeInboxState != null) {
                    return@snapshot
                }
                result.getOrNull()?.let { snapshot ->
                    val state = InboxState(snapshot.emailEnabled, snapshot.emailCount, snapshot.conversations)
                    activeInboxState = state
                    renderInbox(screen, state)
                }
            }
        } else renderInbox(screen, cachedState)
        work({
            val repository = UnifiedInboxRepository(this)
            val emailCount = LocalDatabase.get(this).emailAccountDao().enabledCount()
            InboxState(
                emailEnabled = emailCount > 0,
                emailCount = emailCount,
                conversations = repository.conversations(includeArchived = true, emailEnabledOverride = emailCount > 0)
            )
        }) { result ->
            if (generation != inboxLoadGeneration || currentPage != PAGE_INBOX) return@work
            val state = result.getOrElse {
                if (activeInboxState == null) {
                    screen.controls.removeAllViews()
                    addStandaloneStatus(screen.controls)
                    screen.controls.addView(errorText(it.message ?: "Unable to load messages."))
                } else toast(it.message ?: "Unable to refresh messages.")
                return@work
            }
            activeInboxState = state
            renderInbox(screen, state)
            Async.launch {
                runCatching {
                    UnifiedInboxSnapshotStore.save(
                        applicationContext,
                        UnifiedInboxSnapshotStore.Snapshot(state.emailEnabled, state.emailCount, state.conversations)
                    )
                }
            }
        }
    }

    private fun addStandaloneStatus(content: LinearLayout) {
        val readiness = SmsRuntimeReadiness.inspect(this)
        when {
            !readiness.roleHeld -> content.addView(settingsCard(
                "SMS/MMS is not active",
                "Choose Maclean Messaging as Android's default SMS app. It then receives, stores, and sends carrier SMS/MMS directly; Google Messages is not required. Email remains independent.",
                "Set Maclean Messaging as default"
            ) {
                if (!DefaultSmsRole.request(this, REQUEST_DEFAULT_SMS_ROLE)) {
                    toast("Android did not make the default SMS role available on this device.")
                }
            })
            readiness.missingPermissions.isNotEmpty() -> content.addView(settingsCard(
                "SMS/MMS permissions incomplete",
                readiness.explanation,
                "Grant messaging permissions"
            ) { requestCorePermissions() })
            !readiness.operational -> content.addView(settingsCard(
                "Standalone SMS access needs repair",
                readiness.explanation + " Re-select Maclean Messaging in Android's Default apps screen.",
                "Open default app settings"
            ) { DefaultSmsRole.openDefaultAppSettings(this) })
        }
    }

    private fun renderInbox(screen: InboxListScreen, state: InboxState) {
        val content = screen.controls
        content.removeAllViews()
        addStandaloneStatus(content)
        inboxSelected.retainAll(state.conversations.mapTo(mutableSetOf(), UnifiedConversation::stableId))
        val quickActions = mutableListOf<View>(
            primaryButton("+ Message") { showMessageComposer("", "") },
            compactButton("Contacts") { showContacts() }
        )
        if (state.emailEnabled) quickActions.add(1, primaryButton("+ Email") {
            showEmailCompose(ComposeSeed(ComposeMode.NEW, null))
        })
        content.addView(horizontal(*quickActions.toTypedArray()))
        content.addView(compactBar(if (inboxArchived) "Archive • local to this app" else "Inbox",
            compactButton("Drafts & Outbox") { showWorkflows() },
            compactButton(if (inboxArchived) "Inbox" else "Archive") { inboxArchived = !inboxArchived; showInbox() }))

        val search = edit("Search messages, names, email, or phone", inboxQuery).apply {
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        }
        search.setOnEditorActionListener { _, actionId, _ ->
            if (actionId != android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH) return@setOnEditorActionListener false
            inboxQuery = search.text.toString().trim()
            renderInbox(screen, state)
            true
        }
        content.addView(compactInputRow(
            search,
            smallButton("⌕", "Search conversations") {
                inboxQuery = search.text.toString().trim()
                renderInbox(screen, state)
            },
            smallButton("×", "Clear search") {
                inboxQuery = ""
                renderInbox(screen, state)
            }
        ))
        val filters = if (state.emailEnabled) listOf(FILTER_ALL, FILTER_DEVICE, FILTER_EMAIL) else listOf(FILTER_ALL, FILTER_DEVICE)
        inboxFilter = inboxFilter.takeIf { it in filters } ?: FILTER_ALL
        inboxContactFilter = inboxContactFilter.takeIf { it in CONTACT_FILTER_OPTIONS } ?: CONTACT_ALL
        val visible = visibleConversations(state.conversations)
        content.addView(compactBar(
            "${visible.size}/${state.conversations.size} • ${inboxFilter.shortLabel()} • ${inboxContactFilter.shortLabel()} • ${inboxSort.shortLabel()}",
            compactButton("Filter ▾") { anchor -> showInboxFilterMenu(anchor, screen, state, filters) },
            compactButton("Sort ▾") { anchor -> showChoiceMenu(anchor, SORT_OPTIONS, inboxSort) {
                inboxSort = it
                renderInbox(screen, state)
            } }
        ))
        if (inboxSelected.isNotEmpty()) {
            content.addView(compactBar(
                "${inboxSelected.size} conversation${if (inboxSelected.size == 1) "" else "s"} selected",
                compactButton("Clear") {
                    inboxSelected.clear()
                    renderInbox(screen, state)
                },
                compactButton("Manage ▾") { anchor -> showInboxManagementMenu(anchor, screen, state, visible) }
            ))
        }
        if (visible.isEmpty()) {
            content.addView(text(if (state.conversations.isEmpty()) "No conversations." else "No conversations match this search or filter."))
        }
        activeInboxAdapter?.submit(visible)
    }

    private fun bindConversationCard(card: ShapeContourLayout, item: UnifiedConversation, selectionChanged: () -> Unit) {
        styleInboxCard(card)
        val selected = item.stableId in inboxSelected
        val transport = when (item.transport) {
            CommunicationTransport.EMAIL -> "EMAIL"
            CommunicationTransport.MMS -> "MMS"
            CommunicationTransport.SMS -> "SMS"
        }
        val open: () -> Unit = {
            when (item.transport) {
                CommunicationTransport.EMAIL -> showEmailThread(item.stableId.removePrefix("email:"))
                else -> item.stableId.removePrefix("sms:").toLongOrNull()?.let {
                    showSmsThread(it, item.participants.firstOrNull()?.address.orEmpty())
                }
            }
            Unit
        }
        val heading = text("${if (selected) "✓ Selected • " else ""}${if (item.pinned) "Pinned • " else ""}$transport • ${item.title}${if (item.unreadCount > 0) " • ${item.unreadCount} unread" else ""}", 15f, bold = true).apply {
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        val more = smallButton("⋮", "Conversation actions") { anchor ->
            showActions(anchor, listOfNotNull(
                MenuAction("Open", open),
                MenuAction("Mark as read") { markInboxConversationsRead(listOf(item)) },
                MenuAction("Mark as unread") { markInboxConversationsUnread(listOf(item)) },
                MenuAction(if (item.archived) "Unarchive" else "Archive (in this app)") {
                    changeConversationFlag(listOf(item.stableId), "archived", !item.archived)
                },
                MenuAction(if (item.pinned) "Unpin" else "Pin to top") {
                    changeConversationFlag(listOf(item.stableId), "pinned", !item.pinned)
                },
                MenuAction(if (selected) "Clear selection" else "Select", {
                    if (selected) inboxSelected -= item.stableId else inboxSelected += item.stableId
                    selectionChanged()
                }),
                MenuAction("Forward", { manageConversation(item, ManagementAction.FORWARD) }),
                MenuAction("Copy text", { manageConversation(item, ManagementAction.COPY) }),
                MenuAction("Download .txt", { manageConversation(item, ManagementAction.DOWNLOAD) }),
                MenuAction("Delete conversation", { manageConversation(item, ManagementAction.DELETE) })
            ))
        }
        card.addView(compactHeader(heading, more))
        val addresses = item.participants.map(UnifiedParticipant::address).distinct().joinToString(", ")
        if (addresses.isNotBlank()) card.addView(text(addresses, 11f).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        card.addView(text(item.preview, 14f).apply {
            maxLines = appearance.display.conversationPreviewLines
            ellipsize = TextUtils.TruncateAt.END
        })
        card.addView(text(formatShortDateTime(item.timestamp), 11f, bold = true))
        card.contentDescription = "Open $transport conversation with ${item.title}"
        card.isClickable = true
        card.isFocusable = true
        card.setOnClickListener { open() }
        card.setOnLongClickListener {
            if (item.stableId in inboxSelected) inboxSelected -= item.stableId else inboxSelected += item.stableId
            selectionChanged()
            true
        }
    }

    private fun showSmsThread(threadId: Long, fallbackAddress: String) {
        currentPage = PAGE_THREAD
        activeEmailThreadId = null
        if (fallbackAddress.isNotBlank()) MessageNotifier.cancel(this, fallbackAddress)
        val cachedMessages = activeDeviceMessages.takeIf {
            activeDeviceThreadId == threadId && it.isNotEmpty()
        } ?: DeviceMessageRepository.peekThread(threadId).orEmpty()
        if (activeDeviceThreadId != threadId) deviceMessageSelected.clear()
        activeDeviceThreadId = threadId
        activeDeviceMessages = cachedMessages
        activeDeviceAddress = fallbackAddress
        activeDeviceLoading = true
        val conversationKey = "sms:$threadId"
        activeDeviceSort = UserSettings(this).conversationSort(conversationKey)
            .takeIf { it in THREAD_SORT_OPTIONS } ?: THREAD_OLDEST
        val threadScreen = recycledListScreen(
            fallbackAddress.ifBlank { "Conversation" },
            onBack = ::leaveSmsThread,
            onMenu = { anchor ->
                showDeviceThreadManagementMenu(anchor, threadId, activeDeviceAddress, activeDeviceMessages)
            }
        )
        val generation = threadScreenGeneration
        val status = text(
            if (cachedMessages.isEmpty()) "Loading complete conversation…"
            else "${cachedMessages.size} messages • Refreshing complete conversation…",
            11f,
            bold = true
        )
        val sort = compactButton("Sort ▾") { anchor ->
            showThreadSortMenu(anchor, conversationKey, activeDeviceSort) {
                activeDeviceSort = UserSettings(this).conversationSort(conversationKey)
                    .takeIf { it in THREAD_SORT_OPTIONS } ?: THREAD_OLDEST
                activeDeviceAdapter?.submit(activeDeviceMessages, activeDeviceSort)
                updateDeviceThreadControls()
                scrollListForSort(threadScreen.list, activeDeviceSort)
            }
        }
        threadScreen.controls.addView(threadControlBar(status, sort))
        val replyHost = if (appearance.display.replyLocation == REPLY_LOCATION_TOP) {
            threadScreen.topReply
        } else {
            threadScreen.footer
        }
        installInlineReplyComposer(replyHost, threadId, fallbackAddress)
        val adapter = DeviceMessageAdapter(threadId) {
            activeDeviceAdapter?.notifyDataSetChanged()
            updateDeviceThreadControls()
        }
        threadScreen.list.adapter = adapter
        activeDeviceAdapter = adapter
        activeDeviceList = threadScreen.list
        activeDeviceStatus = status
        if (cachedMessages.isNotEmpty()) {
            adapter.submit(cachedMessages, activeDeviceSort)
            scrollListForSort(threadScreen.list, activeDeviceSort)
        }
        // Opening a conversation changes provider read flags. Ignore that one observer echo so it
        // cannot tear down and rebuild the visible reply, attachment, or voice controls.
        messageProviderIgnoreUntil = SystemClock.elapsedRealtime() + SELF_PROVIDER_CHANGE_QUIET_MS
        val repository = DeviceMessageRepository(this)
        work({
            SystemMessageRepository(this).markThreadRead(threadId)
            repository.threadHeaders(threadId)
        }) headersLoaded@ { result ->
            if (!isCurrentDeviceThread(threadId, generation)) return@headersLoaded
            val headers = result.getOrElse {
                activeDeviceLoading = false
                status.text = it.message ?: "Unable to load conversation."
                status.setTextColor(Color.rgb(190, 25, 25))
                return@headersLoaded
            }
            if (headers.isEmpty()) return@headersLoaded showInbox()
            activeDeviceMessages = headers.distinctBy(DeviceMessage::stableId)
            activeDeviceLoading = headers.any { !it.contentReady }
            activeDeviceAddress = headers.firstOrNull { it.address.isNotBlank() }?.address ?: fallbackAddress
            inlineReplyAddress = activeDeviceAddress
            if (activeDeviceAddress.isNotBlank()) MessageNotifier.cancel(this, activeDeviceAddress)
            deviceMessageSelected.retainAll(activeDeviceMessages.mapTo(mutableSetOf(), DeviceMessage::stableId))
            adapter.submit(activeDeviceMessages, activeDeviceSort)
            updateDeviceThreadControls()
            scrollListForSort(threadScreen.list, activeDeviceSort)

            if (!activeDeviceLoading) return@headersLoaded
            work({ repository.hydrateThread(threadId, headers) }) hydrated@ { hydratedResult ->
                if (!isCurrentDeviceThread(threadId, generation)) return@hydrated
                val messages = hydratedResult.getOrElse {
                    activeDeviceLoading = false
                    status.text = "${activeDeviceMessages.size} messages • Some MMS details could not load: ${it.message.orEmpty()}"
                    return@hydrated
                }
                activeDeviceMessages = messages.distinctBy(DeviceMessage::stableId)
                activeDeviceLoading = false
                activeDeviceAddress = messages.firstOrNull { it.address.isNotBlank() }?.address ?: fallbackAddress
                inlineReplyAddress = activeDeviceAddress
                adapter.submit(activeDeviceMessages, activeDeviceSort)
                updateDeviceThreadControls()
            }
        }
    }

    private fun isCurrentDeviceThread(threadId: Long, generation: Int): Boolean =
        currentPage == PAGE_THREAD && activeDeviceThreadId == threadId && threadScreenGeneration == generation

    private fun updateDeviceThreadControls() {
        val loaded = activeDeviceMessages.size
        val sending = activeDeviceMessages.count { it.id < 0L }
        activeDeviceStatus?.text = when {
            activeDeviceLoading && loaded > 0 ->
                "$loaded message${if (loaded == 1) "" else "s"} • Refreshing complete conversation…"
            activeDeviceLoading -> "Loading complete conversation…"
            sending > 0 ->
                "$loaded message${if (loaded == 1) "" else "s"} • $sending sending… • ${activeDeviceSort.shortLabel()}"
            deviceMessageSelected.isNotEmpty() ->
                "$loaded message${if (loaded == 1) "" else "s"} • Complete • ${deviceMessageSelected.size} selected • ${activeDeviceSort.shortLabel()}"
            else -> "$loaded message${if (loaded == 1) "" else "s"} • Complete • ${activeDeviceSort.shortLabel()}"
        }
    }

    private fun scrollListForSort(list: ListView, sort: String) {
        list.post {
            if ((list.adapter?.count ?: 0) == 0) return@post
            list.setSelection(if (sort == THREAD_OLDEST) list.adapter.count - 1 else 0)
        }
    }

    private fun installInlineReplyComposer(host: LinearLayout, threadId: Long, address: String) {
        messageAttachmentUris.clear()
        attachmentTarget = ATTACH_MESSAGE
        inlineReplyThreadId = threadId
        inlineReplyAddress = address

        val id = UUID.randomUUID().toString()
        val body = edit("Message", "", multiline = true).apply {
            minLines = 1
            maxLines = 5
            gravity = Gravity.CENTER_VERTICAL
        }
        inlineReplyBody = body
        val sims = SimRepository.active(this)
        val sim = Spinner(this).apply {
            adapter = stringAdapter(
                if (sims.isEmpty()) listOf("No active SIM")
                else sims.map { "SIM ${it.slotIndex + 1}: ${it.carrierName.ifBlank { it.displayName }}" }
            )
        }
        val panel = panel()
        if (sims.size > 1) panel.addView(compactBar("Send using", sim))
        else if (sims.isEmpty()) panel.addView(errorText("No active SIM is available for replies."))

        attachmentSummary = text("", 11f).apply { visibility = View.GONE }
        panel.addView(requireNotNull(attachmentSummary))

        val voicePanel = voiceRecorderPanel(
            recipients = { listOf(activeDeviceAddress.ifBlank { inlineReplyAddress }).filter(String::isNotBlank) },
            subscriptionId = { sims.getOrNull(sim.selectedItemPosition)?.subscriptionId }
        ).apply { visibility = View.GONE }
        inlineVoicePanel = voicePanel

        val options = smallButton("＋", "Attachments and reply options") { anchor ->
            showInlineReplyMenu(anchor)
        }
        val microphone = smallButton("🎙", "Record a voice reply") {
            voicePanel.visibility = if (voicePanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            if (voicePanel.visibility == View.VISIBLE) voicePanel.requestFocus()
        }
        val send = primaryButton("Send") { submitComposer(null) }
        panel.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(options, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = dp(controlGap())
            })
            addView(body, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(microphone, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginStart = dp(controlGap())
            })
            addView(send, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginStart = dp(controlGap())
            })
        })
        panel.addView(voicePanel)
        host.addView(panel)

        installComposer(
            panel,
            id,
            body,
            listOf(body),
            saveInitially = false,
            statusMessage = "Reply here • drafts auto-save on this device."
        ) {
            ComposePayload(
                to = listOf(activeDeviceAddress.ifBlank { inlineReplyAddress }).filter(String::isNotBlank),
                body = body.text.toString(),
                subscriptionId = sims.getOrNull(sim.selectedItemPosition)?.subscriptionId ?: -1,
                attachments = messageAttachmentUris.map(Uri::toString)
            )
        }
        sim.onSelectionChanged { queueDraftSave() }
    }

    private fun showInlineReplyMenu(anchor: View) {
        val hasAttachments = messageAttachmentUris.isNotEmpty()
        val actions = buildList {
            add(MenuAction("Attach file") { chooseAttachments(ATTACH_MESSAGE, "*/*") })
            add(MenuAction("Attach audio") { chooseAttachments(ATTACH_MESSAGE, "audio/*") })
            add(MenuAction("Schedule reply…") { scheduleComposer() })
            add(MenuAction("Save reply as draft") {
                val payload = composeSnapshot?.invoke()
                if (payload == null || payload.body.isBlank() && payload.attachments.isEmpty()) {
                    toast("Write a reply or attach a file first.")
                } else saveComposerAndClose()
            })
            if (hasAttachments) add(MenuAction("Manage attachments") { manageComposeAttachments() })
            add(MenuAction("Voice recorder") {
                inlineVoicePanel?.visibility = View.VISIBLE
                inlineVoicePanel?.requestFocus()
            })
        }
        showActions(anchor, actions)
    }

    private fun focusInlineReply(prefill: String = "", voice: Boolean = false) {
        val body = inlineReplyBody
        if (body == null) {
            showMessageComposer(activeDeviceAddress.ifBlank { inlineReplyAddress }, prefill, focusVoice = voice)
            return
        }
        if (prefill.isNotBlank()) {
            val existing = body.text.toString()
            body.setText(if (existing.isBlank()) prefill else "$existing\n$prefill")
            body.setSelection(body.text.length)
        }
        if (voice) {
            inlineVoicePanel?.visibility = View.VISIBLE
            inlineVoicePanel?.requestFocus()
        } else {
            body.requestFocus()
            body.post {
                getSystemService(android.view.inputmethod.InputMethodManager::class.java)
                    ?.showSoftInput(body, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            }
        }
    }

    private fun leaveSmsThread() {
        if (inlineReplyThreadId != null) saveDraftQuietly()
        showInbox()
    }

    private fun showMessageComposer(
        prefillAddress: String,
        prefillBody: String,
        focusVoice: Boolean = false,
        initialAttachments: List<Uri> = emptyList(),
        restored: ComposeRecord? = null
    ) {
        currentPage = PAGE_COMPOSE
        messageAttachmentUris.clear()
        messageAttachmentUris += restored?.payload?.attachments?.map(Uri::parse) ?: initialAttachments
        attachmentTarget = ATTACH_MESSAGE
        val content = screen(if (focusVoice) "Voice message" else "Write SMS / MMS",
            onBack = ::leaveComposer, onMenu = ::showComposeMenu)
        val id = restored?.id ?: UUID.randomUUID().toString()
        val address = recipientEdit("Recipient — contact or phone", restored?.payload?.to?.joinToString(", ") ?: prefillAddress)
        val body = edit("Message", restored?.payload?.body ?: prefillBody, multiline = true)
        val sims = SimRepository.active(this)
        val simOffset = if (restored != null && sims.none { it.subscriptionId == restored.payload.subscriptionId }) 1 else 0
        val sim = Spinner(this).apply {
            adapter = stringAdapter(
                (if (simOffset == 1) listOf("Original SIM unavailable — choose a SIM") else emptyList()) +
                    if (sims.isEmpty()) listOf("No active SIM") else sims.map { "SIM ${it.slotIndex + 1}: ${it.carrierName.ifBlank { it.displayName }}" })
            restored?.payload?.subscriptionId?.let { saved ->
                val position = sims.indexOfFirst { it.subscriptionId == saved }
                if (position >= 0) setSelection(position)
            }
        }
        content.addView(address)
        content.addView(horizontal(
            compactButton("Choose contacts") { chooseRecipients(RecipientKind.PHONE, address) },
            compactButton("Paste recipient") { pasteInto(address) }
        ))
        content.addView(text("Send using", 12f, bold = true))
        content.addView(sim)
        content.addView(body)
        content.addView(horizontal(
            primaryButton("Send now") { submitComposer(null) },
            compactButton("Schedule send ▾") { scheduleComposer() },
            smallButton("⋮", "Message draft options") { showComposeMenu(it) }
        ))
        attachmentSummary = text(attachmentText(messageAttachmentUris), 12f)
        content.addView(requireNotNull(attachmentSummary))
        refreshAttachmentSummary(messageAttachmentUris)
        content.addView(horizontal(
            compactButton("Attach file") { chooseAttachments(ATTACH_MESSAGE, "*/*") },
            compactButton("Attach audio") { chooseAttachments(ATTACH_MESSAGE, "audio/*") },
            compactButton("Save draft") { saveComposerAndClose() }
        ))
        content.addView(voiceRecorderPanel(
            recipients = { splitAddresses(address.text.toString()) },
            subscriptionId = { sims.getOrNull(sim.selectedItemPosition - simOffset)?.subscriptionId }
        ))
        content.addView(text("Audio attachments keep their original format. Schedule send supports SMS, group MMS, and attachments.", 11f))
        installComposer(content, id, body, listOf(address, body)) {
            ComposePayload(to = splitAddresses(address.text.toString()), body = body.text.toString(),
                subscriptionId = sims.getOrNull(sim.selectedItemPosition - simOffset)?.subscriptionId ?: -1,
                attachments = messageAttachmentUris.map(Uri::toString))
        }
        sim.onSelectionChanged { queueDraftSave() }
        configureRecipientSuggestions(listOf(address), RecipientKind.PHONE)
    }

    private fun showContacts() {
        currentPage = PAGE_CONTACTS
        attachmentTarget = ATTACH_NONE
        val content = screen("Contacts and recipients") { showInbox() }
        content.addView(text("Contacts are read live from Android's synchronized Contacts provider.", 14f))
        content.addView(horizontal(
            button("Add contact") {
                runCatching {
                    startActivity(Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI))
                }.onFailure { toast("No contacts app is available.") }
            },
            button("Account sync") {
                runCatching { startActivity(Intent(Settings.ACTION_SYNC_SETTINGS)) }
                    .onFailure { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            }
        ))

        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            content.addView(errorText("Contacts permission is off. Allow it to browse names, phone numbers, and email addresses."))
            content.addView(button("Allow contacts access", match = true) {
                requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), REQUEST_PERMISSIONS)
            })
            return
        }

        val search = edit("Search contact, phone number, or email", contactQuery)
        content.addView(search)
        content.addView(horizontal(
            button("Search") {
                contactQuery = search.text.toString().trim()
                showContacts()
            },
            button("Refresh") { showContacts() }
        ))
        content.addView(button("Clear search", match = true) {
            contactQuery = ""
            showContacts()
        })
        val loading = text("Reading Android contacts…")
        content.addView(loading)
        work({ ContactDirectory(this).all() }) { result ->
            if (currentPage != PAGE_CONTACTS) return@work
            content.removeView(loading)
            val contacts = result.getOrElse {
                content.addView(errorText(it.message ?: "Unable to read Android contacts."))
                return@work
            }
            val query = contactQuery.lowercase(Locale.getDefault())
            val visible = contacts.filter { contact ->
                query.isBlank() || sequenceOf(
                    contact.displayName,
                    contact.phoneNumbers.joinToString(" "),
                    contact.emailAddresses.joinToString(" ")
                ).any { it.lowercase(Locale.getDefault()).contains(query) }
            }
            content.addView(text(
                "${visible.size} of ${contacts.size} messageable contact${if (contacts.size == 1) "" else "s"}",
                15f,
                bold = true
            ))
            if (visible.isEmpty()) {
                content.addView(text(if (contacts.isEmpty()) {
                    "No phone numbers or email addresses are available. Check Android account synchronization, then tap Refresh."
                } else "No contacts match this search."))
            }
            visible.forEach { contact -> content.addView(contactCard(contact)) }
        }
    }

    private fun contactCard(contact: ContactEntry): View {
        val card = panel()
        contact.photoUri?.let { photoUri ->
            card.addView(ImageView(this).apply {
                contentDescription = "Photo for ${contact.displayName}"
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.CENTER_CROP
                maxHeight = dp(96)
                runCatching { setImageURI(photoUri) }
                layoutParams = LinearLayout.LayoutParams(dp(72), dp(72))
            })
        }
        card.addView(text(contact.displayName, 18f, bold = true))
        contact.phoneNumbers.forEach { card.addView(text("Phone: $it", 14f)) }
        contact.emailAddresses.forEach { card.addView(text("Email: $it", 14f)) }
        val message = button("Message") {
            selectContactValue("Choose a phone number", contact.phoneNumbers) {
                showMessageComposer(it, "")
            }
        }.apply { isEnabled = contact.phoneNumbers.isNotEmpty() }
        val email = button("Email") {
            selectContactValue("Choose an email address", contact.emailAddresses) {
                showEmailCompose(ComposeSeed(ComposeMode.NEW, null, to = listOf(it)))
            }
        }.apply { isEnabled = contact.emailAddresses.isNotEmpty() }
        card.addView(horizontal(message, email))
        return card
    }

    private fun selectContactValue(title: String, values: List<String>, selected: (String) -> Unit) {
        when (values.size) {
            0 -> toast("This contact has no matching address.")
            1 -> selected(values.single())
            else -> AlertDialog.Builder(this)
                .setTitle(title)
                .setItems(values.toTypedArray()) { _, which -> selected(values[which]) }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun openSystemContacts() {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI)) }
            .onFailure { toast("No contacts app is available.") }
    }

    private fun chooseRecipients(kind: RecipientKind, target: MultiAutoCompleteTextView) {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), REQUEST_PERMISSIONS)
            return toast("Allow contacts access, then choose contacts again.")
        }
        work({ recipientOptions(ContactDirectory(this).all(), kind) }) { result ->
            val options = result.getOrElse {
                toast(it.message ?: "Unable to read contacts.")
                return@work
            }
            if (options.isEmpty()) return@work toast("No matching contact addresses are available.")
            val checked = BooleanArray(options.size)
            AlertDialog.Builder(this)
                .setTitle(if (kind == RecipientKind.PHONE) "Choose phone recipients" else "Choose email recipients")
                .setMultiChoiceItems(options.map(RecipientOption::label).toTypedArray(), checked) { _, which, value ->
                    checked[which] = value
                }
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Add") { _, _ ->
                    val chosen = options.indices.filter { checked[it] }.map { options[it].address }
                    if (chosen.isEmpty()) return@setPositiveButton
                    val existing = splitAddresses(target.text.toString()).filter { value ->
                        if (kind == RecipientKind.EMAIL) value.contains('@') else value.any(Char::isDigit)
                    }
                    val combined = (existing + chosen).distinctBy(String::lowercase).joinToString(", ")
                    target.setText(combined)
                    target.setSelection(combined.length)
                }
                .show()
        }
    }

    private fun configureRecipientSuggestions(
        fields: List<MultiAutoCompleteTextView>,
        kind: RecipientKind
    ) {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return
        work({ recipientOptions(ContactDirectory(this).all(), kind) }) { result ->
            result.onSuccess { options ->
                fields.forEach { it.setAdapter(RecipientAdapter(this, options, appTypeface())) }
            }
        }
    }

    private fun recipientOptions(contacts: List<ContactEntry>, kind: RecipientKind): List<RecipientOption> =
        contacts.flatMap { contact ->
            val values = if (kind == RecipientKind.PHONE) contact.phoneNumbers else contact.emailAddresses
            values.map { RecipientOption(contact.displayName, it) }
        }.distinctBy { it.address.lowercase(Locale.getDefault()) }
            .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER, RecipientOption::name).thenBy(RecipientOption::address))

    private fun showSettings() {
        currentPage = PAGE_SETTINGS
        appearance = UserSettings(this).appearance
        val content = screen("Settings") { showInbox() }
        content.addView(settingsCard(
            "Drafts & scheduled sends",
            "Open saved drafts, edit or cancel pending schedules, and review send results.",
            "Open Drafts & Outbox"
        ) { showWorkflows() })
        content.addView(settingsCard(
            "Messaging",
            "SMS and MMS use the device SIM and Android's default messaging role.",
            "Default sort and filters"
        ) { showSortSettings() })
        val readiness = SmsRuntimeReadiness.inspect(this)
        val defaultStatus = readiness.explanation
        content.addView(settingsCard(
            "Standalone SMS/MMS",
            defaultStatus,
            when {
                !readiness.roleHeld -> "Set as default SMS app"
                readiness.missingPermissions.isNotEmpty() -> "Grant messaging permissions"
                !readiness.operational -> "Open default app settings"
                else -> "Refresh standalone status"
            }
        ) {
            when {
                !readiness.roleHeld -> if (!DefaultSmsRole.request(this, REQUEST_DEFAULT_SMS_ROLE)) {
                    toast("Android did not make the default SMS role available on this device.")
                }
                readiness.missingPermissions.isNotEmpty() -> requestCorePermissions()
                !readiness.operational -> DefaultSmsRole.openDefaultAppSettings(this)
                else -> showSettings()
            }
        })
        content.addView(settingsCard(
            "Notifications",
            "Control persistent alerts, SMS/MMS and email notices, previews, and quick reply.",
            "Notification settings"
        ) { showNotificationSettings() })
        content.addView(settingsCard(
            "Contacts",
            "Names, phone numbers, and email addresses are read live from Android Contacts.",
            "Browse contacts"
        ) { showContacts() })

        val emailStatus = text("Checking accounts…")
        val emailCard = panel().apply {
            addView(text("Email integration", 16f, bold = true))
            addView(emailStatus)
            addView(compactButton("Manage accounts") { showAccounts() })
        }
        content.addView(emailCard)
        work({ LocalDatabase.get(this).emailAccountDao().enabledCount() }) { result ->
            emailStatus.text = result.fold(
                onSuccess = { if (it == 0) "Off. Email remains hidden until an account is configured." else "Enabled with $it account${if (it == 1) "" else "s"}." },
                onFailure = { "Unable to read email accounts." }
            )
        }

        content.addView(settingsCard(
            "Display style and appearance",
            "Current style: ${appearance.display.style} • ${appearance.display.textFont} • ${appearance.display.textFormat}. Manage separate layouts, fonts, shapes, spacing, colors, and backgrounds.",
            "Manage display"
        ) { showAppearanceSettings() })
        content.addView(settingsCard(
            "Application",
            "Maclean Messaging 1.4.2\ncom.macleanofduartenterprises.macleanmessaging\nMaclean Of Duart Enterprises",
            "GNU AGPLv3 License"
        ) { showLicense() })
    }

    private fun showAppearanceSettings() {
        currentPage = PAGE_APPEARANCE
        appearance = UserSettings(this).appearance
        val settings = UserSettings(this)
        val content = screen("Display & appearance") { showSettings() }
        val selectedStyle = spinner(DISPLAY_STYLE_OPTIONS, appearance.display.style)
        val bubbleShape = spinner(DISPLAY_SHAPE_OPTIONS, appearance.display.bubbleShape)
        val cardShape = spinner(DISPLAY_SHAPE_OPTIONS, appearance.display.cardShape)
        val buttonShape = spinner(DISPLAY_SHAPE_OPTIONS, appearance.display.buttonShape)
        val spacing = spinner(DISPLAY_SPACING_OPTIONS, appearance.display.spacing)
        val textFont = spinner(DISPLAY_FONT_OPTIONS, appearance.display.textFont)
        val textFormat = spinner(TEXT_FORMAT_OPTIONS, appearance.display.textFormat)
        val replyLocation = spinner(REPLY_LOCATION_OPTIONS, appearance.display.replyLocation)
        val outlines = settingsCheckBox("Show outlines around cards and message bubbles", appearance.display.showOutlines)
        val elevation = settingsCheckBox("Use soft elevation and shadows", appearance.display.showElevation)
        val widthLabel = text("Message width: ${appearance.display.messageWidthPercent}%", 12f, bold = true)
        val messageWidth = SeekBar(this).apply {
            max = 30
            progress = appearance.display.messageWidthPercent - 70
        }
        val previewLinesLabel = text("Inbox preview lines: ${appearance.display.conversationPreviewLines}", 12f, bold = true)
        val previewLines = SeekBar(this).apply {
            max = 3
            progress = appearance.display.conversationPreviewLines - 1
        }
        val tintLabel = text("Sent-message accent tint: ${appearance.display.sentTintPercent}%", 12f, bold = true)
        val sentTint = SeekBar(this).apply {
            max = 35
            progress = appearance.display.sentTintPercent
        }
        val styleDescription = text(displayStyleDescription(appearance.display.style), 13f)
        val profileSummary = text("", 12f, bold = true)
        val fontPreview = text("Preview: The quick brown fox — Aa 123", 16f)

        fun refreshProfileSummary() {
            widthLabel.text = "Message width: ${messageWidth.progress + 70}%"
            previewLinesLabel.text = "Inbox preview lines: ${previewLines.progress + 1}"
            tintLabel.text = "Sent-message accent tint: ${sentTint.progress}%"
            profileSummary.text = "${selectedStyle.selectedItem} • ${bubbleShape.selectedItem} bubbles • " +
                "${cardShape.selectedItem} cards • ${textFont.selectedItem} • ${textFormat.selectedItem} • " +
                "${spacing.selectedItem} spacing"
            fontPreview.typeface = typefaceFor(
                textFont.selectedItem.toString(),
                textFormat.selectedItem.toString()
            )
        }

        fun loadProfile(style: String) {
            val profile = settings.displaySettings(style)
            bubbleShape.setSelection(DISPLAY_SHAPE_OPTIONS.indexOf(profile.bubbleShape).coerceAtLeast(0))
            cardShape.setSelection(DISPLAY_SHAPE_OPTIONS.indexOf(profile.cardShape).coerceAtLeast(0))
            buttonShape.setSelection(DISPLAY_SHAPE_OPTIONS.indexOf(profile.buttonShape).coerceAtLeast(0))
            spacing.setSelection(DISPLAY_SPACING_OPTIONS.indexOf(profile.spacing).coerceAtLeast(0))
            textFont.setSelection(DISPLAY_FONT_OPTIONS.indexOf(profile.textFont).coerceAtLeast(0))
            textFormat.setSelection(TEXT_FORMAT_OPTIONS.indexOf(profile.textFormat).coerceAtLeast(0))
            replyLocation.setSelection(REPLY_LOCATION_OPTIONS.indexOf(profile.replyLocation).coerceAtLeast(0))
            messageWidth.progress = profile.messageWidthPercent - 70
            previewLines.progress = profile.conversationPreviewLines - 1
            sentTint.progress = profile.sentTintPercent
            outlines.isChecked = profile.showOutlines
            elevation.isChecked = profile.showElevation
            styleDescription.text = displayStyleDescription(profile.style)
            refreshProfileSummary()
        }

        selectedStyle.onSelectionChanged { position -> loadProfile(DISPLAY_STYLE_OPTIONS[position]) }
        listOf(bubbleShape, cardShape, buttonShape, spacing, textFont, textFormat, replyLocation).forEach { spinner ->
            spinner.onSelectionChanged { refreshProfileSummary() }
        }
        messageWidth.onProgressChanged { refreshProfileSummary() }
        previewLines.onProgressChanged { refreshProfileSummary() }
        sentTint.onProgressChanged { refreshProfileSummary() }
        refreshProfileSummary()

        content.addView(panel().apply {
            addView(text("Display style", 17f, bold = true))
            addView(text("Sleek and Utility keep separate saved layout profiles. Switching styles does not erase the other profile.", 12f))
            addView(selectedStyle)
            addView(styleDescription)
            addView(profileSummary)
            addView(text("Message-bubble shape", 12f, bold = true)); addView(bubbleShape)
            addView(widthLabel); addView(messageWidth)
            addView(tintLabel); addView(sentTint)
            addView(text("Card and panel shape", 12f, bold = true)); addView(cardShape)
            addView(text("Button and control shape", 12f, bold = true)); addView(buttonShape)
            addView(text("Screen spacing", 12f, bold = true)); addView(spacing)
            addView(text("System text style", 12f, bold = true)); addView(textFont)
            addView(text("Includes multiple cursive, calligraphy, and special display choices in addition to the standard system families.", 11f))
            addView(text("Text format", 12f, bold = true)); addView(textFormat)
            addView(text("Choose Regular, Bold, Italic, or Bold italic. Headings retain their semantic emphasis.", 11f))
            addView(fontPreview)
            addView(text("The selected family and format apply to messages, email, editors, controls, recipient suggestions, and screen headings.", 11f))
            addView(text("Message reply location", 12f, bold = true)); addView(replyLocation)
            addView(text("Places the full reply controls above or below the messages in each SMS/MMS conversation.", 11f))
            addView(previewLinesLabel); addView(previewLines)
            addView(outlines)
            addView(elevation)
            addView(compactButton("Reset selected style to its defaults") {
                val style = selectedStyle.selectedItem.toString()
                settings.resetDisplaySettings(style)
                toast("$style display defaults restored.")
                showAppearanceSettings()
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })

        val paletteChoices = UI_PALETTES + UiPalette(
            "Custom",
            appearance.backgroundColor,
            appearance.surfaceColor,
            appearance.accentColor,
            appearance.textColor
        )
        val palette = spinner(paletteChoices.map(UiPalette::name), appearance.paletteName)
        val customBackground = edit("Background color, for example #F4F0E8", colorHex(appearance.backgroundColor))
        val customSurface = edit("Card and message color", colorHex(appearance.surfaceColor))
        val customAccent = edit("Accent and toolbar color", colorHex(appearance.accentColor))
        val customText = edit("Text color", colorHex(appearance.textColor))
        val hasBackgroundPhoto = backgroundPhotoAvailable(appearance)
        val highContrast = CheckBox(this).apply {
            text = "High contrast"
            typeface = appTypeface()
            isChecked = appearance.highContrast
            setTextColor(readableTextColor())
            buttonTintList = ColorStateList.valueOf(if (appearance.highContrast) Color.WHITE else appearance.accentColor)
        }
        val usePhoto = CheckBox(this).apply {
            text = "Use selected photo as background"
            typeface = appTypeface()
            isChecked = appearance.useBackgroundPhoto && hasBackgroundPhoto
            isEnabled = hasBackgroundPhoto
            setTextColor(readableTextColor())
            buttonTintList = ColorStateList.valueOf(if (appearance.highContrast) Color.WHITE else appearance.accentColor)
        }
        val preview = panel().apply {
            addView(text("Palette", 16f, bold = true))
            addView(text("Coordinated background, card, accent, and text colors."))
            addView(palette)
            addView(text("All four fields below are used when Custom is selected.", 11f))
            addView(customBackground)
            addView(customSurface)
            addView(customAccent)
            addView(customText)
        }
        content.addView(preview)

        val photoPanel = panel().apply {
            addView(text("Background photo", 16f, bold = true))
            addView(text(if (hasBackgroundPhoto) "Selected: ${backgroundPhotoName(appearance)}"
                else "No photo selected. Photos remain local to this device."))
            if (hasBackgroundPhoto) {
                val image = ImageView(this@MainActivity).apply {
                    contentDescription = "Selected background photo preview"
                    adjustViewBounds = true
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    maxHeight = dp(220)
                    minimumHeight = dp(120)
                }
                addView(image, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(160)))
                work({ loadBackgroundBitmap(appearance, 1200) }) { result -> result.onSuccess(image::setImageBitmap) }
            }
            addView(usePhoto)
            addView(compactBar(
                "Photo controls",
                compactButton(if (!hasBackgroundPhoto) "Choose" else "Replace") { chooseBackgroundPhoto() },
                compactButton("Remove") { removeBackgroundPhoto() }.apply { isEnabled = hasBackgroundPhoto }
            ))
        }
        content.addView(photoPanel)

        content.addView(panel().apply {
            addView(text("Accessibility & transparency", 16f, bold = true))
            addView(highContrast)
            addView(text("Text size", 12f, bold = true))
            val textScale = SeekBar(this@MainActivity).apply {
                max = 120
                progress = ((appearance.textScale - 0.8f) * 100).toInt().coerceIn(0, 120)
            }
            addView(textScale)
            addView(text("Background/photo strength", 12f, bold = true))
            val backgroundOpacity = SeekBar(this@MainActivity).apply {
                max = 99
                progress = appearance.backgroundOpacity - 1
            }
            addView(backgroundOpacity)
            addView(text("Message-panel opacity", 12f, bold = true))
            val windowOpacity = SeekBar(this@MainActivity).apply {
                max = 99
                progress = appearance.textWindowOpacity - 1
            }
            addView(windowOpacity)
            addView(primaryButton("Save appearance") {
                val selectedPalette = paletteChoices[palette.selectedItemPosition.coerceIn(paletteChoices.indices)]
                val colors = if (selectedPalette.name == "Custom") {
                    listOf(customBackground, customSurface, customAccent, customText).map { field ->
                        parseColor(field.text.toString())
                            ?: return@primaryButton toast("Enter each custom color as #RRGGBB.")
                    }
                } else listOf(selectedPalette.background, selectedPalette.surface, selectedPalette.accent, selectedPalette.text)
                UserSettings(this@MainActivity).apply {
                    setDisplaySettings(DisplaySettings(
                        style = selectedStyle.selectedItem.toString(),
                        bubbleShape = bubbleShape.selectedItem.toString(),
                        cardShape = cardShape.selectedItem.toString(),
                        buttonShape = buttonShape.selectedItem.toString(),
                        spacing = spacing.selectedItem.toString(),
                        textFont = textFont.selectedItem.toString(),
                        textFormat = textFormat.selectedItem.toString(),
                        replyLocation = replyLocation.selectedItem.toString(),
                        messageWidthPercent = messageWidth.progress + 70,
                        conversationPreviewLines = previewLines.progress + 1,
                        showOutlines = outlines.isChecked,
                        showElevation = elevation.isChecked,
                        sentTintPercent = sentTint.progress
                    ))
                    setPalette(selectedPalette.name, colors[0], colors[1], colors[2], colors[3])
                    setHighContrast(highContrast.isChecked)
                    setTextScale(0.8f + textScale.progress / 100f)
                    setBackgroundOpacity(backgroundOpacity.progress + 1)
                    setTextWindowOpacity(windowOpacity.progress + 1)
                    setUseBackgroundPhoto(usePhoto.isChecked)
                }
                toast("${selectedStyle.selectedItem} display and appearance saved.")
                showAppearanceSettings()
            })
        })
    }

    private fun showSortSettings() {
        currentPage = PAGE_SORT_SETTINGS
        val current = UserSettings(this).sorting
        val content = screen("Default sort & filters") { showSettings() }
        val transport = spinner(INBOX_FILTER_OPTIONS, current.inboxTransportFilter)
        val contacts = spinner(CONTACT_FILTER_OPTIONS, current.inboxContactFilter)
        val inbox = spinner(SORT_OPTIONS, current.inboxSort)
        val thread = spinner(THREAD_SORT_OPTIONS, current.threadSort)
        content.addView(panel().apply {
            addView(text("Main page defaults", 16f, bold = true))
            addView(text("Message type", 12f, bold = true)); addView(transport)
            addView(text("Saved-contact status", 12f, bold = true)); addView(contacts)
            addView(text("Conversation order", 12f, bold = true)); addView(inbox)
        })
        content.addView(panel().apply {
            addView(text("Conversation defaults", 16f, bold = true))
            addView(text("Individual message order", 12f, bold = true)); addView(thread)
            addView(text("Each conversation can override this from its Sort menu."))
        })
        content.addView(primaryButton("Save defaults") {
            val saved = SortingSettings(
                inboxTransportFilter = transport.selectedItem.toString(),
                inboxContactFilter = contacts.selectedItem.toString(),
                inboxSort = inbox.selectedItem.toString(),
                threadSort = thread.selectedItem.toString()
            )
            UserSettings(this).setDefaultSorting(saved)
            inboxFilter = saved.inboxTransportFilter
            inboxContactFilter = saved.inboxContactFilter
            inboxSort = saved.inboxSort
            toast("Default sorting saved.")
            showSettings()
        })
    }

    private fun showNotificationSettings() {
        currentPage = PAGE_NOTIFICATION_SETTINGS
        val current = UserSettings(this).notifications
        val content = screen("Notifications") { showSettings() }
        val manager = getSystemService(NotificationManager::class.java)
        val systemAllowed = NotificationController.systemNotificationsAllowed(this)
        val messageChannelBlocked = manager.getNotificationChannel(NotificationChannels.MESSAGES)
            ?.importance == NotificationManager.IMPORTANCE_NONE

        val master = settingsCheckBox("Allow notifications", current.enabled)
        val messages = settingsCheckBox("SMS and MMS notifications", current.messageNotifications)
        val emails = settingsCheckBox("Email notifications", current.emailNotifications)
        val persistent = settingsCheckBox("Keep unread notifications persistent", current.persistentUnread)
        val previews = settingsCheckBox("Show sender and message previews", current.showPreviews)
        val quickReply = settingsCheckBox("Show Quick reply on SMS/MMS alerts", current.quickReply)
        val dependentControls = listOf(messages, emails, persistent, previews, quickReply)

        fun refreshEnabledState() {
            dependentControls.forEach { control ->
                control.isEnabled = master.isChecked
                control.alpha = if (master.isChecked) 1f else 0.5f
            }
        }
        master.setOnCheckedChangeListener { _, _ -> refreshEnabledState() }
        refreshEnabledState()

        content.addView(panel().apply {
            addView(text("App notification controls", 16f, bold = true))
            addView(master)
            addView(text(
                if (systemAllowed) "Android currently allows this app to post notifications."
                else "Android is currently blocking this app's notifications.",
                12f
            ))
            if (messageChannelBlocked) addView(text(
                "The Android SMS/MMS notification channel is blocked; use Android controls below to enable it.",
                12f
            ))
        })
        content.addView(panel().apply {
            addView(text("Notification types", 16f, bold = true))
            addView(messages)
            addView(emails)
        })
        content.addView(panel().apply {
            addView(text("Alert behavior", 16f, bold = true))
            addView(persistent)
            addView(text(
                "Persistent alerts cannot be swiped away. They clear when the conversation is opened, replied to, or no unread email remains.",
                12f
            ))
            addView(previews)
            addView(quickReply)
            addView(text(
                "Android's channel controls have the final say over sound, vibration, lock-screen visibility, and icon badges.",
                12f
            ))
        })
        content.addView(primaryButton("Save notification settings") {
            val saved = NotificationSettings(
                enabled = master.isChecked,
                messageNotifications = messages.isChecked,
                emailNotifications = emails.isChecked,
                persistentUnread = persistent.isChecked,
                showPreviews = previews.isChecked,
                quickReply = quickReply.isChecked
            )
            UserSettings(this).setNotifications(saved)
            if (current.showPreviews != saved.showPreviews || current.quickReply != saved.quickReply) {
                NotificationController.clearManaged(this)
            }
            NotificationController.applyPreferences(this, saved)
            if (saved.enabled && saved.emailNotifications && saved.persistentUnread) {
                EmailSyncWorker.syncNow(this)
            }
            if (saved.enabled && Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_PERMISSIONS)
            } else {
                toast("Notification settings saved.")
                showNotificationSettings()
            }
        })
        content.addView(panel().apply {
            addView(text("Android notification controls", 16f, bold = true))
            addView(text("Change channel sounds, vibration patterns, lock-screen behavior, pop-ups, and badges in Android.", 12f))
            addView(compactButton("Open Android notification controls") {
                runCatching {
                    startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                        putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                    })
                }.onFailure { toast("Android notification controls are unavailable on this device.") }
            })
            addView(compactButton("Clear current notifications") {
                NotificationController.clearManaged(this@MainActivity)
                toast("Current message and email notifications cleared.")
            })
        })
    }

    private fun chooseBackgroundPhoto() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        }
        startActivityForResult(intent, REQUEST_BACKGROUND)
    }

    private fun removeBackgroundPhoto() {
        val settings = UserSettings(this)
        settings.appearance.backgroundUri?.let { value ->
            runCatching { contentResolver.releasePersistableUriPermission(Uri.parse(value), Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        }
        settings.setBackgroundUri(null)
        removeUnusedBackgroundFiles(null)
        cachedBackgroundKey = null
        cachedBackgroundBitmap = null
        toast("Background photo removed.")
        showAppearanceSettings()
    }

    private fun showAccounts() {
        currentPage = PAGE_ACCOUNTS
        val content = screen("Email accounts") { showSettings() }
        content.addView(button("Add email account", match = true) { showAccountEditor(null) })
        content.addView(button("Sync all now", match = true) {
            toast("Synchronizing email…")
            work({ EmailSyncWorker.performDetailed(this) }) { result ->
                result.fold(
                    onSuccess = { run ->
                        toast(when {
                            run.failedAccounts > 0 ->
                                "Email sync finished with ${run.failedAccounts} account error${if (run.failedAccounts == 1) "" else "s"}. See the account status below."
                            run.synchronizedAccounts == 0 -> "No enabled email accounts are set to synchronize."
                            else -> "Email synchronization completed."
                        })
                        showAccounts()
                    },
                    onFailure = {
                        toast(it.message ?: "Email synchronization could not start.")
                        showAccounts()
                    }
                )
            }
        })
        val loading = text("Loading accounts…")
        content.addView(loading)
        work({ EmailAccountService(this).listAll() }) { result ->
            content.removeView(loading)
            val accounts = result.getOrElse {
                content.addView(errorText(it.message ?: "Unable to load accounts."))
                return@work
            }
            if (accounts.isEmpty()) content.addView(text("No email accounts configured."))
            accounts.forEach { account -> content.addView(accountCard(account)) }
        }
    }

    private fun accountCard(account: EmailAccountEntity): View {
        val card = panel()
        card.addView(text(account.displayName, 18f, bold = true))
        card.addView(text(account.emailAddress))
        card.addView(text("${account.authType} • ${if (account.enabled) "Enabled" else "Disabled"} • Sync ${if (account.syncEnabled) "On" else "Off"}${if (account.isDefaultSendAccount) " • Default sender" else ""}", 13f))
        card.addView(text("IMAP: ${account.incomingSecurity} ${account.incomingHost}:${account.incomingPort}\nSMTP: ${account.outgoingSecurity} ${account.outgoingHost}:${account.outgoingPort}", 12f))
        card.addView(text("Last successful sync: ${account.lastSyncAt?.let(::formatDateTime) ?: "Never"}", 12f))
        account.lastSyncError?.takeIf { it.isNotBlank() }?.let {
            card.addView(errorText("Sync needs attention: $it"))
        } ?: card.addView(text(if (account.lastSyncAt == null) "Sync status: Not yet synchronized" else "Sync status: Up to date", 12f, bold = true))
        card.addView(horizontal(
            button(if (account.enabled) "Disable" else "Enable") {
                accountAction { it.setEnabled(account.id, !account.enabled) }
            },
            button(if (account.syncEnabled) "Pause sync" else "Enable sync") {
                accountAction { it.setSyncEnabled(account.id, !account.syncEnabled) }
            }
        ))
        card.addView(horizontal(
            button("Test") {
                work({ EmailAccountService(this).test(account.id) }) { result ->
                    result.fold(
                        onSuccess = { inner -> toast(if (inner.isSuccess) "IMAP and SMTP tests passed." else inner.exceptionOrNull()?.message ?: "Connection test failed.") },
                        onFailure = { toast(it.message ?: "Connection test failed.") }
                    )
                }
            },
            button("Edit") { showAccountEditor(account) },
            button("Remove") { confirmRemove(account) }
        ))
        if (account.enabled && !account.isDefaultSendAccount) {
            card.addView(button("Make default sender", match = true) { accountAction { it.setDefaultSendAccount(account.id) } })
        }
        if (account.authType == "OAUTH2") {
            card.addView(button("Sign in with OAuth2", match = true) {
                runCatching { OAuthUiLauncher.launch(this, account) }.onFailure { toast(it.message ?: "Unable to start OAuth sign-in.") }
            })
        }
        return card
    }

    private fun accountAction(action: suspend (EmailAccountService) -> Unit) {
        work({ action(EmailAccountService(this)) }) { result ->
            if (result.isSuccess) showAccounts() else toast(result.exceptionOrNull()?.message ?: "Account update failed.")
        }
    }

    private fun confirmRemove(account: EmailAccountEntity) {
        AlertDialog.Builder(this)
            .setTitle("Remove ${account.displayName}?")
            .setMessage("The account, synchronized messages, attachments, and encrypted credential will be removed from this device.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Remove") { _, _ -> accountAction { it.remove(account.id) } }
            .show()
    }

    private fun showAccountEditor(existing: EmailAccountEntity?) {
        currentPage = PAGE_ACCOUNT_EDIT
        val content = screen(if (existing == null) "Add email account" else "Edit email account") { showAccounts() }
        val name = edit("Account name", existing?.displayName.orEmpty())
        val address = edit("Email address", existing?.emailAddress.orEmpty(), email = true)
        val username = edit("Username", existing?.username ?: existing?.emailAddress.orEmpty())
        val auth = spinner(listOf("PASSWORD", "OAUTH2"), existing?.authType ?: "PASSWORD")
        val secret = edit(if (existing == null) "Password / app password" else "New password (blank keeps current secret)", "", password = true)
        val clientId = edit("OAuth client ID", existing?.oauthClientId.orEmpty())
        val authorize = edit("OAuth authorization endpoint", existing?.oauthAuthorizeEndpoint.orEmpty(), uri = true)
        val token = edit("OAuth token endpoint", existing?.oauthTokenEndpoint.orEmpty(), uri = true)
        val scopes = edit("OAuth scopes", existing?.oauthScopes.orEmpty())
        val incomingHost = edit("IMAP server", existing?.incomingHost.orEmpty())
        val incomingPort = edit("IMAP port", (existing?.incomingPort ?: 993).toString(), number = true)
        val incomingSecurity = spinner(listOf("TLS", "STARTTLS"), existing?.incomingSecurity ?: "TLS")
        val outgoingHost = edit("SMTP server", existing?.outgoingHost.orEmpty())
        val outgoingPort = edit("SMTP port", (existing?.outgoingPort ?: 587).toString(), number = true)
        val outgoingSecurity = spinner(listOf("TLS", "STARTTLS"), existing?.outgoingSecurity ?: "STARTTLS")
        val signature = edit("Signature", existing?.signature.orEmpty(), multiline = true)

        content.addView(name)
        content.addView(address)
        content.addView(button("Auto-configure provider", match = true) {
            val preset = EmailProviderCatalog.detect(address.text.toString())
            if (preset == null) return@button toast("No built-in preset matched this address.")
            if (name.text.isBlank()) name.setText(preset.displayName)
            if (username.text.isBlank()) username.setText(address.text)
            incomingHost.setText(preset.incomingHost)
            incomingPort.setText(preset.incomingPort.toString())
            incomingSecurity.setSelection(listOf("TLS", "STARTTLS").indexOf(preset.incomingSecurity).coerceAtLeast(0))
            outgoingHost.setText(preset.outgoingHost)
            outgoingPort.setText(preset.outgoingPort.toString())
            outgoingSecurity.setSelection(listOf("TLS", "STARTTLS").indexOf(preset.outgoingSecurity).coerceAtLeast(0))
            if (preset.oauthPreferred) {
                auth.setSelection(1)
                authorize.setText(preset.oauthAuthorizeEndpoint.orEmpty())
                token.setText(preset.oauthTokenEndpoint.orEmpty())
                scopes.setText(preset.oauthScopes.orEmpty())
            }
        })
        content.addView(username)
        content.addView(text("Authentication", 13f, bold = true))
        content.addView(auth)
        content.addView(secret)
        content.addView(clientId)
        content.addView(authorize)
        content.addView(token)
        content.addView(scopes)
        content.addView(incomingHost)
        content.addView(incomingPort)
        content.addView(text("IMAP security", 13f, bold = true))
        content.addView(incomingSecurity)
        content.addView(outgoingHost)
        content.addView(outgoingPort)
        content.addView(text("SMTP security", 13f, bold = true))
        content.addView(outgoingSecurity)
        content.addView(signature)
        content.addView(text("OAuth providers require a distributor-owned client registration. Save the account, then use Sign in with OAuth2 from Email accounts.", 12f))
        content.addView(button("Save account", match = true) {
            val authType = auth.selectedItem.toString()
            val replacement = secret.text.toString().takeIf { it.isNotBlank() }?.toCharArray()
            if (existing != null && existing.authType != authType && authType == "PASSWORD" && replacement == null) {
                return@button toast("Enter a password when changing to password authentication.")
            }
            work({
                val service = EmailAccountService(this)
                if (existing == null) {
                    service.add(NewEmailAccount(
                        displayName = name.text.toString().ifBlank { address.text.toString() },
                        emailAddress = address.text.toString(),
                        incomingHost = incomingHost.text.toString(),
                        incomingPort = incomingPort.text.toString().toIntOrNull() ?: 993,
                        incomingSecurity = incomingSecurity.selectedItem.toString(),
                        outgoingHost = outgoingHost.text.toString(),
                        outgoingPort = outgoingPort.text.toString().toIntOrNull() ?: 587,
                        outgoingSecurity = outgoingSecurity.selectedItem.toString(),
                        username = username.text.toString().ifBlank { address.text.toString() },
                        authType = authType,
                        secret = replacement,
                        oauthClientId = clientId.text.toString().takeIf(String::isNotBlank),
                        oauthAuthorizeEndpoint = authorize.text.toString().takeIf(String::isNotBlank),
                        oauthTokenEndpoint = token.text.toString().takeIf(String::isNotBlank),
                        oauthScopes = scopes.text.toString().takeIf(String::isNotBlank),
                        signature = signature.text.toString()
                    ))
                } else {
                    service.update(existing.copy(
                        displayName = name.text.toString(),
                        emailAddress = address.text.toString(),
                        incomingHost = incomingHost.text.toString(),
                        incomingPort = incomingPort.text.toString().toIntOrNull() ?: existing.incomingPort,
                        incomingSecurity = incomingSecurity.selectedItem.toString(),
                        outgoingHost = outgoingHost.text.toString(),
                        outgoingPort = outgoingPort.text.toString().toIntOrNull() ?: existing.outgoingPort,
                        outgoingSecurity = outgoingSecurity.selectedItem.toString(),
                        username = username.text.toString(),
                        authType = authType,
                        oauthClientId = clientId.text.toString().takeIf(String::isNotBlank),
                        oauthAuthorizeEndpoint = authorize.text.toString().takeIf(String::isNotBlank),
                        oauthTokenEndpoint = token.text.toString().takeIf(String::isNotBlank),
                        oauthScopes = scopes.text.toString().takeIf(String::isNotBlank),
                        signature = signature.text.toString()
                    ), replacement)
                }
            }) { result ->
                if (result.isSuccess) {
                    toast("Account saved.")
                    showAccounts()
                } else toast(result.exceptionOrNull()?.message ?: "Unable to save account.")
            }
        })
    }

    private fun showEmailThread(threadId: String, markReadOnOpen: Boolean = true) {
        currentPage = PAGE_THREAD
        activeDeviceThreadId = null
        if (activeEmailThreadId != threadId) emailMessageSelected.clear()
        val cachedState = activeEmailState.takeIf { activeEmailThreadId == threadId }
            ?: emailThreadCache.get(threadId)
        activeEmailThreadId = threadId
        activeEmailState = cachedState
        val conversationKey = "email:$threadId"
        activeEmailSort = UserSettings(this).conversationSort(conversationKey)
            .takeIf { it in THREAD_SORT_OPTIONS } ?: THREAD_OLDEST
        val threadScreen = recycledListScreen(
            "Email",
            onBack = { showInbox() },
            onMenu = { anchor -> showEmailThreadManagementMenu(anchor, threadId, activeEmailState) }
        )
        val generation = threadScreenGeneration
        val status = text(
            if (cachedState == null) "Loading email…" else "${cachedState.messages.size} emails • Refreshing in background…",
            11f,
            bold = true
        )
        val sort = compactButton("Sort ▾") { anchor ->
            showThreadSortMenu(anchor, conversationKey, activeEmailSort) {
                activeEmailSort = UserSettings(this).conversationSort(conversationKey)
                    .takeIf { it in THREAD_SORT_OPTIONS } ?: THREAD_OLDEST
                activeEmailState?.let { activeEmailAdapter?.submit(it, activeEmailSort) }
                updateEmailThreadControls()
                scrollListForSort(threadScreen.list, activeEmailSort)
            }
        }
        threadScreen.controls.addView(threadControlBar(status, sort))
        val adapter = EmailMessageAdapter(threadId) {
            activeEmailAdapter?.notifyDataSetChanged()
            updateEmailThreadControls()
        }
        threadScreen.list.adapter = adapter
        activeEmailAdapter = adapter
        activeEmailStatus = status
        cachedState?.let {
            adapter.submit(it, activeEmailSort)
            scrollListForSort(threadScreen.list, activeEmailSort)
        }
        work({
            val actions = EmailActionService(this)
            val remoteUnread = if (markReadOnOpen) actions.markThreadReadLocally(threadId) else emptyList()
            val messages = actions.threadMessages(threadId)
            EmailThreadLoad(
                ThreadState(messages, mutableMapOf()),
                remoteUnread
            )
        }) { result ->
            if (!isCurrentEmailThread(threadId, generation)) return@work
            val loaded = result.getOrElse {
                status.text = it.message ?: "Unable to load email."
                status.setTextColor(Color.rgb(190, 25, 25))
                return@work
            }
            val state = loaded.state
            if (state.messages.isEmpty()) return@work showInbox()
            activeEmailState = state
            emailThreadCache.put(threadId, state)
            emailMessageSelected.retainAll(state.messages.mapTo(mutableSetOf(), EmailMessageEntity::stableId))
            adapter.submit(state, activeEmailSort)
            updateEmailThreadControls()
            scrollListForSort(threadScreen.list, activeEmailSort)
            if (loaded.remoteUnread.isNotEmpty()) {
                work({
                    EmailActionService(this).pushSeenState(loaded.remoteUnread, true).getOrThrow()
                }) { pushed ->
                    pushed.exceptionOrNull()?.let {
                        toast("Read status changed here, but the mail server update failed: ${it.message.orEmpty()}")
                    }
                }
            }
        }
    }

    private fun isCurrentEmailThread(threadId: String, generation: Int): Boolean =
        currentPage == PAGE_THREAD && activeEmailThreadId == threadId && threadScreenGeneration == generation

    private fun updateEmailThreadControls() {
        val count = activeEmailState?.messages?.size ?: 0
        activeEmailStatus?.text = when {
            count == 0 -> "Loading email…"
            emailMessageSelected.isNotEmpty() ->
                "$count email${if (count == 1) "" else "s"} • ${emailMessageSelected.size} selected • ${activeEmailSort.shortLabel()}"
            else -> "$count email${if (count == 1) "" else "s"} • ${activeEmailSort.shortLabel()}"
        }
    }

    private fun seedAndCompose(mode: ComposeMode, messageId: String) {
        work({ EmailActionService(this).seed(mode, messageId) }) { result ->
            result.fold(onSuccess = { showEmailCompose(it) }, onFailure = { toast(it.message ?: "Unable to prepare email.") })
        }
    }

    private fun showEmailCompose(
        seed: ComposeSeed,
        restored: ComposeRecord? = null,
        initialAttachments: List<Uri> = emptyList()
    ) {
        currentPage = PAGE_COMPOSE
        emailAttachmentUris.clear()
        emailAttachmentUris += restored?.payload?.attachments?.map(Uri::parse) ?: initialAttachments
        attachmentTarget = ATTACH_EMAIL
        val content = screen(if (seed.mode == ComposeMode.NEW) "Write email" else seed.mode.name.replace('_', ' '),
            onBack = ::leaveComposer, onMenu = ::showComposeMenu)
        val generation = threadScreenGeneration
        val id = restored?.id ?: UUID.randomUUID().toString()
        val from = Spinner(this).apply {
            adapter = stringAdapter(listOf("Loading accounts…"))
        }
        val to = recipientEdit("To — contact or email", seed.to.joinToString(", "))
        val cc = recipientEdit("Cc", seed.cc.joinToString(", "))
        val bcc = recipientEdit("Bcc", restored?.payload?.bcc?.joinToString(", ").orEmpty())
        val subject = edit("Subject", seed.subject)
        val body = edit("Message", seed.body, multiline = true)
        content.addView(text("From", 12f, bold = true)); content.addView(from)
        content.addView(to); content.addView(cc); content.addView(bcc)
        content.addView(horizontal(
            compactButton("Choose To") { chooseRecipients(RecipientKind.EMAIL, to) },
            compactButton("Choose Cc") { chooseRecipients(RecipientKind.EMAIL, cc) },
            compactButton("Choose Bcc") { chooseRecipients(RecipientKind.EMAIL, bcc) }
        ))
        content.addView(subject); content.addView(body)
        val send = primaryButton("Send now") { submitComposer(null) }.apply { isEnabled = false }
        content.addView(horizontal(send,
            compactButton("Schedule send ▾") { scheduleComposer() },
            smallButton("⋮", "Email draft options") { showComposeMenu(it) }))
        attachmentSummary = text(attachmentText(emailAttachmentUris), 12f)
        content.addView(requireNotNull(attachmentSummary))
        refreshAttachmentSummary(emailAttachmentUris)
        content.addView(horizontal(
            compactButton("Attach files") { chooseAttachments(ATTACH_EMAIL) },
            compactButton("Save draft") { saveComposerAndClose() }
        ))
        var accounts: List<EmailAccountEntity> = emptyList()
        var accountOffset = 0
        var accountsLoaded = false
        installComposer(content, id, body, listOf(to, cc, bcc, subject, body)) {
            ComposePayload(kind = "EMAIL", to = splitAddresses(to.text.toString()), cc = splitAddresses(cc.text.toString()),
                bcc = splitAddresses(bcc.text.toString()), subject = subject.text.toString(), body = body.text.toString(),
                accountId = accounts.getOrNull(from.selectedItemPosition - accountOffset)?.id ?: if (!accountsLoaded) seed.accountId else null,
                mode = seed.mode.name, sourceMessageId = seed.sourceMessageId, attachments = emailAttachmentUris.map(Uri::toString))
        }
        work({
            val coordinator = EmailComposeCoordinator(this)
            val available = coordinator.availableFromAccounts()
            val selected = coordinator.initialFromAccount(seed.accountId)
            val attachments = if (restored == null && seed.mode == ComposeMode.FORWARD && seed.sourceMessageId != null)
                LocalDatabase.get(this).emailAttachmentDao().forMessage(seed.sourceMessageId) else emptyList()
            Triple(available, selected, attachments)
        }) { result ->
            if (threadScreenGeneration != generation || activeDraftId != id) return@work
            result.onSuccess { loaded ->
                accounts = loaded.first
                accountsLoaded = true
                accountOffset = if (seed.accountId != null && accounts.none { it.id == seed.accountId }) 1 else 0
                from.adapter = stringAdapter(
                    (if (accountOffset == 1) listOf("Original account unavailable — choose an account") else emptyList()) +
                        if (accounts.isEmpty()) listOf("No enabled email account") else accounts.map { "${it.displayName} — ${it.emailAddress}" })
                val position = accounts.indexOfFirst { it.id == (seed.accountId ?: loaded.second?.id) }
                if (position >= 0) from.setSelection(position)
                send.isEnabled = accounts.isNotEmpty()
                emailAttachmentUris += loaded.third.map { PduContentProvider.uriFor(this, File(it.localPath)) }
                refreshAttachmentSummary(emailAttachmentUris)
                queueDraftSave()
            }.onFailure { toast(it.message ?: "Unable to load email accounts.") }
        }
        from.onSelectionChanged { queueDraftSave() }
        configureRecipientSuggestions(listOf(to, cc, bcc), RecipientKind.EMAIL)
    }

    private fun openAttachment(item: EmailAttachmentEntity) {
        runCatching {
            val uri = PduContentProvider.uriFor(this, File(item.localPath))
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, item.mimeType).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        }.onFailure { toast(it.message ?: "Unable to open attachment.") }
    }

    private fun installComposer(
        content: LinearLayout,
        id: String,
        body: EditText,
        fields: List<EditText>,
        saveInitially: Boolean = true,
        statusMessage: String = "Drafts auto-save on this device. Unsent voice previews must be attached to keep them.",
        snapshot: () -> ComposePayload
    ) {
        activeDraftId = id
        composeBody = body
        composeContainer = content
        composeSnapshot = snapshot
        composeStatus = text(statusMessage, 11f)
        content.addView(composeStatus)
        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { queueDraftSave() }
            override fun afterTextChanged(s: Editable?) = Unit
        }
        fields.forEach { it.addTextChangedListener(watcher) }
        if (saveInitially) queueDraftSave()
    }

    private fun queueDraftSave() {
        draftHandler.removeCallbacks(autosave)
        if (composeSnapshot != null && !composeBusy) draftHandler.postDelayed(autosave, 700)
    }

    // All editor saves and transitions run in order, including Activity recreation.
    private fun <T> composeWork(block: () -> T, complete: (Result<T>) -> Unit) {
        composeExecutor.execute {
            val result = runCatching(block)
            Async.onMain { if (!isFinishing && !isDestroyed) complete(result) }
        }
    }

    private fun saveDraftQuietly() {
        if (composeBusy) return
        val id = activeDraftId ?: return
        val payload = composeSnapshot?.invoke() ?: return
        val inlineReply = inlineReplyThreadId != null && payload.kind == "MESSAGE"
        composeWork({
            val store = ComposeStore.get(this)
            if (inlineReply && payload.body.isBlank() && payload.attachments.isEmpty()) {
                store.delete(id)
                null
            } else store.saveDraft(id, payload)
        }) { result ->
            if (id == activeDraftId && !composeBusy) composeStatus?.text = result.fold(
                onSuccess = { if (it == null) "Empty draft — nothing saved." else "Draft saved on this device." },
                onFailure = { "Draft needs attention: ${it.message}" })
        }
    }

    private fun setComposeBusy(value: Boolean) {
        composeBusy = value
        fun enable(view: View) {
            view.isEnabled = !value
            if (view is ViewGroup) for (i in 0 until view.childCount) enable(view.getChildAt(i))
        }
        composeContainer?.let(::enable)
    }

    private fun saveComposerAndClose() {
        if (composeBusy) return
        val id = activeDraftId ?: return
        val payload = composeSnapshot?.invoke() ?: return
        draftHandler.removeCallbacks(autosave)
        setComposeBusy(true)
        composeWork({ ComposeStore.get(this).saveDraft(id, payload) }) { result ->
            setComposeBusy(false)
            result.fold(onSuccess = { showWorkflows() }, onFailure = { toast("Could not finish saving: ${it.message}") })
        }
    }

    private fun leaveComposer() {
        if (composeBusy) return toast("Please wait while this draft is being saved.")
        if (composeSnapshot?.invoke()?.hasContent() != true && pendingVoiceDraft == null) {
            discardComposer(false)
            return
        }
        AlertDialog.Builder(this).setTitle("Keep this draft?")
            .setMessage("Save text, recipients and attached files in Drafts. Attach any recorded voice preview first if you want to keep it.")
            .setPositiveButton("Save draft") { _, _ -> saveComposerAndClose() }
            .setNeutralButton("Discard") { _, _ -> discardComposer(false) }
            .setNegativeButton("Keep editing", null).show()
    }

    private fun discardComposer(confirm: Boolean = true) {
        if (composeBusy) return
        val id = activeDraftId ?: return showInbox()
        val discard = {
            draftHandler.removeCallbacks(autosave)
            composeSnapshot = null
            setComposeBusy(true)
            composeWork({ ComposeStore.get(this).delete(id) }) { result ->
                result.fold(onSuccess = { showInbox() }, onFailure = { setComposeBusy(false); toast(it.message ?: "Could not discard draft.") })
            }
        }
        if (confirm) confirmDelete("Discard this unsent draft and its app-owned attachment copies? Original files are kept.", discard)
        else discard()
    }

    private fun showComposeMenu(anchor: View) {
        if (composeBusy) return toast("Please wait while the draft is being saved.")
        val target = if (composeSnapshot?.invoke()?.kind == "EMAIL") ATTACH_EMAIL else ATTACH_MESSAGE
        showActions(anchor, listOf(
            MenuAction("Send now") { submitComposer(null) },
            MenuAction("Schedule send — date & time…") { scheduleComposer() },
            MenuAction("Save draft & close") { saveComposerAndClose() },
            MenuAction("Attach file") { chooseAttachments(target) },
            MenuAction("Manage attachments") { manageComposeAttachments() },
            MenuAction("Copy message text") { composeBody?.let { copyText("Draft", it.text.toString()) } },
            MenuAction("Paste into message") { composeBody?.let(::pasteInto) },
            MenuAction("Select all message text") { composeBody?.apply { requestFocus(); selectAll() } },
            MenuAction("Discard draft") { discardComposer() }
        ))
    }

    private fun manageComposeAttachments() {
        val uris = if (composeSnapshot?.invoke()?.kind == "EMAIL") emailAttachmentUris else messageAttachmentUris
        if (uris.isEmpty()) return toast("No attached files. A voice preview must be attached first.")
        AlertDialog.Builder(this).setTitle("Remove attachment from draft")
            .setItems(uris.map(::attachmentDisplayName).toTypedArray()) { _, which ->
                uris.removeAt(which)
                refreshAttachmentSummary(uris)
                queueDraftSave()
            }.setNegativeButton("Keep all", null).show()
    }

    private fun scheduleComposer() {
        if (composeBusy) return
        val payload = composeSnapshot?.invoke() ?: return
        runCatching { payload.validate() }.onFailure { toast(it.message ?: "Check this draft."); return }
        pickSchedule { submitComposer(it) }
    }

    private fun pickSchedule(initial: Long = System.currentTimeMillis() + 60 * 60 * 1000, picked: (Long) -> Unit) {
        val calendar = Calendar.getInstance().apply {
            timeInMillis = initial.coerceAtLeast(System.currentTimeMillis() + 60_000)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
            setBackgroundColor(panelSurfaceColor())
        }
        val date = button("") {}
        val time = button("") {}
        fun labels() {
            date.text = "Date ▾  ${DateFormat.getDateInstance(DateFormat.MEDIUM).format(calendar.time)}"
            time.text = "Time ▾  ${android.text.format.DateFormat.getTimeFormat(this).format(calendar.time)}"
        }
        date.setOnClickListener {
            DatePickerDialog(this, { _, year, month, day ->
                calendar.set(Calendar.YEAR, year); calendar.set(Calendar.MONTH, month); calendar.set(Calendar.DAY_OF_MONTH, day); labels()
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).apply {
                datePicker.minDate = System.currentTimeMillis() - 1000
            }.show()
        }
        time.setOnClickListener {
            TimePickerDialog(this, { _, hour, minute ->
                calendar.set(Calendar.HOUR_OF_DAY, hour); calendar.set(Calendar.MINUTE, minute); labels()
            }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), android.text.format.DateFormat.is24HourFormat(this)).show()
        }
        labels(); panel.addView(date); panel.addView(time)
        panel.addView(text("Time zone: ${calendar.timeZone.id}. The selected instant is retained if you travel. Your phone must be on with the required SIM/network. Android restrictions or being offline can delay sending. Force-stopping the app pauses schedules until it is opened again.", 12f))
        if (Build.VERSION.SDK_INT >= 31 && !ScheduleCoordinator.exactAllowed(this)) {
            panel.addView(text("Optional: allow Alarms & reminders for a more timely wake-up. Without it, Android uses a less precise alarm.", 12f))
            panel.addView(compactButton("Alarms & reminders settings") {
                runCatching { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
                    .onFailure { toast("Open Android Settings → Apps → Special app access → Alarms & reminders.") }
            })
        }
        val dialog = AlertDialog.Builder(this).setTitle("Schedule send").setView(panel)
            .setNegativeButton("Cancel", null).setPositiveButton("Schedule", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (calendar.timeInMillis <= System.currentTimeMillis()) toast("Choose a future date and time.")
                else { dialog.dismiss(); picked(calendar.timeInMillis) }
            }
        }
        dialog.show()
    }

    private fun submitComposer(runAt: Long?) {
        if (composeBusy) return
        val id = activeDraftId ?: return
        val payload = composeSnapshot?.invoke() ?: return
        runCatching { payload.validate() }.onFailure { toast(it.message ?: "Check this draft."); return }
        if (payload.kind == "MESSAGE" && !DefaultSmsRole.isDefault(this)) {
            requestSmsRoleAndContinue(id, payload, runAt, ROLE_ORIGIN_COMPOSER)
            return
        }
        queueComposerPayload(id, payload, runAt)
    }

    private fun queueComposerPayload(id: String, payload: ComposePayload, runAt: Long?) {
        val returnThreadId = inlineReplyThreadId
        val returnAddress = activeDeviceAddress.ifBlank { inlineReplyAddress }
        val immediateInlineReply = returnThreadId != null && payload.kind == "MESSAGE" && runAt == null
        draftHandler.removeCallbacks(autosave)
        setComposeBusy(true)
        val pendingStableId = if (immediateInlineReply) {
            appendPendingInlineReply(requireNotNull(returnThreadId), returnAddress, id, payload).also {
                inlineReplyBody?.text?.clear()
            }
        } else null
        composeStatus?.text = "Saving Outbox item…"
        composeWork({
            val store = ComposeStore.get(this)
            val record = store.schedule(id, payload, runAt ?: System.currentTimeMillis())
            // An immediate inline reply is dispatched directly after this durable commit. Not
            // registering a competing zero-delay Job prevents the JobService from winning the
            // claim and returning control to the conversation before its provider row exists.
            if (!immediateInlineReply) {
                try { ScheduleCoordinator.arm(this, record) }
                catch (error: Exception) { store.finish(id, "FAILED", "Could not register send: ${error.message}"); throw error }
            }
            record
        }) { result ->
            result.fold(onSuccess = { item ->
                if (returnThreadId != null && payload.kind == "MESSAGE") {
                    if (runAt == null) {
                        messageAttachmentUris.clear()
                        refreshAttachmentSummary(messageAttachmentUris)
                        composeStatus?.text = "Sending reply…"
                        toast("Sending reply.")
                        work({
                            ScheduleCoordinator.perform(applicationContext, item.id)
                            ComposeStore.get(applicationContext).get(item.id)
                        }) { sendResult ->
                            // perform() returns only after the SMS/MMS provider row has been
                            // inserted (or the durable Outbox record has entered FAILED). Rebuild
                            // this same open thread now so the temporary row is replaced without
                            // requiring the user to leave and reopen the conversation.
                            if (currentPage == PAGE_THREAD && activeDeviceThreadId == returnThreadId) {
                                showSmsThread(returnThreadId, returnAddress)
                            }
                            val outboxItem = sendResult.getOrNull()
                            if (outboxItem?.state == "FAILED") {
                                toast("The reply remains in Outbox: ${outboxItem.error.orEmpty()}")
                            } else sendResult.exceptionOrNull()?.let { error ->
                                toast("The reply remains in Outbox: ${error.message.orEmpty()}")
                            }
                        }
                    } else {
                        setComposeBusy(false)
                        showSmsThread(returnThreadId, returnAddress)
                        toast("Reply scheduled for ${formatDateTime(item.runAt)}.")
                    }
                } else {
                    setComposeBusy(false)
                    showWorkflows()
                    if (runAt == null) {
                        toast("Sending. Check Outbox for the result.")
                        work({ ScheduleCoordinator.perform(applicationContext, item.id) }) {
                            if (currentPage == PAGE_WORKFLOWS) showWorkflows()
                        }
                    } else toast("Scheduled for ${formatDateTime(item.runAt)}. Manage it in Drafts & Outbox.")
                }
            }, onFailure = {
                setComposeBusy(false)
                pendingStableId?.let(::removePendingInlineReply)
                if (immediateInlineReply && activeDraftId == id && inlineReplyBody?.text.isNullOrBlank()) {
                    inlineReplyBody?.setText(payload.body)
                    inlineReplyBody?.setSelection(inlineReplyBody?.text?.length ?: 0)
                }
                toast("Not sent: ${it.message}. Your saved item is in Drafts & Outbox.")
                // A registration failure leaves a reviewable FAILED item, never an invisible retry.
                composeStatus?.text = "Unable to queue. Open Drafts & Outbox to review the saved item."
            })
        }
    }

    /** Paints an outgoing inline reply synchronously, before any provider or carrier I/O begins. */
    private fun appendPendingInlineReply(
        threadId: Long,
        address: String,
        composeId: String,
        payload: ComposePayload
    ): String? {
        if (currentPage != PAGE_THREAD || activeDeviceThreadId != threadId) return null
        val transport = if (payload.attachments.isNotEmpty() || payload.to.size > 1) {
            CommunicationTransport.MMS
        } else CommunicationTransport.SMS
        val pendingId = -((composeId.hashCode().toLong() and 0x7fffffffL) + 1L)
        val body = payload.body.ifBlank {
            val count = payload.attachments.size
            "Sending $count attachment${if (count == 1) "" else "s"}…"
        }
        val pending = DeviceMessage(
            id = pendingId,
            threadId = threadId,
            transport = transport,
            address = address,
            body = body,
            date = System.currentTimeMillis(),
            incoming = false,
            read = true
        )
        activeDeviceMessages = (activeDeviceMessages.filterNot { it.stableId == pending.stableId } + pending)
            .distinctBy(DeviceMessage::stableId)
        activeDeviceAdapter?.submit(activeDeviceMessages, activeDeviceSort)
        updateDeviceThreadControls()
        activeDeviceList?.post {
            val position = activeDeviceAdapter?.positionOf(pending.stableId) ?: -1
            if (position >= 0) activeDeviceList?.setSelection(position)
        }
        return pending.stableId
    }

    private fun removePendingInlineReply(stableId: String) {
        activeDeviceMessages = activeDeviceMessages.filterNot { it.stableId == stableId }
        activeDeviceAdapter?.submit(activeDeviceMessages, activeDeviceSort)
        updateDeviceThreadControls()
    }

    /** Saves first, then asks Android for the default role; approval resumes this exact action. */
    private fun requestSmsRoleAndContinue(
        itemId: String,
        payload: ComposePayload,
        runAt: Long?,
        origin: String
    ) {
        draftHandler.removeCallbacks(autosave)
        setComposeBusy(true)
        composeStatus?.text = "Saving the draft before requesting default SMS access…"
        composeWork({
            if (origin == ROLE_ORIGIN_COMPOSER) {
                ComposeStore.get(this).saveDraft(itemId, payload)
                    ?: error("The draft is empty.")
            } else {
                ComposeStore.get(this).get(itemId)
                    ?: error("The Outbox item no longer exists.")
            }
        }) { result ->
            result.fold(onSuccess = {
                pendingSmsRoleAction = PendingSmsRoleAction(itemId, runAt, origin)
                setComposeBusy(false)
                if (DefaultSmsRole.isDefault(this)) {
                    resumePendingSmsRoleAction()
                } else if (DefaultSmsRole.request(this, REQUEST_DEFAULT_SMS_ROLE)) {
                    composeStatus?.text = "Approve Maclean Messaging as the default SMS app to continue."
                } else {
                    pendingSmsRoleAction = null
                    composeStatus?.text = "Android did not make the SMS role available. The draft remains saved."
                    toast("Android did not make the default SMS role available on this device.")
                }
            }, onFailure = {
                setComposeBusy(false)
                toast("Could not save before requesting SMS access: ${it.message}")
            })
        }
    }

    private fun hasSmsRolePermissions(): Boolean = listOf(
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_SMS,
        Manifest.permission.RECEIVE_SMS,
        Manifest.permission.RECEIVE_MMS,
        Manifest.permission.RECEIVE_WAP_PUSH
    ).all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun refreshMessagingPage() {
        when (currentPage) {
            PAGE_INBOX -> showInbox()
            PAGE_SETTINGS -> showSettings()
            PAGE_WORKFLOWS -> showWorkflows()
        }
    }

    /** Consumes the continuation before queuing so onResume and onActivityResult cannot send twice. */
    private fun resumePendingSmsRoleAction() {
        val pending = pendingSmsRoleAction ?: return
        if (!DefaultSmsRole.isDefault(this)) return
        if (!hasSmsRolePermissions()) {
            if (!smsPermissionRequestActive) {
                smsPermissionRequestActive = true
                requestPermissions(
                    arrayOf(
                        Manifest.permission.SEND_SMS,
                        Manifest.permission.READ_SMS,
                        Manifest.permission.RECEIVE_SMS,
                        Manifest.permission.RECEIVE_MMS,
                        Manifest.permission.RECEIVE_WAP_PUSH
                    ),
                    REQUEST_SMS_SEND_PERMISSIONS
                )
            }
            return
        }
        pendingSmsRoleAction = null
        composeWork({ ComposeStore.get(this).get(pending.itemId) }) { result ->
            result.fold(onSuccess = { saved ->
                if (saved == null) {
                    setComposeBusy(false)
                    toast("The saved draft or Outbox item no longer exists.")
                } else if (pending.origin == ROLE_ORIGIN_WORKFLOW) {
                    queueWorkflow(saved, pending.runAt)
                } else {
                    queueComposerPayload(saved.id, saved.payload, pending.runAt)
                }
            }, onFailure = {
                setComposeBusy(false)
                toast("Could not continue the saved message: ${it.message}")
            })
        }
    }

    private fun showWorkflows() {
        currentPage = PAGE_WORKFLOWS
        attachmentTarget = ATTACH_NONE
        val content = screen("Drafts & Outbox", onBack = { showInbox() }, onMenu = { anchor ->
            showActions(anchor, listOf(MenuAction("Refresh") { showWorkflows() },
                MenuAction("New SMS / MMS") { showMessageComposer("", "") },
                MenuAction("New email") { showEmailCompose(ComposeSeed(ComposeMode.NEW, null)) }))
        })
        val generation = threadScreenGeneration
        content.addView(text("Drafts and schedules are stored on this device, not in your email server's Drafts folder. Sent history here can be removed without deleting the conversation.", 12f))
        content.addView(compactButton("Refresh status") { showWorkflows() })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        list.addView(text("Loading drafts and sends…", 14f))
        work({
            val store = ComposeStore.get(this)
            store.recoverInterrupted()
            ScheduleCoordinator.reconcileTransportResults(this, store)
            store.all().map { record -> record to if (record.state == "SUBMITTED" && record.resultToken != null)
                LocalDatabase.get(this).messageMetaDao().get(record.resultToken)?.state ?: "SUBMITTED" else record.state }
        }) { result ->
            if (currentPage != PAGE_WORKFLOWS || generation != threadScreenGeneration) return@work
            list.removeAllViews()
            result.fold(onSuccess = { items ->
                if (items.isEmpty()) list.addView(text("No drafts or scheduled messages. Use Save draft or Schedule send in either composer.", 15f))
                items.sortedWith(compareBy<Pair<ComposeRecord, String>> { when (it.first.state) { "DRAFT" -> 0; "SCHEDULED" -> 1; "SENDING" -> 2; "FAILED", "UNKNOWN" -> 3; else -> 4 } }.thenByDescending { it.first.updatedAt })
                    .forEach { (item, status) ->
                        val panel = panel()
                        val kind = if (item.payload.kind == "EMAIL") "Email" else if (item.payload.attachments.isEmpty()) "SMS" else "MMS"
                        panel.addView(compactBar("$kind · ${status.replace('_', ' ')}", smallButton("⋮", "Draft and Outbox actions") { showWorkflowMenu(it, item) }))
                        panel.addView(text(item.payload.to.joinToString(", ").ifBlank { "No To recipient" }, 14f, bold = true))
                        if (item.payload.subject.isNotBlank()) panel.addView(text(item.payload.subject, 14f))
                        panel.addView(text(item.payload.body.take(180).ifBlank { "${item.payload.attachments.size} attachment(s)" }, 13f))
                        if (item.runAt > 0) panel.addView(text("${if (item.state == "SCHEDULED") "Scheduled" else "Requested"}: ${formatDateTime(item.runAt)}", 12f))
                        if (status == "SUBMITTED" || status == "SENDING") panel.addView(text("Waiting for the carrier or server result. Successful sends leave Outbox automatically.", 11f))
                        item.error?.let { panel.addView(text(it, 12f)) }
                        if (item.state == "DRAFT") panel.addView(compactButton("Open draft") { editWorkflow(item) })
                        list.addView(panel)
                    }
            }, onFailure = { list.addView(text("Could not load Outbox: ${it.message}", 14f)) })
        }
    }

    private fun showWorkflowMenu(anchor: View, item: ComposeRecord) {
        val actions = buildList {
            if (item.state == "DRAFT" || item.state == "SCHEDULED") {
                add(MenuAction(if (item.state == "SCHEDULED") "Edit (pause schedule)" else "Open draft") { editWorkflow(item) })
                add(MenuAction("${if (item.state == "SCHEDULED") "Reschedule" else "Schedule send"} — date & time…") {
                    pickSchedule(item.runAt.takeIf { it > 0 } ?: System.currentTimeMillis() + 3600000) { queueWorkflow(item, it) }
                })
                add(MenuAction("Send now…") {
                    AlertDialog.Builder(this@MainActivity).setTitle("Send this item now?")
                        .setMessage("To: ${item.payload.to.joinToString(", ")}\n${item.payload.subject}\n${item.payload.body.take(240)}")
                        .setNegativeButton("Cancel", null).setPositiveButton("Send now") { _, _ -> queueWorkflow(item, null) }.show()
                })
                if (item.state == "SCHEDULED") add(MenuAction("Cancel schedule — keep draft") { editWorkflow(item, open = false) })
            } else if (item.state != "SENDING") add(MenuAction("Resend / edit a copy…") { openWorkflowCopy(item) })
            add(MenuAction("View details") {
                AlertDialog.Builder(this@MainActivity).setTitle("${item.payload.kind} · ${item.state}")
                    .setMessage("To: ${item.payload.to.joinToString()}\nCc: ${item.payload.cc.joinToString()}\nBcc: ${item.payload.bcc.joinToString()}\nAttachments: ${item.payload.attachments.size}\nUpdated: ${formatDateTime(item.updatedAt)}\n${item.error.orEmpty()}")
                    .setPositiveButton("OK", null).show()
            })
            if (item.state != "SENDING") add(MenuAction("Delete this ${if (item.state == "DRAFT") "draft" else "Outbox item"}") {
                confirmDelete("Remove this saved item and cancel any pending schedule? Already-sent messages and original attachment files are not deleted.") {
                    composeWork({
                        val store = ComposeStore.get(this@MainActivity)
                        check(store.delete(item.id)) { "Sending has already started or the item no longer exists." }
                        ScheduleCoordinator.cancelRegistration(this@MainActivity, item)
                    }) { it.onFailure { error -> toast(error.message ?: "Could not remove item.") }; showWorkflows() }
                }
            })
            add(MenuAction("Refresh status") { showWorkflows() })
        }
        showActions(anchor, actions)
    }

    private fun editWorkflow(item: ComposeRecord, open: Boolean = true) {
        composeWork({
            val store = ComposeStore.get(this)
            check(store.pauseForEdit(item.id)) { "Sending has already started or the item changed. Refresh Outbox." }
            ScheduleCoordinator.cancelRegistration(this, item)
            requireNotNull(store.get(item.id))
        }) { result -> result.fold(onSuccess = { if (open) openWorkflow(it) else showWorkflows() }, onFailure = { toast(it.message ?: "Could not open draft."); showWorkflows() }) }
    }

    private fun queueWorkflow(item: ComposeRecord, runAt: Long?) {
        if (item.payload.kind == "MESSAGE" && !DefaultSmsRole.isDefault(this)) {
            requestSmsRoleAndContinue(item.id, item.payload, runAt, ROLE_ORIGIN_WORKFLOW)
            return
        }
        composeWork({
            val store = ComposeStore.get(this)
            val queued = store.reschedule(item.id, runAt ?: System.currentTimeMillis())
            ScheduleCoordinator.cancelRegistration(this, item)
            try { ScheduleCoordinator.arm(this, queued) }
            catch (error: Exception) { store.finish(item.id, "FAILED", "Could not register send: ${error.message}"); throw error }
            queued
        }) { result ->
            result.onFailure { toast(it.message ?: "Unable to schedule. Review the Outbox item.") }
            showWorkflows()
            if (result.isSuccess && runAt == null) work({ ScheduleCoordinator.perform(applicationContext, item.id) }) {
                if (currentPage == PAGE_WORKFLOWS) showWorkflows()
            }
        }
    }

    private fun openWorkflow(item: ComposeRecord) {
        val p = item.payload
        if (p.kind == "EMAIL") showEmailCompose(ComposeSeed(runCatching { ComposeMode.valueOf(p.mode) }.getOrDefault(ComposeMode.NEW),
            p.accountId, p.to, p.cc, p.subject, p.body, p.sourceMessageId), item)
        else showMessageComposer(p.to.joinToString(", "), p.body, restored = item)
    }

    private fun openWorkflowCopy(item: ComposeRecord) {
        AlertDialog.Builder(this).setTitle("Review a new copy")
            .setMessage("This opens an editable copy. Check the conversation first to avoid sending a duplicate. Nothing is sent until you select Send now or Schedule send.")
            .setNegativeButton("Cancel", null).setPositiveButton("Open copy") { _, _ ->
                openWorkflow(item.copy(id = UUID.randomUUID().toString(), jobId = 0, state = "DRAFT", runAt = 0, error = null, resultToken = null))
            }.show()
    }

    private fun changeConversationFlag(ids: List<String>, flag: String, value: Boolean) {
        if (ids.isEmpty()) return toast("Select at least one conversation.")
        work({ ComposeStore.get(this).setFlag(ids, flag, value) }) { result ->
            result.fold(onSuccess = {
                inboxSelected.removeAll(ids.toSet())
                toast(if (flag == "archived") if (value) "Archived in this app. Find it in Archive." else "Moved to Inbox." else if (value) "Pinned to the top." else "Unpinned.")
                showInbox()
            }, onFailure = { toast(it.message ?: "Could not update conversation.") })
        }
    }

    private fun showLicense() {
        currentPage = PAGE_LICENSE
        val content = screen("GNU AGPLv3") { showSettings() }
        content.addView(text(readLicense(this), 12f))
    }

    private fun chooseAttachments(target: Int, mimeType: String = "*/*") {
        attachmentTarget = target
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType(mimeType)
            .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(intent, REQUEST_ATTACHMENTS)
    }

    private fun attachmentFromUri(uri: Uri): Attachment {
        var name: String? = uri.lastPathSegment
        var size: Long? = null
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                name = cursor.getString(0)
                if (!cursor.isNull(1)) size = cursor.getLong(1)
            }
        }
        return Attachment(uri.toString(), contentResolver.getType(uri) ?: "application/octet-stream", name, size)
    }

    /** Never queries a document provider from the UI thread. */
    private fun attachmentText(uris: List<Uri>): String =
        if (uris.isEmpty()) "No attachments selected." else uris.joinToString("\n", transform = ::attachmentDisplayName)

    private fun attachmentDisplayName(uri: Uri): String =
        attachmentMetadataCache.get(uri.toString())?.displayName
            ?: uri.lastPathSegment?.substringAfterLast('/')?.takeIf(String::isNotBlank)
            ?: "Attachment"

    private fun refreshAttachmentSummary(uris: MutableList<Uri>) {
        val summary = attachmentSummary ?: return
        summary.text = attachmentText(uris)
        if (inlineReplyThreadId != null) summary.visibility = if (uris.isEmpty()) View.GONE else View.VISIBLE
        val snapshot = uris.toList()
        val missing = snapshot.filter { attachmentMetadataCache.get(it.toString()) == null }
        if (missing.isEmpty()) return
        work({ missing.associateWith(::attachmentFromUri) }) { result ->
            result.onSuccess { loaded ->
                loaded.forEach { (uri, metadata) -> attachmentMetadataCache.put(uri.toString(), metadata) }
                if (attachmentSummary === summary && snapshot.all { it in uris }) {
                    summary.text = attachmentText(uris)
                }
            }
        }
    }

    private fun voiceRecorderPanel(
        recipients: () -> List<String>,
        subscriptionId: () -> Int?
    ): View {
        val container = panel()
        val status = text("Hold the microphone to record • slide left to cancel • slide up to lock", 12f)
        val liveWaveform = VoiceWaveformView(this).apply {
            setWaveformColors(appearance.accentColor, withAlpha(readableTextColor(), 90))
            visibility = View.GONE
        }
        val lockedControls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
        }
        val preview = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        val liveSamples = mutableListOf<Float>()
        var recorder: VoiceRecorder? = null
        var draft: VoiceDraft? = null
        var locked = false
        var startX = 0f
        var startY = 0f

        lateinit var microphone: GestureButton
        lateinit var pause: Button

        fun discardDraft() {
            val existing = draft ?: return
            VoicePlaybackController.stopIfKey("draft:${existing.file.absolutePath}")
            existing.file.delete()
            if (pendingVoiceDraft?.file == existing.file) pendingVoiceDraft = null
            draft = null
            preview.removeAllViews()
            preview.visibility = View.GONE
        }

        fun resetRecorderUi(message: String) {
            locked = false
            lockedControls.visibility = View.GONE
            liveWaveform.visibility = View.GONE
            liveSamples.clear()
            microphone.isEnabled = true
            microphone.text = "🎙 Hold to record"
            pause.text = "Pause"
            status.text = message
        }

        fun renderPreview(value: VoiceDraft) {
            preview.removeAllViews()
            preview.visibility = View.VISIBLE
            val key = "draft:${value.file.absolutePath}"
            val uri = PduContentProvider.uriFor(this, value.file)
            val waveform = VoiceWaveformView(this).apply {
                setSamples(value.waveform)
                setWaveformColors(appearance.accentColor, withAlpha(readableTextColor(), 90))
            }
            val timer = text("0:00 / ${VoiceMedia.formatDuration(value.durationMs)}", 11f)
            val play = compactButton("Play") { VoicePlaybackController.toggle(this, key, uri) }
            val speed = compactButton("1×") { VoicePlaybackController.cycleSpeed(key) }
            preview.addView(text(
                if (value.opus) "Preview • Ogg + Opus • mono • 48 kHz • ~32 kbps" else "Preview • M4A/AAC compatibility fallback",
                12f,
                bold = true
            ))
            preview.addView(waveform, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
            preview.addView(compactBar("", play, timer, speed))
            waveform.setOnSeek { fraction -> VoicePlaybackController.seek(key, fraction) }
            VoicePlaybackController.observe(key, preview) { state ->
                play.text = when {
                    state.loading -> "Loading…"
                    state.playing -> "Pause"
                    else -> "Play"
                }
                speed.text = String.format(Locale.US, "%s×", if (state.speed % 1f == 0f) state.speed.toInt() else state.speed)
                val total = state.durationMs.toLong().takeIf { it > 0L } ?: value.durationMs
                timer.text = "${VoiceMedia.formatDuration(state.positionMs.toLong())} / ${VoiceMedia.formatDuration(total)}"
                waveform.progress = if (state.durationMs > 0) state.positionMs.toFloat() / state.durationMs else 0f
            }

            val sendVoice = primaryButton("Send voice") {}
            fun attachPreview() {
                VoicePlaybackController.stopIfKey(key)
                if (uri !in messageAttachmentUris) messageAttachmentUris += uri
                if (pendingVoiceDraft?.file == value.file) pendingVoiceDraft = null
                draft = null
                preview.removeAllViews(); preview.visibility = View.GONE
                refreshAttachmentSummary(messageAttachmentUris)
                resetRecorderUi("Voice message attached. Send now, schedule, or save as a draft.")
                queueDraftSave()
            }
            sendVoice.setOnClickListener {
                val targets = recipients()
                val sim = subscriptionId()
                if (targets.isEmpty()) return@setOnClickListener toast("Enter at least one recipient.")
                if (sim == null) return@setOnClickListener toast("An active SIM is required.")
                attachPreview()
                submitComposer(null)
            }
            val save = compactButton("Save original") {
                work({ saveVoiceFile(value.file, value.mimeType) }) { result ->
                    result.fold(
                        onSuccess = { toast("Saved as $it") },
                        onFailure = { toast(it.message ?: "Unable to save the recording.") }
                    )
                }
            }
            val discard = compactButton("Discard") {
                discardDraft()
                resetRecorderUi("Voice recording discarded. Hold the microphone to try again.")
            }
            preview.addView(compactBar("", sendVoice, save, discard))
            preview.addView(compactButton("Attach voice to draft / schedule") { attachPreview() })
        }

        fun stopForPreview() {
            val active = recorder ?: return
            recorder = null
            activeVoiceRecorder = null
            microphone.isEnabled = false
            lockedControls.visibility = View.GONE
            liveWaveform.visibility = View.GONE
            status.text = "Finalizing voice message in the background…"
            work({ active.stop() }) { result ->
                if (!container.isAttachedToWindow) {
                    result.getOrNull()?.file?.delete()
                    return@work
                }
                result.fold(onSuccess = { value ->
                    draft = value
                    pendingVoiceDraft = value
                    resetRecorderUi("Preview your voice message before sending.")
                    renderPreview(value)
                }, onFailure = { error ->
                    resetRecorderUi(error.message ?: "Unable to finish the voice recording.")
                })
            }
        }

        fun cancelRecording(message: String) {
            recorder?.cancel()
            recorder = null
            activeVoiceRecorder = null
            resetRecorderUi(message)
        }

        microphone = primaryButton("🎙 Hold to record") {}
        microphone.contentDescription = "Hold to record a voice message. Slide left to cancel or up to lock."
        microphone.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        voicePermissionStatus = status
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_RECORD_AUDIO)
                        return@setOnTouchListener true
                    }
                    discardDraft()
                    startX = event.rawX
                    startY = event.rawY
                    locked = false
                    liveSamples.clear()
                    val created = VoiceRecorder(this) { elapsed, amplitude ->
                        val active = recorder
                        if (active?.state == VoiceRecorder.State.RECORDING) {
                            if (liveSamples.size >= 360) liveSamples.removeAt(0)
                            liveSamples += amplitude
                            liveWaveform.setSamples(liveSamples.toFloatArray())
                        }
                        val stateLabel = if (active?.state == VoiceRecorder.State.PAUSED) "Paused" else "Recording"
                        status.text = "$stateLabel ${VoiceMedia.formatDuration(elapsed)}${if (locked) " • locked" else " • ← cancel • ↑ lock"}"
                    }
                    val started = runCatching { created.start() }
                    if (started.isFailure) {
                        created.cancel()
                        status.text = started.exceptionOrNull()?.message ?: "Unable to start the microphone."
                        return@setOnTouchListener true
                    }
                    recorder = created
                    activeVoiceRecorder = created
                    liveWaveform.visibility = View.VISIBLE
                    microphone.text = "Recording…"
                    status.text = if (started.getOrThrow().opus) {
                        "Recording Ogg/Opus 0:00 • ← cancel • ↑ lock"
                    } else {
                        "Recording M4A fallback 0:00 • ← cancel • ↑ lock"
                    }
                    view.parent?.requestDisallowInterceptTouchEvent(true)
                    view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (recorder != null && !locked) {
                        val horizontalDistance = event.rawX - startX
                        val verticalDistance = event.rawY - startY
                        if (horizontalDistance <= -dp(90)) {
                            cancelRecording("Voice recording canceled.")
                            view.parent?.requestDisallowInterceptTouchEvent(false)
                        } else if (verticalDistance <= -dp(70)) {
                            locked = true
                            lockedControls.visibility = View.VISIBLE
                            microphone.text = "🎙 Locked"
                            status.text = "Recording locked • use Pause or Stop & preview"
                            view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    view.parent?.requestDisallowInterceptTouchEvent(false)
                    view.performClick()
                    if (recorder != null && !locked) stopForPreview()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    view.parent?.requestDisallowInterceptTouchEvent(false)
                    if (recorder != null && !locked) cancelRecording("Voice recording canceled.")
                    true
                }
                else -> false
            }
        }

        pause = compactButton("Pause") {
            val active = recorder ?: return@compactButton
            runCatching {
                if (active.state == VoiceRecorder.State.PAUSED) {
                    active.resume()
                    pause.text = "Pause"
                } else {
                    active.pause()
                    pause.text = "Resume"
                }
            }.onFailure { toast(it.message ?: "Unable to pause or resume recording.") }
        }
        val stop = compactButton("Stop & preview") { stopForPreview() }
        val cancel = compactButton("Cancel") { cancelRecording("Voice recording canceled.") }
        lockedControls.addView(pause, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        lockedControls.addView(stop, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        lockedControls.addView(cancel, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        container.addView(text("Voice message", 14f, bold = true))
        container.addView(text("Records a compact voice note; it is separate from attaching an audio file.", 11f))
        container.addView(microphone, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        container.addView(status)
        container.addView(liveWaveform, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        container.addView(lockedControls)
        container.addView(preview)
        voicePermissionStatus = status
        return container
    }

    private fun saveVoiceFile(file: File, mimeType: String): String {
        val fileName = file.name.replace(Regex("[\\r\\n/\\\\]+"), "_")
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Maclean Messaging")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val outputUri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Android could not create the download.")
        try {
            file.inputStream().use { input ->
                contentResolver.openOutputStream(outputUri, "w")?.use(input::copyTo)
                    ?: error("Android could not write the download.")
            }
            contentResolver.update(outputUri, ContentValues().apply {
                put(MediaStore.MediaColumns.IS_PENDING, 0)
            }, null, null)
        } catch (error: Throwable) {
            contentResolver.delete(outputUri, null, null)
            throw error
        }
        return "Downloads/Maclean Messaging/$fileName"
    }

    private fun attachmentLabel(attachment: DeviceAttachment): String {
        val size = attachment.sizeBytes?.let { bytes ->
            when {
                bytes >= 1_048_576L -> String.format(Locale.US, "%.1f MB", bytes / 1_048_576.0)
                bytes >= 1024L -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
                else -> "$bytes bytes"
            }
        }
        return listOf(attachment.fileName, attachment.mimeType, size).filterNotNull().joinToString(" • ")
    }

    private fun linkedMessageText(value: String): TextView = ContourTextView(this).apply {
        val cached = linkedTextCache.get(value)
        text = cached ?: value
        textSize = 15f * appearance.textScale
        typeface = appTypeface()
        setTextColor(readableTextColor())
        val inset = if (appearance.display.spacing == DISPLAY_SPACING_COMPACT) 2 else 3
        setPadding(dp(inset), dp(inset), dp(inset), dp(inset))
        setContourShape(appearance.display.bubbleShape)
        setHorizontallyScrolling(false)
        isSingleLine = false
        maxLines = Int.MAX_VALUE
        ellipsize = null
        breakStrategy = Layout.BREAK_STRATEGY_HIGH_QUALITY
        hyphenationFrequency = Layout.HYPHENATION_FREQUENCY_NORMAL
        linksClickable = true
        highlightColor = Color.TRANSPARENT
        if (cached == null && value.isNotBlank() && linkedTextLoading.add(value)) {
            tag = value
            Async.launch {
                val linked = SpannableString(value).apply {
                    Linkify.addLinks(this, Linkify.WEB_URLS or Linkify.EMAIL_ADDRESSES or Linkify.PHONE_NUMBERS)
                }
                Async.onMain {
                    linkedTextLoading -= value
                    linkedTextCache.put(value, linked)
                    if (!isFinishing && !isDestroyed && tag == value && isAttachedToWindow) {
                        text = linked
                    }
                }
            }
        }
    }

    private fun isVoiceMessage(attachment: DeviceAttachment): Boolean {
        val type = attachment.mimeType.substringBefore(';').lowercase(Locale.US)
        val voiceType = type == "audio/ogg" || type == "audio/opus" || type == "application/ogg" || type == "audio/mp4"
        return voiceType && attachment.fileName.contains("Voice Message", ignoreCase = true)
    }

    private fun voiceMessageView(
        threadId: Long,
        address: String,
        message: DeviceMessage,
        attachment: DeviceAttachment
    ): View {
        val key = "voice:${message.stableId}:${attachment.partId}"
        val uri = Uri.parse(attachment.contentUri)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(3), dp(4), dp(3))
        }
        val heading = text(
            if (attachment.mimeType.substringBefore(';').equals("audio/ogg", true)) "🎙 Voice message • Opus" else "🎙 Voice message",
            12f,
            bold = true
        )
        val waveform = VoiceWaveformView(this).apply {
            setSamples(VoiceWaveformView.placeholder(attachment.fileName + attachment.sizeBytes))
            setWaveformColors(appearance.accentColor, withAlpha(readableTextColor(), 90))
        }
        val cachedDuration = voiceDurationCache.get(key)
        var probedDuration = cachedDuration?.takeIf { it > 0L } ?: 0L
        val duration = text(
            if (probedDuration > 0L) VoiceMedia.formatDuration(probedDuration) else "Duration …",
            11f
        )
        val play = compactButton("Play") {
            VoicePlaybackController.toggle(this, key, uri)
        }
        val speed = compactButton("1×") {
            VoicePlaybackController.cycleSpeed(key)
        }
        val more = smallButton("⋮", "Voice message actions") { anchor ->
            showVoiceMessageMenu(anchor, threadId, address, message, attachment)
        }
        box.addView(heading)
        box.addView(waveform, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        box.addView(compactBar("", play, duration, speed, more))
        waveform.setOnSeek { fraction -> VoicePlaybackController.seek(key, fraction) }
        VoicePlaybackController.observe(key, box) { state ->
            play.text = when {
                state.loading -> "Loading…"
                state.playing -> "Pause"
                else -> "Play"
            }
            speed.text = String.format(Locale.US, "%s×", if (state.speed % 1f == 0f) state.speed.toInt() else state.speed)
            val total = state.durationMs.toLong().takeIf { it > 0L } ?: probedDuration
            duration.text = if (state.active && total > 0L) {
                "${VoiceMedia.formatDuration(state.positionMs.toLong())} / ${VoiceMedia.formatDuration(total)}"
            } else if (total > 0L) {
                VoiceMedia.formatDuration(total)
            } else {
                state.error ?: "Duration …"
            }
            waveform.progress = if (state.active && state.durationMs > 0) {
                state.positionMs.toFloat() / state.durationMs
            } else 0f
        }
        if (cachedDuration == null && voiceDurationLoading.add(key)) work({ VoiceMedia.durationMs(this, uri) }) { result ->
            voiceDurationLoading -= key
            val value = result.getOrDefault(0L)
            voiceDurationCache.put(key, value.takeIf { it > 0L } ?: UNKNOWN_VOICE_DURATION)
            if (value > 0L) probedDuration = value
            if (box.isAttachedToWindow) {
                duration.text = if (value > 0L) VoiceMedia.formatDuration(value) else "Duration unavailable"
            }
        }
        box.setOnLongClickListener {
            showVoiceMessageMenu(more, threadId, address, message, attachment)
            true
        }
        return box
    }

    private fun decodeMmsPreview(attachment: DeviceAttachment): Bitmap {
        val uri = Uri.parse(attachment.contentUri)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val boundsInput = contentResolver.openInputStream(uri)
            ?: error("Android could not open this MMS image.")
        boundsInput.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1440 || bounds.outHeight / sample > 1440) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
            ?: error("Android could not decode this MMS image.")
    }

    private fun decodeImage(uri: Uri, maximumDimension: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            ?: error("Android could not open this image.")
        var sample = 1
        while (bounds.outWidth / sample > maximumDimension || bounds.outHeight / sample > maximumDimension) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
            ?: error("Android could not decode this image.")
    }

    private fun decodeImage(file: File, maximumDimension: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        check(bounds.outWidth > 0 && bounds.outHeight > 0) { "Android could not read this background image." }
        var sample = 1
        while (bounds.outWidth / sample > maximumDimension || bounds.outHeight / sample > maximumDimension) sample *= 2
        return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: error("Android could not decode this background image.")
    }

    @Synchronized
    private fun importBackgroundPhoto(uri: Uri): File {
        val directory = File(filesDir, "appearance-backgrounds").apply { mkdirs() }
        val target = File(directory, "background-${System.currentTimeMillis()}.image")
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                target.outputStream().use(input::copyTo)
            } ?: error("Android could not open the selected background photo.")
            check(target.length() > 0L) { "The selected background photo is empty." }
            return target
        } catch (error: Throwable) {
            target.delete()
            throw error
        }
    }

    private fun removeUnusedBackgroundFiles(keep: File?) {
        val directory = File(filesDir, "appearance-backgrounds")
        directory.listFiles()?.forEach { file ->
            if (keep == null || file.absolutePath != keep.absolutePath) file.delete()
        }
    }

    private fun backgroundPhotoAvailable(value: AppearanceSettings): Boolean =
        value.backgroundFilePath?.let(::File)?.isFile == true || value.backgroundUri != null

    private fun backgroundPhotoName(value: AppearanceSettings): String =
        value.backgroundDisplayName?.takeIf(String::isNotBlank)
            ?: value.backgroundUri?.let(Uri::parse)?.lastPathSegment?.substringAfterLast('/')
            ?: "Background photo"

    private fun backgroundPhotoKey(value: AppearanceSettings): String? {
        val file = value.backgroundFilePath?.let(::File)?.takeIf(File::isFile)
        return file?.let { "${it.absolutePath}:${it.length()}:${it.lastModified()}" }
            ?: value.backgroundUri
    }

    @Synchronized
    private fun loadBackgroundBitmap(value: AppearanceSettings, maximumDimension: Int): Bitmap {
        val refreshed = UserSettings(this).appearance
        val storedPath = refreshed.backgroundFilePath ?: value.backgroundFilePath
        storedPath?.let(::File)?.takeIf(File::isFile)?.let { file ->
            runCatching { decodeImage(file, maximumDimension) }.getOrNull()?.let { return it }
        }
        val uri = value.backgroundUri?.let(Uri::parse)
            ?: error("No background photo is selected.")
        val imported = runCatching { importBackgroundPhoto(uri) }.getOrNull()
        if (imported != null) {
            val name = value.backgroundDisplayName ?: runCatching { displayName(uri) }.getOrDefault("Background photo")
            UserSettings(this).setBackgroundLocalCopy(imported.absolutePath, name)
            removeUnusedBackgroundFiles(imported)
            return decodeImage(imported, maximumDimension)
        }
        return decodeImage(uri, maximumDimension)
    }

    private fun displayName(uri: Uri): String {
        var name = uri.lastPathSegment.orEmpty()
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) name = cursor.getString(0).orEmpty().ifBlank { name }
        }
        return name.ifBlank { "Background photo" }
    }

    private fun openMmsAttachment(attachment: DeviceAttachment) {
        work({
            val file = DeviceMessageRepository(this).materializeAttachment(attachment)
            PduContentProvider.uriFor(this, file)
        }) { result ->
            result.fold(onSuccess = { uri ->
                runCatching {
                    startActivity(
                        Intent.createChooser(
                            Intent(Intent.ACTION_VIEW)
                                .setDataAndType(uri, attachment.mimeType)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),
                            "Open ${attachment.fileName}"
                        )
                    )
                }.onFailure { toast("No app can open this MMS attachment.") }
            }, onFailure = { toast(it.message ?: "Unable to open MMS attachment.") })
        }
    }

    private fun saveMmsAttachment(attachment: DeviceAttachment) {
        work({
            val fileName = attachment.fileName.replace(Regex("[\\r\\n/\\\\]+"), "_").ifBlank { "MMS-attachment" }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, attachment.mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Maclean Messaging")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val outputUri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: error("Android could not create the download.")
            try {
                val input = contentResolver.openInputStream(Uri.parse(attachment.contentUri))
                    ?: error("Android could not open this MMS attachment.")
                input.use { source ->
                    contentResolver.openOutputStream(outputUri, "w")?.use(source::copyTo)
                        ?: error("Android could not write the download.")
                }
                contentResolver.update(
                    outputUri,
                    ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) },
                    null,
                    null
                )
            } catch (error: Throwable) {
                contentResolver.delete(outputUri, null, null)
                throw error
            }
            "Downloads/Maclean Messaging/$fileName"
        }) { result ->
            result.fold(
                onSuccess = { toast("Saved as $it") },
                onFailure = { toast(it.message ?: "Unable to save MMS attachment.") }
            )
        }
    }

    private fun showInboxMenu(anchor: View) {
        val state = activeInboxState
        val actions = buildList {
            add(MenuAction("New SMS / MMS") { showMessageComposer("", "") })
            if (state?.emailEnabled == true) add(MenuAction("New email") {
                showEmailCompose(ComposeSeed(ComposeMode.NEW, null))
            })
            add(MenuAction("Contacts") { showContacts() })
            add(MenuAction("Drafts & scheduled Outbox") { showWorkflows() })
            add(MenuAction(if (inboxArchived) "Inbox" else "Archived conversations") { inboxArchived = !inboxArchived; showInbox() })
            add(MenuAction("Manage selected") {
                if (state == null) toast("Conversations are still loading.")
                else showInboxManagementMenu(anchor, null, state, visibleConversations(state.conversations))
            })
            add(MenuAction("Settings") { showSettings() })
        }
        showActions(anchor, actions)
    }

    private fun showInboxFilterMenu(
        anchor: View,
        screen: InboxListScreen,
        state: InboxState,
        transportFilters: List<String>
    ) {
        val actions = transportFilters.map { value ->
            MenuAction("Type · ${if (value == inboxFilter) "✓ " else ""}$value") {
                inboxFilter = value
                renderInbox(screen, state)
            }
        } + CONTACT_FILTER_OPTIONS.map { value ->
            MenuAction("Sender · ${if (value == inboxContactFilter) "✓ " else ""}$value") {
                inboxContactFilter = value
                renderInbox(screen, state)
            }
        }
        showActions(anchor, actions)
    }

    private fun showInboxManagementMenu(
        anchor: View,
        screen: InboxListScreen?,
        state: InboxState,
        visible: List<UnifiedConversation>
    ) {
        val refresh = {
            if (screen == null) showInbox() else renderInbox(screen, state)
        }
        showActions(anchor, listOf(
            MenuAction("Select shown") {
                visible.forEach { inboxSelected += it.stableId }
                refresh()
            },
            MenuAction("Clear selection") {
                inboxSelected.clear()
                refresh()
            },
            MenuAction("Mark selected as read") { markSelectedInboxConversationsRead(state) },
            MenuAction("Mark selected as unread") { markSelectedInboxConversationsUnread(state) },
            MenuAction("Forward selected") { manageConversations(state, ManagementAction.FORWARD) },
            MenuAction("Archive selected (in this app)") { changeConversationFlag(inboxSelected.toList(), "archived", true) },
            MenuAction("Unarchive selected") { changeConversationFlag(inboxSelected.toList(), "archived", false) },
            MenuAction("Pin selected") { changeConversationFlag(inboxSelected.toList(), "pinned", true) },
            MenuAction("Unpin selected") { changeConversationFlag(inboxSelected.toList(), "pinned", false) },
            MenuAction("Copy selected") { manageConversations(state, ManagementAction.COPY) },
            MenuAction("Download selected .txt") { manageConversations(state, ManagementAction.DOWNLOAD) },
            MenuAction("Delete selected") { manageConversations(state, ManagementAction.DELETE) }
        ))
    }

    private fun showDeviceThreadManagementMenu(
        anchor: View,
        threadId: Long,
        address: String,
        messages: List<DeviceMessage>
    ) {
        if (messages.isEmpty()) return toast("Messages are still loading.")
        val refresh = {
            activeDeviceAdapter?.notifyDataSetChanged()
            updateDeviceThreadControls()
        }
        showActions(anchor, listOf(
            MenuAction("Archive / pin conversation") { showConversationOrganization(anchor, "sms:$threadId") },
            MenuAction("Reply") { focusInlineReply() },
            MenuAction("Voice message") { focusInlineReply(voice = true) },
            MenuAction("Select loaded") {
                messages.forEach { deviceMessageSelected += it.stableId }
                refresh()
            },
            MenuAction("Clear selection") {
                deviceMessageSelected.clear()
                refresh()
            },
            MenuAction("Mark conversation as read") {
                markDeviceMessagesRead(threadId, address, messages, "Conversation marked as read.")
            },
            MenuAction("Mark conversation as unread") {
                markDeviceMessagesUnread(threadId, address, messages, "Conversation marked as unread.")
            },
            MenuAction("Mark selected as read") {
                markSelectedDeviceMessagesRead(threadId, address, messages)
            },
            MenuAction("Mark selected as unread") {
                markSelectedDeviceMessagesUnread(threadId, address, messages)
            },
            MenuAction("Forward selected") { manageDeviceMessages(threadId, address, messages, ManagementAction.FORWARD) },
            MenuAction("Copy selected") { manageDeviceMessages(threadId, address, messages, ManagementAction.COPY) },
            MenuAction("Download selected .txt") { manageDeviceMessages(threadId, address, messages, ManagementAction.DOWNLOAD) },
            MenuAction("Delete selected") { manageDeviceMessages(threadId, address, messages, ManagementAction.DELETE) }
        ))
    }

    private fun showDeviceMessageMenu(anchor: View, threadId: Long, address: String, message: DeviceMessage) {
        showActions(anchor, listOfNotNull(
            MenuAction(if (message.stableId in deviceMessageSelected) "Clear selection" else "Select") {
                if (message.stableId in deviceMessageSelected) deviceMessageSelected -= message.stableId
                else deviceMessageSelected += message.stableId
                activeDeviceAdapter?.notifyDataSetChanged()
                updateDeviceThreadControls()
            },
            MenuAction("Reply to this message") { showQuotedReply(address, message) },
            MenuAction("React (compatible text)") { showReactionPicker(address, message) },
            MenuAction("Forward") { forwardDeviceMessage(message) },
            if (!message.incoming) MenuAction("Resend / edit a copy…") { resendDeviceMessage(address, message) } else null,
            MenuAction("Mark as read") {
                markDeviceMessagesRead(threadId, address, listOf(message), "Message marked as read.")
            },
            MenuAction("Mark as unread") {
                markDeviceMessagesUnread(threadId, address, listOf(message), "Message marked as unread.")
            },
            MenuAction("Copy text") { manageDeviceMessage(threadId, address, message, ManagementAction.COPY) },
            MenuAction("Download .txt") { manageDeviceMessage(threadId, address, message, ManagementAction.DOWNLOAD) },
            MenuAction("Delete") { manageDeviceMessage(threadId, address, message, ManagementAction.DELETE) }
        ))
    }

    private fun showVoiceMessageMenu(
        anchor: View,
        threadId: Long,
        address: String,
        message: DeviceMessage,
        attachment: DeviceAttachment
    ) {
        val key = "voice:${message.stableId}:${attachment.partId}"
        val uri = Uri.parse(attachment.contentUri)
        showActions(anchor, listOf(
            MenuAction("Play / pause") { VoicePlaybackController.toggle(this, key, uri) },
            MenuAction("Save to device") { saveMmsAttachment(attachment) },
            MenuAction("Share") { shareVoiceMessage(attachment) },
            MenuAction("Forward") { forwardDeviceMessage(message) },
            MenuAction("Reply") { showQuotedReply(address, message) },
            MenuAction("React (compatible text)") { showReactionPicker(address, message) },
            MenuAction("Mark as read") {
                markDeviceMessagesRead(threadId, address, listOf(message), "Message marked as read.")
            },
            MenuAction("Mark as unread") {
                markDeviceMessagesUnread(threadId, address, listOf(message), "Message marked as unread.")
            },
            MenuAction("Delete") { manageDeviceMessage(threadId, address, message, ManagementAction.DELETE) },
            MenuAction("View details") { showVoiceDetails(message, attachment) }
        ))
    }

    private fun showQuotedReply(address: String, message: DeviceMessage) {
        val speaker = if (message.incoming) message.address.ifBlank { "sender" } else "my message"
        inlineReplyAddress = address
        focusInlineReply("↪ Reply to $speaker:\n“${messageExcerpt(message)}”\n\n")
    }

    private fun showReactionPicker(address: String, message: DeviceMessage) {
        val reactions = arrayOf("👍", "❤️", "😂", "😮", "😢", "👎")
        AlertDialog.Builder(this)
            .setTitle("React to message")
            .setMessage("Carrier SMS/MMS has no universal native reaction format. Maclean Messaging sends an interoperable text reaction you can review before sending.")
            .setItems(reactions) { _, which ->
                inlineReplyAddress = address
                focusInlineReply("${reactions[which]} to “${messageExcerpt(message)}”")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun messageExcerpt(message: DeviceMessage): String {
        val body = message.body
            .takeUnless { it.matches(Regex("\\[MMS(?: message| with .*attachments?)?]", RegexOption.IGNORE_CASE)) }
            ?.replace(Regex("\\s+"), " ")
            ?.trim()
            .orEmpty()
        val fallback = if (message.attachments.any(::isVoiceMessage)) "Voice message" else {
            message.attachments.firstOrNull()?.fileName ?: "Message"
        }
        return (body.ifBlank { fallback }).replace('“', '\'').replace('”', '\'').take(180)
    }

    private fun forwardDeviceMessage(message: DeviceMessage) {
        val body = message.body.takeUnless { it.startsWith("[MMS") }.orEmpty()
        if (message.attachments.isEmpty()) {
            showMessageComposer("", body)
            return
        }
        work({
            val repository = DeviceMessageRepository(this)
            message.attachments.map { attachment ->
                PduContentProvider.uriFor(this, repository.materializeAttachment(attachment))
            }
        }) { result ->
            result.fold(
                onSuccess = { uris -> showMessageComposer("", body, initialAttachments = uris) },
                onFailure = { toast(it.message ?: "Unable to prepare the message for forwarding.") }
            )
        }
    }

    private fun resendDeviceMessage(address: String, message: DeviceMessage) {
        if (message.incoming) return
        work({
            val repository = DeviceMessageRepository(this)
            message.attachments.map { PduContentProvider.uriFor(this, repository.materializeAttachment(it)) }
        }) { result -> result.fold(onSuccess = { uris ->
            showMessageComposer(message.address.ifBlank { address }, message.body.takeUnless { it.startsWith("[MMS") }.orEmpty(), initialAttachments = uris)
            toast("Review this copy and the sending SIM. Select Send now to resend; the original is kept.")
        }, onFailure = { toast(it.message ?: "Unable to prepare resend.") }) }
    }

    private fun shareVoiceMessage(attachment: DeviceAttachment) {
        work({
            val file = DeviceMessageRepository(this).materializeAttachment(attachment)
            PduContentProvider.uriFor(this, file)
        }) { result ->
            result.fold(onSuccess = { uri ->
                runCatching {
                    startActivity(Intent.createChooser(
                        Intent(Intent.ACTION_SEND).apply {
                            type = attachment.mimeType
                            putExtra(Intent.EXTRA_STREAM, uri)
                            clipData = ClipData.newUri(contentResolver, attachment.fileName, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        },
                        "Share voice message"
                    ))
                }.onFailure { toast("No app can share this voice message.") }
            }, onFailure = { toast(it.message ?: "Unable to prepare the voice message.") })
        }
    }

    private fun showVoiceDetails(message: DeviceMessage, attachment: DeviceAttachment) {
        work({ VoiceMedia.durationMs(this, Uri.parse(attachment.contentUri)) }) { result ->
            val bytes = attachment.sizeBytes?.let { "$it bytes" } ?: "Unknown"
            val duration = result.getOrDefault(0L).takeIf { it > 0L }?.let(VoiceMedia::formatDuration) ?: "Unknown"
            AlertDialog.Builder(this)
                .setTitle("Voice message details")
                .setMessage(
                    "File: ${attachment.fileName}\n" +
                        "Format: ${attachment.mimeType}\n" +
                        "Duration: $duration\n" +
                        "Size: $bytes\n" +
                        "Direction: ${if (message.incoming) "Received" else "Sent"}\n" +
                        "Contact: ${message.address}\n" +
                        "Date: ${formatDateTime(message.date)}"
                )
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun showEmailThreadManagementMenu(
        anchor: View,
        threadId: String,
        state: ThreadState?
    ) {
        if (state == null) return toast("Email is still loading.")
        val refresh = {
            activeEmailAdapter?.notifyDataSetChanged()
            updateEmailThreadControls()
        }
        val latest = state.messages.maxByOrNull(EmailMessageEntity::timestamp)
        val actions = buildList {
            add(MenuAction("Archive / pin conversation") { showConversationOrganization(anchor, "email:$threadId") })
            latest?.let { message -> add(MenuAction("Reply") { seedAndCompose(ComposeMode.REPLY, message.stableId) }) }
            add(MenuAction("Mark conversation as read") {
                markEmailMessagesRead(threadId, state.messages, "Conversation marked as read.")
            })
            add(MenuAction("Mark conversation as unread") {
                markEmailMessagesUnread(threadId, state.messages, "Conversation marked as unread.")
            })
            add(MenuAction("Select all") {
                state.messages.forEach { emailMessageSelected += it.stableId }
                refresh()
            })
            add(MenuAction("Clear selection") {
                emailMessageSelected.clear()
                refresh()
            })
            add(MenuAction("Mark selected as read") { markSelectedEmailMessagesRead(threadId, state) })
            add(MenuAction("Mark selected as unread") { markSelectedEmailMessagesUnread(threadId, state) })
            add(MenuAction("Forward selected") { manageEmailMessages(threadId, state, ManagementAction.FORWARD) })
            add(MenuAction("Copy selected") { manageEmailMessages(threadId, state, ManagementAction.COPY) })
            add(MenuAction("Download selected .txt") { manageEmailMessages(threadId, state, ManagementAction.DOWNLOAD) })
            add(MenuAction("Delete selected") { manageEmailMessages(threadId, state, ManagementAction.DELETE) })
        }
        showActions(anchor, actions)
    }

    private fun showConversationOrganization(anchor: View, id: String) {
        work({
            val stored = ComposeStore.get(this).flags()[id]
            val email = id.takeIf { it.startsWith("email:") }?.let { LocalDatabase.get(this).emailThreadDao().get(it.removePrefix("email:")) }
            (stored?.first ?: email?.archived ?: false) to (stored?.second ?: email?.pinned ?: false)
        }) { result -> result.fold(onSuccess = { (archived, pinned) ->
            if (!anchor.isAttachedToWindow) return@fold
            showActions(anchor, listOf(
                MenuAction(if (archived) "Unarchive — move to Inbox" else "Archive conversation (in this app)") { changeConversationFlag(listOf(id), "archived", !archived) },
                MenuAction(if (pinned) "Unpin conversation" else "Pin conversation") { changeConversationFlag(listOf(id), "pinned", !pinned) }
            ))
        }, onFailure = { toast(it.message ?: "Could not load conversation options.") }) }
    }

    private fun showEmailMessageMenu(anchor: View, threadId: String, message: EmailMessageEntity) {
        showActions(anchor, listOfNotNull(
            MenuAction(if (message.stableId in emailMessageSelected) "Clear selection" else "Select") {
                if (message.stableId in emailMessageSelected) emailMessageSelected -= message.stableId
                else emailMessageSelected += message.stableId
                activeEmailAdapter?.notifyDataSetChanged()
                updateEmailThreadControls()
            },
            MenuAction("Reply") { seedAndCompose(ComposeMode.REPLY, message.stableId) },
            MenuAction("Reply all") { seedAndCompose(ComposeMode.REPLY_ALL, message.stableId) },
            MenuAction("Forward") { seedAndCompose(ComposeMode.FORWARD, message.stableId) },
            if (!message.incoming) MenuAction("Resend / edit a copy…") { resendEmailMessage(message) } else null,
            MenuAction("Mark as read") {
                markEmailMessagesRead(threadId, listOf(message), "Email marked as read.")
            },
            MenuAction("Mark as unread") {
                markEmailMessagesUnread(threadId, listOf(message), "Email marked as unread.")
            },
            MenuAction("Copy text") { manageEmailMessage(threadId, message, ManagementAction.COPY) },
            MenuAction("Download .txt") { manageEmailMessage(threadId, message, ManagementAction.DOWNLOAD) },
            MenuAction("Delete") { manageEmailMessage(threadId, message, ManagementAction.DELETE) }
        ))
    }

    private fun resendEmailMessage(message: EmailMessageEntity) {
        if (message.incoming) return
        work({
            val original = ComposeStore.get(this).all().firstOrNull { it.resultToken == message.stableId && it.payload.kind == "EMAIL" }
            val files = LocalDatabase.get(this).emailAttachmentDao().forMessage(message.stableId)
            if (message.attachmentCount > files.size) error("Some original attachments are missing. Use a new email and reattach them before sending.")
            val payload = original?.payload?.copy(attachments = files.map { PduContentProvider.uriFor(this, File(it.localPath)).toString() })
                ?: ComposePayload(kind = "EMAIL", accountId = message.accountId, subject = message.subject.orEmpty(), body = message.bodyText,
                    attachments = files.map { PduContentProvider.uriFor(this, File(it.localPath)).toString() })
            payload to (original == null)
        }) { result -> result.fold(onSuccess = { (payload, historical) ->
            val record = ComposeRecord(UUID.randomUUID().toString(), 0, payload, "DRAFT", 0, System.currentTimeMillis(), null, null)
            if (!historical) openWorkflowCopy(record)
            else AlertDialog.Builder(this).setTitle("Review recipients before resending")
                .setMessage("This older sent email did not retain separate To, Cc and Bcc fields. Its previous recipient list is shown below for reference; re-enter recipients in the correct fields to avoid exposing Bcc addresses.\n\n${message.recipientsJson}")
                .setNegativeButton("Cancel", null).setPositiveButton("Open editable copy") { _, _ -> openWorkflow(record) }.show()
        }, onFailure = { toast(it.message ?: "Unable to prepare email resend.") }) }
    }

    private fun showThreadSortMenu(anchor: View, conversationKey: String, current: String, changed: () -> Unit) {
        showChoiceMenu(anchor, THREAD_SORT_OPTIONS, current) { selected ->
            UserSettings(this).setConversationSort(conversationKey, selected)
            changed()
        }
    }

    private fun showChoiceMenu(anchor: View, values: List<String>, current: String, selected: (String) -> Unit) {
        showActions(anchor, values.map { value ->
            MenuAction("${if (value == current) "✓ " else ""}$value") { selected(value) }
        })
    }

    private fun showActions(anchor: View, actions: List<MenuAction>) {
        PopupMenu(this, anchor).apply {
            actions.forEachIndexed { index, action -> menu.add(0, index, index, action.label) }
            setOnMenuItemClickListener { item ->
                actions.getOrNull(item.itemId)?.action?.invoke()
                true
            }
            show()
        }
    }

    private fun sortDeviceMessages(messages: List<DeviceMessage>, sort: String): List<DeviceMessage> = when (sort) {
        THREAD_NEWEST -> messages.sortedByDescending(DeviceMessage::date)
        THREAD_INCOMING -> messages.sortedWith(compareByDescending<DeviceMessage> { it.incoming }.thenBy(DeviceMessage::date))
        THREAD_SENT -> messages.sortedWith(compareBy<DeviceMessage> { it.incoming }.thenBy(DeviceMessage::date))
        THREAD_TEXT -> messages.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER, DeviceMessage::body).thenBy(DeviceMessage::date))
        else -> messages.sortedBy(DeviceMessage::date)
    }

    private fun sortEmailMessages(messages: List<EmailMessageEntity>, sort: String): List<EmailMessageEntity> = when (sort) {
        THREAD_NEWEST -> messages.sortedByDescending(EmailMessageEntity::timestamp)
        THREAD_INCOMING -> messages.sortedWith(compareByDescending<EmailMessageEntity> { it.incoming }.thenBy(EmailMessageEntity::timestamp))
        THREAD_SENT -> messages.sortedWith(compareBy<EmailMessageEntity> { it.incoming }.thenBy(EmailMessageEntity::timestamp))
        THREAD_TEXT -> messages.sortedWith(compareBy<EmailMessageEntity, String>(String.CASE_INSENSITIVE_ORDER) { it.subject.orEmpty() + " " + it.bodyText }
            .thenBy(EmailMessageEntity::timestamp))
        else -> messages.sortedBy(EmailMessageEntity::timestamp)
    }

    private fun visibleConversations(items: List<UnifiedConversation>): List<UnifiedConversation> {
        val query = inboxQuery.trim().lowercase(Locale.getDefault())
        val queryDigits = query.filter { it.isDigit() }
        val filtered = items.filter { item ->
            val transportMatches = when (inboxFilter) {
                FILTER_DEVICE -> item.transport != CommunicationTransport.EMAIL
                FILTER_EMAIL -> item.transport == CommunicationTransport.EMAIL
                else -> true
            }
            val contactMatches = when (inboxContactFilter) {
                CONTACT_SAVED -> item.hasSavedContact
                CONTACT_UNKNOWN -> !item.hasSavedContact
                else -> true
            }
            val fields = buildList {
                add(item.title)
                add(item.preview)
                item.participants.forEach {
                    add(it.address)
                    it.displayName?.let(::add)
                }
            }
            val textMatches = query.isBlank() || fields.any { it.lowercase(Locale.getDefault()).contains(query) }
            val phoneMatches = queryDigits.isNotBlank() && item.participants.any {
                it.address.filter(Char::isDigit).contains(queryDigits)
            }
            item.archived == inboxArchived && transportMatches && contactMatches && (textMatches || phoneMatches)
        }
        return when (inboxSort) {
            SORT_OLDEST -> filtered.sortedWith(
                compareByDescending<UnifiedConversation> { it.pinned }.thenBy(UnifiedConversation::timestamp)
            )
            SORT_ADDRESS_ASC -> filtered.sortedWith(
                compareByDescending<UnifiedConversation> { it.pinned }.thenBy(String.CASE_INSENSITIVE_ORDER) { it.title }
            )
            SORT_ADDRESS_DESC -> filtered.sortedWith(
                compareByDescending<UnifiedConversation> { it.pinned }.thenByDescending { it.title.lowercase(Locale.getDefault()) }
            )
            SORT_MESSAGE_ASC -> filtered.sortedWith(
                compareByDescending<UnifiedConversation> { it.pinned }.thenBy(String.CASE_INSENSITIVE_ORDER) { it.preview }
            )
            SORT_UNREAD -> filtered.sortedWith(
                compareByDescending<UnifiedConversation> { it.pinned }
                    .thenByDescending { it.unreadCount > 0 }
                    .thenByDescending(UnifiedConversation::timestamp)
            )
            SORT_DEVICE_FIRST -> filtered.sortedWith(
                compareByDescending<UnifiedConversation> { it.pinned }
                    .thenBy { it.transport == CommunicationTransport.EMAIL }
                    .thenByDescending(UnifiedConversation::timestamp)
            )
            SORT_EMAIL_FIRST -> filtered.sortedWith(
                compareByDescending<UnifiedConversation> { it.pinned }
                    .thenByDescending { it.transport == CommunicationTransport.EMAIL }
                    .thenByDescending(UnifiedConversation::timestamp)
            )
            SORT_CONTACTS_FIRST -> filtered.sortedWith(
                compareByDescending<UnifiedConversation> { it.pinned }
                    .thenByDescending(UnifiedConversation::hasSavedContact)
                    .thenByDescending(UnifiedConversation::timestamp)
            )
            SORT_UNKNOWN_FIRST -> filtered.sortedWith(
                compareByDescending<UnifiedConversation> { it.pinned }
                    .thenBy(UnifiedConversation::hasSavedContact)
                    .thenByDescending(UnifiedConversation::timestamp)
            )
            else -> filtered.sortedWith(
                compareByDescending<UnifiedConversation> { it.pinned }.thenByDescending(UnifiedConversation::timestamp)
            )
        }
    }

    private fun markSelectedInboxConversationsRead(state: InboxState) {
        val selected = state.conversations.filter { it.stableId in inboxSelected }
        if (selected.isEmpty()) return toast("Select at least one conversation.")
        markInboxConversationsRead(selected)
    }

    private fun markSelectedInboxConversationsUnread(state: InboxState) {
        val selected = state.conversations.filter { it.stableId in inboxSelected }
        if (selected.isEmpty()) return toast("Select at least one conversation.")
        markInboxConversationsUnread(selected)
    }

    private fun markInboxConversationsRead(conversations: List<UnifiedConversation>) =
        setInboxConversationsUnread(conversations, unread = false)

    private fun markInboxConversationsUnread(conversations: List<UnifiedConversation>) =
        setInboxConversationsUnread(conversations, unread = true)

    private fun setInboxConversationsUnread(
        conversations: List<UnifiedConversation>,
        unread: Boolean
    ) {
        if (conversations.isEmpty()) return
        work({
            val emailIds = mutableListOf<String>()
            val system = SystemMessageRepository(this)
            val database = LocalDatabase.get(this)
            conversations.forEach { conversation ->
                if (conversation.transport == CommunicationTransport.EMAIL) {
                    val threadId = conversation.stableId.removePrefix("email:")
                    emailIds += database.emailMessageDao().forThread(threadId)
                        .filter { it.unread != unread }
                        .map(EmailMessageEntity::stableId)
                } else {
                    val threadId = requireNotNull(conversation.stableId.removePrefix("sms:").toLongOrNull())
                    if (unread) system.markThreadUnread(threadId) else system.markThreadRead(threadId)
                }
            }
            if (emailIds.isNotEmpty()) {
                EmailActionService(this).setUnread(emailIds, unread).getOrThrow()
            }
        }) { result ->
            result.fold(
                onSuccess = {
                    val ids = conversations.mapTo(mutableSetOf(), UnifiedConversation::stableId)
                    inboxSelected.removeAll(ids)
                    if (!unread) {
                        conversations.filter { it.transport != CommunicationTransport.EMAIL }
                            .flatMap(UnifiedConversation::participants)
                            .map(UnifiedParticipant::address)
                            .filter(String::isNotBlank)
                            .distinct()
                            .forEach { MessageNotifier.cancel(this, it) }
                    }
                    activeInboxState = null
                    toast(
                        if (conversations.size == 1) "Conversation marked as ${if (unread) "unread" else "read"}."
                        else "${conversations.size} conversations marked as ${if (unread) "unread" else "read"}."
                    )
                    if (currentPage == PAGE_INBOX) showInbox()
                },
                onFailure = {
                    activeInboxState = null
                    toast(it.message ?: "Some read-state changes may not have completed.")
                    if (currentPage == PAGE_INBOX) showInbox()
                }
            )
        }
    }

    private fun markSelectedDeviceMessagesRead(
        threadId: Long,
        address: String,
        messages: List<DeviceMessage>
    ) {
        val selected = messages.filter { it.stableId in deviceMessageSelected }
        if (selected.isEmpty()) return toast("Select at least one message.")
        markDeviceMessagesRead(
            threadId,
            address,
            selected,
            "${selected.size} selected message${if (selected.size == 1) "" else "s"} marked as read."
        )
    }

    private fun markSelectedDeviceMessagesUnread(
        threadId: Long,
        address: String,
        messages: List<DeviceMessage>
    ) {
        val selected = messages.filter { it.stableId in deviceMessageSelected }
        if (selected.isEmpty()) return toast("Select at least one message.")
        markDeviceMessagesUnread(
            threadId,
            address,
            selected,
            "${selected.size} selected message${if (selected.size == 1) "" else "s"} marked as unread."
        )
    }

    private fun markDeviceMessagesRead(
        threadId: Long,
        address: String,
        messages: List<DeviceMessage>,
        successMessage: String
    ) = setDeviceMessagesReadState(threadId, address, messages, read = true, successMessage = successMessage)

    private fun markDeviceMessagesUnread(
        threadId: Long,
        address: String,
        messages: List<DeviceMessage>,
        successMessage: String
    ) = setDeviceMessagesReadState(threadId, address, messages, read = false, successMessage = successMessage)

    private fun setDeviceMessagesReadState(
        threadId: Long,
        address: String,
        messages: List<DeviceMessage>,
        read: Boolean,
        successMessage: String
    ) {
        if (messages.isEmpty()) return toast("No messages are available to mark as ${if (read) "read" else "unread"}.")
        work({
            val repository = DeviceMessageRepository(this)
            if (read) repository.markRead(messages) else repository.markUnread(messages)
        }) { result ->
            result.fold(
                onSuccess = {
                    val ids = messages.mapTo(mutableSetOf(), DeviceMessage::stableId)
                    deviceMessageSelected.removeAll(ids)
                    if (currentPage == PAGE_THREAD && activeDeviceThreadId == threadId) {
                        activeDeviceMessages = activeDeviceMessages.map { message ->
                            if (message.stableId in ids) message.copy(read = read) else message
                        }
                        activeDeviceAdapter?.submit(activeDeviceMessages, activeDeviceSort)
                        updateDeviceThreadControls()
                        if (read && activeDeviceMessages.none { !it.read } && address.isNotBlank()) {
                            MessageNotifier.cancel(this, address)
                        }
                    }
                    toast(successMessage)
                },
                onFailure = { toast(it.message ?: "Unable to mark the message as ${if (read) "read" else "unread"}.") }
            )
        }
    }

    private fun markSelectedEmailMessagesRead(threadId: String, state: ThreadState) {
        val selected = state.messages.filter { it.stableId in emailMessageSelected }
        if (selected.isEmpty()) return toast("Select at least one email.")
        markEmailMessagesRead(
            threadId,
            selected,
            "${selected.size} selected email${if (selected.size == 1) "" else "s"} marked as read."
        )
    }

    private fun markSelectedEmailMessagesUnread(threadId: String, state: ThreadState) {
        val selected = state.messages.filter { it.stableId in emailMessageSelected }
        if (selected.isEmpty()) return toast("Select at least one email.")
        markEmailMessagesUnread(
            threadId,
            selected,
            "${selected.size} selected email${if (selected.size == 1) "" else "s"} marked as unread."
        )
    }

    private fun markEmailMessagesRead(
        threadId: String,
        messages: List<EmailMessageEntity>,
        successMessage: String
    ) = setEmailMessagesReadState(threadId, messages, unread = false, successMessage = successMessage)

    private fun markEmailMessagesUnread(
        threadId: String,
        messages: List<EmailMessageEntity>,
        successMessage: String
    ) = setEmailMessagesReadState(threadId, messages, unread = true, successMessage = successMessage)

    private fun setEmailMessagesReadState(
        threadId: String,
        messages: List<EmailMessageEntity>,
        unread: Boolean,
        successMessage: String
    ) {
        if (messages.isEmpty()) return toast("No emails are available to mark as ${if (unread) "unread" else "read"}.")
        work({
            EmailActionService(this).setUnread(messages.map(EmailMessageEntity::stableId), unread).getOrThrow()
        }) { result ->
            result.fold(
                onSuccess = {
                    val ids = messages.mapTo(mutableSetOf(), EmailMessageEntity::stableId)
                    emailMessageSelected.removeAll(ids)
                    if (currentPage == PAGE_THREAD && activeEmailThreadId == threadId) {
                        activeEmailState?.let { current ->
                            val updated = ThreadState(
                                current.messages.map { message ->
                                    if (message.stableId in ids) message.copy(unread = unread) else message
                                },
                                current.attachments
                            )
                            activeEmailState = updated
                            activeEmailAdapter?.submit(updated, activeEmailSort)
                            updateEmailThreadControls()
                        }
                    }
                    toast(successMessage)
                },
                onFailure = { toast(it.message ?: "Unable to mark the email as ${if (unread) "unread" else "read"}.") }
            )
        }
    }

    private fun manageConversation(item: UnifiedConversation, action: ManagementAction) {
        if (action == ManagementAction.DELETE) {
            val prompt = if (item.transport == CommunicationTransport.EMAIL) {
                "Permanently delete this email conversation from the mail server and this device?"
            } else {
                "Delete this conversation from this device?"
            }
            confirmDelete(prompt) {
                work({ deleteConversation(item) }) { result ->
                    if (result.isSuccess) {
                        inboxSelected -= item.stableId
                        activeInboxState = null
                        toast("Conversation deleted.")
                        showInbox()
                    } else toast(result.exceptionOrNull()?.message ?: "Unable to delete conversation.")
                }
            }
            return
        }
        work({ conversationText(item) }) { result ->
            result.fold(
                onSuccess = { finishTextAction(action, item.title, it, item.accountId) },
                onFailure = { toast(it.message ?: "Unable to read conversation.") }
            )
        }
    }

    private fun manageConversations(state: InboxState, action: ManagementAction) {
        val selected = state.conversations.filter { it.stableId in inboxSelected }
        if (selected.isEmpty()) return toast("Select at least one conversation.")
        if (action == ManagementAction.DELETE) {
            val includesEmail = selected.any { it.transport == CommunicationTransport.EMAIL }
            val prompt = if (includesEmail) {
                "Delete ${selected.size} selected conversation${if (selected.size == 1) "" else "s"}? Email messages will also be permanently deleted from their mail servers."
            } else {
                "Delete ${selected.size} selected conversation${if (selected.size == 1) "" else "s"} from this device?"
            }
            confirmDelete(prompt) {
                work({
                    for (conversation in selected) deleteConversation(conversation)
                }) { result ->
                    if (result.isSuccess) {
                        inboxSelected.clear()
                        activeInboxState = null
                        toast("Selected conversations deleted.")
                        showInbox()
                    } else toast(result.exceptionOrNull()?.message ?: "Unable to delete selected conversations.")
                }
            }
            return
        }
        work({
            selected.joinToString("\n\n================================\n\n") { conversationText(it) }
        }) { result ->
            result.fold(
                onSuccess = { finishTextAction(action, "Selected conversations", it, selected.firstNotNullOfOrNull(UnifiedConversation::accountId)) },
                onFailure = { toast(it.message ?: "Unable to read selected conversations.") }
            )
        }
    }

    private suspend fun deleteConversation(item: UnifiedConversation) {
        if (item.transport == CommunicationTransport.EMAIL) {
            EmailActionService(this).deleteThread(item.stableId.removePrefix("email:")).getOrThrow()
        } else {
            val threadId = requireNotNull(item.stableId.removePrefix("sms:").toLongOrNull())
            DeviceMessageRepository(this).deleteThread(threadId)
        }
    }

    private fun conversationText(item: UnifiedConversation): String {
        val heading = "${item.title}\n${formatDateTime(item.timestamp)}"
        val messages = if (item.transport == CommunicationTransport.EMAIL) {
            formatEmailMessages(LocalDatabase.get(this).emailMessageDao().forThread(item.stableId.removePrefix("email:")))
        } else {
            val threadId = requireNotNull(item.stableId.removePrefix("sms:").toLongOrNull())
            formatDeviceMessages(DeviceMessageRepository(this).thread(threadId))
        }
        return "$heading\n\n$messages"
    }

    private fun manageDeviceMessage(
        threadId: Long,
        address: String,
        message: DeviceMessage,
        action: ManagementAction
    ) {
        if (action == ManagementAction.DELETE) {
            confirmDelete("Delete this ${message.transport.name} message from this device?") {
                work({ DeviceMessageRepository(this).delete(message) }) { result ->
                    if (result.isSuccess) {
                        deviceMessageSelected -= message.stableId
                        toast("Message deleted.")
                        showSmsThread(threadId, address)
                    } else toast(result.exceptionOrNull()?.message ?: "Unable to delete message.")
                }
            }
        } else {
            finishTextAction(action, "${message.transport.name} message", formatDeviceMessages(listOf(message)), null)
        }
    }

    private fun manageDeviceMessages(
        threadId: Long,
        address: String,
        messages: List<DeviceMessage>,
        action: ManagementAction
    ) {
        val selected = messages.filter { it.stableId in deviceMessageSelected }
        if (selected.isEmpty()) return toast("Select at least one message.")
        if (action == ManagementAction.DELETE) {
            confirmDelete("Delete ${selected.size} selected message${if (selected.size == 1) "" else "s"} from this device?") {
                work({
                    val repository = DeviceMessageRepository(this)
                    selected.forEach(repository::delete)
                }) { result ->
                    if (result.isSuccess) {
                        deviceMessageSelected.clear()
                        toast("Selected messages deleted.")
                        showSmsThread(threadId, address)
                    } else toast(result.exceptionOrNull()?.message ?: "Unable to delete selected messages.")
                }
            }
        } else {
            finishTextAction(action, "Selected messages", formatDeviceMessages(selected), null)
        }
    }

    private fun manageEmailMessage(threadId: String, message: EmailMessageEntity, action: ManagementAction) {
        if (action == ManagementAction.DELETE) {
            confirmDelete("Permanently delete this email from the mail server and this device?") {
                work({ EmailActionService(this).deleteMessages(listOf(message.stableId)).getOrThrow() }) { result ->
                    if (result.isSuccess) {
                        emailMessageSelected -= message.stableId
                        toast("Email deleted from the mail server and this device.")
                        showEmailThread(threadId)
                    } else toast(result.exceptionOrNull()?.message ?: "Unable to delete email.")
                }
            }
        } else {
            finishTextAction(action, message.subject ?: "Email message", formatEmailMessages(listOf(message)), message.accountId)
        }
    }

    private fun manageEmailMessages(threadId: String, state: ThreadState, action: ManagementAction) {
        val selected = state.messages.filter { it.stableId in emailMessageSelected }
        if (selected.isEmpty()) return toast("Select at least one email.")
        if (action == ManagementAction.DELETE) {
            confirmDelete("Permanently delete ${selected.size} selected email${if (selected.size == 1) "" else "s"} from the mail server and this device?") {
                work({
                    EmailActionService(this).deleteMessages(selected.map(EmailMessageEntity::stableId)).getOrThrow()
                }) { result ->
                    if (result.isSuccess) {
                        emailMessageSelected.clear()
                        toast("Selected emails deleted from the mail server and this device.")
                        showEmailThread(threadId)
                    } else toast(result.exceptionOrNull()?.message ?: "Unable to delete selected emails.")
                }
            }
        } else {
            finishTextAction(action, "Selected emails", formatEmailMessages(selected), selected.first().accountId)
        }
    }

    private fun finishTextAction(
        action: ManagementAction,
        title: String,
        value: String,
        accountId: String?
    ) {
        when (action) {
            ManagementAction.COPY -> copyText(title, value)
            ManagementAction.DOWNLOAD -> work({ saveTextFile(title, value) }) { result ->
                result.fold(
                    onSuccess = { toast("Saved as $it") },
                    onFailure = { toast(it.message ?: "Unable to save text file.") }
                )
            }
            ManagementAction.FORWARD -> chooseForwardTarget(title, value, accountId)
            ManagementAction.DELETE -> Unit
        }
    }

    private fun chooseForwardTarget(title: String, value: String, accountId: String?) {
        work({ LocalDatabase.get(this).emailAccountDao().enabled() }) { result ->
            val accounts = result.getOrDefault(emptyList())
            val options = buildList {
                add("SMS/MMS")
                if (accounts.isNotEmpty()) add("Email")
            }
            AlertDialog.Builder(this)
                .setTitle("Forward using")
                .setItems(options.toTypedArray()) { _, which ->
                    if (options[which] == "Email") {
                        val from = accounts.firstOrNull { it.id == accountId }?.id
                            ?: accounts.firstOrNull { it.isDefaultSendAccount }?.id
                            ?: accounts.first().id
                        showEmailCompose(ComposeSeed(
                            mode = ComposeMode.NEW,
                            accountId = from,
                            subject = if (title.startsWith("Fwd:", true)) title else "Fwd: $title",
                            body = value
                        ))
                    } else {
                        showMessageComposer("", value)
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun formatDeviceMessages(messages: List<DeviceMessage>): String =
        messages.sortedBy(DeviceMessage::date).joinToString("\n\n") { message ->
            val direction = if (message.incoming) "From" else "To"
            val attachments = message.attachments.takeIf(List<DeviceAttachment>::isNotEmpty)
                ?.joinToString("\n", prefix = "\n\nAttachments:\n") {
                    "- ${it.fileName} (${it.mimeType}${it.sizeBytes?.let { size -> ", $size bytes" }.orEmpty()})"
                }.orEmpty()
            "${message.transport.name} $direction: ${message.address}\nDate: ${formatDateTime(message.date)}\n\n${message.body}$attachments"
        }

    private fun formatEmailMessages(messages: List<EmailMessageEntity>): String =
        messages.sortedBy(EmailMessageEntity::timestamp).joinToString("\n\n") { message ->
            val recipients = parseRecipientJson(message.recipientsJson).joinToString(", ")
            "From: ${message.sender}\nTo: $recipients\nSubject: ${message.subject.orEmpty()}\nDate: ${formatDateTime(message.timestamp)}\n\n${message.bodyText}"
        }

    private fun parseRecipientJson(value: String): List<String> = runCatching {
        val array = JSONArray(value)
        (0 until array.length()).map { array.getString(it) }
    }.getOrDefault(emptyList())

    private fun copyText(label: String, value: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText(label, value))
        toast("Copied to clipboard.")
    }

    private fun pasteInto(field: EditText) {
        val clipboard = getSystemService(ClipboardManager::class.java)
        val value = clipboard.primaryClip?.takeIf { it.itemCount > 0 }
            ?.getItemAt(0)?.coerceToText(this)?.toString()
        if (value.isNullOrEmpty()) return toast("The clipboard has no text to paste.")
        val start = field.selectionStart.coerceAtLeast(0)
        field.text.insert(start, value)
    }

    private fun saveTextFile(title: String, value: String): String {
        val safeTitle = title.replace(Regex("[^A-Za-z0-9._-]+"), "-").trim('-').take(48).ifBlank { "messages" }
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val name = "Maclean-Messaging-$safeTitle-$stamp.txt"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Maclean Messaging")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Android could not create the download.")
        try {
            contentResolver.openOutputStream(uri, "w")?.use { it.write(value.toByteArray(Charsets.UTF_8)) }
                ?: error("Android could not open the download.")
            contentResolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
        } catch (error: Throwable) {
            contentResolver.delete(uri, null, null)
            throw error
        }
        return "Downloads/Maclean Messaging/$name"
    }

    private fun confirmDelete(message: String, confirmed: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle("Confirm deletion")
            .setMessage(message)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ -> confirmed() }
            .show()
    }

    private fun selectionBox(label: String, checked: Boolean, changed: (Boolean) -> Unit): CheckBox =
        CheckBox(this).apply {
            text = label
            typeface = appTypeface()
            isChecked = checked
            setTextColor(readableTextColor())
            minHeight = dp(regularControlHeight())
            setOnCheckedChangeListener { _, value -> changed(value) }
        }

    private fun settingsCheckBox(label: String, checked: Boolean): CheckBox = CheckBox(this).apply {
        text = label
        typeface = appTypeface()
        isChecked = checked
        setTextColor(readableTextColor())
        minHeight = dp(regularControlHeight())
        buttonTintList = ColorStateList.valueOf(if (appearance.highContrast) Color.WHITE else appearance.accentColor)
    }

    private fun screen(
        title: String,
        onBack: (() -> Unit)? = null,
        onMenu: ((View) -> Unit)? = null
    ): LinearLayout {
        prepareScreen()
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                dp(screenHorizontalPadding()),
                dp(screenVerticalPadding()),
                dp(screenHorizontalPadding()),
                dp(24)
            )
            setBackgroundColor(Color.TRANSPARENT)
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.TRANSPARENT)
            addView(content)
        }
        installScreen(title, onBack, onMenu, scroll)
        return content
    }

    /** Recycles inbox rows so hundreds of conversations never become hundreds of live view trees. */
    private fun recycledInboxScreen(
        title: String,
        onMenu: ((View) -> Unit)? = null
    ): InboxListScreen {
        prepareScreen()
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                dp(screenHorizontalPadding()),
                dp(screenVerticalPadding().coerceAtLeast(6)),
                dp(screenHorizontalPadding()),
                0
            )
            setBackgroundColor(Color.TRANSPARENT)
        }
        val list = ListView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            cacheColorHint = Color.TRANSPARENT
            divider = null
            isVerticalScrollBarEnabled = true
            clipToPadding = false
            setPadding(dp(screenHorizontalPadding()), dp(2), dp(screenHorizontalPadding()), dp(24))
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.TRANSPARENT)
            addView(controls, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
            addView(list, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            ))
        }
        installScreen(title, null, onMenu, body)
        return InboxListScreen(controls, list)
    }

    private fun recycledListScreen(
        title: String,
        onBack: (() -> Unit)? = null,
        onMenu: ((View) -> Unit)? = null
    ): ThreadListScreen {
        prepareScreen()
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                dp(screenHorizontalPadding()),
                dp(screenVerticalPadding().coerceAtLeast(6)),
                dp(screenHorizontalPadding()),
                dp(2)
            )
            setBackgroundColor(Color.TRANSPARENT)
        }
        val list = ListView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            cacheColorHint = Color.TRANSPARENT
            divider = null
            isVerticalScrollBarEnabled = true
            clipToPadding = false
            setPadding(dp(screenHorizontalPadding()), dp(2), dp(screenHorizontalPadding()), dp(24))
        }
        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                dp(screenHorizontalPadding()),
                0,
                dp(screenHorizontalPadding()),
                dp(screenVerticalPadding().coerceAtLeast(6))
            )
            setBackgroundColor(Color.TRANSPARENT)
        }
        val topReply = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                dp(screenHorizontalPadding()),
                0,
                dp(screenHorizontalPadding()),
                0
            )
            setBackgroundColor(Color.TRANSPARENT)
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.TRANSPARENT)
            addView(topReply, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
            addView(controls, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
            addView(list, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            ))
            addView(footer, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        }
        installScreen(title, onBack, onMenu, body)
        return ThreadListScreen(controls, list, topReply, footer)
    }

    private fun prepareScreen() {
        draftHandler.removeCallbacks(autosave)
        composeSnapshot = null
        activeDraftId = null
        composeBody = null
        composeStatus = null
        composeContainer = null
        composeBusy = false
        inlineReplyThreadId = null
        inlineReplyAddress = ""
        inlineReplyBody = null
        inlineVoicePanel = null
        activeVoiceRecorder?.cancel()
        activeVoiceRecorder = null
        pendingVoiceDraft?.let { draft ->
            VoicePlaybackController.stopIfKey("draft:${draft.file.absolutePath}")
            draft.file.delete()
        }
        pendingVoiceDraft = null
        voicePermissionStatus = null
        appearance = UserSettings(this).appearance
        threadScreenGeneration++
        activeDeviceAdapter = null
        activeDeviceList = null
        activeDeviceStatus = null
        activeInboxAdapter = null
        activeEmailAdapter = null
        activeEmailStatus = null
        emailAttachmentsLoading.clear()
    }

    private fun installScreen(
        title: String,
        onBack: (() -> Unit)?,
        onMenu: ((View) -> Unit)?,
        body: View
    ) {
        window.statusBarColor = Color.WHITE
        window.decorView.systemUiVisibility =
            window.decorView.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        val backgroundColor = if (appearance.highContrast) Color.BLACK else backgroundWithStrength(
            appearance.backgroundColor,
            appearance.backgroundOpacity
        )
        window.navigationBarColor = backgroundColor
        val root = FrameLayout(this).apply {
            setBackgroundColor(backgroundColor)
        }
        if (!appearance.highContrast && appearance.useBackgroundPhoto && backgroundPhotoAvailable(appearance)) {
            val backgroundImage = ImageView(this).apply {
                contentDescription = null
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                scaleType = ImageView.ScaleType.CENTER_CROP
                alpha = appearance.backgroundOpacity / 100f
            }
            root.addView(backgroundImage, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ))
            val key = backgroundPhotoKey(appearance)
            if (key != null && key == cachedBackgroundKey && cachedBackgroundBitmap != null) {
                backgroundImage.setImageBitmap(cachedBackgroundBitmap)
            } else work({ loadBackgroundBitmap(appearance, 2048) }) { result ->
                result.onSuccess { bitmap ->
                    cachedBackgroundKey = key
                    cachedBackgroundBitmap = bitmap
                    if (backgroundImage.isAttachedToWindow) backgroundImage.setImageBitmap(bitmap)
                }
            }
        }
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.TRANSPARENT)
        }
        val safeArea = View(this).apply { setBackgroundColor(Color.WHITE) }
        outer.addView(safeArea, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= 35) statusBarHeight() + dp(4) else dp(4)
        ))
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(
                dp(if (isSleekDisplay()) 10 else 6),
                dp(if (isSleekDisplay()) 6 else 4),
                dp(if (isSleekDisplay()) 10 else 6),
                dp(if (isSleekDisplay()) 6 else 4)
            )
            setBackgroundColor(if (appearance.highContrast) Color.BLACK else appearance.accentColor)
            elevation = if (appearance.display.showElevation) dp(4).toFloat() else 0f
        }
        if (onBack != null) toolbar.addView(toolbarButton("‹", "Back") { onBack() })
        toolbar.addView(TextView(this).apply {
            text = title
            textSize = (if (isSleekDisplay()) 19f else 20f) * appearance.textScale
            typeface = appTypeface(isSleekDisplay())
            setTextColor(Color.WHITE)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(8), dp(5), dp(6), dp(5))
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (onMenu != null) toolbar.addView(toolbarButton("⋮", "Page menu") { view -> onMenu(view) })
        outer.addView(toolbar)
        outer.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(outer, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener { _, insets ->
                val statusHeight = insets.getInsets(WindowInsets.Type.statusBars()).top
                val requestedHeight = statusHeight.coerceAtLeast(statusBarHeight()) + dp(4)
                if (safeArea.layoutParams.height != requestedHeight) {
                    safeArea.layoutParams = safeArea.layoutParams.apply { height = requestedHeight }
                }
                val keyboardBottom = insets.getInsets(WindowInsets.Type.ime()).bottom
                val navigationBottom = insets.getInsets(WindowInsets.Type.navigationBars()).bottom
                val requestedBottom = maxOf(keyboardBottom, navigationBottom)
                if (outer.paddingBottom != requestedBottom) {
                    outer.setPadding(0, 0, 0, requestedBottom)
                }
                insets
            }
            root.requestApplyInsets()
        }
        setContentView(root)
    }

    private fun panel(): ShapeContourLayout = ShapeContourLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        configureContour(
            appearance.display.cardShape,
            dp(panelHorizontalPadding()),
            dp(panelVerticalPadding())
        )
        background = surfaceDrawable(
            color = panelSurfaceColor(),
            shape = appearance.display.cardShape,
            outlined = appearance.display.showOutlines,
            opacityPercent = appearance.textWindowOpacity
        )
        elevation = if (appearance.display.showElevation) dp(if (isSleekDisplay()) 3 else 2).toFloat() else 0f
        clipToOutline = true
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, dp(panelGap()), 0, dp(panelGap()))
        }
    }

    private fun section(value: String): TextView = text(value, 19f, bold = true).apply {
        setPadding(0, dp(if (appearance.display.spacing == DISPLAY_SPACING_COMPACT) 14 else 18), 0, dp(5))
    }

    private fun text(value: String, size: Float = 15f, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size * appearance.textScale
        typeface = appTypeface(bold)
        setTextColor(readableTextColor())
        setHorizontallyScrolling(false)
        breakStrategy = Layout.BREAK_STRATEGY_HIGH_QUALITY
        hyphenationFrequency = Layout.HYPHENATION_FREQUENCY_NORMAL
        val inset = if (appearance.display.spacing == DISPLAY_SPACING_COMPACT) 2 else 3
        setPadding(dp(inset), dp(inset), dp(inset), dp(inset))
    }

    private fun errorText(value: String): TextView = text(value, 13f).apply { setTextColor(Color.rgb(190, 25, 25)) }

    private fun button(label: String, match: Boolean = false, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 14f * appearance.textScale
        typeface = appTypeface()
        isAllCaps = false
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            if (match) ViewGroup.LayoutParams.MATCH_PARENT else ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(0, dp(controlGap()), 0, dp(controlGap())) }
        minimumHeight = dp(regularControlHeight())
        minHeight = dp(regularControlHeight())
        backgroundTintList = null
        background = controlBackground(primary = false)
        elevation = controlElevation()
        setTextColor(readableTextColor())
    }

    private fun primaryButton(label: String, onClick: () -> Unit): GestureButton = GestureButton(this).apply {
        text = label
        textSize = 13f * appearance.textScale
        typeface = appTypeface(bold = true)
        isAllCaps = false
        minimumHeight = dp(compactControlHeight().coerceAtLeast(40))
        minHeight = dp(compactControlHeight().coerceAtLeast(40))
        minWidth = 0
        setPadding(dp(12), 0, dp(12), 0)
        backgroundTintList = null
        background = controlBackground(primary = true)
        elevation = controlElevation()
        setTextColor(if (appearance.highContrast) Color.BLACK else contrastingText(appearance.accentColor))
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, dp(controlGap()), 0, dp(controlGap()))
        }
    }

    private fun compactButton(label: String, onClick: (View) -> Unit): Button = Button(this).apply {
        text = label
        textSize = 12f * appearance.textScale
        typeface = appTypeface()
        isAllCaps = false
        minimumHeight = dp(compactControlHeight())
        minHeight = dp(compactControlHeight())
        minWidth = 0
        setPadding(dp(9), 0, dp(9), 0)
        backgroundTintList = null
        background = controlBackground(primary = false)
        elevation = controlElevation()
        setTextColor(readableTextColor())
        setOnClickListener(onClick)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, dp(controlGap()), 0, dp(controlGap()))
        }
    }

    private fun smallButton(label: String, description: String, onClick: (View) -> Unit): Button = Button(this).apply {
        text = label
        contentDescription = description
        textSize = 18f * appearance.textScale
        typeface = appTypeface()
        isAllCaps = false
        minimumHeight = dp(compactControlHeight())
        minHeight = dp(compactControlHeight())
        minimumWidth = dp(compactControlHeight())
        minWidth = dp(compactControlHeight())
        setPadding(0, 0, 0, 0)
        backgroundTintList = null
        background = controlBackground(primary = false)
        elevation = controlElevation()
        setTextColor(readableTextColor())
        setOnClickListener(onClick)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, dp(controlGap()), 0, dp(controlGap()))
        }
    }

    private fun toolbarButton(label: String, description: String, onClick: (View) -> Unit): Button = Button(this).apply {
        text = label
        contentDescription = description
        textSize = 25f
        typeface = appTypeface()
        isAllCaps = false
        minimumHeight = dp(42)
        minHeight = dp(42)
        minimumWidth = dp(42)
        minWidth = dp(42)
        setPadding(0, 0, 0, 0)
        backgroundTintList = null
        background = toolbarControlBackground()
        setTextColor(Color.WHITE)
        setOnClickListener(onClick)
    }

    private fun compactHeader(heading: View, menu: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(heading, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(menu, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginStart = dp(controlGap())
        })
    }

    private fun compactBar(label: String, vararg actions: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(controlGap()), 0, dp(controlGap()))
        addView(text(label, 11f, bold = true).apply {
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        actions.forEach { action ->
            addView(action, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginStart = dp(controlGap())
            })
        }
    }

    private fun threadControlBar(status: TextView, vararg actions: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(controlGap()), 0, dp(controlGap()))
        status.maxLines = 3
        status.ellipsize = TextUtils.TruncateAt.END
        addView(status, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        actions.forEach {
            addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginStart = dp(controlGap())
            })
        }
    }

    private fun compactInputRow(input: View, vararg actions: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        actions.forEach { action ->
            addView(action, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginStart = dp(controlGap())
            })
        }
    }

    private fun messagePanel(incoming: Boolean): LinearLayout = panel().apply {
        configureContour(
            appearance.display.bubbleShape,
            dp(panelHorizontalPadding()),
            dp(panelVerticalPadding())
        )
        background = surfaceDrawable(
            color = panelSurfaceColor(incoming),
            shape = appearance.display.bubbleShape,
            outlined = appearance.display.showOutlines,
            opacityPercent = appearance.textWindowOpacity
        )
        val side = messageSideMargin()
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            if (incoming) setMargins(0, dp(panelGap()), side, dp(panelGap()))
            else setMargins(side, dp(panelGap()), 0, dp(panelGap()))
        }
    }

    private fun settingsCard(title: String, description: String, actionLabel: String, action: () -> Unit): View =
        panel().apply {
            addView(text(title, 16f, bold = true))
            addView(text(description, 13f))
            addView(compactButton(actionLabel) { action() })
        }

    private fun readableTextColor(): Int = if (appearance.highContrast) Color.WHITE else appearance.textColor

    private fun appTypeface(bold: Boolean = false): Typeface = typefaceFor(
        appearance.display.textFont,
        appearance.display.textFormat,
        bold
    )

    private fun typefaceFor(font: String, format: String, bold: Boolean = false): Typeface {
        val cacheKey = "$font|$format|$bold"
        typefaceCache[cacheKey]?.let { return it }
        val family = when (font) {
            DISPLAY_FONT_SERIF,
            DISPLAY_FONT_CALLIGRAPHY_CLASSIC -> "serif"
            DISPLAY_FONT_MONOSPACE -> "monospace"
            DISPLAY_FONT_CONDENSED -> "sans-serif-condensed"
            DISPLAY_FONT_CURSIVE_SCRIPT,
            DISPLAY_FONT_CALLIGRAPHY_FLOURISHED -> "cursive"
            DISPLAY_FONT_CURSIVE_CASUAL -> "casual"
            DISPLAY_FONT_SPECIAL_SMALL_CAPS -> "sans-serif-smallcaps"
            DISPLAY_FONT_SPECIAL_SLAB -> "serif-monospace"
            DISPLAY_FONT_SPECIAL_LIGHT -> "sans-serif-light"
            DISPLAY_FONT_SPECIAL_HEAVY -> "sans-serif-black"
            else -> "sans-serif"
        }
        val familyStyle = when (font) {
            DISPLAY_FONT_CALLIGRAPHY_CLASSIC -> Typeface.ITALIC
            DISPLAY_FONT_CALLIGRAPHY_FLOURISHED -> Typeface.BOLD_ITALIC
            else -> Typeface.NORMAL
        }
        val formatStyle = when (format) {
            TEXT_FORMAT_BOLD -> Typeface.BOLD
            TEXT_FORMAT_ITALIC -> Typeface.ITALIC
            TEXT_FORMAT_BOLD_ITALIC -> Typeface.BOLD_ITALIC
            else -> Typeface.NORMAL
        }
        val requestedStyle = (familyStyle or formatStyle) or (if (bold) Typeface.BOLD else Typeface.NORMAL)
        return Typeface.create(family, requestedStyle).also { typefaceCache[cacheKey] = it }
    }

    private fun isSleekDisplay(): Boolean = appearance.display.style == DISPLAY_STYLE_SLEEK

    private fun displayStyleDescription(style: String): String = if (style == DISPLAY_STYLE_UTILITY) {
        "Utility keeps the current compact, direct, block-forward layout with strong structure and minimal decoration."
    } else {
        "Sleek is the default: softer spacing, rounded surfaces, clearer sent/received separation, and gentle visual depth."
    }

    private fun screenHorizontalPadding(): Int = when (appearance.display.spacing) {
        DISPLAY_SPACING_COMPACT -> 10
        DISPLAY_SPACING_SPACIOUS -> 18
        else -> 14
    }

    private fun screenVerticalPadding(): Int = when (appearance.display.spacing) {
        DISPLAY_SPACING_COMPACT -> 6
        DISPLAY_SPACING_SPACIOUS -> 14
        else -> 10
    }

    private fun panelHorizontalPadding(): Int = when (appearance.display.spacing) {
        DISPLAY_SPACING_COMPACT -> 10
        DISPLAY_SPACING_SPACIOUS -> 18
        else -> 14
    }

    private fun panelVerticalPadding(): Int = when (appearance.display.spacing) {
        DISPLAY_SPACING_COMPACT -> 8
        DISPLAY_SPACING_SPACIOUS -> 15
        else -> 11
    }

    private fun panelGap(): Int = when (appearance.display.spacing) {
        DISPLAY_SPACING_COMPACT -> 4
        DISPLAY_SPACING_SPACIOUS -> 10
        else -> 7
    }

    private fun controlGap(): Int = when (appearance.display.spacing) {
        DISPLAY_SPACING_COMPACT -> 2
        DISPLAY_SPACING_SPACIOUS -> 6
        else -> 4
    }

    private fun regularControlHeight(): Int = when (appearance.display.spacing) {
        DISPLAY_SPACING_COMPACT -> 42
        DISPLAY_SPACING_SPACIOUS -> 50
        else -> 46
    }

    private fun compactControlHeight(): Int = when (appearance.display.spacing) {
        DISPLAY_SPACING_COMPACT -> 38
        DISPLAY_SPACING_SPACIOUS -> 46
        else -> 42
    }

    private fun shapeRadius(shape: String): Float = dp(when (shape) {
        DISPLAY_SHAPE_SQUARE -> 0
        DISPLAY_SHAPE_SOFT -> 12
        DISPLAY_SHAPE_OVAL -> 96
        else -> 24
    }).toFloat()

    /** Keeps content away from progressively deeper corner arcs selected in Display settings. */
    private fun shapeHorizontalPadding(shape: String, base: Int): Int = base + when (shape) {
        DISPLAY_SHAPE_SQUARE -> 0
        DISPLAY_SHAPE_SOFT -> 2
        DISPLAY_SHAPE_ROUNDED -> 8
        DISPLAY_SHAPE_OVAL -> 18
        else -> 8
    }

    private fun shapeVerticalPadding(shape: String, base: Int): Int = base + when (shape) {
        DISPLAY_SHAPE_SQUARE -> 0
        DISPLAY_SHAPE_SOFT -> 1
        DISPLAY_SHAPE_ROUNDED -> 3
        DISPLAY_SHAPE_OVAL -> 7
        else -> 3
    }

    private fun applyShapeAwarePadding(view: View, shape: String, horizontal: Int, vertical: Int) {
        val h = dp(shapeHorizontalPadding(shape, horizontal))
        val v = dp(shapeVerticalPadding(shape, vertical))
        view.setPadding(h, v, h, v)
    }

    private fun surfaceDrawable(
        color: Int,
        shape: String,
        outlined: Boolean,
        opacityPercent: Int = 100
    ): GradientDrawable = GradientDrawable().apply {
        cornerRadius = shapeRadius(shape)
        setColor(color)
        if (outlined || appearance.highContrast) {
            setStroke(
                dp(1),
                if (appearance.highContrast) Color.WHITE else withAlpha(appearance.accentColor, 82)
            )
        }
        alpha = (opacityPercent.coerceIn(1, 100) * 255 / 100).coerceIn(3, 255)
    }

    private fun panelSurfaceColor(incoming: Boolean? = null): Int {
        if (appearance.highContrast) return Color.rgb(25, 25, 25)
        if (incoming != false || appearance.display.sentTintPercent == 0) return appearance.surfaceColor
        return blendColors(appearance.surfaceColor, appearance.accentColor, appearance.display.sentTintPercent)
    }

    private fun blendColors(base: Int, overlay: Int, overlayPercent: Int): Int {
        val amount = overlayPercent.coerceIn(0, 100) / 100f
        fun channel(baseValue: Int, overlayValue: Int): Int =
            (baseValue * (1f - amount) + overlayValue * amount).toInt().coerceIn(0, 255)
        return Color.rgb(
            channel(Color.red(base), Color.red(overlay)),
            channel(Color.green(base), Color.green(overlay)),
            channel(Color.blue(base), Color.blue(overlay))
        )
    }

    private fun controlBackground(primary: Boolean): RippleDrawable {
        val fill = when {
            appearance.highContrast && primary -> Color.WHITE
            appearance.highContrast -> Color.DKGRAY
            primary -> appearance.accentColor
            else -> appearance.surfaceColor
        }
        val content = surfaceDrawable(
            fill,
            appearance.display.buttonShape,
            outlined = appearance.display.showOutlines && !primary
        )
        val mask = surfaceDrawable(Color.WHITE, appearance.display.buttonShape, outlined = false)
        val ripple = if (primary) contrastingText(fill) else appearance.accentColor
        return RippleDrawable(ColorStateList.valueOf(withAlpha(ripple, 55)), content, mask)
    }

    private fun toolbarControlBackground(): RippleDrawable {
        val mask = surfaceDrawable(Color.WHITE, appearance.display.buttonShape, outlined = false)
        return RippleDrawable(ColorStateList.valueOf(withAlpha(Color.WHITE, 75)), null, mask)
    }

    private fun controlElevation(): Float =
        if (appearance.display.showElevation) dp(if (isSleekDisplay()) 2 else 1).toFloat() else 0f

    private fun messageSideMargin(): Int {
        val availableWidth = (resources.displayMetrics.widthPixels - dp(screenHorizontalPadding() * 2)).coerceAtLeast(1)
        val unusedPercent = 100 - appearance.display.messageWidthPercent.coerceIn(70, 100)
        return (availableWidth * unusedPercent / 100f).toInt()
    }

    private fun applyInputStyle(field: TextView) {
        field.backgroundTintList = null
        field.background = surfaceDrawable(
            color = panelSurfaceColor(),
            shape = appearance.display.cardShape,
            outlined = true,
            opacityPercent = appearance.textWindowOpacity
        )
        applyShapeAwarePadding(field, appearance.display.cardShape, 12, 9)
        field.minHeight = dp(regularControlHeight())
        field.elevation = if (appearance.display.showElevation) dp(1).toFloat() else 0f
        field.clipToOutline = true
    }

    private fun Spinner.onSelectionChanged(changed: (Int) -> Unit) {
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = changed(position)
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
    }

    private fun SeekBar.onProgressChanged(changed: (Int) -> Unit) {
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = changed(progress)
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
    }

    private fun contrastingText(color: Int): Int {
        val luminance = (Color.red(color) * 299 + Color.green(color) * 587 + Color.blue(color) * 114) / 1000
        return if (luminance >= 145) Color.BLACK else Color.WHITE
    }

    private fun backgroundWithStrength(color: Int, strength: Int): Int {
        val amount = strength.coerceIn(1, 100) / 100f
        val base = if (contrastingText(color) == Color.BLACK) Color.WHITE else Color.BLACK
        fun channel(value: Int, baseValue: Int) = (value * amount + baseValue * (1f - amount)).toInt().coerceIn(0, 255)
        return Color.rgb(
            channel(Color.red(color), Color.red(base)),
            channel(Color.green(color), Color.green(base)),
            channel(Color.blue(color), Color.blue(base))
        )
    }

    private fun withAlpha(color: Int, alpha: Int): Int =
        Color.argb(alpha.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    private fun darken(color: Int, amount: Float): Int = Color.rgb(
        (Color.red(color) * amount).toInt().coerceIn(0, 255),
        (Color.green(color) * amount).toInt().coerceIn(0, 255),
        (Color.blue(color) * amount).toInt().coerceIn(0, 255)
    )

    private fun colorHex(color: Int): String = String.format(
        Locale.US,
        "#%02X%02X%02X",
        Color.red(color),
        Color.green(color),
        Color.blue(color)
    )

    private fun parseColor(value: String): Int? = runCatching {
        val normalized = value.trim().let { if (it.startsWith("#")) it else "#$it" }
        require(normalized.length == 7)
        Color.parseColor(normalized)
    }.getOrNull()

    private fun String.shortLabel(): String = when (this) {
        FILTER_ALL -> "All"
        FILTER_DEVICE -> "SMS/MMS"
        FILTER_EMAIL -> "Email"
        CONTACT_ALL -> "All senders"
        CONTACT_SAVED -> "Contacts"
        CONTACT_UNKNOWN -> "Non-contacts"
        SORT_NEWEST -> "Newest"
        SORT_OLDEST -> "Oldest"
        SORT_ADDRESS_ASC -> "Name A–Z"
        SORT_ADDRESS_DESC -> "Name Z–A"
        SORT_MESSAGE_ASC -> "Text A–Z"
        SORT_UNREAD -> "Unread"
        SORT_DEVICE_FIRST -> "SMS/MMS first"
        SORT_EMAIL_FIRST -> "Email first"
        SORT_CONTACTS_FIRST -> "Contacts first"
        SORT_UNKNOWN_FIRST -> "Non-contacts first"
        THREAD_INCOMING -> "Received first"
        THREAD_SENT -> "Sent first"
        else -> this
    }

    private fun horizontal(vararg views: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        views.forEachIndexed { index, view ->
            addView(view, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (index > 0) marginStart = dp(controlGap())
                if (index < views.lastIndex) marginEnd = dp(controlGap())
                topMargin = dp(controlGap())
                bottomMargin = dp(controlGap())
            })
        }
    }

    private fun recipientEdit(hint: String, value: String): MultiAutoCompleteTextView =
        MultiAutoCompleteTextView(this).apply {
            this.hint = hint
            setText(value, false)
            setSelection(text.length)
            setTextColor(readableTextColor())
            setHintTextColor(withAlpha(readableTextColor(), 170))
            textSize = 15f * appearance.textScale
            typeface = appTypeface()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
            setSingleLine(false)
            maxLines = 3
            setHorizontallyScrolling(false)
            breakStrategy = Layout.BREAK_STRATEGY_HIGH_QUALITY
            hyphenationFrequency = Layout.HYPHENATION_FREQUENCY_NORMAL
            threshold = 1
            setTokenizer(MultiAutoCompleteTextView.CommaTokenizer())
            applyInputStyle(this)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

    private fun edit(
        hint: String,
        value: String,
        multiline: Boolean = false,
        password: Boolean = false,
        number: Boolean = false,
        email: Boolean = false,
        uri: Boolean = false
    ): EditText = EditText(this).apply {
        this.hint = hint
        setText(value)
        setTextColor(readableTextColor())
        setHintTextColor(withAlpha(readableTextColor(), 170))
        textSize = 15f * appearance.textScale
        typeface = appTypeface()
        inputType = when {
            password -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            number -> InputType.TYPE_CLASS_NUMBER
            email -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            uri -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            multiline -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            else -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        if (multiline) {
            minLines = 4
            gravity = Gravity.TOP
            setHorizontallyScrolling(false)
            breakStrategy = Layout.BREAK_STRATEGY_HIGH_QUALITY
            hyphenationFrequency = Layout.HYPHENATION_FREQUENCY_NORMAL
        }
        applyInputStyle(this)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun spinner(values: List<String>, selected: String): Spinner =
        Spinner(this).apply {
            adapter = stringAdapter(values)
            setSelection(values.indexOf(selected).coerceAtLeast(0))
        }

    private fun stringAdapter(values: List<String>): ArrayAdapter<String> =
        object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, values) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
                style(super.getView(position, convertView, parent))

            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View =
                style(super.getDropDownView(position, convertView, parent))

            private fun style(view: View): View = view.apply {
                (this as? TextView)?.typeface = appTypeface()
            }
        }

    private fun splitAddresses(value: String): List<String> =
        value.split(",", ";").map(String::trim).filter(String::isNotBlank).distinctBy(String::lowercase)

    private fun showSentDestination(recipients: List<String>) {
        val recipient = recipients.singleOrNull()
        if (recipient == null) {
            showInbox()
            return
        }
        work({ Telephony.Threads.getOrCreateThreadId(this, recipient) }) { result ->
            result.fold(
                onSuccess = { threadId -> showSmsThread(threadId, recipient) },
                onFailure = { showInbox() }
            )
        }
    }

    private fun toast(value: String) = Toast.makeText(this, value, Toast.LENGTH_LONG).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun statusBarHeight(): Int = dp(24)
    private fun formatDateTime(timestamp: Long): String = requireNotNull(dateTimeFormat.get()).format(Date(timestamp))
    private fun formatShortDateTime(timestamp: Long): String = requireNotNull(shortDateTimeFormat.get()).format(Date(timestamp))

    private fun <T> work(block: suspend () -> T, complete: (Result<T>) -> Unit) {
        Async.launch {
            val result = try { Result.success(block()) } catch (error: Throwable) { Result.failure(error) }
            Async.onMain {
                if (!isFinishing && !isDestroyed) complete(result)
            }
        }
    }

    private data class InboxState(val emailEnabled: Boolean, val emailCount: Int, val conversations: List<UnifiedConversation>)
    private data class ThreadState(
        val messages: List<EmailMessageEntity>,
        val attachments: MutableMap<String, List<EmailAttachmentEntity>>
    )
    private data class EmailThreadLoad(val state: ThreadState, val remoteUnread: List<EmailMessageEntity>)
    private data class SharedLaunch(val text: String, val subject: String, val uris: List<Uri>)
    private data class SharedContent(
        val text: String,
        val subject: String,
        val attachments: List<Uri>,
        val emailAvailable: Boolean
    )
    private data class InboxListScreen(val controls: LinearLayout, val list: ListView)
    private data class ThreadListScreen(
        val controls: LinearLayout,
        val list: ListView,
        val topReply: LinearLayout,
        val footer: LinearLayout
    )
    private data class MenuAction(val label: String, val action: () -> Unit)
    private data class UiPalette(val name: String, val background: Int, val surface: Int, val accent: Int, val text: Int)
    private enum class ManagementAction { DELETE, FORWARD, DOWNLOAD, COPY }
    private enum class RecipientKind { PHONE, EMAIL }
    private data class RecipientOption(val name: String, val address: String) {
        val label: String get() = "$name — $address"
    }

    private class ThreadRowHolder(val root: FrameLayout, val card: LinearLayout)

    private inner class InboxConversationAdapter(
        private val selectionChanged: () -> Unit
    ) : BaseAdapter() {
        private var items: List<UnifiedConversation> = emptyList()

        fun submit(value: List<UnifiedConversation>) {
            items = value
            notifyDataSetChanged()
        }

        override fun getCount(): Int = items.size
        override fun getItem(position: Int): UnifiedConversation = items[position]
        override fun getItemId(position: Int): Long = getItem(position).stableId.hashCode().toLong()
        override fun hasStableIds(): Boolean = true

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val holder = (convertView?.tag as? ThreadRowHolder) ?: newThreadRow()
            bindConversationCard(holder.card as ShapeContourLayout, getItem(position), selectionChanged)
            return holder.root
        }
    }

    private inner class EmailMessageAdapter(
        private val threadId: String,
        private val selectionChanged: () -> Unit
    ) : BaseAdapter() {
        private var state: ThreadState? = null
        private var items: List<EmailMessageEntity> = emptyList()

        fun submit(value: ThreadState, sort: String) {
            state = value
            items = sortEmailMessages(value.messages, sort)
            notifyDataSetChanged()
        }

        override fun getCount(): Int = items.size
        override fun getItem(position: Int): EmailMessageEntity = items[position]
        override fun getItemId(position: Int): Long = getItem(position).stableId.hashCode().toLong()
        override fun hasStableIds(): Boolean = true

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val holder = (convertView?.tag as? ThreadRowHolder) ?: newThreadRow()
            val currentState = requireNotNull(state)
            bindEmailMessageCard(holder.card, threadId, currentState, getItem(position), selectionChanged)
            return holder.root
        }
    }

    private inner class DeviceMessageAdapter(
        private val threadId: Long,
        private val selectionChanged: () -> Unit
    ) : BaseAdapter() {
        private var items: List<DeviceMessage> = emptyList()

        fun submit(messages: List<DeviceMessage>, sort: String) {
            items = sortDeviceMessages(messages, sort)
            notifyDataSetChanged()
        }

        fun itemAt(position: Int): DeviceMessage? = items.getOrNull(position)

        fun positionOf(stableId: String): Int = items.indexOfFirst { it.stableId == stableId }

        override fun getCount(): Int = items.size
        override fun getItem(position: Int): DeviceMessage = items[position]
        override fun getItemId(position: Int): Long {
            val message = getItem(position)
            return message.id * 2L + if (message.transport == CommunicationTransport.MMS) 1L else 0L
        }
        override fun hasStableIds(): Boolean = true

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val holder = (convertView?.tag as? ThreadRowHolder) ?: newThreadRow()
            bindDeviceMessageCard(holder.card, threadId, getItem(position), selectionChanged)
            return holder.root
        }
    }

    private fun newThreadRow(): ThreadRowHolder {
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
        }
        val card = ShapeContourLayout(this)
        root.addView(card)
        return ThreadRowHolder(root, card).also { root.tag = it }
    }

    private fun styleInboxCard(card: ShapeContourLayout) {
        card.removeAllViews()
        card.orientation = LinearLayout.VERTICAL
        card.configureContour(
            appearance.display.cardShape,
            dp(panelHorizontalPadding()),
            dp(panelVerticalPadding())
        )
        card.background = surfaceDrawable(
            color = panelSurfaceColor(),
            shape = appearance.display.cardShape,
            outlined = appearance.display.showOutlines,
            opacityPercent = appearance.textWindowOpacity
        )
        card.elevation = if (appearance.display.showElevation) dp(if (isSleekDisplay()) 3 else 2).toFloat() else 0f
        card.clipToOutline = true
        card.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            setMargins(0, dp(panelGap()), 0, dp(panelGap()))
        }
    }

    private fun styleThreadCard(card: LinearLayout, incoming: Boolean) {
        card.removeAllViews()
        card.orientation = LinearLayout.VERTICAL
        (card as? ShapeContourLayout)?.configureContour(
            appearance.display.bubbleShape,
            dp(panelHorizontalPadding()),
            dp(panelVerticalPadding())
        ) ?: applyShapeAwarePadding(
            card,
            appearance.display.bubbleShape,
            panelHorizontalPadding(),
            panelVerticalPadding()
        )
        card.background = surfaceDrawable(
            color = panelSurfaceColor(incoming),
            shape = appearance.display.bubbleShape,
            outlined = appearance.display.showOutlines,
            opacityPercent = appearance.textWindowOpacity
        )
        card.elevation = if (appearance.display.showElevation) dp(if (isSleekDisplay()) 3 else 2).toFloat() else 0f
        card.clipToOutline = true
        val side = messageSideMargin()
        card.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            if (incoming) setMargins(0, dp(panelGap()), side, dp(panelGap()))
            else setMargins(side, dp(panelGap()), 0, dp(panelGap()))
        }
    }

    private fun bindDeviceMessageCard(
        card: LinearLayout,
        threadId: Long,
        message: DeviceMessage,
        selectionChanged: () -> Unit
    ) {
        styleThreadCard(card, message.incoming)
        val type = if (message.transport == CommunicationTransport.MMS) "MMS" else "SMS"
        val pending = message.id < 0L
        val selected = !pending && message.stableId in deviceMessageSelected
        val heading = text(
            "${if (selected) "✓ Selected • " else ""}" +
                when {
                    message.incoming -> "$type • From ${message.address}"
                    pending -> "$type • Sending…"
                    else -> "$type • Sent"
                },
            12f,
            bold = true
        ).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val more: View = if (pending) Space(this) else smallButton("⋮", "Message actions") { anchor ->
            showDeviceMessageMenu(anchor, threadId, activeDeviceAddress, message)
        }
        card.addView(compactHeader(heading, more))
        val visibleBody = message.body.takeUnless {
            message.attachments.isNotEmpty() && it.startsWith("[MMS", ignoreCase = true)
        }.orEmpty()
        if (visibleBody.isNotBlank()) card.addView(linkedMessageText(visibleBody))
        message.attachments.forEach attachmentLoop@ { attachment ->
            if (isVoiceMessage(attachment)) {
                card.addView(voiceMessageView(threadId, activeDeviceAddress, message, attachment))
                return@attachmentLoop
            }
            card.addView(text(attachmentLabel(attachment), 12f, bold = true))
            if (attachment.mimeType.startsWith("image/")) {
                val preview = ImageView(this).apply {
                    contentDescription = "MMS image: ${attachment.fileName}"
                    adjustViewBounds = true
                    scaleType = ImageView.ScaleType.CENTER_INSIDE
                    maxHeight = dp(360)
                    minimumHeight = dp(120)
                    setBackgroundColor(if (appearance.highContrast) Color.DKGRAY else Color.rgb(235, 239, 244))
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                }
                card.addView(preview)
                bindMmsPreview(preview, attachment)
            }
            card.addView(compactBar(
                "Attachment",
                compactButton("Open") { openMmsAttachment(attachment) },
                compactButton("Save") { saveMmsAttachment(attachment) }
            ))
        }
        card.addView(text(formatDateTime(message.date), 11f))
        if (pending) {
            card.isLongClickable = false
            card.setOnLongClickListener(null)
        } else {
            card.setOnLongClickListener {
                if (message.stableId in deviceMessageSelected) deviceMessageSelected -= message.stableId
                else deviceMessageSelected += message.stableId
                selectionChanged()
                true
            }
        }
    }

    private fun bindEmailMessageCard(
        card: LinearLayout,
        threadId: String,
        state: ThreadState,
        message: EmailMessageEntity,
        selectionChanged: () -> Unit
    ) {
        styleThreadCard(card, message.incoming)
        val selected = message.stableId in emailMessageSelected
        val heading = text(
            "${if (selected) "✓ Selected • " else ""}${if (message.incoming) "From ${message.sender}" else "Sent email"}",
            12f,
            bold = true
        ).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val more = smallButton("⋮", "Email actions") { anchor -> showEmailMessageMenu(anchor, threadId, message) }
        card.addView(compactHeader(heading, more))
        message.subject?.takeIf(String::isNotBlank)?.let { card.addView(text(it, 15f, bold = true)) }
        card.addView(linkedMessageText(message.bodyText))
        card.addView(text(formatDateTime(message.timestamp), 11f))
        val attachments = state.attachments[message.stableId]
        when {
            attachments != null -> attachments.forEach { item ->
                card.addView(compactButton(item.fileName ?: "Open attachment") { openAttachment(item) })
            }
            message.attachmentCount > 0 -> {
                card.addView(text("Loading ${message.attachmentCount} attachment${if (message.attachmentCount == 1) "" else "s"}…", 11f))
                loadEmailAttachments(threadId, state, message.stableId)
            }
        }
        card.setOnLongClickListener {
            if (message.stableId in emailMessageSelected) emailMessageSelected -= message.stableId
            else emailMessageSelected += message.stableId
            selectionChanged()
            true
        }
    }

    private fun loadEmailAttachments(threadId: String, state: ThreadState, messageId: String) {
        if (!emailAttachmentsLoading.add(messageId)) return
        work({ LocalDatabase.get(this).emailAttachmentDao().forMessage(messageId) }) { result ->
            emailAttachmentsLoading -= messageId
            if (currentPage != PAGE_THREAD || activeEmailThreadId != threadId || activeEmailState !== state) return@work
            result.onSuccess {
                state.attachments[messageId] = it
                activeEmailAdapter?.notifyDataSetChanged()
            }.onFailure {
                state.attachments[messageId] = emptyList()
                toast(it.message ?: "Unable to load an email attachment.")
            }
        }
    }

    private fun bindMmsPreview(preview: ImageView, attachment: DeviceAttachment) {
        val key = "${attachment.partId}:${attachment.sizeBytes ?: -1L}"
        preview.tag = key
        preview.setImageDrawable(null)
        mmsPreviewCache.get(key)?.let {
            preview.setImageBitmap(it)
            return
        }
        if (!mmsPreviewLoading.add(key)) return
        work({ decodeMmsPreview(attachment) }) { decoded ->
            mmsPreviewLoading -= key
            decoded.onSuccess { bitmap ->
                mmsPreviewCache.put(key, bitmap)
                if (preview.tag == key && preview.isAttachedToWindow) preview.setImageBitmap(bitmap)
            }
        }
    }

    /** Explicit performClick override keeps gesture-driven microphone controls accessible. */
    private class GestureButton(context: Context) : Button(context) {
        override fun performClick(): Boolean = super.performClick()
    }

    private class RecipientAdapter(
        private val context: Context,
        private val all: List<RecipientOption>,
        private val itemTypeface: Typeface
    ) : BaseAdapter(), Filterable {
        private var visible: List<RecipientOption> = all
        private val filter = object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val query = constraint?.toString()?.trim()?.lowercase(Locale.getDefault()).orEmpty()
                val digits = query.filter(Char::isDigit)
                val matches = if (query.isBlank()) all else all.filter {
                    it.name.lowercase(Locale.getDefault()).contains(query) ||
                        it.address.lowercase(Locale.getDefault()).contains(query) ||
                        (digits.isNotBlank() && it.address.filter(Char::isDigit).contains(digits))
                }
                return FilterResults().apply {
                    values = matches
                    count = matches.size
                }
            }

            @Suppress("UNCHECKED_CAST")
            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                visible = results?.values as? List<RecipientOption> ?: emptyList()
                if (visible.isEmpty()) notifyDataSetInvalidated() else notifyDataSetChanged()
            }

            override fun convertResultToString(resultValue: Any?): CharSequence =
                (resultValue as? RecipientOption)?.address.orEmpty()
        }

        override fun getCount(): Int = visible.size
        override fun getItem(position: Int): RecipientOption = visible[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getFilter(): Filter = filter
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val density = context.resources.displayMetrics.density
            return (convertView as? TextView ?: TextView(context)).apply {
                text = getItem(position).label
                textSize = 16f
                typeface = itemTypeface
                setTextColor(Color.BLACK)
                setPadding((14 * density).toInt(), (12 * density).toInt(), (14 * density).toInt(), (12 * density).toInt())
            }
        }
    }

    companion object {
        private const val REQUEST_PERMISSIONS = 7101
        private const val REQUEST_ATTACHMENTS = 7102
        private const val REQUEST_BACKGROUND = 7103
        private const val REQUEST_RECORD_AUDIO = 7104
        private const val REQUEST_DEFAULT_SMS_ROLE = 7105
        private const val REQUEST_SMS_SEND_PERMISSIONS = 7106
        private const val STATE_SMS_ROLE_ITEM_ID = "state.sms-role.item-id"
        private const val STATE_SMS_ROLE_RUN_AT = "state.sms-role.run-at"
        private const val STATE_SMS_ROLE_ORIGIN = "state.sms-role.origin"
        private const val ROLE_ORIGIN_COMPOSER = "COMPOSER"
        private const val ROLE_ORIGIN_WORKFLOW = "WORKFLOW"
        private const val NO_SCHEDULE_TIME = Long.MIN_VALUE
        private const val MMS_PREVIEW_CACHE_KIB = 24 * 1024
        private const val ATTACHMENT_METADATA_CACHE_ITEMS = 96
        private const val VOICE_DURATION_CACHE_ITEMS = 128
        private const val EMAIL_THREAD_CACHE_ITEMS = 4
        private const val LINKED_TEXT_CACHE_CHARS = 512 * 1024
        private const val MESSAGE_PROVIDER_REFRESH_DELAY_MS = 750L
        private const val MESSAGE_PROVIDER_REFRESH_THROTTLE_MS = 2_000L
        private const val SELF_PROVIDER_CHANGE_QUIET_MS = 1_500L
        private const val UNKNOWN_VOICE_DURATION = -1L
        private const val MAX_SHARED_ATTACHMENT_BYTES = 50L * 1024 * 1024
        private const val ATTACH_NONE = 0
        private const val ATTACH_EMAIL = 1
        private const val ATTACH_MESSAGE = 2
        private const val PAGE_INBOX = 0
        private const val PAGE_SETTINGS = 1
        private const val PAGE_ACCOUNTS = 2
        private const val PAGE_ACCOUNT_EDIT = 3
        private const val PAGE_THREAD = 4
        private const val PAGE_COMPOSE = 5
        private const val PAGE_LICENSE = 6
        private const val PAGE_CONTACTS = 7
        private const val PAGE_APPEARANCE = 8
        private const val PAGE_SORT_SETTINGS = 9
        private const val PAGE_NOTIFICATION_SETTINGS = 10
        private const val PAGE_WORKFLOWS = 11
        private val composeExecutor = Executors.newSingleThreadExecutor()
        const val EXTRA_NOTIFICATION_ADDRESS = "com.macleanofduartenterprises.macleanmessaging.extra.NOTIFICATION_ADDRESS"
        const val EXTRA_NOTIFICATION_MESSAGE_URI = "com.macleanofduartenterprises.macleanmessaging.extra.NOTIFICATION_MESSAGE_URI"
        const val EXTRA_NOTIFICATION_THREAD_ID = "com.macleanofduartenterprises.macleanmessaging.extra.NOTIFICATION_THREAD_ID"
        private const val FILTER_ALL = "All messages"
        private const val FILTER_DEVICE = "SMS/MMS only"
        private const val FILTER_EMAIL = "Email only"
        private const val CONTACT_ALL = "All senders"
        private const val CONTACT_SAVED = "Saved contacts only"
        private const val CONTACT_UNKNOWN = "Non-contacts only"
        private const val SORT_NEWEST = "Newest first"
        private const val SORT_OLDEST = "Oldest first"
        private const val SORT_ADDRESS_ASC = "Address/name A–Z"
        private const val SORT_ADDRESS_DESC = "Address/name Z–A"
        private const val SORT_MESSAGE_ASC = "Message text A–Z"
        private const val SORT_UNREAD = "Unread first"
        private const val SORT_DEVICE_FIRST = "SMS/MMS first"
        private const val SORT_EMAIL_FIRST = "Email first"
        private const val SORT_CONTACTS_FIRST = "Saved contacts first"
        private const val SORT_UNKNOWN_FIRST = "Non-contacts first"
        private const val THREAD_OLDEST = "Oldest first"
        private const val THREAD_NEWEST = "Newest first"
        private const val THREAD_INCOMING = "Received first"
        private const val THREAD_SENT = "Sent first"
        private const val THREAD_TEXT = "Message text A–Z"
        private const val DISPLAY_STYLE_SLEEK = "Sleek"
        private const val DISPLAY_STYLE_UTILITY = "Utility"
        private const val DISPLAY_SHAPE_SQUARE = "Square"
        private const val DISPLAY_SHAPE_SOFT = "Soft corners"
        private const val DISPLAY_SHAPE_ROUNDED = "Rounded"
        private const val DISPLAY_SHAPE_OVAL = "Oval"
        private const val DISPLAY_SPACING_COMPACT = "Compact"
        private const val DISPLAY_SPACING_COMFORTABLE = "Comfortable"
        private const val DISPLAY_SPACING_SPACIOUS = "Spacious"
        private const val DISPLAY_FONT_SYSTEM = "System sans"
        private const val DISPLAY_FONT_SERIF = "Serif"
        private const val DISPLAY_FONT_MONOSPACE = "Monospace"
        private const val DISPLAY_FONT_CONDENSED = "Condensed"
        private const val DISPLAY_FONT_CURSIVE_SCRIPT = "Cursive — Script"
        private const val DISPLAY_FONT_CURSIVE_CASUAL = "Cursive — Casual"
        private const val DISPLAY_FONT_CALLIGRAPHY_CLASSIC = "Calligraphy — Classic"
        private const val DISPLAY_FONT_CALLIGRAPHY_FLOURISHED = "Calligraphy — Flourished"
        private const val DISPLAY_FONT_SPECIAL_SMALL_CAPS = "Special — Small caps"
        private const val DISPLAY_FONT_SPECIAL_SLAB = "Special — Slab serif"
        private const val DISPLAY_FONT_SPECIAL_LIGHT = "Special — Light"
        private const val DISPLAY_FONT_SPECIAL_HEAVY = "Special — Heavy"
        private const val TEXT_FORMAT_REGULAR = "Regular"
        private const val TEXT_FORMAT_BOLD = "Bold"
        private const val TEXT_FORMAT_ITALIC = "Italic"
        private const val TEXT_FORMAT_BOLD_ITALIC = "Bold italic"
        private const val REPLY_LOCATION_TOP = "Top of conversation"
        private const val REPLY_LOCATION_BOTTOM = "Bottom of conversation"
        private val INBOX_FILTER_OPTIONS = listOf(FILTER_ALL, FILTER_DEVICE, FILTER_EMAIL)
        private val CONTACT_FILTER_OPTIONS = listOf(CONTACT_ALL, CONTACT_SAVED, CONTACT_UNKNOWN)
        private val DISPLAY_STYLE_OPTIONS = listOf(DISPLAY_STYLE_SLEEK, DISPLAY_STYLE_UTILITY)
        private val DISPLAY_SHAPE_OPTIONS = listOf(
            DISPLAY_SHAPE_SQUARE,
            DISPLAY_SHAPE_SOFT,
            DISPLAY_SHAPE_ROUNDED,
            DISPLAY_SHAPE_OVAL
        )
        private val DISPLAY_SPACING_OPTIONS = listOf(
            DISPLAY_SPACING_COMPACT,
            DISPLAY_SPACING_COMFORTABLE,
            DISPLAY_SPACING_SPACIOUS
        )
        private val DISPLAY_FONT_OPTIONS = listOf(
            DISPLAY_FONT_SYSTEM,
            DISPLAY_FONT_SERIF,
            DISPLAY_FONT_MONOSPACE,
            DISPLAY_FONT_CONDENSED,
            DISPLAY_FONT_CURSIVE_SCRIPT,
            DISPLAY_FONT_CURSIVE_CASUAL,
            DISPLAY_FONT_CALLIGRAPHY_CLASSIC,
            DISPLAY_FONT_CALLIGRAPHY_FLOURISHED,
            DISPLAY_FONT_SPECIAL_SMALL_CAPS,
            DISPLAY_FONT_SPECIAL_SLAB,
            DISPLAY_FONT_SPECIAL_LIGHT,
            DISPLAY_FONT_SPECIAL_HEAVY
        )
        private val TEXT_FORMAT_OPTIONS = listOf(
            TEXT_FORMAT_REGULAR,
            TEXT_FORMAT_BOLD,
            TEXT_FORMAT_ITALIC,
            TEXT_FORMAT_BOLD_ITALIC
        )
        private val REPLY_LOCATION_OPTIONS = listOf(REPLY_LOCATION_BOTTOM, REPLY_LOCATION_TOP)
        private val SORT_OPTIONS = listOf(
            SORT_NEWEST,
            SORT_OLDEST,
            SORT_ADDRESS_ASC,
            SORT_ADDRESS_DESC,
            SORT_MESSAGE_ASC,
            SORT_UNREAD,
            SORT_DEVICE_FIRST,
            SORT_EMAIL_FIRST,
            SORT_CONTACTS_FIRST,
            SORT_UNKNOWN_FIRST
        )
        private val THREAD_SORT_OPTIONS = listOf(
            THREAD_OLDEST,
            THREAD_NEWEST,
            THREAD_INCOMING,
            THREAD_SENT,
            THREAD_TEXT
        )
        private val UI_PALETTES = listOf(
            UiPalette("Soft Cloud", Color.rgb(246, 248, 252), Color.WHITE, Color.rgb(19, 74, 119), Color.rgb(24, 32, 42)),
            UiPalette("Warm Sand", Color.rgb(248, 242, 232), Color.rgb(255, 253, 249), Color.rgb(145, 82, 39), Color.rgb(50, 38, 29)),
            UiPalette("Quiet Sage", Color.rgb(240, 246, 239), Color.rgb(252, 255, 251), Color.rgb(52, 103, 73), Color.rgb(27, 43, 32)),
            UiPalette("Ocean Mist", Color.rgb(236, 247, 248), Color.rgb(250, 255, 255), Color.rgb(24, 104, 116), Color.rgb(22, 43, 47)),
            UiPalette("Soft Plum", Color.rgb(247, 241, 248), Color.rgb(255, 252, 255), Color.rgb(113, 64, 106), Color.rgb(47, 32, 46)),
            UiPalette("Midnight", Color.rgb(15, 25, 34), Color.rgb(25, 39, 52), Color.rgb(45, 112, 166), Color.rgb(240, 246, 252))
        )
    }
}
