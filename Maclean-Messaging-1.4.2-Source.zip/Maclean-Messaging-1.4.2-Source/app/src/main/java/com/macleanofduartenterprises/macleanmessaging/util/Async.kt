/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 */

package com.macleanofduartenterprises.macleanmessaging.util

import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.ThreadFactory
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.startCoroutine

/**
 * Lightweight Android-platform coroutine launcher used by the offline build.
 *
 * A cached thread pool used to create an unbounded number of workers while a large mailbox,
 * image previews, voice metadata, and provider observers were active together. Besides wasting
 * memory, that made otherwise independent UI work compete for CPU and storage. The bounded pool
 * below keeps I/O concurrent without allowing a burst of attachment work to stall the app. A
 * separate serial lane is used for ordered telephony/provider transactions.
 */
object Async {
    private val ioWorkers = Runtime.getRuntime().availableProcessors().coerceIn(2, 4)
    private val executor = Executors.newFixedThreadPool(ioWorkers, NamedThreadFactory("maclean-io"))
    private val serialExecutor = Executors.newSingleThreadExecutor(NamedThreadFactory("maclean-serial"))
    private val main = Handler(Looper.getMainLooper())

    fun launch(block: suspend () -> Unit): Future<*> = submit(executor, block)

    /** Runs storage/provider mutations in submission order without blocking UI or receiver threads. */
    fun launchSerial(block: suspend () -> Unit): Future<*> = submit(serialExecutor, block)

    fun onMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else main.post(block)
    }

    private fun submit(
        executor: java.util.concurrent.ExecutorService,
        block: suspend () -> Unit
    ): Future<*> = executor.submit {
        block.startCoroutine(object : Continuation<Unit> {
            override val context = EmptyCoroutineContext
            override fun resumeWith(result: Result<Unit>) {
                result.exceptionOrNull()?.printStackTrace()
            }
        })
    }

    private class NamedThreadFactory(private val prefix: String) : ThreadFactory {
        private val next = AtomicInteger(1)

        override fun newThread(task: Runnable): Thread = Thread(task, "$prefix-${next.getAndIncrement()}").apply {
            priority = Thread.NORM_PRIORITY - 1
        }
    }
}
