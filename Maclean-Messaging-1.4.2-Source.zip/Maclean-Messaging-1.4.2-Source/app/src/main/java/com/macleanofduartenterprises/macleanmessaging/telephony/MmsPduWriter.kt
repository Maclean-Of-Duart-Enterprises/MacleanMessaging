/* Maclean Messaging — SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanmessaging.telephony

import java.io.ByteArrayOutputStream

/**
 * Deterministic MM1 Send.req writer.
 *
 * The byte layout follows AOSP PduComposer: multipart/related uses the dedicated
 * start (0x8a) and related-type (0x89) parameters, while every Content-ID is an
 * RFC-style quoted string. Several MMSCs accept malformed multipart metadata but
 * silently deliver only the text part, so these details are transport-critical.
 */
object MmsPduWriter {
    data class Part(
        val mimeType: String,
        val name: String,
        val data: ByteArray,
        val utf8: Boolean = false,
        val contentId: String = "part"
    )

    fun encodeSendRequest(
        recipients: List<String>,
        body: String,
        media: List<Part>,
        requestDeliveryReport: Boolean,
        transactionId: String = System.currentTimeMillis().toString(16)
    ): ByteArray {
        require(recipients.isNotEmpty()) { "Enter at least one MMS recipient." }
        require(body.isNotEmpty() || media.isNotEmpty()) { "An MMS must contain text or media." }

        val out = ByteArrayOutputStream()
        out.write(X_MMS_MESSAGE_TYPE); out.write(MESSAGE_TYPE_SEND_REQ)
        out.write(X_MMS_TRANSACTION_ID); writeText(out, transactionId)
        out.write(X_MMS_VERSION); out.write(MMS_VERSION_1_2)
        out.write(X_MMS_FROM); out.write(1); out.write(FROM_INSERT_ADDRESS)
        recipients.forEach {
            out.write(X_MMS_TO)
            writeEncodedString(out, normalizeAddress(it))
        }
        out.write(X_MMS_MESSAGE_CLASS); out.write(MESSAGE_CLASS_PERSONAL)
        out.write(X_MMS_PRIORITY); out.write(PRIORITY_NORMAL)
        out.write(X_MMS_DELIVERY_REPORT); out.write(if (requestDeliveryReport) YES else NO)
        out.write(X_MMS_READ_REPORT); out.write(NO)

        val content = buildList {
            if (body.isNotEmpty()) add(
                Part("text/plain", "text.txt", body.toByteArray(Charsets.UTF_8), utf8 = true, contentId = "text")
            )
            addAll(media)
        }
        val smil = Part(
            "application/smil",
            "presentation.smil",
            buildSmil(content).toByteArray(Charsets.UTF_8),
            utf8 = true,
            contentId = "smil"
        )

        out.write(X_MMS_CONTENT_TYPE)
        val rootType = ByteArrayOutputStream().apply {
            write(WELL_KNOWN_MULTIPART_RELATED)
            write(PARAMETER_START); writeText(this, "<smil>")
            write(PARAMETER_RELATED_TYPE); writeText(this, "application/smil")
        }.toByteArray()
        writeValueLength(out, rootType.size.toLong())
        out.write(rootType)

        val parts = listOf(smil) + content
        writeUintvar(out, parts.size.toLong())
        parts.forEach { writePart(out, it) }
        return out.toByteArray()
    }

    private fun writePart(out: ByteArrayOutputStream, part: Part) {
        require(part.data.isNotEmpty()) { "${part.name} is empty." }
        val safeName = sanitizeName(part.name)
        val safeContentId = sanitizeContentId(part.contentId)
        val mimeType = part.mimeType.substringBefore(';').trim().lowercase()
            .ifBlank { "application/octet-stream" }

        val headers = ByteArrayOutputStream()
        val contentType = ByteArrayOutputStream().apply {
            val token = WELL_KNOWN_CONTENT_TYPES[mimeType]
            if (token == null) writeText(this, mimeType) else write(token or 0x80)
            write(PARAMETER_NAME); writeText(this, safeName)
            if (part.utf8) {
                write(PARAMETER_CHARSET)
                write(CHARSET_UTF8_SHORT_INTEGER)
            }
        }.toByteArray()
        writeValueLength(headers, contentType.size.toLong())
        headers.write(contentType)
        headers.write(HEADER_CONTENT_ID)
        writeQuotedString(headers, "<$safeContentId>")
        headers.write(HEADER_CONTENT_LOCATION)
        writeText(headers, safeName)

        val headerBytes = headers.toByteArray()
        writeUintvar(out, headerBytes.size.toLong())
        writeUintvar(out, part.data.size.toLong())
        out.write(headerBytes)
        out.write(part.data)
    }

    private fun normalizeAddress(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.contains('@')) return trimmed
        val number = buildString {
            trimmed.forEachIndexed { index, character ->
                if (character.isDigit() || character == '+' && index == 0) append(character)
            }
        }
        require(number.any(Char::isDigit)) { "Enter a valid MMS recipient." }
        return "$number/TYPE=PLMN"
    }

    private fun buildSmil(parts: List<Part>): String {
        val elements = parts.joinToString("") { part ->
            val source = xmlAttribute(sanitizeName(part.name))
            when {
                part.mimeType.startsWith("text/", true) -> "<text src=\"$source\" region=\"Text\"/>"
                part.mimeType.startsWith("image/", true) -> "<img src=\"$source\" region=\"Image\"/>"
                part.mimeType.startsWith("audio/", true) -> "<audio src=\"$source\"/>"
                part.mimeType.startsWith("video/", true) -> "<video src=\"$source\" region=\"Image\"/>"
                else -> "<ref src=\"$source\"/>"
            }
        }
        return "<smil><head><layout><root-layout width=\"320px\" height=\"480px\"/>" +
            "<region id=\"Image\" left=\"0\" top=\"0\" width=\"320px\" height=\"320px\"/>" +
            "<region id=\"Text\" left=\"0\" top=\"320px\" width=\"320px\" height=\"160px\"/>" +
            "</layout></head><body><par dur=\"5000ms\">$elements</par></body></smil>"
    }

    private fun sanitizeName(value: String): String = value.replace(Regex("[\\r\\n/\\\\]+"), "_")
        .take(100).ifBlank { "attachment" }

    private fun sanitizeContentId(value: String): String = value
        .replace(Regex("[<>\\r\\n\"]+"), "_").take(80).ifBlank { "part" }

    private fun xmlAttribute(value: String): String = value.replace("&", "&amp;")
        .replace("\"", "&quot;").replace("<", "&lt;").replace(">", "&gt;")

    private fun writeText(out: ByteArrayOutputStream, value: String) {
        val bytes = value.toByteArray(Charsets.UTF_8)
        if (bytes.firstOrNull()?.toInt()?.and(0xff)?.let { it > 127 } == true) out.write(127)
        out.write(bytes)
        out.write(0)
    }

    private fun writeQuotedString(out: ByteArrayOutputStream, value: String) {
        out.write(34)
        out.write(value.toByteArray(Charsets.UTF_8))
        out.write(0)
    }

    private fun writeEncodedString(out: ByteArrayOutputStream, value: String) {
        val text = value.toByteArray(Charsets.UTF_8)
        writeValueLength(out, text.size + 2L)
        out.write(CHARSET_UTF8_SHORT_INTEGER)
        out.write(text)
        out.write(0)
    }

    private fun writeValueLength(out: ByteArrayOutputStream, length: Long) {
        if (length < 31L) out.write(length.toInt()) else {
            out.write(31)
            writeUintvar(out, length)
        }
    }

    private fun writeUintvar(out: ByteArrayOutputStream, value: Long) {
        require(value >= 0L)
        var working = value
        val encoded = IntArray(10)
        var count = 0
        do {
            encoded[count++] = (working and 0x7f).toInt()
            working = working ushr 7
        } while (working > 0)
        for (index in count - 1 downTo 0) {
            out.write(encoded[index] or if (index == 0) 0 else 0x80)
        }
    }

    private val WELL_KNOWN_CONTENT_TYPES = mapOf(
        "text/html" to 0x02,
        "text/plain" to 0x03,
        "image/gif" to 0x1d,
        "image/jpeg" to 0x1e,
        "image/png" to 0x20,
        "application/vnd.wap.multipart.related" to 0x33
    )

    private const val X_MMS_MESSAGE_TYPE = 0x8c
    private const val X_MMS_TRANSACTION_ID = 0x98
    private const val X_MMS_VERSION = 0x8d
    private const val X_MMS_FROM = 0x89
    private const val X_MMS_TO = 0x97
    private const val X_MMS_MESSAGE_CLASS = 0x8a
    private const val X_MMS_DELIVERY_REPORT = 0x86
    private const val X_MMS_PRIORITY = 0x8f
    private const val X_MMS_READ_REPORT = 0x90
    private const val X_MMS_CONTENT_TYPE = 0x84
    private const val MESSAGE_TYPE_SEND_REQ = 0x80
    private const val MMS_VERSION_1_2 = 0x92
    private const val FROM_INSERT_ADDRESS = 0x81
    private const val MESSAGE_CLASS_PERSONAL = 0x80
    private const val PRIORITY_NORMAL = 0x81
    private const val YES = 0x80
    private const val NO = 0x81
    private const val WELL_KNOWN_MULTIPART_RELATED = 0xb3
    private const val PARAMETER_CHARSET = 0x81
    private const val PARAMETER_NAME = 0x85
    private const val PARAMETER_RELATED_TYPE = 0x89
    private const val PARAMETER_START = 0x8a
    private const val HEADER_CONTENT_LOCATION = 0x8e
    private const val HEADER_CONTENT_ID = 0xc0
    private const val CHARSET_UTF8_SHORT_INTEGER = 0xea
}
