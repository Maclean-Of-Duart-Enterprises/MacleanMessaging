/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.backup

import android.content.Context
import android.provider.Telephony
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream

object BackupCodec {
    const val FORMAT_VERSION = 1

    fun exportSms(context: Context, output: OutputStream) {
        val root = JSONObject()
        root.put("format", "maclean-messaging-backup")
        root.put("version", FORMAT_VERSION)
        val array = JSONArray()

        context.contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(
                Telephony.Sms.ADDRESS,
                Telephony.Sms.BODY,
                Telephony.Sms.DATE,
                Telephony.Sms.TYPE,
                Telephony.Sms.READ,
                Telephony.Sms.SUBSCRIPTION_ID
            ),
            null, null,
            "${Telephony.Sms.DATE} ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                array.put(JSONObject().apply {
                    put("address", c.getString(0))
                    put("body", c.getString(1))
                    put("date", c.getLong(2))
                    put("type", c.getInt(3))
                    put("read", c.getInt(4))
                    put("subscriptionId", c.getInt(5))
                })
            }
        }
        root.put("sms", array)
        output.write(root.toString(2).toByteArray(Charsets.UTF_8))
    }
}
