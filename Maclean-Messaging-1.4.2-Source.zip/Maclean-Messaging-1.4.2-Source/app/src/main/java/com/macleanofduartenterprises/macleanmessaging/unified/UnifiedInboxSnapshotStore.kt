/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 */

package com.macleanofduartenterprises.macleanmessaging.unified

import android.content.Context
import android.util.AtomicFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * App-private last-known inbox used only for immediate first paint after process restart. The
 * Android SMS/MMS provider and local email database remain authoritative and refresh this snapshot
 * in the background every time the inbox opens.
 */
object UnifiedInboxSnapshotStore {
    data class Snapshot(
        val emailEnabled: Boolean,
        val emailCount: Int,
        val conversations: List<UnifiedConversation>
    )

    fun load(context: Context): Snapshot? {
        val file = snapshotFile(context)
        if (!file.isFile) return null
        return runCatching {
            val root = JSONObject(file.readText(Charsets.UTF_8))
            check(root.optInt("schema", 0) == SCHEMA)
            val conversations = root.getJSONArray("conversations").let { array ->
                (0 until array.length()).map { index -> conversationFromJson(array.getJSONObject(index)) }
            }
            Snapshot(
                emailEnabled = root.optBoolean("emailEnabled", false),
                emailCount = root.optInt("emailCount", 0),
                conversations = conversations
            )
        }.getOrNull()
    }

    fun save(context: Context, snapshot: Snapshot) {
        val root = JSONObject()
            .put("schema", SCHEMA)
            .put("emailEnabled", snapshot.emailEnabled)
            .put("emailCount", snapshot.emailCount)
            .put("conversations", JSONArray().apply {
                snapshot.conversations.forEach { put(conversationToJson(it)) }
            })
        val atomic = AtomicFile(snapshotFile(context))
        val output = atomic.startWrite()
        try {
            output.write(root.toString().toByteArray(Charsets.UTF_8))
            output.fd.sync()
            atomic.finishWrite(output)
        } catch (error: Throwable) {
            atomic.failWrite(output)
            throw error
        }
    }

    private fun conversationToJson(value: UnifiedConversation): JSONObject = JSONObject()
        .put("stableId", value.stableId)
        .put("transport", value.transport.name)
        .put("title", value.title)
        .put("preview", value.preview)
        .put("timestamp", value.timestamp)
        .put("unreadCount", value.unreadCount)
        .put("pinned", value.pinned)
        .put("favorite", value.favorite)
        .put("archived", value.archived)
        .put("accountId", value.accountId)
        .put("hasSavedContact", value.hasSavedContact)
        .put("participants", JSONArray().apply {
            value.participants.forEach { participant ->
                put(JSONObject()
                    .put("id", participant.id)
                    .put("displayName", participant.displayName)
                    .put("address", participant.address)
                    .put("photoUri", participant.photoUri))
            }
        })

    private fun conversationFromJson(value: JSONObject): UnifiedConversation = UnifiedConversation(
        stableId = value.getString("stableId"),
        transport = CommunicationTransport.valueOf(value.getString("transport")),
        participants = value.getJSONArray("participants").let { array ->
            (0 until array.length()).map { index ->
                val participant = array.getJSONObject(index)
                UnifiedParticipant(
                    id = participant.getString("id"),
                    displayName = participant.optString("displayName").takeIf(String::isNotBlank),
                    address = participant.getString("address"),
                    photoUri = participant.optString("photoUri").takeIf(String::isNotBlank)
                )
            }
        },
        title = value.getString("title"),
        preview = value.optString("preview"),
        timestamp = value.getLong("timestamp"),
        unreadCount = value.optInt("unreadCount", 0),
        pinned = value.optBoolean("pinned", false),
        favorite = value.optBoolean("favorite", false),
        archived = value.optBoolean("archived", false),
        accountId = value.optString("accountId").takeIf(String::isNotBlank),
        hasSavedContact = value.optBoolean("hasSavedContact", false)
    )

    private fun snapshotFile(context: Context): File =
        File(context.filesDir, "performance/inbox-snapshot.json").apply { parentFile?.mkdirs() }

    private const val SCHEMA = 1
}
