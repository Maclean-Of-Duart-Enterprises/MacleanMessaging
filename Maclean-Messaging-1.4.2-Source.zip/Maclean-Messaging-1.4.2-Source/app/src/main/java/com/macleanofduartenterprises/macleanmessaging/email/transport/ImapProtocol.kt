/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 */

package com.macleanofduartenterprises.macleanmessaging.email.transport

import java.util.Base64

/** Android-free IMAP helpers so authentication and batched FETCH parsing are host-testable. */
internal object ImapProtocol {
    private val uidPattern = Regex("\\bUID\\s+(\\d+)", RegexOption.IGNORE_CASE)
    private val flagsPattern = Regex("\\bFLAGS\\s+\\(([^)]*)\\)", RegexOption.IGNORE_CASE)

    fun saslPlain(username: String, password: String): String {
        require(username.isNotBlank()) { "Email username is required." }
        require(password.isNotEmpty()) { "Email password is required." }
        require(username.none { it == '\u0000' } && password.none { it == '\u0000' }) {
            "Email credentials contain an invalid NUL character."
        }
        val payload = "\u0000$username\u0000$password".toByteArray(Charsets.UTF_8)
        return try {
            Base64.getEncoder().encodeToString(payload)
        } finally {
            payload.fill(0)
        }
    }

    fun base64Utf8(value: String): String {
        val bytes = value.toByteArray(Charsets.UTF_8)
        return try {
            Base64.getEncoder().encodeToString(bytes)
        } finally {
            bytes.fill(0)
        }
    }

    fun uidSet(uids: List<Long>): String {
        require(uids.isNotEmpty()) { "At least one UID is required." }
        require(uids.all { it > 0L }) { "IMAP UIDs must be positive." }
        return uids.distinct().joinToString(",")
    }

    fun uid(line: String): Long? = uidPattern.find(line)?.groupValues?.get(1)?.toLongOrNull()

    fun flags(line: String): Set<String> = flagsPattern.find(line)
        ?.groupValues
        ?.get(1)
        ?.split(' ')
        ?.filter(String::isNotBlank)
        ?.toSet()
        .orEmpty()
}
