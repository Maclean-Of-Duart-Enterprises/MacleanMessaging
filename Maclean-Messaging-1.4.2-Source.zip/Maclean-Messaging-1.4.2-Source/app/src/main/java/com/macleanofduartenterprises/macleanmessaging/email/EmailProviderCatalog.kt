/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.email

data class EmailProviderPreset(
    val id: String,
    val displayName: String,
    val domains: Set<String>,
    val incomingHost: String,
    val incomingPort: Int,
    val incomingSecurity: String,
    val outgoingHost: String,
    val outgoingPort: Int,
    val outgoingSecurity: String,
    val oauthAuthorizeEndpoint: String? = null,
    val oauthTokenEndpoint: String? = null,
    val oauthScopes: String? = null,
    val oauthPreferred: Boolean = false
)

object EmailProviderCatalog {
    val presets = listOf(
        EmailProviderPreset(
            "gmail", "Gmail", setOf("gmail.com", "googlemail.com"),
            "imap.gmail.com", 993, "TLS",
            "smtp.gmail.com", 587, "STARTTLS",
            "https://accounts.google.com/o/oauth2/v2/auth",
            "https://oauth2.googleapis.com/token",
            "openid email https://mail.google.com/ offline_access",
            true
        ),
        EmailProviderPreset(
            "microsoft", "Microsoft Outlook / Microsoft 365",
            setOf("outlook.com","hotmail.com","live.com","msn.com"),
            "outlook.office365.com", 993, "TLS",
            "smtp.office365.com", 587, "STARTTLS",
            "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
            "https://login.microsoftonline.com/common/oauth2/v2.0/token",
            "openid email offline_access https://outlook.office.com/IMAP.AccessAsUser.All https://outlook.office.com/SMTP.Send",
            true
        ),
        EmailProviderPreset(
            "yahoo", "Yahoo Mail", setOf("yahoo.com","ymail.com"),
            "imap.mail.yahoo.com", 993, "TLS",
            "smtp.mail.yahoo.com", 465, "TLS"
        ),
        EmailProviderPreset(
            "fastmail", "Fastmail", setOf("fastmail.com","fastmail.fm"),
            "imap.fastmail.com", 993, "TLS",
            "smtp.fastmail.com", 465, "TLS"
        )
    )

    fun detect(address: String): EmailProviderPreset? {
        val domain = address.substringAfterLast("@", "").lowercase()
        return presets.firstOrNull { domain in it.domains }
    }
}
