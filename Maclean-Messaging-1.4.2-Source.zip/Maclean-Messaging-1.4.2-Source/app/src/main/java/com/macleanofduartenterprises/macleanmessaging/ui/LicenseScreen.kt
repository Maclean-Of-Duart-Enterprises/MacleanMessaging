/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 */

package com.macleanofduartenterprises.macleanmessaging.ui

import android.content.Context

fun readLicense(context: Context): String =
    context.assets.open("agpl-3.0.txt").bufferedReader().use { it.readText() }
