/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.spam

/**
 * Local-only heuristic scorer. No message content leaves the device.
 * Replace or augment with a user-trainable local model later.
 */
object SpamScorer {
    fun score(sender: String, body: String): Int {
        var score = 0
        val lower = body.lowercase()
        val triggers = listOf(
            "urgent", "gift card", "verify your account", "crypto",
            "prize", "winner", "click this link", "final notice"
        )
        score += triggers.count { lower.contains(it) } * 15
        if (Regex("""https?://""").containsMatchIn(lower)) score += 10
        if (sender.length <= 6 && sender.all(Char::isDigit)) score += 5
        return score.coerceIn(0, 100)
    }
}
