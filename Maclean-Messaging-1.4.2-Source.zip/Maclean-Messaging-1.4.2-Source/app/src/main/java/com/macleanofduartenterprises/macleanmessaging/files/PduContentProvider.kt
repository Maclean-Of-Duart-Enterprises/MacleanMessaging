/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 */

package com.macleanofduartenterprises.macleanmessaging.files

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import java.io.File
import java.io.FileNotFoundException

/** Narrow provider for outgoing PDUs and SmsManager's incoming-MMS download destination. */
class PduContentProvider : ContentProvider() {
    override fun onCreate(): Boolean = true

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        val writable = mode in WRITABLE_MODES
        if (mode != "r" && !writable) throw FileNotFoundException("Unsupported file mode: $mode")
        val file = resolve(uri, requireExisting = !writable)
        if (!writable) return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        // Only the dedicated carrier-download directory is writable. Other cached attachments and
        // outgoing PDUs remain read-only even if a caller obtains a URI grant.
        val incomingRoot = File(requireNotNull(context).filesDir, "incoming-mms").canonicalFile
        if (!file.path.startsWith(incomingRoot.path + File.separator)) {
            throw FileNotFoundException("Writable path is not an MMS download destination")
        }
        file.parentFile?.mkdirs()
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.parseMode(mode))
    }

    override fun getType(uri: Uri): String {
        val extension = uri.lastPathSegment?.substringAfterLast('.', "")?.lowercase().orEmpty()
        return when (extension) {
            "pdu" -> "application/vnd.wap.mms-message"
            "ogg", "opus" -> "audio/ogg"
            "m4a" -> "audio/mp4"
            "mp3" -> "audio/mpeg"
            "wav" -> "audio/wav"
            "flac" -> "audio/flac"
            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
                ?: "application/octet-stream"
        }
    }

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor {
        val file = resolve(uri)
        val requested = projection ?: arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        return MatrixCursor(requested).apply {
            addRow(requested.map {
                when (it) {
                    OpenableColumns.DISPLAY_NAME -> file.name
                    OpenableColumns.SIZE -> file.length()
                    else -> null
                }
            })
        }
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0

    private fun resolve(uri: Uri, requireExisting: Boolean = true): File {
        val appContext = requireNotNull(context)
        val segments = uri.pathSegments.map(Uri::decode)
        val explicitRoot = when (segments.firstOrNull()) {
            ROOT_CACHE -> appContext.cacheDir
            ROOT_FILES -> appContext.filesDir
            else -> null
        }
        if (explicitRoot != null) {
            return resolveUnder(explicitRoot, segments.drop(1).joinToString(File.separator), requireExisting)
        }

        // Backward compatibility for temporary URIs created before 1.2.13. Writable carrier
        // destinations always belong under files/incoming-mms; older generic read URIs are
        // resolved only when the file actually exists, avoiding cache/files ambiguity.
        val relative = segments.joinToString(File.separator)
        if (!requireExisting && relative.startsWith("incoming-mms${File.separator}")) {
            return resolveUnder(appContext.filesDir, relative, false)
        }
        for (root in listOf(appContext.cacheDir, appContext.filesDir)) {
            runCatching { resolveUnder(root, relative, true) }.getOrNull()?.let { return it }
        }
        throw FileNotFoundException(relative)
    }

    private fun resolveUnder(root: File, relative: String, requireExisting: Boolean): File {
        if (relative.isBlank()) throw FileNotFoundException(relative)
        val canonicalRoot = root.canonicalFile
        val file = File(canonicalRoot, relative).canonicalFile
        if (!file.path.startsWith(canonicalRoot.path + File.separator) || (requireExisting && !file.isFile)) {
            throw FileNotFoundException(relative)
        }
        return file
    }

    companion object {
        fun uriFor(context: Context, file: File): Uri {
            val canonical = file.canonicalFile
            val (rootName, root) = when {
                canonical.path.startsWith(context.cacheDir.canonicalPath + File.separator) ->
                    ROOT_CACHE to context.cacheDir.canonicalFile
                canonical.path.startsWith(context.filesDir.canonicalPath + File.separator) ->
                    ROOT_FILES to context.filesDir.canonicalFile
                else -> throw IllegalArgumentException("File is outside app storage")
            }
            val relative = canonical.relativeTo(root).path.replace(File.separatorChar, '/')
            return Uri.Builder().scheme("content").authority(context.packageName + ".files")
                .encodedPath("/" + (listOf(rootName) + relative.split('/')).joinToString("/") { Uri.encode(it) })
                .build()
        }

        private const val ROOT_CACHE = "cache"
        private const val ROOT_FILES = "files"
        private val WRITABLE_MODES = setOf("w", "wt", "wa", "rw", "rwt")
    }
}
