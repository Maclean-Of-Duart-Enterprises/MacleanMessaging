/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.system

import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.provider.Settings

object DefaultSmsRole {
    /** RoleManager is authoritative on every Android version supported by this app. */
    fun isDefault(context: Context): Boolean {
        val roleManager = context.getSystemService(RoleManager::class.java)
        return if (roleManager?.isRoleAvailable(RoleManager.ROLE_SMS) == true) {
            roleManager.isRoleHeld(RoleManager.ROLE_SMS)
        } else {
            // Defensive fallback for devices whose vendor framework does not expose ROLE_SMS.
            Telephony.Sms.getDefaultSmsPackage(context) == context.packageName
        }
    }

    fun isAvailable(context: Context): Boolean =
        context.getSystemService(RoleManager::class.java)?.isRoleAvailable(RoleManager.ROLE_SMS) == true

    fun requestIntent(context: Context): Intent {
        val roleManager = context.getSystemService(RoleManager::class.java)
        return roleManager.createRequestRoleIntent(RoleManager.ROLE_SMS)
    }

    /** Returns true only when Android's role chooser was launched. */
    fun request(activity: Activity, requestCode: Int): Boolean {
        if (isDefault(activity)) return false
        if (!isAvailable(activity)) return false
        activity.startActivityForResult(requestIntent(activity), requestCode)
        return true
    }

    /** Opens Android's default-app page when the role is held but its provider app-op is stale. */
    fun openDefaultAppSettings(activity: Activity) {
        val intent = Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)
        runCatching { activity.startActivity(intent) }
            .getOrElse { activity.startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }
}
