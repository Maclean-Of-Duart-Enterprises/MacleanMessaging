/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.unified

enum class CommunicationTransport {
    SMS,
    MMS,
    EMAIL
}

data class UnifiedParticipant(
    val id: String,
    val displayName: String?,
    val address: String,
    val photoUri: String? = null
)

data class UnifiedConversation(
    val stableId: String,
    val transport: CommunicationTransport,
    val participants: List<UnifiedParticipant>,
    val title: String,
    val preview: String,
    val timestamp: Long,
    val unreadCount: Int,
    val pinned: Boolean = false,
    val favorite: Boolean = false,
    val archived: Boolean = false,
    val accountId: String? = null,
    val hasSavedContact: Boolean = false
)

data class UnifiedMessage(
    val stableId: String,
    val conversationId: String,
    val transport: CommunicationTransport,
    val sender: UnifiedParticipant,
    val recipients: List<UnifiedParticipant>,
    val subject: String? = null,
    val body: String,
    val timestamp: Long,
    val incoming: Boolean,
    val unread: Boolean,
    val attachments: List<UnifiedAttachment> = emptyList(),
    val accountId: String? = null
)

data class UnifiedAttachment(
    val id: String,
    val fileName: String?,
    val mimeType: String,
    val sizeBytes: Long?,
    val contentUri: String?
)
