/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.email.compose

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.macleanofduartenterprises.macleanmessaging.files.PduContentProvider
import com.macleanofduartenterprises.macleanmessaging.data.LocalDatabase
import com.macleanofduartenterprises.macleanmessaging.email.data.*
import com.macleanofduartenterprises.macleanmessaging.email.transport.EmailDraft
import com.macleanofduartenterprises.macleanmessaging.email.transport.SmtpTransport
import org.json.JSONArray
import java.security.MessageDigest
import java.util.UUID
import java.io.File

class EmailComposeCoordinator(private val context:Context){
    private val db=LocalDatabase.get(context)
    suspend fun availableFromAccounts()=db.emailAccountDao().enabled()
    suspend fun initialFromAccount(replyAccountId:String?=null):EmailAccountEntity?{
        if(replyAccountId!=null)db.emailAccountDao().get(replyAccountId)?.takeIf{it.enabled}?.let{return it}
        return db.emailAccountDao().defaultSendAccount()?:db.emailAccountDao().enabled().firstOrNull()
    }

    suspend fun send(
        fromAccountId:String,
        draft:EmailDraft,
        mode:ComposeMode=ComposeMode.NEW,
        sourceMessageId:String?=null
    ):Result<String>{
        val account=db.emailAccountDao().get(fromAccountId)
            ?:return Result.failure(IllegalArgumentException("Email account was removed."))
        if(!account.enabled)return Result.failure(IllegalStateException("Email account is disabled."))

        val source=sourceMessageId?.let(db.emailMessageDao()::get)
        val replySource=source?.takeIf { mode==ComposeMode.REPLY || mode==ComposeMode.REPLY_ALL }
        val domain=account.emailAddress.substringAfter('@',"macleanmessaging.local")
            .filter { it.isLetterOrDigit() || it=='.' || it=='-' }
            .ifBlank { "macleanmessaging.local" }
        // Snapshot attachments before SMTP. Sent copies must survive draft/Outbox removal.
        val mediaDir = File(context.filesDir, "sent-email-media/${UUID.randomUUID()}")
        val savedAttachments = try {
            draft.attachmentUris.mapIndexed { index, value ->
                val uri = Uri.parse(value)
                val name = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) it.getString(0) else null
                } ?: uri.lastPathSegment ?: "attachment"
                val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
                mediaDir.mkdirs()
                val file = File(mediaDir, "$index-${name.replace(Regex("[^\\p{L}\\p{N}._ -]"), "_").takeLast(140)}")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    file.outputStream().use { output ->
                        val buffer = ByteArray(32 * 1024); var total = 0L
                        while (true) { val size = input.read(buffer); if (size < 0) break
                            total += size; require(total <= 50L * 1024 * 1024) { "Attachment exceeds the 50 MiB local limit." }
                            output.write(buffer, 0, size)
                        }
                    }
                } ?: error("Cannot read attachment: $name")
                Triple(file, name, mime)
            }
        } catch (error: Exception) {
            mediaDir.listFiles()?.filter(File::isFile)?.forEach(File::delete); mediaDir.delete()
            return Result.failure(error)
        }
        val outgoing=draft.copy(
            attachmentUris = savedAttachments.map { PduContentProvider.uriFor(context, it.first).toString() },
            messageId=draft.messageId ?: "${UUID.randomUUID()}@$domain",
            inReplyTo=replySource?.stableId?.takeIf { '@' in it },
            references=replySource?.stableId?.takeIf { '@' in it }?.let(::listOf).orEmpty()
        )
        val result=SmtpTransport(context).send(account,outgoing)
        if(result.isSuccess){
            val id=result.getOrThrow().trim().trim('<','>')
            val now=System.currentTimeMillis()
            val threadId=replySource?.threadId
                ?:stableThreadId(account.id,outgoing.subject,outgoing.to+outgoing.cc+outgoing.bcc+account.emailAddress)
            db.emailMessageDao().upsert(EmailMessageEntity(
                stableId=id,accountId=account.id,threadId=threadId,remoteMessageId=null,
                sender=account.emailAddress,recipientsJson=JSONArray(outgoing.to+outgoing.cc+outgoing.bcc).toString(),
                subject=outgoing.subject,bodyText=outgoing.plainTextBody,bodyHtml=null,timestamp=now,
                incoming=false,unread=false,folder="SENT",attachmentCount=outgoing.attachmentUris.size
            ))
            db.emailAttachmentDao().upsertAll(savedAttachments.map { (file, name, mime) ->
                EmailAttachmentEntity(UUID.randomUUID().toString(), id, account.id, name, mime, file.length(), file.absolutePath)
            })
            val existing=db.emailThreadDao().get(threadId)
            db.emailThreadDao().upsert(EmailThreadEntity(
                stableId=threadId,accountId=account.id,remoteThreadId=existing?.remoteThreadId,subject=outgoing.subject,
                participantsJson=existing?.participantsJson?:JSONArray(outgoing.to+outgoing.cc+outgoing.bcc).toString(),
                preview=outgoing.plainTextBody.replace(Regex("\\s+")," ").take(240),
                timestamp=now,unreadCount=existing?.unreadCount?:0,
                pinned=existing?.pinned?:false,favorite=existing?.favorite?:false,archived=false
            ))
        } else {
            mediaDir.listFiles()?.filter(File::isFile)?.forEach(File::delete); mediaDir.delete()
        }
        return result
    }

    private fun stableThreadId(accountId:String,subject:String,recipients:List<String>):String{
        val s=subject.replace(Regex("(?i)^\\s*((re|fw|fwd):\\s*)+"),"").trim().lowercase()
        val p=recipients.map{it.trim().lowercase()}.sorted().joinToString("|")
        return MessageDigest.getInstance("SHA-256").digest("$accountId|$s|$p".toByteArray())
            .joinToString(""){"%02x".format(it)}.take(32)
    }
}
