/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 */

package com.macleanofduartenterprises.macleanmessaging.data

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.Telephony
import android.text.Html
import android.util.Log
import android.os.SystemClock
import android.webkit.MimeTypeMap
import com.macleanofduartenterprises.macleanmessaging.unified.CommunicationTransport
import com.macleanofduartenterprises.macleanmessaging.telephony.LocalMmsAttachmentStore
import java.io.File
import java.nio.charset.Charset

data class DeviceAttachment(
    val partId: Long,
    val mimeType: String,
    val fileName: String,
    val contentUri: String,
    val sizeBytes: Long?
)

data class DeviceMessage(
    val id: Long,
    val threadId: Long,
    val transport: CommunicationTransport,
    val address: String,
    val body: String,
    val date: Long,
    val incoming: Boolean,
    val read: Boolean,
    val attachments: List<DeviceAttachment> = emptyList(),
    /** False only for the lightweight MMS header shown while parts load in the background. */
    val contentReady: Boolean = true
) {
    val stableId: String get() = "${transport.name.lowercase()}:$id"
}

data class DeviceConversation(
    val threadId: Long,
    val latest: DeviceMessage,
    val unreadCount: Int
)

/** Reads and manages the system SMS and MMS stores used by the default SMS app. */
class DeviceMessageRepository(private val context: Context) {
    /**
     * Builds lightweight thread summaries directly from the provider cursors. The older approach
     * materialized every SMS, every MMS part, and every MMS address before it could show one row;
     * this path only hydrates the newest MMS in each conversation.
     */
    fun conversations(): List<DeviceConversation> {
        cachedConversations()?.let { return it }
        val summaries = linkedMapOf<Long, ConversationSummary>()
        val sms = runCatching { scanSmsConversations(summaries) }
            .onFailure { Log.e(TAG, "SMS conversation scan failed", it) }
        val mms = runCatching { scanMmsConversations(summaries) }
            .onFailure { Log.e(TAG, "MMS conversation scan failed; preserving SMS inbox", it) }
        if (sms.isFailure && mms.isFailure) throw sms.exceptionOrNull() ?: mms.exceptionOrNull()!!
        val latest = summaries.mapNotNull { (threadId, summary) ->
            summary.latest?.let { threadId to it }
        }
        val hydratedMms = hydrateMmsMessages(latest.mapNotNull { (_, item) ->
            item.takeIf { it.transport == CommunicationTransport.MMS }
        }).associateBy(DeviceMessage::stableId)
        return latest.map { (threadId, newest) ->
            DeviceConversation(
                threadId,
                hydratedMms[newest.stableId] ?: newest,
                summaries.getValue(threadId).unreadCount
            )
        }.sortedByDescending { it.latest.date }.also(::cacheConversations)
    }

    /** Loads the complete mixed SMS/MMS history off the UI thread for a recycled conversation list. */
    fun thread(threadId: Long): List<DeviceMessage> {
        cachedThread(threadId)?.let { return it }
        return hydrateThread(threadId, threadHeaders(threadId))
    }

    /**
     * Loads every SMS and MMS row but deliberately leaves MMS parts unexpanded. This lets a long
     * conversation paint immediately while attachment, voice, and image metadata are hydrated on
     * a second background pass. No paging or message limit is applied.
     */
    fun threadHeaders(threadId: Long): List<DeviceMessage> {
        cachedThread(threadId)?.let { return it }
        val sms = runCatching { loadSms(threadId) }
            .onFailure { Log.e(TAG, "SMS thread $threadId failed", it) }
        val mms = runCatching { loadMmsHeaders(threadId) }
            .onFailure { Log.e(TAG, "MMS headers for thread $threadId failed; preserving SMS messages", it) }
        if (sms.isFailure && mms.isFailure) throw sms.exceptionOrNull() ?: mms.exceptionOrNull()!!
        return (sms.getOrDefault(emptyList()) + mms.getOrDefault(emptyList()))
            .sortedBy(DeviceMessage::date)
            .also { value ->
                if (value.none { !it.contentReady }) cacheThread(threadId, value)
            }
    }

    /** Completes the second phase and caches the authoritative full thread. */
    fun hydrateThread(threadId: Long, headers: List<DeviceMessage>): List<DeviceMessage> {
        cachedThread(threadId)?.let { return it }
        val hydrated = hydrateMmsMessages(headers.filter { it.transport == CommunicationTransport.MMS })
            .associateBy(DeviceMessage::stableId)
        return headers.map { hydrated[it.stableId] ?: it }
            .sortedBy(DeviceMessage::date)
            .also { cacheThread(threadId, it) }
    }

    fun delete(message: DeviceMessage): Int {
        val uri = when (message.transport) {
            CommunicationTransport.MMS -> ContentUris.withAppendedId(Telephony.Mms.CONTENT_URI, message.id)
            else -> ContentUris.withAppendedId(Telephony.Sms.CONTENT_URI, message.id)
        }
        return try {
            context.contentResolver.delete(uri, null, null)
        } finally {
            invalidateCaches(message.threadId)
            if (message.transport == CommunicationTransport.MMS) {
                LocalMmsAttachmentStore.deleteMessage(context, message.id)
            }
        }
    }

    /** Marks provider-backed SMS/MMS rows read without reloading their bodies or attachments. */
    fun markRead(messages: Collection<DeviceMessage>): Int = setRead(messages, true)

    /** Marks provider-backed SMS/MMS rows unread while keeping them seen to avoid duplicate alerts. */
    fun markUnread(messages: Collection<DeviceMessage>): Int = setRead(messages, false)

    private fun setRead(messages: Collection<DeviceMessage>, read: Boolean): Int {
        var updated = 0
        messages.distinctBy(DeviceMessage::stableId)
            .groupBy(DeviceMessage::transport)
            .forEach { (transport, group) ->
                group.map(DeviceMessage::id).chunked(READ_UPDATE_CHUNK_SIZE).forEach { ids ->
                    val placeholders = ids.joinToString(",") { "?" }
                    val args = ids.map(Long::toString).toTypedArray()
                    val (uri, idColumn, values) = when (transport) {
                        CommunicationTransport.MMS -> Triple(
                            Telephony.Mms.CONTENT_URI,
                            Telephony.Mms._ID,
                            ContentValues().apply {
                                put(Telephony.Mms.READ, if (read) 1 else 0)
                                put(Telephony.Mms.SEEN, 1)
                            }
                        )
                        else -> Triple(
                            Telephony.Sms.CONTENT_URI,
                            Telephony.Sms._ID,
                            ContentValues().apply {
                                put(Telephony.Sms.READ, if (read) 1 else 0)
                                put(Telephony.Sms.SEEN, 1)
                            }
                        )
                    }
                    updated += context.contentResolver.update(
                        uri,
                        values,
                        "$idColumn IN ($placeholders)",
                        args
                    )
                }
            }
        messages.map(DeviceMessage::threadId).distinct().forEach(::invalidateCaches)
        return updated
    }

    fun deleteThread(threadId: Long): Int {
        val args = arrayOf(threadId.toString())
        val mmsIds = runCatching { mmsIdsForThread(threadId) }.getOrDefault(emptyList())
        val sms = runCatching { context.contentResolver.delete(
            Telephony.Sms.CONTENT_URI,
            "${Telephony.Sms.THREAD_ID}=?",
            args
        ) }
        val mms = runCatching { context.contentResolver.delete(
            Telephony.Mms.CONTENT_URI,
            "${Telephony.Mms.THREAD_ID}=?",
            args
        ) }
        mms.onSuccess { mmsIds.forEach { LocalMmsAttachmentStore.deleteMessage(context, it) } }
        if (sms.isFailure && mms.isFailure) throw sms.exceptionOrNull() ?: mms.exceptionOrNull()!!
        invalidateCaches(threadId)
        return sms.getOrDefault(0) + mms.getOrDefault(0)
    }

    /** Copies a provider-owned MMS part into the app cache for safe external viewing. */
    fun materializeAttachment(attachment: DeviceAttachment): File {
        val directory = File(context.cacheDir, "mms-parts").apply { mkdirs() }
        val safeName = attachment.fileName
            .replace(Regex("[^\\p{L}\\p{N}._ -]+"), "_")
            .trim()
            .take(80)
            .ifBlank {
                val extension = MimeTypeMap.getSingleton()
                    .getExtensionFromMimeType(attachment.mimeType)
                    ?.let { ".$it" }
                    .orEmpty()
                "attachment$extension"
            }
        val target = File(File(directory, attachment.partId.toString()).apply { mkdirs() }, safeName)
        context.contentResolver.openInputStream(Uri.parse(attachment.contentUri))?.use { input ->
            target.outputStream().use(input::copyTo)
        } ?: error("Android could not open this MMS attachment.")
        return target
    }

    private fun scanSmsConversations(summaries: MutableMap<Long, ConversationSummary>) {
        context.contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(
                Telephony.Sms._ID,
                Telephony.Sms.THREAD_ID,
                Telephony.Sms.ADDRESS,
                Telephony.Sms.BODY,
                Telephony.Sms.DATE,
                Telephony.Sms.READ,
                Telephony.Sms.TYPE
            ),
            null,
            null,
            "${Telephony.Sms.DATE} DESC"
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                val threadId = cursor.getLong(1)
                val summary = summaries.getOrPut(threadId) { ConversationSummary() }
                val read = cursor.getInt(5) != 0
                if (!read) summary.unreadCount++
                val date = cursor.getLong(4)
                if (summary.latest == null || date > summary.latest!!.date) {
                    summary.latest = DeviceMessage(
                        id = cursor.getLong(0),
                        threadId = threadId,
                        transport = CommunicationTransport.SMS,
                        address = cursor.getString(2).orEmpty(),
                        body = cursor.getString(3).orEmpty(),
                        date = date,
                        read = read,
                        incoming = cursor.getInt(6) == Telephony.Sms.MESSAGE_TYPE_INBOX
                    )
                }
            }
        }
    }

    private fun scanMmsConversations(summaries: MutableMap<Long, ConversationSummary>) {
        context.contentResolver.query(
            Telephony.Mms.CONTENT_URI,
            arrayOf(
                Telephony.Mms._ID,
                Telephony.Mms.THREAD_ID,
                Telephony.Mms.DATE,
                Telephony.Mms.READ,
                Telephony.Mms.MESSAGE_BOX,
                Telephony.Mms.SUBJECT
            ),
            null,
            null,
            "${Telephony.Mms.DATE} DESC"
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                val threadId = cursor.getLong(1)
                val summary = summaries.getOrPut(threadId) { ConversationSummary() }
                val read = cursor.getInt(3) != 0
                if (!read) summary.unreadCount++
                val date = normalizeMmsDate(cursor.getLong(2))
                if (summary.latest == null || date > summary.latest!!.date) {
                    summary.latest = DeviceMessage(
                        id = cursor.getLong(0),
                        threadId = threadId,
                        transport = CommunicationTransport.MMS,
                        address = "",
                        body = cursor.getString(5).orEmpty(),
                        date = date,
                        read = read,
                        incoming = cursor.getInt(4) == Telephony.Mms.MESSAGE_BOX_INBOX
                    )
                }
            }
        }
    }

    private fun mmsConversationPreview(messageId: Long, subject: String): String {
        val textParts = mutableListOf<String>()
        var attachmentCount = 0
        var hasVoiceMessage = false
        context.contentResolver.query(
            Uri.parse("content://mms/part"),
            arrayOf("_id", "ct", "text", "chset", "name", "fn", "cl"),
            "mid=?",
            arrayOf(messageId.toString()),
            "_id ASC"
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                val type = cursor.getString(1).orEmpty().substringBefore(';').trim().lowercase()
                if (type == "text/plain" || type == "text/html") {
                    val partId = cursor.getLong(0)
                    val inline = cursor.getString(2)
                    val charset = mmsCharset(if (cursor.isNull(3)) null else cursor.getInt(3))
                    val value = inline?.takeIf(String::isNotEmpty) ?: runCatching {
                        context.contentResolver.openInputStream(Uri.parse("content://mms/part/$partId"))
                            ?.use { it.readBytes().toString(charset) }
                    }.getOrNull()
                    value?.takeIf(String::isNotBlank)?.let {
                        textParts += if (type == "text/html") {
                            Html.fromHtml(it, Html.FROM_HTML_MODE_LEGACY).toString().trim()
                        } else it
                    }
                } else if (type != "application/smil") {
                    attachmentCount++
                    val name = sequenceOf(4, 5, 6)
                        .mapNotNull { index -> cursor.getString(index)?.takeIf(String::isNotBlank) }
                        .firstOrNull()
                        .orEmpty()
                    if (type in setOf("audio/ogg", "audio/opus", "application/ogg", "audio/mp4") &&
                        name.contains("Voice Message", ignoreCase = true)
                    ) hasVoiceMessage = true
                }
            }
        }
        LocalMmsAttachmentStore.list(context, messageId).forEach { part ->
            attachmentCount++
            if (part.mimeType in setOf("audio/ogg", "audio/opus", "application/ogg", "audio/mp4") &&
                part.fileName.contains("Voice Message", ignoreCase = true)
            ) hasVoiceMessage = true
        }
        return listOf(subject, textParts.distinct().joinToString("\n"))
            .filter(String::isNotBlank)
            .distinct()
            .joinToString("\n")
            .ifBlank {
                if (hasVoiceMessage) "🎙 Voice message"
                else if (attachmentCount == 0) "[MMS message]"
                else "[MMS with $attachmentCount attachment${if (attachmentCount == 1) "" else "s"}]"
            }
    }

    private fun normalizeMmsDate(value: Long): Long =
        if (value < 1_000_000_000_000L) value * 1000L else value

    private fun loadSms(threadId: Long?): List<DeviceMessage> {
        val out = mutableListOf<DeviceMessage>()
        context.contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(
                Telephony.Sms._ID,
                Telephony.Sms.THREAD_ID,
                Telephony.Sms.ADDRESS,
                Telephony.Sms.BODY,
                Telephony.Sms.DATE,
                Telephony.Sms.READ,
                Telephony.Sms.TYPE
            ),
            threadId?.let { "${Telephony.Sms.THREAD_ID}=?" },
            threadId?.let { arrayOf(it.toString()) },
            "${Telephony.Sms.DATE} ASC"
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                out += DeviceMessage(
                    id = cursor.getLong(0),
                    threadId = cursor.getLong(1),
                    transport = CommunicationTransport.SMS,
                    address = cursor.getString(2).orEmpty(),
                    body = cursor.getString(3).orEmpty(),
                    date = cursor.getLong(4),
                    read = cursor.getInt(5) != 0,
                    incoming = cursor.getInt(6) == Telephony.Sms.MESSAGE_TYPE_INBOX
                )
            }
        }
        return out
    }

    private fun loadMmsHeaders(threadId: Long?): List<DeviceMessage> {
        val out = mutableListOf<DeviceMessage>()
        context.contentResolver.query(
            Telephony.Mms.CONTENT_URI,
            arrayOf(
                Telephony.Mms._ID,
                Telephony.Mms.THREAD_ID,
                Telephony.Mms.DATE,
                Telephony.Mms.READ,
                Telephony.Mms.MESSAGE_BOX,
                Telephony.Mms.SUBJECT
            ),
            threadId?.let { "${Telephony.Mms.THREAD_ID}=?" },
            threadId?.let { arrayOf(it.toString()) },
            "${Telephony.Mms.DATE} ASC"
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                val id = cursor.getLong(0)
                val incoming = cursor.getInt(4) == Telephony.Mms.MESSAGE_BOX_INBOX
                val subject = cursor.getString(5).orEmpty()
                out += DeviceMessage(
                    id = id,
                    threadId = cursor.getLong(1),
                    transport = CommunicationTransport.MMS,
                    address = "",
                    body = subject.ifBlank { "[MMS content loading…]" },
                    date = normalizeMmsDate(cursor.getLong(2)),
                    read = cursor.getInt(3) != 0,
                    incoming = incoming,
                    contentReady = false
                )
            }
        }
        return out
    }

    private fun hydrateMmsMessages(headers: List<DeviceMessage>): List<DeviceMessage> =
        headers.map { header ->
            runCatching {
                val parts = mmsParts(header.id)
                val subject = header.body.takeUnless { it == "[MMS content loading…]" }.orEmpty()
                val visibleText = listOf(subject, parts.text)
                    .filter(String::isNotBlank)
                    .distinct()
                    .joinToString("\n")
                    .ifBlank {
                        if (parts.attachments.isEmpty()) "[MMS message]"
                        else "[MMS with ${parts.attachments.size} attachment${if (parts.attachments.size == 1) "" else "s"}]"
                    }
                header.copy(
                    address = mmsAddress(header.id, header.incoming),
                    body = visibleText,
                    attachments = parts.attachments,
                    contentReady = true
                )
            }.onFailure { Log.e(TAG, "Could not hydrate mms:${header.id}", it) }
                .getOrElse {
                    header.copy(
                        body = header.body.takeUnless { value -> value == "[MMS content loading…]" }
                            ?: "[MMS content unavailable]",
                        contentReady = true
                    )
                }
        }

    private fun mmsParts(messageId: Long): MmsParts {
        val textParts = mutableListOf<String>()
        val attachments = mutableListOf<DeviceAttachment>()
        context.contentResolver.query(
            Uri.parse("content://mms/part"),
            arrayOf("_id", "ct", "text", "name", "fn", "cl", "chset"),
            "mid=?",
            arrayOf(messageId.toString()),
            "_id ASC"
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                val partId = cursor.getLong(0)
                val type = cursor.getString(1).orEmpty().substringBefore(';').trim().lowercase()
                val partUri = Uri.parse("content://mms/part/$partId")
                if (type == "text/plain" || type == "text/html") {
                    val inline = cursor.getString(2)
                    val charset = mmsCharset(if (cursor.isNull(6)) null else cursor.getInt(6))
                    val value = inline?.takeIf(String::isNotEmpty) ?: runCatching {
                        context.contentResolver.openInputStream(partUri)
                            ?.use { it.readBytes().toString(charset) }
                    }.getOrNull()
                    value?.takeIf(String::isNotBlank)?.let {
                        textParts += if (type == "text/html") {
                            Html.fromHtml(it, Html.FROM_HTML_MODE_LEGACY).toString().trim()
                        } else it
                    }
                } else if (type != "application/smil") {
                    val name = cursor.getString(3)?.takeIf(String::isNotBlank)
                        ?: cursor.getString(4)?.takeIf(String::isNotBlank)
                        ?: cursor.getString(5)?.takeIf(String::isNotBlank)
                        ?: defaultAttachmentName(partId, type)
                    attachments += DeviceAttachment(
                        partId = partId,
                        mimeType = type.ifBlank { "application/octet-stream" },
                        fileName = name,
                        contentUri = partUri.toString(),
                        // Opening every part descriptor while a conversation loads caused visible
                        // storage bursts. The exact byte count is optional and is resolved only by
                        // operations that actually read or save the part.
                        sizeBytes = null
                    )
                }
            }
        }
        LocalMmsAttachmentStore.list(context, messageId).forEach { part ->
            attachments += DeviceAttachment(
                partId = part.stableId,
                mimeType = part.mimeType,
                fileName = part.fileName,
                contentUri = part.contentUri,
                sizeBytes = part.sizeBytes
            )
        }
        return MmsParts(textParts.distinct().joinToString("\n"), attachments)
    }

    private fun mmsIdsForThread(threadId: Long): List<Long> {
        val ids = mutableListOf<Long>()
        context.contentResolver.query(
            Telephony.Mms.CONTENT_URI,
            arrayOf(Telephony.Mms._ID),
            "${Telephony.Mms.THREAD_ID}=?",
            arrayOf(threadId.toString()),
            null
        )?.use { cursor -> while (cursor.moveToNext()) ids += cursor.getLong(0) }
        return ids
    }

    private fun mmsCharset(mibEnum: Int?): Charset {
        val name = when (mibEnum) {
            3 -> "US-ASCII"
            4 -> "ISO-8859-1"
            5 -> "ISO-8859-2"
            6 -> "ISO-8859-3"
            7 -> "ISO-8859-4"
            8 -> "ISO-8859-5"
            9 -> "ISO-8859-6"
            10 -> "ISO-8859-7"
            11 -> "ISO-8859-8"
            12 -> "ISO-8859-9"
            17 -> "Shift_JIS"
            106 -> "UTF-8"
            1000 -> "UTF-16BE"
            1015 -> "UTF-16"
            2025 -> "GB2312"
            2026 -> "Big5"
            2252 -> "windows-1252"
            else -> "UTF-8"
        }
        return runCatching { Charset.forName(name) }.getOrDefault(Charsets.UTF_8)
    }

    private fun defaultAttachmentName(partId: Long, mimeType: String): String {
        val extension = MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType)
        return "attachment-$partId${extension?.let { ".$it" }.orEmpty()}"
    }

    private fun mmsAddress(messageId: Long, incoming: Boolean): String {
        val desiredType = if (incoming) MMS_FROM else MMS_TO
        val preferred = mutableListOf<String>()
        val fallback = mutableListOf<String>()
        context.contentResolver.query(
            Uri.parse("content://mms/$messageId/addr"),
            arrayOf("address", "type"),
            null,
            null,
            null
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                val address = cursor.getString(0).orEmpty()
                if (address.isBlank() || address == "insert-address-token") continue
                fallback += address
                if (cursor.getInt(1) == desiredType) preferred += address
            }
        }
        return (preferred.ifEmpty { fallback }).distinct().joinToString(", ")
    }

    private fun cachedConversations(): List<DeviceConversation>? = synchronized(CACHE_LOCK) {
        conversationCache?.takeIf {
            SystemClock.elapsedRealtime() - it.createdAt <= CONVERSATION_CACHE_MS
        }?.value
    }

    private fun cacheConversations(value: List<DeviceConversation>) = synchronized(CACHE_LOCK) {
        conversationCache = TimedConversations(SystemClock.elapsedRealtime(), value)
    }

    private fun cachedThread(threadId: Long): List<DeviceMessage>? = synchronized(CACHE_LOCK) {
        threadCache[threadId]
    }

    private fun cacheThread(threadId: Long, value: List<DeviceMessage>) = synchronized(CACHE_LOCK) {
        threadCache[threadId] = value
        while (threadCache.size > MAX_CACHED_THREADS) {
            val oldest = threadCache.entries.iterator()
            if (oldest.hasNext()) {
                oldest.next()
                oldest.remove()
            }
        }
    }

    companion object {
        private data class ConversationSummary(var latest: DeviceMessage? = null, var unreadCount: Int = 0)
        private data class MmsParts(val text: String, val attachments: List<DeviceAttachment>)
        private data class TimedConversations(val createdAt: Long, val value: List<DeviceConversation>)

        private const val MMS_FROM = 137
        private const val MMS_TO = 151
        private const val TAG = "DeviceMessages"
        private const val READ_UPDATE_CHUNK_SIZE = 200
        private const val CONVERSATION_CACHE_MS = 10_000L
        private const val MAX_CACHED_THREADS = 4
        private val CACHE_LOCK = Any()
        private var conversationCache: TimedConversations? = null
        private val threadCache = object : LinkedHashMap<Long, List<DeviceMessage>>(MAX_CACHED_THREADS, 0.75f, true) {}

        /** Provider observers and transport commits call this to prevent stale instant snapshots. */
        fun invalidateCaches(threadId: Long? = null) = synchronized(CACHE_LOCK) {
            conversationCache = null
            if (threadId == null) threadCache.clear() else threadCache.remove(threadId)
        }

        /** A memory-only full snapshot used to paint a reopened conversation without I/O. */
        fun peekThread(threadId: Long): List<DeviceMessage>? = synchronized(CACHE_LOCK) {
            threadCache[threadId]
        }
    }
}
