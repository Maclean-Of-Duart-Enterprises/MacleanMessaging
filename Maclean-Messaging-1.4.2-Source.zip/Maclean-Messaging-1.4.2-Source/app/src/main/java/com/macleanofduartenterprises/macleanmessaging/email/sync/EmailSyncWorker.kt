/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 */

package com.macleanofduartenterprises.macleanmessaging.email.sync

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import com.macleanofduartenterprises.macleanmessaging.data.LocalDatabase
import com.macleanofduartenterprises.macleanmessaging.email.notifications.EmailNotifier
import com.macleanofduartenterprises.macleanmessaging.email.transport.ImapTransport
import com.macleanofduartenterprises.macleanmessaging.util.Async

object EmailSyncWorker {
    private const val PERIODIC_JOB = 0x4D5301
    private const val NOW_JOB = 0x4D5302

    fun reconcile(context: Context) {
        val enabled = LocalDatabase.get(context).emailAccountDao().enabled().any { it.syncEnabled }
        if (!enabled) return disable(context)
        val service = ComponentName(context, EmailSyncJobService::class.java)
        val job = JobInfo.Builder(PERIODIC_JOB, service)
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            .setPersisted(true)
            .setPeriodic(15 * 60 * 1000L)
            .build()
        context.getSystemService(JobScheduler::class.java).schedule(job)
    }

    fun syncNow(context: Context) {
        val service = ComponentName(context, EmailSyncJobService::class.java)
        val job = JobInfo.Builder(NOW_JOB, service)
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            .setMinimumLatency(0)
            .setOverrideDeadline(1_000)
            .build()
        context.getSystemService(JobScheduler::class.java).schedule(job)
    }

    fun disable(context: Context) {
        context.getSystemService(JobScheduler::class.java).apply {
            cancel(PERIODIC_JOB)
            cancel(NOW_JOB)
        }
    }

    data class RunResult(
        val synchronizedAccounts: Int,
        val failedAccounts: Int,
        val retryableFailure: Boolean
    )

    suspend fun perform(context: Context): Boolean = performDetailed(context).retryableFailure

    suspend fun performDetailed(context: Context): RunResult {
        val db = LocalDatabase.get(context)
        val accounts = db.emailAccountDao().enabled().filter { it.syncEnabled }
        var retry = false
        var synchronized = 0
        var failed = 0
        for (account in accounts) {
            val result = ImapTransport(context).sync(account)
            if (result.isSuccess) {
                synchronized++
                db.emailAccountDao().updateSyncStatus(account.id, System.currentTimeMillis(), null)
                val sync = result.getOrThrow()
                EmailNotifier.updateUnread(
                    context,
                    account,
                    db.emailUnreadCount(account.id),
                    alert = sync.newMessages > 0
                )
            } else {
                failed++
                val error = result.exceptionOrNull()
                db.emailAccountDao().updateSyncStatus(account.id, account.lastSyncAt, error?.message?.take(500))
                retry = retry || ImapTransport.isRetryable(error)
            }
        }
        return RunResult(synchronized, failed, retry)
    }
}

class EmailSyncJobService : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        Async.launch {
            val retry = EmailSyncWorker.perform(applicationContext)
            Async.onMain { jobFinished(params, retry) }
        }
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = true

    /** Android 15 invokes this when the network satisfying the job changes. Socket timeouts and
     * transport diagnostics safely handle any in-flight connection; the job itself may continue. */
    override fun onNetworkChanged(params: JobParameters) = Unit
}
