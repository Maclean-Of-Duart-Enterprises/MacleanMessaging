/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.email.data

interface EmailAccountDao {
    fun all(): List<EmailAccountEntity>
    fun enabled(): List<EmailAccountEntity>
    fun enabledCount(): Int
    fun get(id:String): EmailAccountEntity?
    fun defaultSendAccount(): EmailAccountEntity?
    fun clearDefaultSendAccount()
    fun setDefaultSendAccountFlag(id:String)
    fun updateSyncStatus(id:String,time:Long?,error:String?)
    fun upsert(account:EmailAccountEntity)
    fun delete(id:String)
    fun makeDefaultSendAccount(id:String){
        clearDefaultSendAccount()
        setDefaultSendAccountFlag(id)
    }
}

interface EmailThreadDao {
    fun list(accountId:String,archived:Boolean=false):List<EmailThreadEntity>
    fun listAllAccounts(archived:Boolean=false):List<EmailThreadEntity>
    fun search(pattern:String,limit:Int=200):List<EmailThreadEntity>
    fun get(id:String):EmailThreadEntity?
    fun upsert(value:EmailThreadEntity)
    fun upsertAll(values:List<EmailThreadEntity>)
    fun delete(id:String)
    fun deleteForAccount(accountId:String)
    fun setArchived(id:String,value:Boolean)
    fun setPinned(id:String,value:Boolean)
    fun setFavorite(id:String,value:Boolean)
}

interface EmailMessageDao {
    fun forThread(threadId:String):List<EmailMessageEntity>
    fun get(id:String):EmailMessageEntity?
    fun upsert(value:EmailMessageEntity)
    fun upsertAll(values:List<EmailMessageEntity>)
    fun delete(id:String)
    fun deleteForAccount(accountId:String)
    fun setUnread(id:String,unread:Boolean)
    fun moveToFolder(id:String,folder:String)
}

interface EmailAttachmentDao {
    fun forMessage(messageId:String):List<EmailAttachmentEntity>
    fun upsertAll(values:List<EmailAttachmentEntity>)
    fun deleteForMessage(messageId:String)
    fun deleteForAccount(accountId:String)
}
