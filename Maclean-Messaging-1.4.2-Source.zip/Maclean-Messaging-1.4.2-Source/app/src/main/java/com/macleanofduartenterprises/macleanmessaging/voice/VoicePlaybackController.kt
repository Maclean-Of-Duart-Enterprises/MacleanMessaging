/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 */

package com.macleanofduartenterprises.macleanmessaging.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.View
import java.util.Locale

data class VoicePlaybackSnapshot(
    val active: Boolean = false,
    val loading: Boolean = false,
    val playing: Boolean = false,
    val positionMs: Int = 0,
    val durationMs: Int = 0,
    val speed: Float = 1f,
    val error: String? = null
)

/** One in-app player lets a voice message continue while conversation views are rebuilt. */
object VoicePlaybackController {
    private data class Observer(
        val key: String,
        val owner: View,
        val callback: (VoicePlaybackSnapshot) -> Unit
    )

    private val main = Handler(Looper.getMainLooper())
    private val observers = mutableListOf<Observer>()
    private var player: MediaPlayer? = null
    private var currentKey: String? = null
    private var loading = false
    private var prepared = false
    private var speed = 1f
    private var lastError: String? = null

    private val progress = object : Runnable {
        override fun run() {
            notifyCurrent()
            if (loading || runCatching { player?.isPlaying == true }.getOrDefault(false)) {
                main.postDelayed(this, 200L)
            }
        }
    }

    fun observe(key: String, owner: View, callback: (VoicePlaybackSnapshot) -> Unit) {
        val observer = Observer(key, owner, callback)
        observers += observer
        owner.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(view: View) = Unit
            override fun onViewDetachedFromWindow(view: View) {
                observers.remove(observer)
                view.removeOnAttachStateChangeListener(this)
            }
        })
        callback(snapshot(key))
    }

    fun toggle(context: Context, key: String, uri: Uri) {
        if (currentKey == key && prepared) {
            val activePlayer = player ?: return
            if (runCatching { activePlayer.isPlaying }.getOrDefault(false)) activePlayer.pause()
            else {
                if (activePlayer.duration > 0 && activePlayer.currentPosition >= activePlayer.duration - 25) {
                    activePlayer.seekTo(0)
                }
                activePlayer.start()
            }
            notifyCurrent()
            scheduleProgress()
            return
        }
        if (currentKey == key && loading) return

        val oldKey = currentKey
        releasePlayerInternal()
        currentKey = null
        oldKey?.let(::notifyKey)
        currentKey = key
        loading = true
        prepared = false
        speed = 1f
        lastError = null
        notifyCurrent()

        val created = MediaPlayer()
        player = created
        runCatching {
            created.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            created.setDataSource(context.applicationContext, uri)
            created.setOnPreparedListener { ready ->
                if (player !== ready || currentKey != key) return@setOnPreparedListener
                loading = false
                prepared = true
                applySpeed(ready)
                ready.start()
                notifyCurrent()
                scheduleProgress()
            }
            created.setOnCompletionListener {
                notifyCurrent()
            }
            created.setOnErrorListener { failed, _, _ ->
                if (player === failed) {
                    loading = false
                    prepared = false
                    lastError = "Unable to play this voice message."
                    notifyCurrent()
                }
                true
            }
            created.prepareAsync()
            scheduleProgress()
        }.onFailure { error ->
            loading = false
            prepared = false
            lastError = error.message ?: "Unable to play this voice message."
            releasePlayerInternal(keepKey = true)
            notifyCurrent()
        }
    }

    fun cycleSpeed(key: String) {
        if (currentKey != key || !prepared) return
        speed = when (speed) {
            1f -> 1.5f
            1.5f -> 2f
            else -> 1f
        }
        player?.let(::applySpeed)
        notifyCurrent()
    }

    fun seek(key: String, fraction: Float) {
        if (currentKey != key || !prepared) return
        val active = player ?: return
        val duration = runCatching { active.duration }.getOrDefault(0)
        if (duration <= 0) return
        active.seekTo((duration * fraction.coerceIn(0f, 1f)).toInt())
        notifyCurrent()
    }

    fun stopIfKey(key: String) {
        if (currentKey != key) return
        val oldKey = currentKey
        releasePlayerInternal()
        currentKey = null
        oldKey?.let(::notifyKey)
    }

    fun release() {
        val oldKey = currentKey
        releasePlayerInternal()
        currentKey = null
        observers.clear()
        oldKey?.let(::notifyKey)
    }

    private fun snapshot(key: String): VoicePlaybackSnapshot {
        if (key != currentKey) return VoicePlaybackSnapshot()
        val active = player
        val position = if (prepared) runCatching { active?.currentPosition ?: 0 }.getOrDefault(0) else 0
        val duration = if (prepared) runCatching { active?.duration ?: 0 }.getOrDefault(0) else 0
        return VoicePlaybackSnapshot(
            active = true,
            loading = loading,
            playing = prepared && runCatching { active?.isPlaying == true }.getOrDefault(false),
            positionMs = position,
            durationMs = duration,
            speed = speed,
            error = lastError
        )
    }

    private fun applySpeed(active: MediaPlayer) {
        runCatching {
            active.playbackParams = PlaybackParams().setSpeed(speed).setPitch(1f)
        }
    }

    private fun scheduleProgress() {
        main.removeCallbacks(progress)
        main.post(progress)
    }

    private fun notifyCurrent() {
        currentKey?.let(::notifyKey)
    }

    private fun notifyKey(key: String) {
        val value = snapshot(key)
        observers.filter { it.key == key }.toList().forEach { it.callback(value) }
    }

    private fun releasePlayerInternal(keepKey: Boolean = false) {
        main.removeCallbacks(progress)
        val active = player
        player = null
        loading = false
        prepared = false
        runCatching { active?.reset() }
        runCatching { active?.release() }
        if (!keepKey) lastError = null
    }
}

object VoiceMedia {
    fun durationMs(context: Context, uri: Uri): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally {
            runCatching { retriever.release() }
        }
    }

    fun formatDuration(durationMs: Long): String {
        val seconds = (durationMs.coerceAtLeast(0L) / 1000L).toInt()
        return String.format(Locale.US, "%d:%02d", seconds / 60, seconds % 60)
    }
}
