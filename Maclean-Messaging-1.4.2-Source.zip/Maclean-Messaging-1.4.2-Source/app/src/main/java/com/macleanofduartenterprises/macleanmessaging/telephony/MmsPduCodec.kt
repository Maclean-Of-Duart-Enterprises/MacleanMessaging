/* Maclean Messaging — SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanmessaging.telephony

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import com.macleanofduartenterprises.macleanmessaging.model.Attachment
import com.macleanofduartenterprises.macleanmessaging.model.OutgoingMessage
import java.io.ByteArrayOutputStream

/** MM1 Send.req encoder with adaptive carrier-envelope image preparation. */
object MmsPduCodec {
    fun encodeSendReq(context: Context, msg: OutgoingMessage, carrier: MmsCarrierConfig.Profile): ByteArray {
        val originals = msg.attachments.mapIndexed { index, attachment ->
            readAttachment(context, attachment).let {
                it.copy(name = "${index + 1}-${it.name}", contentId = "media-${index + 1}")
            }
        }
        val imageIndexes = originals.indices.filter { originals[it].isCompressibleImage() }
        if (imageIndexes.isEmpty()) {
            return encode(msg, originals).also { requireFits(it, carrier.maxMessageBytes) }
        }

        // Measure the exact fixed PDU footprint using one-byte placeholders for images. This
        // includes the actual recipients, text, SMIL, headers, and every non-image attachment.
        val skeleton = originals.map {
            if (it.isCompressibleImage()) it.copy(data = byteArrayOf(0)) else it
        }
        val skeletonPdu = encode(msg, skeleton)
        val exactFixedBytes = skeletonPdu.size - imageIndexes.size
        val totalImageBudget = MmsImageFitPolicy.totalImageBudget(
            carrier.maxMessageBytes,
            exactFixedBytes
        )
        require(totalImageBudget > 0) {
            "The message text and non-image attachments exceed this carrier's " +
                "${formatSize(carrier.maxMessageBytes)} MMS limit."
        }

        // Start with the quality-oriented budget, then tighten it if encoder variance or an
        // incompressible image leaves the complete serialized PDU above the carrier limit.
        val budgetFactors = doubleArrayOf(1.00, 0.92, 0.84, 0.76, 0.68, 0.60, 0.52, 0.44)
        var smallest: ByteArray? = null
        for (factor in budgetFactors) {
            val perImageBudget = MmsImageFitPolicy.perImageBudget(
                (totalImageBudget * factor).toInt(),
                imageIndexes.size
            )
            val prepared = originals.map {
                if (it.isCompressibleImage()) {
                    prepareImage(it, perImageBudget, carrier.maxImageWidth, carrier.maxImageHeight)
                } else it
            }
            val encoded = encode(msg, prepared)
            if (smallest == null || encoded.size < smallest.size) smallest = encoded
            if (encoded.size <= carrier.maxMessageBytes) return encoded
        }
        val actual = smallest?.size ?: encode(msg, originals).size
        error(
            "The image could not be reduced enough for this carrier's " +
                "${formatSize(carrier.maxMessageBytes)} MMS limit (smallest encoded message: " +
                "${formatSize(actual)}). Remove an attachment or send fewer images."
        )
    }

    private fun encode(msg: OutgoingMessage, media: List<MmsPart>): ByteArray =
        MmsPduWriter.encodeSendRequest(
            recipients = msg.recipients,
            body = msg.body,
            media = media.map {
                MmsPduWriter.Part(it.mimeType, it.name, it.data, it.utf8, it.contentId)
            },
            requestDeliveryReport = msg.requestDeliveryReport
        )

    private fun readAttachment(context: Context, attachment: Attachment): MmsPart {
        val data = context.contentResolver.openInputStream(android.net.Uri.parse(attachment.uri))?.use { input ->
            val buffer = ByteArrayOutputStream()
            val chunk = ByteArray(DEFAULT_BUFFER_SIZE)
            var total = 0L
            while (true) {
                val count = input.read(chunk)
                if (count < 0) break
                total += count
                require(total <= MmsCarrierConfig.APP_MAX_MESSAGE_BYTES) {
                    "${attachment.displayName ?: "MMS attachment"} is larger than the 2 MiB app limit."
                }
                buffer.write(chunk, 0, count)
            }
            buffer.toByteArray()
        } ?: error("Android could not open ${attachment.displayName ?: "the MMS attachment"}.")
        val name = attachment.displayName?.replace(Regex("[\\r\\n/\\\\]+"), "_")
            ?.take(100)?.ifBlank { null } ?: "attachment"
        return MmsPart(attachment.mimeType.ifBlank { "application/octet-stream" }, name, data)
    }

    private fun prepareImage(part: MmsPart, targetBytes: Int, maxWidth: Int, maxHeight: Int): MmsPart {
        if (!part.isCompressibleImage()) return part
        val bounds = BitmapFactory.Options().also {
            it.inJustDecodeBounds = true
            BitmapFactory.decodeByteArray(part.data, 0, part.data.size, it)
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return part
        val (orientedMaxWidth, orientedMaxHeight) = if (bounds.outWidth >= bounds.outHeight) {
            maxWidth to maxHeight
        } else {
            maxHeight to maxWidth
        }
        if (
            part.data.size <= targetBytes &&
            bounds.outWidth <= orientedMaxWidth &&
            bounds.outHeight <= orientedMaxHeight
        ) return part

        val options = BitmapFactory.Options().apply {
            inSampleSize = sampleSize(
                bounds.outWidth,
                bounds.outHeight,
                orientedMaxWidth,
                orientedMaxHeight
            )
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = BitmapFactory.decodeByteArray(part.data, 0, part.data.size, options) ?: return part
        return try {
            var smallest: ByteArray? = null
            for (step in MmsImageFitPolicy.steps) {
                val fit = minOf(
                    1.0,
                    orientedMaxWidth.toDouble() / decoded.width,
                    orientedMaxHeight.toDouble() / decoded.height
                ) * step.dimensionScale
                val width = (decoded.width * fit).toInt().coerceAtLeast(1)
                val height = (decoded.height * fit).toInt().coerceAtLeast(1)
                val scaled = if (width == decoded.width && height == decoded.height) decoded
                    else Bitmap.createScaledBitmap(decoded, width, height, true)
                val flattened = Bitmap.createBitmap(
                    scaled.width,
                    scaled.height,
                    Bitmap.Config.ARGB_8888
                ).also { bitmap ->
                    Canvas(bitmap).apply { drawColor(Color.WHITE); drawBitmap(scaled, 0f, 0f, null) }
                }
                val bytes = ByteArrayOutputStream().also {
                    check(flattened.compress(Bitmap.CompressFormat.JPEG, step.jpegQuality, it))
                }.toByteArray()
                if (scaled !== decoded) scaled.recycle()
                flattened.recycle()
                if (smallest == null || bytes.size < smallest.size) smallest = bytes
                if (bytes.size <= targetBytes) return part.asJpeg(bytes)
            }
            part.asJpeg(requireNotNull(smallest))
        } finally {
            decoded.recycle()
        }
    }

    private fun sampleSize(width: Int, height: Int, targetWidth: Int, targetHeight: Int): Int {
        var sample = 1
        while (width / (sample * 2) >= targetWidth && height / (sample * 2) >= targetHeight) {
            sample *= 2
        }
        return sample
    }

    private fun MmsPart.isCompressibleImage(): Boolean =
        mimeType.startsWith("image/", true) && !mimeType.equals("image/gif", true)

    private fun MmsPart.asJpeg(bytes: ByteArray): MmsPart = copy(
        mimeType = "image/jpeg",
        name = name.substringBeforeLast('.', name) + ".jpg",
        data = bytes
    )

    private fun requireFits(pdu: ByteArray, transportLimit: Int) {
        require(pdu.size <= transportLimit) {
            "The selected carrier allows ${formatSize(transportLimit)} per MMS. " +
                "The non-image attachment content cannot be safely reduced to that size."
        }
    }

    private fun formatSize(bytes: Int): String = if (bytes >= 1024 * 1024) {
        String.format(java.util.Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
    } else "${(bytes + 1023) / 1024} KB"

    private data class MmsPart(
        val mimeType: String,
        val name: String,
        val data: ByteArray,
        val utf8: Boolean = false,
        val contentId: String = "part"
    )
}
