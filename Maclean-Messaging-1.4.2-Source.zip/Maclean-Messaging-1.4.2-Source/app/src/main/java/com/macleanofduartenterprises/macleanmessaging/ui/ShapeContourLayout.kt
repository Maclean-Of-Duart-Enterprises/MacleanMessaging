/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 */

package com.macleanofduartenterprises.macleanmessaging.ui

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * A vertical panel whose children follow the visible corner contour instead of sharing one flat
 * left and right margin. Headings near the top and dates near the bottom are inset farther than
 * body text in the middle, matching rounded and capsule-shaped backgrounds.
 */
internal class ShapeContourLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : LinearLayout(context, attrs) {
    private var contourShape = SHAPE_SQUARE

    init {
        orientation = VERTICAL
    }

    fun configureContour(shape: String, horizontalPadding: Int, verticalPadding: Int) {
        contourShape = shape
        setPadding(horizontalPadding, verticalPadding, horizontalPadding, verticalPadding)
        requestLayout()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        resetContourMargins()
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        if (orientation != VERTICAL || contourShape == SHAPE_SQUARE || childCount == 0) return

        // Wrapped text can become taller after an inset changes its width. Two short passes let
        // the child positions and the surface contour converge without an unbounded layout loop.
        repeat(2) {
            if (!applyContourMargins()) return
            super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        }
    }

    private fun resetContourMargins() {
        for (index in 0 until childCount) {
            val params = getChildAt(index).layoutParams as? ContourLayoutParams ?: continue
            params.leftMargin = params.baseLeftMargin
            params.rightMargin = params.baseRightMargin
        }
    }

    private fun applyContourMargins(): Boolean {
        val width = measuredWidth
        val height = measuredHeight
        if (width <= 0 || height <= 0) return false
        val radius = when (contourShape) {
            SHAPE_SOFT -> dp(12).toFloat()
            SHAPE_ROUNDED -> dp(24).toFloat()
            SHAPE_OVAL -> min(dp(96).toFloat(), min(width, height) / 2f)
            else -> 0f
        }
        if (radius <= 0f) return false

        var changed = false
        var top = paddingTop
        for (index in 0 until childCount) {
            val child = getChildAt(index)
            if (child.visibility == View.GONE) continue
            val params = child.layoutParams as? ContourLayoutParams ?: continue
            top += params.topMargin
            val bottom = top + child.measuredHeight
            val probe = min(dp(8), max(1, child.measuredHeight / 2))
            val boundary = max(
                roundedBoundaryInset(width, height, (top + probe).toFloat(), radius),
                roundedBoundaryInset(width, height, (bottom - probe).toFloat(), radius)
            )
            val additionalLeft = max(0, boundary - paddingLeft)
            val additionalRight = max(0, boundary - paddingRight)
            val requestedLeft = params.baseLeftMargin + additionalLeft
            val requestedRight = params.baseRightMargin + additionalRight
            if (params.leftMargin != requestedLeft || params.rightMargin != requestedRight) {
                params.leftMargin = requestedLeft
                params.rightMargin = requestedRight
                changed = true
            }
            top = bottom + params.bottomMargin
        }
        return changed
    }

    override fun generateDefaultLayoutParams(): LayoutParams =
        ContourLayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)

    override fun generateLayoutParams(attrs: AttributeSet): LayoutParams =
        ContourLayoutParams(context, attrs)

    override fun generateLayoutParams(params: ViewGroup.LayoutParams): LayoutParams =
        if (params is LinearLayout.LayoutParams) ContourLayoutParams(params)
        else ContourLayoutParams(params)

    override fun checkLayoutParams(params: ViewGroup.LayoutParams): Boolean =
        params is ContourLayoutParams

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private class ContourLayoutParams : LinearLayout.LayoutParams {
        val baseLeftMargin: Int
        val baseRightMargin: Int

        constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
            baseLeftMargin = leftMargin
            baseRightMargin = rightMargin
        }

        constructor(width: Int, height: Int) : super(width, height) {
            baseLeftMargin = leftMargin
            baseRightMargin = rightMargin
        }

        constructor(source: LinearLayout.LayoutParams) : super(source) {
            baseLeftMargin = leftMargin
            baseRightMargin = rightMargin
        }

        constructor(source: ViewGroup.LayoutParams) : super(source) {
            baseLeftMargin = leftMargin
            baseRightMargin = rightMargin
        }
    }

    private companion object {
        const val SHAPE_SQUARE = "Square"
        const val SHAPE_SOFT = "Soft corners"
        const val SHAPE_ROUNDED = "Rounded"
        const val SHAPE_OVAL = "Oval"
    }
}

/** Horizontal inset of a rounded-rectangle boundary at [y]. */
internal fun roundedBoundaryInset(width: Int, height: Int, y: Float, radius: Float): Int {
    if (width <= 0 || height <= 0 || radius <= 0f) return 0
    val r = min(radius, min(width, height) / 2f)
    val clampedY = y.coerceIn(0f, height.toFloat())
    val distanceFromCornerCenter = when {
        clampedY < r -> r - clampedY
        clampedY > height - r -> clampedY - (height - r)
        else -> return 0
    }
    return (r - sqrt(max(0f, r * r - distanceFromCornerCenter * distanceFromCornerCenter))).toInt()
}
