/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 */

package com.macleanofduartenterprises.macleanmessaging.telephony

import android.content.Context
import android.util.AtomicFile
import android.util.Log
import com.macleanofduartenterprises.macleanmessaging.files.PduContentProvider
import org.json.JSONObject
import java.io.File

/**
 * Durable in-app fallback for MMS providers that create a part row but refuse its data stream.
 *
 * Android's canonical MMS provider remains the first choice. This store is used only after every
 * provider stream mode fails, keeping the already downloaded or outgoing attachment visible,
 * shareable, forwardable, and downloadable inside Maclean Messaging on affected vendor builds.
 */
object LocalMmsAttachmentStore {
    data class StoredPart(
        val stableId: Long,
        val mimeType: String,
        val fileName: String,
        val contentUri: String,
        val sizeBytes: Long
    )

    fun store(
        context: Context,
        messageId: Long,
        sequence: Int,
        mimeType: String,
        fileName: String,
        data: ByteArray
    ): StoredPart {
        require(messageId >= 0L) { "MMS message id must not be negative." }
        require(sequence >= 0) { "MMS part sequence must not be negative." }
        val directory = partDirectory(context, messageId, sequence).apply { mkdirs() }
        val payload = File(directory, PAYLOAD_FILE)
        val metadata = File(directory, METADATA_FILE)
        writeAtomic(payload, data)
        try {
            writeAtomic(
                metadata,
                JSONObject()
                    .put("mimeType", normalizedMimeType(mimeType))
                    .put("fileName", safeDisplayName(fileName, sequence))
                    .put("sizeBytes", data.size.toLong())
                    .toString()
                    .toByteArray(Charsets.UTF_8)
            )
        } catch (error: Throwable) {
            payload.delete()
            throw error
        }
        return requireNotNull(readPart(context, messageId, sequence)) {
            "The local MMS attachment fallback could not be verified."
        }
    }

    fun list(context: Context, messageId: Long): List<StoredPart> =
        messageDirectory(context, messageId)
            .listFiles(File::isDirectory)
            .orEmpty()
            .sortedBy { it.name.toIntOrNull() ?: Int.MAX_VALUE }
            .mapNotNull { directory ->
                val sequence = directory.name.toIntOrNull() ?: return@mapNotNull null
                runCatching { readPart(context, messageId, sequence) }
                    .onFailure { Log.e(TAG, "Unreadable local MMS fallback $messageId/$sequence", it) }
                    .getOrNull()
            }

    fun deleteMessage(context: Context, messageId: Long) {
        val directory = messageDirectory(context, messageId)
        directory.listFiles()?.forEach { part ->
            part.listFiles()?.forEach(File::delete)
            part.delete()
        }
        directory.delete()
    }

    private fun readPart(context: Context, messageId: Long, sequence: Int): StoredPart? {
        val directory = partDirectory(context, messageId, sequence)
        val payload = File(directory, PAYLOAD_FILE)
        val metadata = File(directory, METADATA_FILE)
        if (!payload.isFile || !metadata.isFile) return null
        val value = JSONObject(metadata.readText(Charsets.UTF_8))
        return StoredPart(
            stableId = syntheticPartId(messageId, sequence),
            mimeType = normalizedMimeType(value.optString("mimeType")),
            fileName = safeDisplayName(value.optString("fileName"), sequence),
            contentUri = PduContentProvider.uriFor(context, payload).toString(),
            sizeBytes = payload.length()
        )
    }

    private fun writeAtomic(file: File, bytes: ByteArray) {
        val atomic = AtomicFile(file)
        val output = atomic.startWrite()
        try {
            output.write(bytes)
            output.fd.sync()
            atomic.finishWrite(output)
        } catch (error: Throwable) {
            atomic.failWrite(output)
            throw error
        }
    }

    private fun messageDirectory(context: Context, messageId: Long) =
        File(File(context.filesDir, ROOT_DIRECTORY), messageId.toString())

    private fun partDirectory(context: Context, messageId: Long, sequence: Int) =
        File(messageDirectory(context, messageId), sequence.toString())

    private fun normalizedMimeType(value: String): String =
        value.substringBefore(';').trim().lowercase().ifBlank { "application/octet-stream" }

    private fun safeDisplayName(value: String, sequence: Int): String = value
        .replace(Regex("[\\r\\n/\\\\]+"), "_")
        .trim()
        .take(120)
        .ifBlank { "attachment-${sequence + 1}" }

    private fun syntheticPartId(messageId: Long, sequence: Int): Long =
        -((messageId.coerceAtMost((Long.MAX_VALUE - sequence - 1L) / PART_ID_FACTOR) * PART_ID_FACTOR) + sequence + 1L)

    private const val ROOT_DIRECTORY = "local-mms-parts"
    private const val PAYLOAD_FILE = "payload"
    private const val METADATA_FILE = "metadata.json"
    private const val PART_ID_FACTOR = 1_000L
    private const val TAG = "LocalMmsParts"
}
