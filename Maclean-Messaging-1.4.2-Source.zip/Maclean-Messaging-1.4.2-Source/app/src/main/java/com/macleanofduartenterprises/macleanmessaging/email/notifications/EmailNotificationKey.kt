/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.email.notifications

object EmailNotificationKey {
    fun accountChannelId(accountId: String): String =
        "email-account-$accountId"

    fun threadNotificationId(accountId: String, threadId: String): Int =
        ("$accountId:$threadId").hashCode()

    fun accountNotificationId(accountId: String): Int =
        accountId.hashCode()
}
