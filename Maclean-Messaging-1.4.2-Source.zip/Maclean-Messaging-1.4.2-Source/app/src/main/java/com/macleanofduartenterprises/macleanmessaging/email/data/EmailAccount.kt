/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.email.data

data class EmailAccountEntity(
 val id:String, val displayName:String, val emailAddress:String,
 val incomingHost:String, val incomingPort:Int, val incomingSecurity:String,
 val outgoingHost:String, val outgoingPort:Int, val outgoingSecurity:String,
 val username:String, val authType:String, val credentialAlias:String?,
 val oauthClientId:String?=null, val oauthAuthorizeEndpoint:String?=null,
 val oauthTokenEndpoint:String?=null, val oauthScopes:String?=null,
 val enabled:Boolean=true, val syncEnabled:Boolean=true,
 val isDefaultSendAccount:Boolean=false, val accountColorArgb:Long?=null,
 val signature:String?=null, val lastSyncAt:Long?=null, val lastSyncError:String?=null
)
data class EmailThreadEntity(val stableId:String,val accountId:String,val remoteThreadId:String?,val subject:String?,val participantsJson:String,val preview:String,val timestamp:Long,val unreadCount:Int,val pinned:Boolean=false,val favorite:Boolean=false,val archived:Boolean=false)
data class EmailMessageEntity(val stableId:String,val accountId:String,val threadId:String,val remoteMessageId:String?,val sender:String,val recipientsJson:String,val subject:String?,val bodyText:String,val bodyHtml:String?,val timestamp:Long,val incoming:Boolean,val unread:Boolean,val folder:String,val attachmentCount:Int=0)

data class EmailAttachmentEntity(
    val id: String,
    val messageId: String,
    val accountId: String,
    val fileName: String?,
    val mimeType: String,
    val sizeBytes: Long,
    val localPath: String
)
