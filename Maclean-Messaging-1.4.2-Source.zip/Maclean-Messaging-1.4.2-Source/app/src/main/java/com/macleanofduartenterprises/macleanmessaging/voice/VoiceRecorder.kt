/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 */

package com.macleanofduartenterprises.macleanmessaging.voice

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.macleanofduartenterprises.macleanmessaging.util.Async
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sqrt

data class VoiceDraft(
    val file: File,
    val mimeType: String,
    val durationMs: Long,
    val waveform: FloatArray,
    val opus: Boolean
)

/**
 * Records a compact voice-message asset. Ogg/Opus is attempted first on every recording; devices
 * whose media stack rejects that public Android configuration fall back to mono AAC in M4A.
 */
class VoiceRecorder(
    private val context: Context,
    private val onSample: (elapsedMs: Long, amplitude: Float) -> Unit
) {
    enum class State { IDLE, RECORDING, PAUSED }

    private val handler = Handler(Looper.getMainLooper())
    private val samples = mutableListOf<Float>()
    private var mediaRecorder: MediaRecorder? = null
    private var outputFile: File? = null
    private var startedAt = 0L
    private var pausedAt = 0L
    private var pausedDuration = 0L
    private var opus = true

    var state: State = State.IDLE
        private set

    val currentFile: File? get() = outputFile
    val isOpus: Boolean get() = opus

    private val sampler = object : Runnable {
        override fun run() {
            if (state == State.IDLE) return
            val elapsed = elapsedMs()
            val normalized = if (state == State.RECORDING) {
                val raw = runCatching { mediaRecorder?.maxAmplitude ?: 0 }.getOrDefault(0)
                sqrt((raw / 32767f).coerceIn(0f, 1f)).coerceAtLeast(0.04f)
            } else {
                samples.lastOrNull()?.coerceAtMost(0.12f) ?: 0.04f
            }
            if (state == State.RECORDING) samples += normalized
            onSample(elapsed, normalized)
            handler.postDelayed(this, SAMPLE_INTERVAL_MS)
        }
    }

    fun start(): VoiceDraftFormat {
        check(state == State.IDLE) { "A voice recording is already active." }
        val directory = File(context.cacheDir, "voice-drafts").apply { mkdirs() }
        val baseName = "Voice Message " + SimpleDateFormat("yyyy-MM-dd HH-mm-ss", Locale.US).format(Date())
        val preferred = uniqueFile(directory, baseName, ".ogg")
        val preferredResult = runCatching {
            begin(preferred, MediaRecorder.OutputFormat.OGG, MediaRecorder.AudioEncoder.OPUS, true)
        }
        if (preferredResult.isFailure) {
            releaseRecorder()
            preferred.delete()
            val fallback = uniqueFile(directory, baseName, ".m4a")
            runCatching {
                begin(fallback, MediaRecorder.OutputFormat.MPEG_4, MediaRecorder.AudioEncoder.AAC, false)
            }.getOrElse { error ->
                releaseRecorder()
                fallback.delete()
                throw error
            }
        }
        startedAt = System.currentTimeMillis()
        pausedAt = 0L
        pausedDuration = 0L
        samples.clear()
        state = State.RECORDING
        handler.post(sampler)
        return VoiceDraftFormat(opus, if (opus) "audio/ogg" else "audio/mp4")
    }

    fun pause() {
        if (state != State.RECORDING) return
        mediaRecorder?.pause()
        pausedAt = System.currentTimeMillis()
        state = State.PAUSED
    }

    fun resume() {
        if (state != State.PAUSED) return
        mediaRecorder?.resume()
        pausedDuration += (System.currentTimeMillis() - pausedAt).coerceAtLeast(0L)
        pausedAt = 0L
        state = State.RECORDING
    }

    fun stop(): VoiceDraft {
        check(state != State.IDLE) { "No voice recording is active." }
        val elapsed = elapsedMs()
        val file = requireNotNull(outputFile)
        val recordedAsOpus = opus
        handler.removeCallbacks(sampler)
        val recorder = mediaRecorder
        mediaRecorder = null
        state = State.IDLE
        try {
            recorder?.stop()
        } catch (error: Throwable) {
            file.delete()
            throw IllegalStateException("The recording was too short to save.", error)
        } finally {
            runCatching { recorder?.release() }
        }
        check(file.isFile && file.length() > 0L) { "Android did not create the voice recording." }
        return VoiceDraft(
            file = file,
            mimeType = if (recordedAsOpus) "audio/ogg" else "audio/mp4",
            durationMs = elapsed.coerceAtLeast(1L),
            waveform = samples.toFloatArray().let { if (it.isEmpty()) floatArrayOf(0.08f) else it },
            opus = recordedAsOpus
        )
    }

    fun cancel() {
        handler.removeCallbacks(sampler)
        val recorder = mediaRecorder
        mediaRecorder = null
        val file = outputFile
        outputFile = null
        state = State.IDLE
        // Reset/release can block while an OEM media service drains its encoder. Detach the UI
        // state immediately and do that cleanup on the bounded I/O pool so leaving a composer or
        // sliding to cancel never freezes the visible screen.
        Async.launch {
            runCatching { recorder?.reset() }
            runCatching { recorder?.release() }
            file?.delete()
        }
    }

    private fun begin(file: File, outputFormat: Int, encoder: Int, useOpus: Boolean) {
        @Suppress("DEPRECATION")
        val recorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else MediaRecorder()
        mediaRecorder = recorder
        outputFile = file
        opus = useOpus
        recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
        recorder.setOutputFormat(outputFormat)
        recorder.setAudioEncoder(encoder)
        recorder.setAudioChannels(1)
        recorder.setAudioSamplingRate(48_000)
        recorder.setAudioEncodingBitRate(32_000)
        recorder.setOutputFile(file.absolutePath)
        recorder.prepare()
        recorder.start()
    }

    private fun elapsedMs(now: Long = System.currentTimeMillis()): Long {
        if (startedAt == 0L) return 0L
        val activePause = if (state == State.PAUSED && pausedAt > 0L) now - pausedAt else 0L
        return (now - startedAt - pausedDuration - activePause).coerceAtLeast(0L)
    }

    private fun releaseRecorder() {
        val recorder = mediaRecorder
        mediaRecorder = null
        runCatching { recorder?.reset() }
        runCatching { recorder?.release() }
    }

    private fun uniqueFile(directory: File, baseName: String, extension: String): File {
        var candidate = File(directory, baseName + extension)
        var suffix = 2
        while (candidate.exists()) {
            candidate = File(directory, "$baseName ($suffix)$extension")
            suffix++
        }
        return candidate
    }

    companion object {
        private const val SAMPLE_INTERVAL_MS = 90L
    }
}

data class VoiceDraftFormat(val opus: Boolean, val mimeType: String)
