/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.contacts

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract

data class ContactSummary(
    val displayName: String,
    val photoUri: Uri?
)

object ContactResolver {
    fun resolve(context: Context, address: String): ContactSummary? {
        if (context.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val email = address.contains('@')
        val uri = Uri.withAppendedPath(
            if (email) ContactsContract.CommonDataKinds.Email.CONTENT_FILTER_URI
            else ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(address)
        )
        val displayName = if (email) ContactsContract.CommonDataKinds.Email.DISPLAY_NAME
        else ContactsContract.PhoneLookup.DISPLAY_NAME
        val photoUri = if (email) ContactsContract.CommonDataKinds.Email.PHOTO_URI
        else ContactsContract.PhoneLookup.PHOTO_URI
        context.contentResolver.query(
            uri,
            arrayOf(
                displayName,
                photoUri
            ),
            null, null, null
        )?.use { c ->
            if (c.moveToFirst()) {
                return ContactSummary(
                    c.getString(0) ?: address,
                    c.getString(1)?.let(Uri::parse)
                )
            }
        }
        return null
    }
}
