/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.telephony

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager
import android.telephony.PhoneNumberUtils
import android.telephony.SubscriptionManager

object SmsSender {
    const val ACTION_SENT = "com.macleanofduartenterprises.macleanmessaging.SMS_SENT"
    const val ACTION_DELIVERED = "com.macleanofduartenterprises.macleanmessaging.SMS_DELIVERED"

    fun send(
        context: Context,
        destination: String,
        body: String,
        subscriptionId: Int,
        token: String
    ): Int {
        require(subscriptionId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
            "Select an active SIM before sending SMS."
        }
        val normalizedDestination = PhoneNumberUtils.normalizeNumber(destination)
            .takeIf(String::isNotBlank)
            ?: error("Enter a valid phone number.")
        @Suppress("DEPRECATION")
        val manager = if (Build.VERSION.SDK_INT >= 31) {
            context.getSystemService(SmsManager::class.java).createForSubscriptionId(subscriptionId)
        } else SmsManager.getSmsManagerForSubscriptionId(subscriptionId)

        val parts = manager.divideMessage(body)
        val sent = ArrayList<PendingIntent>()
        val delivered = ArrayList<PendingIntent>()

        parts.indices.forEach { index ->
            val sentIntent = Intent(context, SmsStatusReceiver::class.java).apply {
                action = ACTION_SENT
                data = Uri.parse("maclean-sms-status:$token/sent/$index")
                putExtra("token", token)
                putExtra("part", index)
                putExtra("parts", parts.size)
            }
            val deliveredIntent = Intent(context, SmsStatusReceiver::class.java).apply {
                action = ACTION_DELIVERED
                data = Uri.parse("maclean-sms-status:$token/delivered/$index")
                putExtra("token", token)
                putExtra("part", index)
                putExtra("parts", parts.size)
            }
            sent += PendingIntent.getBroadcast(
                context, (token.hashCode() * 31) + index,
                sentIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            delivered += PendingIntent.getBroadcast(
                context, (token.hashCode() * 37) + index,
                deliveredIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        if (parts.size == 1) {
            manager.sendTextMessage(normalizedDestination, null, parts.single(), sent.single(), delivered.single())
        } else {
            manager.sendMultipartTextMessage(normalizedDestination, null, parts, sent, delivered)
        }
        return parts.size
    }
}
