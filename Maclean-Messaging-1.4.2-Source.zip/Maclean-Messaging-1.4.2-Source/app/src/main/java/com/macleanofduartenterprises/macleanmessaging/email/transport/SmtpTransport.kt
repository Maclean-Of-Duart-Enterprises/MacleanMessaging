/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.email.transport
import android.content.Context
import android.provider.OpenableColumns
import android.util.Base64
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailAccountEntity
import com.macleanofduartenterprises.macleanmessaging.email.mime.MimeCodec
import com.macleanofduartenterprises.macleanmessaging.email.oauth.OAuth2Manager
import com.macleanofduartenterprises.macleanmessaging.email.security.AndroidKeystoreCredentialStore
import java.io.*
import java.net.Socket
import java.util.UUID
class SmtpTransport(private val context:Context):OutgoingEmailTransport{
 private val secrets=AndroidKeystoreCredentialStore(context);private val oauth=OAuth2Manager(context)
 override suspend fun testConnection(a:EmailAccountEntity)=runCatching{conn(a).use{it.connect()}}
 override suspend fun send(a:EmailAccountEntity,d:EmailDraft)=runCatching{
  require(d.to.isNotEmpty()||d.cc.isNotEmpty()||d.bcc.isNotEmpty())
  val at=d.attachmentUris.map{u->
   val uri=android.net.Uri.parse(u)
   val name=context.contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{c->
    if(c.moveToFirst())c.getString(0) else null
   }?:uri.lastPathSegment?:"attachment"
   name to (context.contentResolver.openInputStream(uri)?.use{it.readBytes()}?:error("Attachment unreadable"))
  }
  val domain=a.emailAddress.substringAfter('@',"macleanmessaging.local")
   .filter{it.isLetterOrDigit()||it=='.'||it=='-'}.ifBlank{"macleanmessaging.local"}
  val messageId=(d.messageId?:"${UUID.randomUUID()}@$domain").trim().trim('<','>')
  val raw=MimeCodec.build(
   from=a.emailAddress,to=d.to,cc=d.cc,bcc=d.bcc,subject=d.subject,body=d.plainTextBody,
   attachments=at,signature=a.signature,messageId=messageId,inReplyTo=d.inReplyTo,references=d.references
  )
  conn(a).use{it.connect();it.send(a.emailAddress,(d.to+d.cc+d.bcc).distinct(),raw)}
  messageId
 }
 private fun conn(a:EmailAccountEntity):SmtpConnection{val auth=if(a.authType=="OAUTH2")AuthCredential.OAuth(oauth.accessToken(a).getOrThrow()) else {val ch=a.credentialAlias?.let(secrets::get)?:error("Missing password");AuthCredential.Password(ch.concatToString()).also{ch.fill('\u0000')}};return SmtpConnection(a,auth)}
}
private class SmtpConnection(private val a:EmailAccountEntity,private val auth:AuthCredential):AutoCloseable{private var s:Socket?=null;private var r:BufferedReader?=null;private var w:BufferedWriter?=null
 fun connect(){s=if(a.outgoingSecurity=="TLS")TlsSocket.direct(a.outgoingHost,a.outgoingPort) else TlsSocket.plain(a.outgoingHost,a.outgoingPort);reset();expect(resp(),220);var ehlo=cmd("EHLO macleanmessaging.local",250);if(a.outgoingSecurity=="STARTTLS"){require(ehlo.any{it.contains("STARTTLS",true)});cmd("STARTTLS",220);s=TlsSocket.upgrade(s!!,a.outgoingHost,a.outgoingPort);reset();ehlo=cmd("EHLO macleanmessaging.local",250)};when(auth){is AuthCredential.Password->{cmd("AUTH LOGIN",334);cmd(Base64.encodeToString(a.username.toByteArray(),Base64.NO_WRAP),334);cmd(Base64.encodeToString(auth.value.toByteArray(),Base64.NO_WRAP),235)};is AuthCredential.OAuth->{val p="user=${a.username}\u0001auth=Bearer ${auth.accessToken}\u0001\u0001";cmd("AUTH XOAUTH2 ${Base64.encodeToString(p.toByteArray(),Base64.NO_WRAP)}",235)}}}
 fun send(from:String,rec:List<String>,raw:ByteArray){cmd("MAIL FROM:<${box(from)}>",250);rec.forEach{cmd("RCPT TO:<${box(it)}>",250,251)};cmd("DATA",354);val text=raw.toString(Charsets.UTF_8).replace("\r\n","\n").replace("\r","\n").split('\n').joinToString("\r\n"){if(it.startsWith('.'))".$it" else it};w!!.write(text+"\r\n.\r\n");w!!.flush();expect(resp(),250)}
 private fun box(v:String)=Regex("<([^>]+)>").find(v)?.groupValues?.get(1)?:v.trim();private fun cmd(c:String,vararg ok:Int):List<String>{w!!.write(c+"\r\n");w!!.flush();val x=resp();expect(x,*ok);return x};private fun resp():List<String>{val x=mutableListOf<String>();while(true){val l=r!!.readLine()?:throw EOFException();x+=l;if(l.length>=4&&l[3]==' ')return x}};private fun expect(x:List<String>,vararg ok:Int){val code=x.last().take(3).toIntOrNull()?:error("Invalid SMTP response");require(code in ok.toSet()){x.joinToString(" | ")}};private fun reset(){r=BufferedReader(InputStreamReader(s!!.getInputStream()));w=BufferedWriter(OutputStreamWriter(s!!.getOutputStream()))};override fun close(){runCatching{s?.close()}}}
