/* Maclean Messaging — SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanmessaging.telephony

import kotlin.math.roundToInt

/** Pure sizing policy shared by the Android image compressor and host regression tests. */
object MmsImageFitPolicy {
    data class Step(val dimensionScale: Double, val jpegQuality: Int)

    /**
     * Reserve 18% of the carrier envelope for MM1/WSP headers, recipients, text, SMIL,
     * part headers, and implementation variance. A normal 300 KiB carrier therefore
     * receives a 54 KiB reserve and an approximately 246 KiB media target.
     */
    fun structuralReserve(transportLimit: Int): Int {
        require(transportLimit > 0)
        return (transportLimit * RESERVE_FRACTION).roundToInt()
            .coerceIn(MIN_RESERVE_BYTES, MAX_RESERVE_BYTES)
            .coerceAtMost((transportLimit / 3).coerceAtLeast(1))
    }

    /** Exact fixed PDU bytes win when text, recipients, or non-image parts exceed the reserve. */
    fun totalImageBudget(transportLimit: Int, exactFixedPduBytes: Int): Int =
        (transportLimit - maxOf(structuralReserve(transportLimit), exactFixedPduBytes))
            .coerceAtLeast(0)

    fun perImageBudget(totalImageBudget: Int, imageCount: Int): Int {
        require(imageCount > 0)
        return (totalImageBudget / imageCount).coerceAtLeast(0)
    }

    /**
     * Quality and dimensions decline together. This avoids destroying detail by repeatedly
     * lowering JPEG quality while retaining more pixels than the carrier can transport.
     */
    val steps: List<Step> = listOf(
        Step(1.00, 92),
        Step(0.94, 90),
        Step(0.88, 88),
        Step(0.81, 86),
        Step(0.74, 84),
        Step(0.67, 82),
        Step(0.60, 79),
        Step(0.53, 76),
        Step(0.46, 72),
        Step(0.39, 68),
        Step(0.33, 63),
        Step(0.27, 57),
        Step(0.22, 50)
    )

    private const val RESERVE_FRACTION = 0.18
    private const val MIN_RESERVE_BYTES = 30 * 1024
    private const val MAX_RESERVE_BYTES = 60 * 1024
}
