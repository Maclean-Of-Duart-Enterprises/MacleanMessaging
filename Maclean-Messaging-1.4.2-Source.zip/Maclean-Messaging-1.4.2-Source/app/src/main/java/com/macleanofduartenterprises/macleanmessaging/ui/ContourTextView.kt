/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 */

package com.macleanofduartenterprises.macleanmessaging.ui

import android.content.Context
import android.graphics.Canvas
import android.text.Layout
import android.text.Spanned
import android.text.StaticLayout
import android.text.style.ClickableSpan
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/**
 * Read-only text that gives each wrapped line independent left and right insets. Android's normal
 * TextView layout uses one rectangular width; StaticLayout.setIndents lets the first/last lines
 * follow the selected curved surface while middle lines use the wider center.
 */
internal class ContourTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : TextView(context, attrs) {
    private var contourShape = SHAPE_SQUARE
    private var contourLayout: StaticLayout? = null
    private var pressedLink: ClickableSpan? = null
    private var cachedContentWidth = -1
    private var cachedLayoutKey = 0

    fun setContourShape(shape: String) {
        if (contourShape == shape) return
        contourShape = shape
        clearLayoutCache()
        requestLayout()
        invalidate()
    }

    override fun onTextChanged(text: CharSequence?, start: Int, lengthBefore: Int, lengthAfter: Int) {
        super.onTextChanged(text, start, lengthBefore, lengthAfter)
        clearLayoutCache()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = when (MeasureSpec.getMode(widthMeasureSpec)) {
            MeasureSpec.EXACTLY, MeasureSpec.AT_MOST -> MeasureSpec.getSize(widthMeasureSpec)
            else -> max(suggestedMinimumWidth, compoundPaddingLeft + compoundPaddingRight + dp(48))
        }
        val contentWidth = max(1, width - compoundPaddingLeft - compoundPaddingRight)
        val key = currentLayoutKey()
        var layout = contourLayout?.takeIf {
            cachedContentWidth == contentWidth && cachedLayoutKey == key
        }
        if (layout == null) {
            layout = buildLayout(contentWidth, null)
            val firstIndents = lineIndents(layout, contentWidth)
            if (firstIndents != null) {
                layout = buildLayout(contentWidth, firstIndents)
                val refined = lineIndents(layout, contentWidth)
                if (refined != null && !refined.contentEquals(firstIndents)) {
                    layout = buildLayout(contentWidth, refined)
                }
            }
            contourLayout = layout
            cachedContentWidth = contentWidth
            cachedLayoutKey = key
        }
        val desiredHeight = max(
            suggestedMinimumHeight,
            layout.height + compoundPaddingTop + compoundPaddingBottom
        )
        setMeasuredDimension(
            resolveSizeAndState(width, widthMeasureSpec, 0),
            resolveSizeAndState(desiredHeight, heightMeasureSpec, 0)
        )
    }

    private fun clearLayoutCache() {
        contourLayout = null
        cachedContentWidth = -1
        cachedLayoutKey = 0
    }

    private fun currentLayoutKey(): Int {
        var result = text?.hashCode() ?: 0
        result = 31 * result + contourShape.hashCode()
        result = 31 * result + paint.textSize.toBits()
        result = 31 * result + (typeface?.style ?: 0)
        result = 31 * result + maxLines
        result = 31 * result + breakStrategy
        result = 31 * result + hyphenationFrequency
        return result
    }

    private fun buildLayout(width: Int, indents: IntArray?): StaticLayout {
        val value = text ?: ""
        return StaticLayout.Builder.obtain(value, 0, value.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setIncludePad(includeFontPadding)
            .setBreakStrategy(breakStrategy)
            .setHyphenationFrequency(hyphenationFrequency)
            .setLineSpacing(lineSpacingExtra, lineSpacingMultiplier)
            .setMaxLines(maxLines)
            .apply {
                if (ellipsize != null) setEllipsize(ellipsize)
                if (indents != null) setIndents(indents, indents)
            }
            .build()
    }

    private fun lineIndents(layout: StaticLayout, width: Int): IntArray? {
        if (contourShape == SHAPE_SQUARE || layout.lineCount == 0) return null
        val height = layout.height.coerceAtLeast(1)
        val radius = when (contourShape) {
            SHAPE_SOFT -> dp(12).toFloat()
            SHAPE_ROUNDED -> dp(24).toFloat()
            SHAPE_OVAL -> min(dp(96).toFloat(), min(width, height) / 2f)
            else -> 0f
        }
        if (radius <= 0f) return null
        val maximum = (width * MAXIMUM_INDENT_FRACTION).toInt()
        return IntArray(layout.lineCount) { line ->
            val center = (layout.getLineTop(line) + layout.getLineBottom(line)) / 2f
            roundedBoundaryInset(width, height, center, radius).coerceAtMost(maximum)
        }
    }

    override fun onDraw(canvas: Canvas) {
        val layout = contourLayout ?: return super.onDraw(canvas)
        val checkpoint = canvas.save()
        canvas.translate(compoundPaddingLeft.toFloat(), compoundPaddingTop.toFloat())
        layout.draw(canvas)
        canvas.restoreToCount(checkpoint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val link = clickableSpanAt(event.x, event.y)
        return when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pressedLink = link
                link != null || super.onTouchEvent(event)
            }
            MotionEvent.ACTION_UP -> {
                val pressed = pressedLink
                pressedLink = null
                if (pressed != null && pressed === link) {
                    pressed.onClick(this)
                    performClick()
                    true
                } else super.onTouchEvent(event)
            }
            MotionEvent.ACTION_CANCEL -> {
                pressedLink = null
                super.onTouchEvent(event)
            }
            else -> pressedLink != null || super.onTouchEvent(event)
        }
    }

    override fun performClick(): Boolean = super.performClick()

    private fun clickableSpanAt(x: Float, y: Float): ClickableSpan? {
        val value = text as? Spanned ?: return null
        val layout = contourLayout ?: return null
        val localX = x - compoundPaddingLeft
        val localY = y - compoundPaddingTop
        if (localX < 0f || localY < 0f || localY > layout.height) return null
        val line = layout.getLineForVertical(localY.toInt())
        if (localX < layout.getLineLeft(line) || localX > layout.getLineRight(line)) return null
        val offset = layout.getOffsetForHorizontal(line, localX)
        return value.getSpans(offset, offset, ClickableSpan::class.java).firstOrNull()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private companion object {
        const val SHAPE_SQUARE = "Square"
        const val SHAPE_SOFT = "Soft corners"
        const val SHAPE_ROUNDED = "Rounded"
        const val SHAPE_OVAL = "Oval"
        const val MAXIMUM_INDENT_FRACTION = 0.22f
    }
}
