/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.email.transport

import android.content.Context
import android.util.Log
import com.macleanofduartenterprises.macleanmessaging.data.LocalDatabase
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailAccountEntity
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailMessageEntity
import com.macleanofduartenterprises.macleanmessaging.email.oauth.OAuth2Manager
import com.macleanofduartenterprises.macleanmessaging.email.security.AndroidKeystoreCredentialStore
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.IOException
import java.net.Socket

class ImapTransport(private val context: Context) : IncomingEmailTransport {
    private val secrets = AndroidKeystoreCredentialStore(context)
    private val oauth = OAuth2Manager(context)

    override suspend fun testConnection(account: EmailAccountEntity): Result<Unit> =
        diagnosed(account, "connection test") { stage ->
            connection(account).use {
                stage("opening the secure connection")
                it.connect()
                stage("checking the authenticated session")
                it.noop()
            }
        }

    override suspend fun sync(account: EmailAccountEntity): Result<SyncResult> =
        diagnosed(account, "mailbox sync") { stage ->
        val database = LocalDatabase.get(context)
        val ingestor = EmailSyncIngestor(context)
        connection(account).use { connection ->
            stage("opening the secure connection and authenticating")
            connection.connect()
            stage("selecting INBOX")
            connection.selectInbox()
            stage("listing all INBOX messages")
            val serverUids = connection.search()
            val knownUids = database.knownEmailUids(account.id)
            val existingUids = serverUids.filter(knownUids::contains)
            stage("refreshing read and unread flags")
            var updatedMessages = database.applyEmailSeenFlags(
                account.id,
                connection.fetchFlags(existingUids)
            )
            var newMessages = 0

            // Newest batches arrive first, but every UID is fetched. Persisting each bounded batch
            // keeps memory stable and makes an interrupted first sync resume from the database.
            serverUids.filterNot(knownUids::contains)
                .asReversed()
                .chunked(FETCH_BATCH_SIZE)
                .forEach { batch ->
                    stage("downloading message batch")
                    val ingested = ingestor.ingest(account, connection.fetch(batch))
                    newMessages += ingested.newMessages
                    updatedMessages += ingested.updatedMessages
                }
            SyncResult(newMessages, updatedMessages, 1)
        }
    }

    private suspend fun <T> diagnosed(
        account: EmailAccountEntity,
        operation: String,
        block: suspend ((String) -> Unit) -> T
    ): Result<T> {
        var stage = "preparing account credentials"
        return try {
            Result.success(block { stage = it })
        } catch (error: Throwable) {
            val failure = diagnosticFailure(account, operation, stage, error)
            Log.e(TAG, "${account.incomingHost}:${account.incomingPort} ${failure.message}", failure)
            Result.failure(failure)
        }
    }

    private fun diagnosticFailure(
        account: EmailAccountEntity,
        operation: String,
        stage: String,
        error: Throwable
    ): ImapOperationException {
        val rawReason = error.message
            ?.lineSequence()
            ?.firstOrNull()
            ?.trim()
            .orEmpty()
            .ifBlank { "The server closed the operation without an explanation." }
        val accountValues = listOf(account.username, account.emailAddress)
            .filter(String::isNotBlank)
            .distinct()
        val accountRedacted = accountValues.fold(rawReason) { value, secret ->
            value.replace(secret, "[account]", ignoreCase = true)
        }
        val safeReason = accountRedacted
            .replace(
                Regex("(?i)(password|passcode|token|bearer|authorization|oauth)\\s*[:=]\\s*[^\\s,;]+"),
                "$1=[redacted]"
            )
            .replace(
                Regex("(?i)(access_token|refresh_token|id_token|password)\\\"?\\s*[:=]\\s*\\\"?[A-Za-z0-9._~+/=-]{8,}"),
                "$1=[redacted]"
            )
            .take(MAX_DIAGNOSTIC_LENGTH)
        val authFailure = safeReason.contains("AUTHENTICATE", ignoreCase = true) ||
            safeReason.contains("AUTHENTICATION", ignoreCase = true) ||
            safeReason.contains("LOGIN failed", ignoreCase = true) ||
            safeReason.contains("invalid login", ignoreCase = true) ||
            safeReason.contains("credentials", ignoreCase = true)
        val configurationFailure = stage == "preparing account credentials" ||
            safeReason.contains("is required", ignoreCase = true) ||
            safeReason.contains("Missing password", ignoreCase = true)
        return ImapOperationException(
            retryable = !authFailure && !configurationFailure,
            message = "IMAP $operation failed while $stage (${error.javaClass.simpleName}): $safeReason"
        ).also { it.stackTrace = error.stackTrace }
    }

    private fun connection(account: EmailAccountEntity): ImapConnection {
        require(account.username.isNotBlank()) { "Email username is required." }
        val auth = if (account.authType == "OAUTH2") {
            AuthCredential.OAuth(oauth.accessToken(account).getOrThrow())
        } else {
            val characters = account.credentialAlias?.let(secrets::get) ?: error("Missing password")
            require(characters.isNotEmpty()) { "The saved email password is empty. Enter it again in Email accounts." }
            AuthCredential.Password(characters.concatToString()).also { characters.fill('\u0000') }
        }
        return ImapConnection(account, auth)
    }

    companion object {
        private const val FETCH_BATCH_SIZE = 12
        private const val MAX_DIAGNOSTIC_LENGTH = 320
        private const val TAG = "MacleanEmailSync"

        fun isRetryable(error: Throwable?): Boolean =
            (error as? ImapOperationException)?.retryable ?: (error is IOException)
    }

    /** Updates the real IMAP Seen flag for messages that were opened or marked unread. */
    suspend fun setSeen(
        account: EmailAccountEntity,
        messages: List<EmailMessageEntity>,
        seen: Boolean
    ): Result<Unit> = diagnosed(account, if (seen) "mark read" else "mark unread") { stage ->
        if (messages.isEmpty()) return@diagnosed
        connection(account).use { connection ->
            stage("opening the secure connection and authenticating")
            connection.connect()
            stage("selecting INBOX")
            connection.selectInbox()
            stage("locating selected messages")
            val uids = connection.resolveUids(messages)
            require(uids.size == messages.size) { "The mail server could not locate every selected email." }
            stage("updating the server read state")
            connection.setSeen(uids, seen)
        }
    }

    /** Permanently removes selected INBOX messages on the configured IMAP server. */
    suspend fun delete(
        account: EmailAccountEntity,
        messages: List<EmailMessageEntity>
    ): Result<Unit> = diagnosed(account, "delete messages") { stage ->
        if (messages.isEmpty()) return@diagnosed
        connection(account).use { connection ->
            stage("opening the secure connection and authenticating")
            connection.connect()
            stage("selecting INBOX")
            connection.selectInbox()
            stage("locating selected messages")
            val uids = connection.resolveUids(messages)
            require(uids.size == messages.size) { "The mail server could not locate every selected email." }
            stage("deleting messages on the server")
            connection.delete(uids)
        }
    }

}

internal class ImapOperationException(
    val retryable: Boolean,
    message: String
) : IOException(message)

data class RemoteEmail(val uid: Long, val flags: Set<String>, val raw: ByteArray)

private class ImapConnection(
    private val account: EmailAccountEntity,
    private val auth: AuthCredential
) : AutoCloseable {
    private var socket: Socket? = null
    private var input: BufferedInputStream? = null
    private var output: BufferedOutputStream? = null
    private var commandNumber = 1

    fun connect() {
        require(account.incomingSecurity in setOf("TLS", "STARTTLS")) {
            "IMAP requires TLS or STARTTLS."
        }
        socket = if (account.incomingSecurity == "TLS") {
            TlsSocket.direct(account.incomingHost, account.incomingPort)
        } else {
            TlsSocket.plain(account.incomingHost, account.incomingPort)
        }
        resetStreams()
        var greeting = readLine()
        require(greeting.startsWith("* OK") || greeting.startsWith("* PREAUTH")) { greeting }
        if (account.incomingSecurity == "STARTTLS") {
            command("STARTTLS")
            socket = TlsSocket.upgrade(requireNotNull(socket), account.incomingHost, account.incomingPort)
            resetStreams()
            greeting = "* OK"
        }
        if (greeting.startsWith("* PREAUTH")) return
        val capabilities = runCatching { capabilities() }.getOrDefault(emptySet())
        when (auth) {
            is AuthCredential.Password -> {
                when {
                    capabilities.any { it.equals("AUTH=PLAIN", ignoreCase = true) } ->
                        authenticate("PLAIN", listOf(ImapProtocol.saslPlain(account.username, auth.value)))
                    capabilities.any { it.equals("AUTH=LOGIN", ignoreCase = true) } ->
                        authenticate("LOGIN", listOf(
                            ImapProtocol.base64Utf8(account.username),
                            ImapProtocol.base64Utf8(auth.value)
                        ))
                    else -> command("LOGIN ${quote(account.username)} ${quote(auth.value)}")
                }
            }
            is AuthCredential.OAuth -> {
                val payload = "user=${account.username}\u0001auth=Bearer ${auth.accessToken}\u0001\u0001"
                authenticate("XOAUTH2", listOf(ImapProtocol.base64Utf8(payload)))
            }
        }
    }

    fun noop() {
        command("NOOP")
    }

    fun selectInbox() {
        command("SELECT \"INBOX\"")
    }

    fun search(): List<Long> = searchCommand("UID SEARCH ALL")

    fun fetch(uids: List<Long>): List<RemoteEmail> {
        if (uids.isEmpty()) return emptyList()
        val tag = nextTag()
        send("$tag UID FETCH ${ImapProtocol.uidSet(uids)} (UID FLAGS BODY.PEEK[])")
        val messages = linkedMapOf<Long, RemoteEmail>()
        while (true) {
            val line = readLine()
            val uid = ImapProtocol.uid(line)
            val flags = ImapProtocol.flags(line)
            val size = Regex("\\{(\\d+)\\}$").find(line)?.groupValues?.get(1)?.toIntOrNull()
            if (uid != null && size != null) {
                messages[uid] = RemoteEmail(uid, flags, readBytes(size))
            }
            if (line.startsWith("$tag ")) {
                require(line.startsWith("$tag OK")) { line }
                break
            }
        }
        return uids.mapNotNull(messages::get)
    }

    fun fetchFlags(uids: List<Long>): Map<Long, Set<String>> {
        if (uids.isEmpty()) return emptyMap()
        val result = linkedMapOf<Long, Set<String>>()
        uids.chunked(MAX_UIDS_PER_COMMAND).forEach { chunk ->
            val tag = nextTag()
            send("$tag UID FETCH ${ImapProtocol.uidSet(chunk)} (UID FLAGS)")
            while (true) {
                val line = readLine()
                ImapProtocol.uid(line)?.let { uid -> result[uid] = ImapProtocol.flags(line) }
                if (line.startsWith("$tag ")) {
                    require(line.startsWith("$tag OK")) { line }
                    break
                }
            }
        }
        return result
    }

    fun resolveUids(messages: List<EmailMessageEntity>): List<Long> = messages.mapNotNull { message ->
        message.remoteMessageId?.toLongOrNull()
            ?: message.stableId.substringAfterLast(':').takeIf { message.stableId.startsWith("imap:") }?.toLongOrNull()
            ?: findByMessageId(message.stableId)
    }.distinct()

    fun setSeen(uids: List<Long>, seen: Boolean) {
        uids.chunked(MAX_UIDS_PER_COMMAND).forEach { chunk ->
            val operation = if (seen) "+FLAGS.SILENT" else "-FLAGS.SILENT"
            command("UID STORE ${chunk.joinToString(",")} $operation (\\Seen)")
        }
    }

    fun delete(uids: List<Long>) {
        uids.chunked(MAX_UIDS_PER_COMMAND).forEach { chunk ->
            command("UID STORE ${chunk.joinToString(",")} +FLAGS.SILENT (\\Deleted)")
        }
        command("EXPUNGE")
    }

    private fun findByMessageId(stableId: String): Long? {
        val clean = stableId.trim().trim('<', '>')
        if (clean.isBlank()) return null
        return searchCommand("UID SEARCH HEADER Message-ID ${quote("<$clean>")}").lastOrNull()
            ?: searchCommand("UID SEARCH HEADER Message-ID ${quote(clean)}").lastOrNull()
    }

    private fun searchCommand(value: String): List<Long> {
        val searchLine = command(value).firstOrNull { it.startsWith("* SEARCH") }.orEmpty()
        return searchLine.removePrefix("* SEARCH").trim().split(' ').mapNotNull(String::toLongOrNull)
    }

    private fun capabilities(): Set<String> = command("CAPABILITY")
        .firstOrNull { it.startsWith("* CAPABILITY", ignoreCase = true) }
        .orEmpty()
        .substringAfter(' ', "")
        .substringAfter(' ', "")
        .split(' ')
        .filter(String::isNotBlank)
        .toSet()

    /** Sends SASL data only after the server continuation, so SASL-IR support is not required. */
    private fun authenticate(mechanism: String, responses: List<String>) {
        require(responses.isNotEmpty()) { "IMAP authentication response is required." }
        val tag = nextTag()
        send("$tag AUTHENTICATE $mechanism")
        var responseIndex = 0
        while (true) {
            val line = readLine()
            if (line.startsWith("+")) {
                require(responseIndex < responses.size) { "IMAP $mechanism authentication requested extra credentials." }
                send(responses[responseIndex++])
            }
            if (line.startsWith("$tag ")) {
                require(line.startsWith("$tag OK")) { "IMAP AUTHENTICATE failed: $line" }
                require(responseIndex == responses.size) { "IMAP $mechanism authentication ended before credentials were sent." }
                return
            }
        }
    }

    private fun command(value: String): List<String> {
        val tag = nextTag()
        send("$tag $value")
        val response = mutableListOf<String>()
        while (true) {
            val line = readLine()
            response += line
            if (line.startsWith("$tag ")) {
                val operation = value.substringBefore(' ')
                require(line.startsWith("$tag OK")) { "IMAP $operation failed: $line" }
                return response
            }
        }
    }

    private fun nextTag() = "A${commandNumber++.toString().padStart(4, '0')}"

    private fun quote(value: String): String {
        require(value.none { it == '\r' || it == '\n' || it == '\u0000' }) { "Invalid IMAP credential characters." }
        return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\""
    }

    private fun resetStreams() {
        input = BufferedInputStream(requireNotNull(socket).getInputStream())
        output = BufferedOutputStream(requireNotNull(socket).getOutputStream())
    }

    private fun send(value: String) {
        requireNotNull(output).write((value + "\r\n").toByteArray())
        requireNotNull(output).flush()
    }

    private fun readLine(): String {
        val bytes = ByteArrayOutputStream()
        while (true) {
            val next = requireNotNull(input).read()
            if (next < 0) throw EOFException()
            if (next == '\n'.code) break
            if (next != '\r'.code) bytes.write(next)
        }
        return bytes.toString("UTF-8")
    }

    private fun readBytes(size: Int): ByteArray {
        val bytes = ByteArray(size)
        var offset = 0
        while (offset < size) {
            val read = requireNotNull(input).read(bytes, offset, size - offset)
            if (read < 0) throw EOFException()
            offset += read
        }
        return bytes
    }

    override fun close() {
        runCatching { socket?.close() }
    }

    private companion object {
        const val MAX_UIDS_PER_COMMAND = 250
    }
}
