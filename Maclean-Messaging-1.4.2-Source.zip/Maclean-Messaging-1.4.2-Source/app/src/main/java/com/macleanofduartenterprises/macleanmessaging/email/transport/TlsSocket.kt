/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.email.transport

import java.net.InetSocketAddress
import java.net.Socket
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket

internal object TlsSocket {
    fun direct(host: String, port: Int, timeout: Int = 30_000): SSLSocket {
        // Wrapping a connected TCP socket gives Android's TLS stack an explicit peer host. This
        // reliably supplies SNI for virtual-hosted mail servers and preserves hostname checks.
        val raw = plain(host, port, timeout)
        return try {
            upgrade(raw, host, port, timeout)
        } catch (error: Throwable) {
            runCatching { raw.close() }
            throw error
        }
    }

    fun plain(host: String, port: Int, timeout: Int = 30_000): Socket = Socket().apply {
        soTimeout = timeout
        connect(InetSocketAddress(host, port), timeout)
    }

    fun upgrade(raw: Socket, host: String, port: Int, timeout: Int = 30_000): SSLSocket {
        val context = SSLContext.getInstance("TLS").apply { init(null, null, null) }
        val socket = context.socketFactory.createSocket(raw, host, port, true) as SSLSocket
        socket.soTimeout = timeout
        socket.useClientMode = true
        socket.enabledProtocols = socket.enabledProtocols
            .filter { it == "TLSv1.3" || it == "TLSv1.2" }
            .toTypedArray()
            .takeIf { it.isNotEmpty() }
            ?: socket.enabledProtocols
        socket.sslParameters = socket.sslParameters.apply {
            endpointIdentificationAlgorithm = "HTTPS"
            runCatching { serverNames = listOf(SNIHostName(host)) }
        }
        socket.startHandshake()
        return socket
    }
}
