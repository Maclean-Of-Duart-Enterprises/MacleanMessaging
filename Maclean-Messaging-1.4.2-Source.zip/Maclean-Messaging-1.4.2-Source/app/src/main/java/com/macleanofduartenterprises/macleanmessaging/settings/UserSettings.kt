/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.settings

import android.content.Context
import android.graphics.Color

class UserSettings(private val context: Context) {
    private val preferences = context.getSharedPreferences("appearance", Context.MODE_PRIVATE)

    val appearance: AppearanceSettings
        get() {
            val uri = preferences.getString("background_uri", null)
            val localPath = preferences.getString("background_file_path", null)
            val displayStyle = normalizedDisplayStyle(preferences.getString("display_style", DISPLAY_SLEEK))
            return AppearanceSettings(
                textScale = preferences.getFloat("text_scale", 1f),
                highContrast = preferences.getBoolean("high_contrast", false),
                backgroundOpacity = preferences.getInt("background_opacity", 100).coerceIn(1, 100),
                textWindowOpacity = preferences.getInt("text_window_opacity", 90).coerceIn(1, 100),
                backgroundUri = uri,
                backgroundFilePath = localPath,
                backgroundDisplayName = preferences.getString("background_display_name", null),
                useBackgroundPhoto = preferences.getBoolean("use_background_photo", uri != null || localPath != null),
                paletteName = preferences.getString("palette_name", "Soft Cloud") ?: "Soft Cloud",
                backgroundColor = preferences.getInt("background_color", Color.rgb(246, 248, 252)),
                surfaceColor = preferences.getInt("surface_color", Color.WHITE),
                accentColor = preferences.getInt("accent_color", Color.rgb(19, 74, 119)),
                textColor = preferences.getInt("text_color", Color.rgb(24, 32, 42)),
                display = displaySettings(displayStyle)
            )
        }

    fun displaySettings(style: String): DisplaySettings {
        val normalized = normalizedDisplayStyle(style)
        val defaults = if (normalized == DISPLAY_UTILITY) utilityDefaults() else sleekDefaults()
        val prefix = displayPrefix(normalized)
        return DisplaySettings(
            style = normalized,
            bubbleShape = preferences.getString("${prefix}bubble_shape", defaults.bubbleShape)
                ?.takeIf { it in SHAPE_OPTIONS } ?: defaults.bubbleShape,
            cardShape = preferences.getString("${prefix}card_shape", defaults.cardShape)
                ?.takeIf { it in SHAPE_OPTIONS } ?: defaults.cardShape,
            buttonShape = preferences.getString("${prefix}button_shape", defaults.buttonShape)
                ?.takeIf { it in SHAPE_OPTIONS } ?: defaults.buttonShape,
            spacing = preferences.getString("${prefix}spacing", defaults.spacing)
                ?.takeIf { it in SPACING_OPTIONS } ?: defaults.spacing,
            textFont = preferences.getString("${prefix}text_font", defaults.textFont)
                ?.takeIf { it in FONT_OPTIONS } ?: defaults.textFont,
            textFormat = preferences.getString("${prefix}text_format", defaults.textFormat)
                ?.takeIf { it in TEXT_FORMAT_OPTIONS } ?: defaults.textFormat,
            replyLocation = preferences.getString("${prefix}reply_location", defaults.replyLocation)
                ?.takeIf { it in REPLY_LOCATION_OPTIONS } ?: defaults.replyLocation,
            messageWidthPercent = preferences.getInt("${prefix}message_width", defaults.messageWidthPercent)
                .coerceIn(70, 100),
            conversationPreviewLines = preferences.getInt("${prefix}preview_lines", defaults.conversationPreviewLines)
                .coerceIn(1, 4),
            showOutlines = preferences.getBoolean("${prefix}show_outlines", defaults.showOutlines),
            showElevation = preferences.getBoolean("${prefix}show_elevation", defaults.showElevation),
            sentTintPercent = preferences.getInt("${prefix}sent_tint", defaults.sentTintPercent)
                .coerceIn(0, 35)
        )
    }

    val sorting: SortingSettings
        get() = SortingSettings(
            inboxTransportFilter = preferences.getString("default_inbox_transport", "All messages") ?: "All messages",
            inboxContactFilter = preferences.getString("default_inbox_contacts", "All senders") ?: "All senders",
            inboxSort = preferences.getString("default_inbox_sort", "Newest first") ?: "Newest first",
            threadSort = preferences.getString("default_thread_sort", "Oldest first") ?: "Oldest first"
        )

    val notifications: NotificationSettings
        get() = NotificationSettings(
            enabled = preferences.getBoolean("notifications_enabled", true),
            messageNotifications = preferences.getBoolean("message_notifications", true),
            emailNotifications = preferences.getBoolean("email_notifications", true),
            persistentUnread = preferences.getBoolean("persistent_unread_notifications", false),
            showPreviews = preferences.getBoolean("notification_previews", true),
            quickReply = preferences.getBoolean("notification_quick_reply", true)
        )

    fun setTextScale(value: Float) =
        preferences.edit().putFloat("text_scale", value.coerceIn(0.8f, 2.0f)).apply()

    fun setHighContrast(value: Boolean) =
        preferences.edit().putBoolean("high_contrast", value).apply()

    fun setBackgroundOpacity(value: Int) =
        preferences.edit().putInt("background_opacity", value.coerceIn(1, 100)).apply()

    fun setTextWindowOpacity(value: Int) =
        preferences.edit().putInt("text_window_opacity", value.coerceIn(1, 100)).apply()

    fun setBackgroundUri(value: String?) =
        preferences.edit().apply {
            if (value == null) {
                remove("background_uri")
                remove("background_file_path")
                remove("background_display_name")
                putBoolean("use_background_photo", false)
            } else {
                putString("background_uri", value)
                putBoolean("use_background_photo", true)
            }
        }.apply()

    /** Stores an app-owned copy so the background survives provider permission changes. */
    fun setBackgroundPhoto(sourceUri: String?, localPath: String, displayName: String) =
        preferences.edit().apply {
            if (sourceUri == null) remove("background_uri") else putString("background_uri", sourceUri)
            putString("background_file_path", localPath)
            putString("background_display_name", displayName)
            putBoolean("use_background_photo", true)
        }.apply()

    fun setBackgroundLocalCopy(localPath: String, displayName: String) =
        preferences.edit()
            .putString("background_file_path", localPath)
            .putString("background_display_name", displayName)
            .apply()

    fun setUseBackgroundPhoto(value: Boolean) =
        preferences.edit().putBoolean(
            "use_background_photo",
            value && (appearance.backgroundUri != null || appearance.backgroundFilePath != null)
        ).apply()

    fun setPalette(
        name: String,
        backgroundColor: Int,
        surfaceColor: Int,
        accentColor: Int,
        textColor: Int
    ) = preferences.edit()
        .putString("palette_name", name)
        .putInt("background_color", backgroundColor)
        .putInt("surface_color", surfaceColor)
        .putInt("accent_color", accentColor)
        .putInt("text_color", textColor)
        .apply()

    fun setDisplaySettings(value: DisplaySettings) {
        val normalized = normalizedDisplayStyle(value.style)
        val prefix = displayPrefix(normalized)
        preferences.edit()
            .putString("display_style", normalized)
            .putString("${prefix}bubble_shape", value.bubbleShape.takeIf { it in SHAPE_OPTIONS } ?: SHAPE_ROUNDED)
            .putString("${prefix}card_shape", value.cardShape.takeIf { it in SHAPE_OPTIONS } ?: SHAPE_ROUNDED)
            .putString("${prefix}button_shape", value.buttonShape.takeIf { it in SHAPE_OPTIONS } ?: SHAPE_OVAL)
            .putString("${prefix}spacing", value.spacing.takeIf { it in SPACING_OPTIONS } ?: SPACING_COMFORTABLE)
            .putString("${prefix}text_font", value.textFont.takeIf { it in FONT_OPTIONS } ?: FONT_SYSTEM)
            .putString("${prefix}text_format", value.textFormat.takeIf { it in TEXT_FORMAT_OPTIONS } ?: TEXT_FORMAT_REGULAR)
            .putString(
                "${prefix}reply_location",
                value.replyLocation.takeIf { it in REPLY_LOCATION_OPTIONS } ?: REPLY_LOCATION_BOTTOM
            )
            .putInt("${prefix}message_width", value.messageWidthPercent.coerceIn(70, 100))
            .putInt("${prefix}preview_lines", value.conversationPreviewLines.coerceIn(1, 4))
            .putBoolean("${prefix}show_outlines", value.showOutlines)
            .putBoolean("${prefix}show_elevation", value.showElevation)
            .putInt("${prefix}sent_tint", value.sentTintPercent.coerceIn(0, 35))
            .apply()
    }

    fun resetDisplaySettings(style: String) {
        val normalized = normalizedDisplayStyle(style)
        val prefix = displayPrefix(normalized)
        preferences.edit().apply {
            DISPLAY_PROFILE_KEYS.forEach { remove(prefix + it) }
            putString("display_style", normalized)
        }.apply()
    }

    fun setDefaultSorting(value: SortingSettings) = preferences.edit()
        .putString("default_inbox_transport", value.inboxTransportFilter)
        .putString("default_inbox_contacts", value.inboxContactFilter)
        .putString("default_inbox_sort", value.inboxSort)
        .putString("default_thread_sort", value.threadSort)
        .apply()

    fun setNotifications(value: NotificationSettings) = preferences.edit()
        .putBoolean("notifications_enabled", value.enabled)
        .putBoolean("message_notifications", value.messageNotifications)
        .putBoolean("email_notifications", value.emailNotifications)
        .putBoolean("persistent_unread_notifications", value.persistentUnread)
        .putBoolean("notification_previews", value.showPreviews)
        .putBoolean("notification_quick_reply", value.quickReply)
        .apply()

    fun conversationSort(conversationId: String): String =
        preferences.getString("conversation_sort_$conversationId", sorting.threadSort)
            ?: sorting.threadSort

    fun setConversationSort(conversationId: String, value: String) =
        preferences.edit().putString("conversation_sort_$conversationId", value).apply()

    private fun normalizedDisplayStyle(value: String?): String =
        if (value == DISPLAY_UTILITY) DISPLAY_UTILITY else DISPLAY_SLEEK

    private fun displayPrefix(style: String): String = "display_${style.lowercase()}_"

    private fun sleekDefaults() = DisplaySettings(
        style = DISPLAY_SLEEK,
        bubbleShape = SHAPE_ROUNDED,
        cardShape = SHAPE_ROUNDED,
        buttonShape = SHAPE_OVAL,
        spacing = SPACING_COMFORTABLE,
        textFont = FONT_SYSTEM,
        textFormat = TEXT_FORMAT_REGULAR,
        replyLocation = REPLY_LOCATION_BOTTOM,
        messageWidthPercent = 84,
        conversationPreviewLines = 2,
        showOutlines = false,
        showElevation = true,
        sentTintPercent = 12
    )

    private fun utilityDefaults() = DisplaySettings(
        style = DISPLAY_UTILITY,
        bubbleShape = SHAPE_SOFT,
        cardShape = SHAPE_SOFT,
        buttonShape = SHAPE_SQUARE,
        spacing = SPACING_COMPACT,
        textFont = FONT_SYSTEM,
        textFormat = TEXT_FORMAT_REGULAR,
        replyLocation = REPLY_LOCATION_BOTTOM,
        messageWidthPercent = 92,
        conversationPreviewLines = 2,
        showOutlines = true,
        showElevation = false,
        sentTintPercent = 0
    )

    private companion object {
        const val DISPLAY_SLEEK = "Sleek"
        const val DISPLAY_UTILITY = "Utility"
        const val SHAPE_SQUARE = "Square"
        const val SHAPE_SOFT = "Soft corners"
        const val SHAPE_ROUNDED = "Rounded"
        const val SHAPE_OVAL = "Oval"
        const val SPACING_COMPACT = "Compact"
        const val SPACING_COMFORTABLE = "Comfortable"
        const val FONT_SYSTEM = "System sans"
        const val FONT_SERIF = "Serif"
        const val FONT_MONOSPACE = "Monospace"
        const val FONT_CONDENSED = "Condensed"
        const val FONT_CURSIVE_SCRIPT = "Cursive — Script"
        const val FONT_CURSIVE_CASUAL = "Cursive — Casual"
        const val FONT_CALLIGRAPHY_CLASSIC = "Calligraphy — Classic"
        const val FONT_CALLIGRAPHY_FLOURISHED = "Calligraphy — Flourished"
        const val FONT_SPECIAL_SMALL_CAPS = "Special — Small caps"
        const val FONT_SPECIAL_SLAB = "Special — Slab serif"
        const val FONT_SPECIAL_LIGHT = "Special — Light"
        const val FONT_SPECIAL_HEAVY = "Special — Heavy"
        const val TEXT_FORMAT_REGULAR = "Regular"
        const val TEXT_FORMAT_BOLD = "Bold"
        const val TEXT_FORMAT_ITALIC = "Italic"
        const val TEXT_FORMAT_BOLD_ITALIC = "Bold italic"
        const val REPLY_LOCATION_TOP = "Top of conversation"
        const val REPLY_LOCATION_BOTTOM = "Bottom of conversation"
        val SHAPE_OPTIONS = setOf(SHAPE_SQUARE, SHAPE_SOFT, SHAPE_ROUNDED, SHAPE_OVAL)
        val SPACING_OPTIONS = setOf(SPACING_COMPACT, SPACING_COMFORTABLE, "Spacious")
        val FONT_OPTIONS = setOf(
            FONT_SYSTEM,
            FONT_SERIF,
            FONT_MONOSPACE,
            FONT_CONDENSED,
            FONT_CURSIVE_SCRIPT,
            FONT_CURSIVE_CASUAL,
            FONT_CALLIGRAPHY_CLASSIC,
            FONT_CALLIGRAPHY_FLOURISHED,
            FONT_SPECIAL_SMALL_CAPS,
            FONT_SPECIAL_SLAB,
            FONT_SPECIAL_LIGHT,
            FONT_SPECIAL_HEAVY
        )
        val TEXT_FORMAT_OPTIONS = setOf(
            TEXT_FORMAT_REGULAR,
            TEXT_FORMAT_BOLD,
            TEXT_FORMAT_ITALIC,
            TEXT_FORMAT_BOLD_ITALIC
        )
        val REPLY_LOCATION_OPTIONS = setOf(REPLY_LOCATION_TOP, REPLY_LOCATION_BOTTOM)
        val DISPLAY_PROFILE_KEYS = listOf(
            "bubble_shape",
            "card_shape",
            "button_shape",
            "spacing",
            "text_font",
            "text_format",
            "reply_location",
            "message_width",
            "preview_lines",
            "show_outlines",
            "show_elevation",
            "sent_tint"
        )
    }
}

data class AppearanceSettings(
    val textScale: Float,
    val highContrast: Boolean,
    val backgroundOpacity: Int,
    val textWindowOpacity: Int,
    val backgroundUri: String?,
    val backgroundFilePath: String?,
    val backgroundDisplayName: String?,
    val useBackgroundPhoto: Boolean,
    val paletteName: String,
    val backgroundColor: Int,
    val surfaceColor: Int,
    val accentColor: Int,
    val textColor: Int,
    val display: DisplaySettings
)

data class DisplaySettings(
    val style: String,
    val bubbleShape: String,
    val cardShape: String,
    val buttonShape: String,
    val spacing: String,
    val textFont: String,
    val textFormat: String,
    val replyLocation: String,
    val messageWidthPercent: Int,
    val conversationPreviewLines: Int,
    val showOutlines: Boolean,
    val showElevation: Boolean,
    val sentTintPercent: Int
)

data class SortingSettings(
    val inboxTransportFilter: String,
    val inboxContactFilter: String,
    val inboxSort: String,
    val threadSort: String
)

data class NotificationSettings(
    val enabled: Boolean,
    val messageNotifications: Boolean,
    val emailNotifications: Boolean,
    val persistentUnread: Boolean,
    val showPreviews: Boolean,
    val quickReply: Boolean
)
