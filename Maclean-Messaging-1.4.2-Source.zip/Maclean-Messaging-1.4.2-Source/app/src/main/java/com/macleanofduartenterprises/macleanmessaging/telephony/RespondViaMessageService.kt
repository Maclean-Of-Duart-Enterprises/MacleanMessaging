/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 */

package com.macleanofduartenterprises.macleanmessaging.telephony

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.telephony.SubscriptionManager
import com.macleanofduartenterprises.macleanmessaging.data.SystemMessageRepository
import com.macleanofduartenterprises.macleanmessaging.model.OutgoingMessage
import com.macleanofduartenterprises.macleanmessaging.util.Async

/** Handles Android's "respond via message" action while the app holds the SMS role. */
class RespondViaMessageService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val recipient = intent?.data?.schemeSpecificPart?.substringBefore("?").orEmpty()
        val body = intent?.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
        val subscriptionId = SubscriptionManager.getDefaultSmsSubscriptionId()
        if (recipient.isBlank() || body.isBlank() || subscriptionId == SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        Async.launch {
            runCatching {
                SystemMessageRepository(this@RespondViaMessageService).send(
                    OutgoingMessage(listOf(recipient), body, subscriptionId = subscriptionId)
                )
            }
            Async.onMain { stopSelf(startId) }
        }
        return START_NOT_STICKY
    }
}
