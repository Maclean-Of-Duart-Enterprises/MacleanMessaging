/* Maclean Messaging — SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanmessaging.telephony

import android.content.Context
import android.os.Bundle
import android.telephony.CarrierConfigManager

/** Separates the app's attachment policy from the SIM carrier's real transport envelope. */
object MmsCarrierConfig {
    data class Profile(
        val maxMessageBytes: Int,
        val maxImageWidth: Int,
        val maxImageHeight: Int
    )

    /** Users may select source attachments up to 2 MiB before carrier-safe preparation. */
    const val APP_MAX_MESSAGE_BYTES = 2 * 1024 * 1024
    const val DEFAULT_TRANSPORT_BYTES = 300 * 1024

    /**
     * Android's carrier configuration is authoritative for the encoded PDU submitted to the MMSC.
     * A larger app-side allowance must never be passed as a transport override: many MMSCs reject
     * an oversized request even when SmsManager accepted the API call.
     */
    fun profile(context: Context, subscriptionId: Int): Profile {
        val config = runCatching {
            context.getSystemService(CarrierConfigManager::class.java)
                ?.getConfigForSubId(subscriptionId)
        }.getOrNull()
        val maxMessageBytes = config
            ?.getInt(CarrierConfigManager.KEY_MMS_MAX_MESSAGE_SIZE_INT, DEFAULT_TRANSPORT_BYTES)
            ?.takeIf { it >= MIN_TRANSPORT_BYTES }
            ?.coerceAtMost(APP_MAX_MESSAGE_BYTES)
            ?: DEFAULT_TRANSPORT_BYTES
        val maxImageWidth = validImageBound(
            config?.getInt(CarrierConfigManager.KEY_MMS_MAX_IMAGE_WIDTH_INT, DEFAULT_IMAGE_WIDTH),
            DEFAULT_IMAGE_WIDTH
        )
        val maxImageHeight = validImageBound(
            config?.getInt(CarrierConfigManager.KEY_MMS_MAX_IMAGE_HEIGHT_INT, DEFAULT_IMAGE_HEIGHT),
            DEFAULT_IMAGE_HEIGHT
        )
        return Profile(maxMessageBytes, maxImageWidth, maxImageHeight)
    }

    fun transportLimit(context: Context, subscriptionId: Int): Int =
        profile(context, subscriptionId).maxMessageBytes

    /** Empty overrides tell SmsManager to use the APN and carrier bundle selected for the SIM. */
    fun operationOverrides(): Bundle = Bundle.EMPTY

    private fun validImageBound(value: Int?, fallback: Int): Int =
        value?.takeIf { it in MIN_IMAGE_BOUND..MAX_IMAGE_BOUND } ?: fallback

    private const val MIN_TRANSPORT_BYTES = 64 * 1024
    private const val DEFAULT_IMAGE_WIDTH = 640
    private const val DEFAULT_IMAGE_HEIGHT = 480
    private const val MIN_IMAGE_BOUND = 64
    private const val MAX_IMAGE_BOUND = 4096
}
