/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.data

import android.content.ContentResolver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.Telephony
import android.util.Log
import com.macleanofduartenterprises.macleanmessaging.model.Attachment
import com.macleanofduartenterprises.macleanmessaging.model.OutgoingMessage
import com.macleanofduartenterprises.macleanmessaging.model.Transport
import com.macleanofduartenterprises.macleanmessaging.telephony.LocalMmsAttachmentStore
import com.macleanofduartenterprises.macleanmessaging.telephony.MmsProviderWriter
import com.macleanofduartenterprises.macleanmessaging.telephony.MmsTransport
import com.macleanofduartenterprises.macleanmessaging.telephony.SmsSender
import com.macleanofduartenterprises.macleanmessaging.system.SmsRuntimeReadiness
import java.util.UUID

class SystemMessageRepository(private val context: Context) {

    fun send(message: OutgoingMessage): String {
        val readiness = SmsRuntimeReadiness.inspect(context)
        check(readiness.operational) { readiness.explanation }
        val token = UUID.randomUUID().toString()
        // A default SMS app must persist its outgoing row before carrier submission. Never silently
        // send an invisible message when the system provider rejected the matching conversation row.
        val systemUri = when (message.transport) {
            Transport.SMS -> insertOutgoingSms(message)
            Transport.MMS -> insertOutgoingMms(message)
        }
        DeviceMessageRepository.invalidateCaches()
        val metadata = LocalDatabase.get(context).messageMetaDao()
        metadata.upsert(MessageMetaEntity(token, systemUri.toString(), "SENDING"))

        try {
            when (message.transport) {
                Transport.SMS -> SmsSender.send(
                    context,
                    message.recipients.single(),
                    message.body,
                    message.subscriptionId,
                    token
                )
                Transport.MMS -> MmsTransport.send(context, message, token)
            }
        } catch (error: Throwable) {
            metadata.updateState(token, "FAILED")
            updateOutgoingProvider(systemUri, message.transport, false)
            throw error
        }
        return token
    }

    /**
     * Default SMS apps are responsible for adding their own outgoing rows to the system provider.
     * Writing the row before handing the message to SmsManager makes it visible immediately and
     * gives incoming and outgoing messages the same Android conversation/thread id.
     */
    private fun insertOutgoingSms(message: OutgoingMessage): Uri {
        val recipient = message.recipients.single()
        val threadId = runCatching { Telephony.Threads.getOrCreateThreadId(context, recipient) }.getOrNull()
        val values = ContentValues().apply {
            threadId?.let { put(Telephony.Sms.THREAD_ID, it) }
            put(Telephony.Sms.ADDRESS, recipient)
            put(Telephony.Sms.BODY, message.body)
            put(Telephony.Sms.DATE, System.currentTimeMillis())
            put(Telephony.Sms.READ, 1)
            put(Telephony.Sms.SEEN, 1)
            put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_OUTBOX)
            put(Telephony.Sms.STATUS, Telephony.Sms.STATUS_PENDING)
            put(Telephony.Sms.SUBSCRIPTION_ID, message.subscriptionId)
        }
        val inserted = runCatching {
            context.contentResolver.insert(Telephony.Sms.Outbox.CONTENT_URI, values)
        }.getOrNull() ?: context.contentResolver.insert(Telephony.Sms.CONTENT_URI, values)
            ?: error("Android did not create the outgoing SMS row.")
        return ContentUris.withAppendedId(Telephony.Sms.CONTENT_URI, ContentUris.parseId(inserted))
    }

    /** Adds a matching MMS provider row, text part, addresses, and attachment parts. */
    private fun insertOutgoingMms(message: OutgoingMessage): Uri {
        var inserted: Uri? = null
        try {
            val threadId = runCatching {
                Telephony.Threads.getOrCreateThreadId(context, message.recipients.toSet())
            }.getOrNull()
            val values = ContentValues().apply {
                    threadId?.let { put(Telephony.Mms.THREAD_ID, it) }
                    put(Telephony.Mms.DATE, System.currentTimeMillis() / 1000L)
                    put(Telephony.Mms.READ, 1)
                    put(Telephony.Mms.SEEN, 1)
                    put(Telephony.Mms.MESSAGE_BOX, Telephony.Mms.MESSAGE_BOX_OUTBOX)
                    put("m_type", MMS_SEND_REQUEST)
                    put("v", MMS_VERSION_1_2)
                    put("ct_t", "application/vnd.wap.multipart.related")
                    put("tr_id", "T${System.currentTimeMillis().toString(16)}")
                    put("sub_id", message.subscriptionId)
                }
            inserted = runCatching {
                context.contentResolver.insert(Telephony.Mms.Outbox.CONTENT_URI, values)
            }.getOrNull() ?: context.contentResolver.insert(Telephony.Mms.CONTENT_URI, values)
                ?: error("Android did not create the outgoing MMS row.")
            val messageId = ContentUris.parseId(requireNotNull(inserted))
            insertMmsAddress(messageId, "insert-address-token", MMS_FROM)
            message.recipients.forEach { insertMmsAddress(messageId, it, MMS_TO) }
            if (message.body.isNotEmpty()) insertMmsTextPart(messageId, message.body)
            message.attachments.forEachIndexed { index, attachment ->
                insertMmsAttachmentPart(messageId, attachment, index + 1)
            }
            return ContentUris.withAppendedId(Telephony.Mms.CONTENT_URI, messageId)
        } catch (error: Throwable) {
            inserted?.let { uri ->
                runCatching { LocalMmsAttachmentStore.deleteMessage(context, ContentUris.parseId(uri)) }
            }
            inserted?.let { uri -> runCatching { context.contentResolver.delete(uri, null, null) } }
            throw error
        }
    }

    private fun insertMmsAddress(messageId: Long, address: String, type: Int) {
        context.contentResolver.insert(
            Uri.parse("content://mms/$messageId/addr"),
            ContentValues().apply {
                put("address", address)
                put("type", type)
                put("charset", MMS_CHARSET_UTF8)
            }
        ) ?: error("Android did not create an MMS address row.")
    }

    private fun insertMmsTextPart(messageId: Long, body: String) {
        context.contentResolver.insert(
            Uri.parse("content://mms/$messageId/part"),
            ContentValues().apply {
                put("ct", "text/plain")
                put("text", body)
                put("chset", MMS_CHARSET_UTF8)
                put("seq", 0)
            }
        ) ?: error("Android did not create the MMS text part.")
    }

    private fun insertMmsAttachmentPart(messageId: Long, attachment: Attachment, sequence: Int) {
        val values = ContentValues().apply {
            put("ct", attachment.mimeType.ifBlank { "application/octet-stream" })
            attachment.displayName?.takeIf(String::isNotBlank)?.let { name ->
                put("name", name)
                put("fn", name)
                put("cl", name)
            }
            put("seq", sequence)
        }
        val source = context.contentResolver.openInputStream(Uri.parse(attachment.uri))
            ?: error("Android could not open ${attachment.displayName ?: "the MMS attachment"}.")
        val data = source.use { it.readBytes() }
        require(data.size <= com.macleanofduartenterprises.macleanmessaging.telephony.MmsCarrierConfig.APP_MAX_MESSAGE_BYTES) {
            "${attachment.displayName ?: "MMS attachment"} is larger than 2 MiB."
        }
        runCatching {
            MmsProviderWriter.insertBinaryPart(context.contentResolver, messageId, values, data)
        }.onFailure {
            Log.w(TAG, "Vendor MMS provider rejected outgoing binary part; using durable app storage", it)
        }.getOrElse {
            LocalMmsAttachmentStore.store(
                context,
                messageId,
                sequence,
                attachment.mimeType,
                attachment.displayName.orEmpty(),
                data
            )
        }
    }

    private fun updateOutgoingProvider(uri: Uri?, transport: Transport, sent: Boolean) {
        uri ?: return
        val values = ContentValues().apply {
            when (transport) {
                Transport.SMS -> put(
                    Telephony.Sms.TYPE,
                    if (sent) Telephony.Sms.MESSAGE_TYPE_SENT else Telephony.Sms.MESSAGE_TYPE_FAILED
                )
                Transport.MMS -> put(
                    Telephony.Mms.MESSAGE_BOX,
                    if (sent) Telephony.Mms.MESSAGE_BOX_SENT else MMS_BOX_FAILED
                )
            }
        }
        runCatching { context.contentResolver.update(uri, values, null, null) }
    }

    /**
     * Re-applies a known terminal state to Android's canonical provider URI. This repairs rows
     * created by builds that could persist metadata before Android stopped their async callback.
     */
    fun reconcileProvider(entity: MessageMetaEntity): Boolean {
        val original = entity.systemUri?.let(Uri::parse) ?: return false
        val id = runCatching { ContentUris.parseId(original) }.getOrNull() ?: return false
        val isMms = original.authority == "mms"
        val values = ContentValues()
        when {
            isMms && entity.state == "CARRIER_ACCEPTED" ->
                values.put(Telephony.Mms.MESSAGE_BOX, Telephony.Mms.MESSAGE_BOX_SENT)
            isMms && entity.state == "FAILED" ->
                values.put(Telephony.Mms.MESSAGE_BOX, MMS_BOX_FAILED)
            !isMms && entity.state in setOf("SENT", "DELIVERED", "DELIVERY_FAILED") -> {
                values.put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_SENT)
                values.put(Telephony.Sms.STATUS, when (entity.state) {
                    "DELIVERED" -> Telephony.Sms.STATUS_COMPLETE
                    "DELIVERY_FAILED" -> Telephony.Sms.STATUS_FAILED
                    else -> Telephony.Sms.STATUS_PENDING
                })
            }
            !isMms && entity.state == "FAILED" -> {
                values.put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_FAILED)
                values.put(Telephony.Sms.STATUS, Telephony.Sms.STATUS_FAILED)
            }
            else -> return false
        }
        val canonical = ContentUris.withAppendedId(
            if (isMms) Telephony.Mms.CONTENT_URI else Telephony.Sms.CONTENT_URI,
            id
        )
        return runCatching { context.contentResolver.update(canonical, values, null, null) > 0 }
            .getOrDefault(false)
    }

    fun markThreadRead(threadId: Long) {
        val values = ContentValues().apply {
            put(Telephony.Sms.READ, 1)
            put(Telephony.Sms.SEEN, 1)
        }
        context.contentResolver.update(
            Telephony.Sms.CONTENT_URI,
            values,
            "${Telephony.Sms.THREAD_ID}=? AND ${Telephony.Sms.READ}=0",
            arrayOf(threadId.toString())
        )
        DeviceMessageRepository.invalidateCaches(threadId)
        context.contentResolver.update(
            Telephony.Mms.CONTENT_URI,
            ContentValues().apply {
                put(Telephony.Mms.READ, 1)
                put(Telephony.Mms.SEEN, 1)
            },
            "${Telephony.Mms.THREAD_ID}=? AND ${Telephony.Mms.READ}=0",
            arrayOf(threadId.toString())
        )
    }

    /** Marks a conversation unread without making Android re-alert already seen messages. */
    fun markThreadUnread(threadId: Long) {
        context.contentResolver.update(
            Telephony.Sms.CONTENT_URI,
            ContentValues().apply {
                put(Telephony.Sms.READ, 0)
                put(Telephony.Sms.SEEN, 1)
            },
            "${Telephony.Sms.THREAD_ID}=?",
            arrayOf(threadId.toString())
        )
        DeviceMessageRepository.invalidateCaches(threadId)
        context.contentResolver.update(
            Telephony.Mms.CONTENT_URI,
            ContentValues().apply {
                put(Telephony.Mms.READ, 0)
                put(Telephony.Mms.SEEN, 1)
            },
            "${Telephony.Mms.THREAD_ID}=?",
            arrayOf(threadId.toString())
        )
    }

    fun deleteSms(id: Long): Int =
        context.contentResolver.delete(
            ContentUris.withAppendedId(Telephony.Sms.CONTENT_URI, id),
            null,
            null
        ).also { DeviceMessageRepository.invalidateCaches() }

    fun searchSms(query: String, limit: Int = 200): List<SystemSms> {
        val out = mutableListOf<SystemSms>()
        context.contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(
                Telephony.Sms._ID,
                Telephony.Sms.THREAD_ID,
                Telephony.Sms.ADDRESS,
                Telephony.Sms.BODY,
                Telephony.Sms.DATE,
                Telephony.Sms.TYPE,
                Telephony.Sms.READ,
                Telephony.Sms.SUBSCRIPTION_ID
            ),
            "${Telephony.Sms.BODY} LIKE ?",
            arrayOf("%$query%"),
            "${Telephony.Sms.DATE} DESC LIMIT $limit"
        )?.use { c ->
            while (c.moveToNext()) {
                out += SystemSms(
                    id = c.getLong(0),
                    threadId = c.getLong(1),
                    address = c.getString(2).orEmpty(),
                    body = c.getString(3).orEmpty(),
                    date = c.getLong(4),
                    type = c.getInt(5),
                    read = c.getInt(6) != 0,
                    subscriptionId = c.getInt(7)
                )
            }
        }
        return out
    }

    private companion object {
        const val TAG = "SystemMessages"
        const val MMS_FROM = 137
        const val MMS_TO = 151
        const val MMS_SEND_REQUEST = 128
        const val MMS_VERSION_1_2 = 0x12
        const val MMS_CHARSET_UTF8 = 106
        const val MMS_BOX_FAILED = 5
    }
}

data class SystemSms(
    val id: Long,
    val threadId: Long,
    val address: String,
    val body: String,
    val date: Long,
    val type: Int,
    val read: Boolean,
    val subscriptionId: Int
)
