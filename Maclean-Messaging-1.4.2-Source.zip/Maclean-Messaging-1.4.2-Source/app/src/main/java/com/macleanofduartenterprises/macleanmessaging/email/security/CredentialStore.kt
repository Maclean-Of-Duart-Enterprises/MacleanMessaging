/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.email.security
import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
interface CredentialStore { fun put(alias:String,secret:CharArray); fun get(alias:String):CharArray?; fun remove(alias:String) }
class AndroidKeystoreCredentialStore(context:Context):CredentialStore {
 private val prefs=context.applicationContext.getSharedPreferences("email_credentials",Context.MODE_PRIVATE)
 private val ks=KeyStore.getInstance("AndroidKeyStore").apply{load(null)}
 override fun put(alias:String,secret:CharArray){
  val cipher=Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE,key(alias)); val ct=cipher.doFinal(String(secret).toByteArray())
  val packed=ByteArray(cipher.iv.size+ct.size); System.arraycopy(cipher.iv,0,packed,0,cipher.iv.size);System.arraycopy(ct,0,packed,cipher.iv.size,ct.size)
  prefs.edit().putString(alias,Base64.encodeToString(packed,Base64.NO_WRAP)).apply(); secret.fill('\u0000')
 }
 override fun get(alias:String):CharArray?{ val packed=Base64.decode(prefs.getString(alias,null)?:return null,Base64.NO_WRAP); if(packed.size<=12)return null; val k=ks.getKey(kalias(alias),null) as? SecretKey?:return null; val c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE,k,GCMParameterSpec(128,packed.copyOfRange(0,12))); return c.doFinal(packed.copyOfRange(12,packed.size)).toString(Charsets.UTF_8).toCharArray() }
 override fun remove(alias:String){prefs.edit().remove(alias).apply();if(ks.containsAlias(kalias(alias)))ks.deleteEntry(kalias(alias))}
 private fun key(alias:String):SecretKey{(ks.getKey(kalias(alias),null) as? SecretKey)?.let{return it};val g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");g.init(KeyGenParameterSpec.Builder(kalias(alias),KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());return g.generateKey()}
 private fun kalias(a:String)="maclean.messaging.email.$a"
}
