/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 */

package com.macleanofduartenterprises.macleanmessaging.contacts

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.telephony.PhoneNumberUtils
import android.os.SystemClock

/**
 * A short-lived, in-memory lookup built with three bulk Contacts queries. This avoids issuing a
 * separate Contacts provider query for every conversation while still reflecting changes quickly.
 */
class ContactIndex private constructor(
    private val emails: Map<String, ContactSummary>,
    private val phones: Map<String, ContactSummary>,
    private val phoneSuffixes: Map<String, ContactSummary>
) {
    fun resolve(address: String): ContactSummary? {
        val value = address.trim()
        if (value.isBlank()) return null
        if ('@' in value) return emails[value.lowercase()]
        val normalized = PhoneNumberUtils.normalizeNumber(value)
        if (normalized.isBlank()) return null
        return phones[normalized] ?: normalized.takeIf { it.length >= 7 }
            ?.takeLast(10)
            ?.let(phoneSuffixes::get)
    }

    companion object {
        private const val CACHE_DURATION_MS = 60_000L
        private val empty = ContactIndex(emptyMap(), emptyMap(), emptyMap())

        @Volatile private var cached: ContactIndex? = null
        @Volatile private var cachedAt = 0L

        fun load(context: Context): ContactIndex {
            if (context.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                return empty
            }
            val now = SystemClock.elapsedRealtime()
            cached?.takeIf { now - cachedAt < CACHE_DURATION_MS }?.let { return it }
            return synchronized(this) {
                cached?.takeIf { now - cachedAt < CACHE_DURATION_MS } ?: runCatching { build(context) }
                    .getOrDefault(empty).also {
                    cached = it
                    cachedAt = SystemClock.elapsedRealtime()
                }
            }
        }

        private fun build(context: Context): ContactIndex {
            val emailMap = linkedMapOf<String, ContactSummary>()
            val phoneMap = linkedMapOf<String, ContactSummary>()
            val suffixMap = linkedMapOf<String, ContactSummary>()
            ContactDirectory(context).all().forEach { contact ->
                val summary = ContactSummary(contact.displayName, contact.photoUri)
                contact.emailAddresses.forEach { emailMap.putIfAbsent(it.trim().lowercase(), summary) }
                contact.phoneNumbers.forEach { number ->
                    val normalized = PhoneNumberUtils.normalizeNumber(number)
                    if (normalized.isNotBlank()) {
                        phoneMap.putIfAbsent(normalized, summary)
                        if (normalized.length >= 7) suffixMap.putIfAbsent(normalized.takeLast(10), summary)
                    }
                }
            }
            return ContactIndex(emailMap, phoneMap, suffixMap)
        }
    }
}
