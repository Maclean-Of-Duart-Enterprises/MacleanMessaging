/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.email.oauth
import android.content.*
import android.net.Uri
import android.util.Base64
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailAccountEntity
import com.macleanofduartenterprises.macleanmessaging.email.security.AndroidKeystoreCredentialStore
import java.net.*
import java.security.*
import org.json.JSONObject
class OAuth2Manager(private val context:Context){
 private val prefs=context.getSharedPreferences("oauth_sessions",Context.MODE_PRIVATE);private val secrets=AndroidKeystoreCredentialStore(context)
 fun buildAuthorizationIntent(a:EmailAccountEntity):Intent{require(a.authType=="OAUTH2");val verifier=random(48);val challenge=Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray()),Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING);val state=random(24);prefs.edit().putString("state:$state","${a.id}|$verifier").apply();val u=Uri.parse(requireNotNull(a.oauthAuthorizeEndpoint)).buildUpon().appendQueryParameter("response_type","code").appendQueryParameter("client_id",requireNotNull(a.oauthClientId)).appendQueryParameter("redirect_uri",REDIRECT_URI).appendQueryParameter("scope",a.oauthScopes?:"openid email offline_access").appendQueryParameter("state",state).appendQueryParameter("code_challenge",challenge).appendQueryParameter("code_challenge_method","S256").build();return Intent(Intent.ACTION_VIEW,u)}
 suspend fun consumeRedirect(uri:Uri,lookup:suspend(String)->EmailAccountEntity?):Result<String>{val err=uri.getQueryParameter("error");if(err!=null)return Result.failure(IllegalStateException("OAuth error: $err"));val code=uri.getQueryParameter("code")?:return Result.failure(IllegalArgumentException("Missing code"));val state=uri.getQueryParameter("state")?:return Result.failure(IllegalArgumentException("Missing state"));val packed=prefs.getString("state:$state",null)?:return Result.failure(SecurityException("OAuth state mismatch"));prefs.edit().remove("state:$state").apply();val parts=packed.split("|",limit=2);val a=lookup(parts[0])?:return Result.failure(IllegalStateException("Account removed"));return runCatching{val t=tokenRequest(requireNotNull(a.oauthTokenEndpoint),mapOf("grant_type" to "authorization_code","code" to code,"client_id" to requireNotNull(a.oauthClientId),"redirect_uri" to REDIRECT_URI,"code_verifier" to parts[1]));t.second?.let{secrets.put(a.credentialAlias?:"oauth-${a.id}",it.toCharArray())};a.id}}
 fun accessToken(a:EmailAccountEntity):Result<String> = runCatching{val refresh=a.credentialAlias?.let(secrets::get)?.concatToString()?:error("No OAuth refresh token");val t=tokenRequest(requireNotNull(a.oauthTokenEndpoint),mapOf("grant_type" to "refresh_token","refresh_token" to refresh,"client_id" to requireNotNull(a.oauthClientId)));t.second?.let{secrets.put(a.credentialAlias?:"oauth-${a.id}",it.toCharArray())};t.first}
 private fun tokenRequest(endpoint:String,p:Map<String,String>):Pair<String,String?>{val c=URL(endpoint).openConnection() as HttpURLConnection;c.requestMethod="POST";c.connectTimeout=30000;c.readTimeout=30000;c.doOutput=true;c.setRequestProperty("Content-Type","application/x-www-form-urlencoded");val body=p.entries.joinToString("&"){URLEncoder.encode(it.key,"UTF-8")+"="+URLEncoder.encode(it.value,"UTF-8")};c.outputStream.use{it.write(body.toByteArray())};val text=(if(c.responseCode in 200..299)c.inputStream else c.errorStream).bufferedReader().use{it.readText()};if(c.responseCode !in 200..299)error("OAuth HTTP ${c.responseCode}: $text");val j=JSONObject(text);return j.getString("access_token") to j.optString("refresh_token").takeIf{it.isNotBlank()}}
 private fun random(n:Int):String{val b=ByteArray(n);SecureRandom().nextBytes(b);return Base64.encodeToString(b,Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)}
 companion object{const val REDIRECT_URI="macleanmessaging://oauth2redirect"}
}
