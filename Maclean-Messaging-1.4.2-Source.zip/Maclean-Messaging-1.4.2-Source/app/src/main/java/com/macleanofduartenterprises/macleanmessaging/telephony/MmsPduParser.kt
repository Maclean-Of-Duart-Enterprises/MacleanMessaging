/* Maclean Messaging — SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanmessaging.telephony

/** Small MM1/WSP decoder for Notification.ind and Retrieve.conf carrier PDUs. */
object MmsPduParser {
    data class Notification(
        val transactionId: String,
        val contentLocation: String,
        val sender: String?
    )

    data class RetrievedPart(
        val mimeType: String,
        val name: String,
        val contentId: String?,
        val data: ByteArray
    )

    data class Retrieved(
        val transactionId: String?,
        val messageId: String?,
        val sender: String,
        val dateMillis: Long,
        val parts: List<RetrievedPart>
    ) {
        val text: String = parts.filter { isVisibleTextPart(it.mimeType) }
            .joinToString("\n") { it.data.toString(Charsets.UTF_8) }
        val attachments: List<RetrievedPart> = parts.filterNot { isInlineTextPart(it.mimeType) }
    }

    /** Android's MMS provider stores these content types in the part table's text column. */
    fun isInlineTextPart(mimeType: String): Boolean = when (normalizedType(mimeType)) {
        "text/plain", "text/html", "application/smil" -> true
        else -> false
    }

    /** SMIL controls presentation and must not be duplicated in the visible message body. */
    fun isVisibleTextPart(mimeType: String): Boolean = when (normalizedType(mimeType)) {
        "text/plain", "text/html" -> true
        else -> false
    }

    private fun normalizedType(value: String): String =
        value.substringBefore(';').trim().lowercase()

    fun parseNotification(data: ByteArray): Notification {
        val headers = parseHeaders(data)
        check(headers.messageType == MMS_NOTIFICATION_IND) { "Carrier push is not an MMS notification." }
        val location = headers.contentLocation?.takeIf(String::isNotBlank)
            ?: error("MMS notification has no content location.")
        return Notification(headers.transactionId.orEmpty(), location, headers.sender)
    }

    fun parseRetrieveConf(data: ByteArray): Retrieved {
        val headers = parseHeaders(data)
        check(headers.messageType == MMS_RETRIEVE_CONF) { "Downloaded carrier response is not an MMS message." }
        val bodyOffset = headers.bodyOffset ?: error("Downloaded MMS has no multipart body.")
        val cursor = Cursor(data, bodyOffset)
        val count = cursor.readUintvar().toInt().coerceAtMost(MAX_PARTS)
        val parts = buildList {
            repeat(count) {
                val headerLength = cursor.readUintvar().toInt()
                val dataLength = cursor.readUintvar().toInt()
                require(headerLength >= 0 && dataLength >= 0 && headerLength <= cursor.remaining) { "Invalid MMS part header." }
                val headerEnd = cursor.position + headerLength
                val descriptor = parsePartHeaders(data, cursor.position, headerEnd)
                cursor.position = headerEnd
                require(dataLength <= cursor.remaining) { "Truncated MMS attachment." }
                val bytes = data.copyOfRange(cursor.position, cursor.position + dataLength)
                cursor.position += dataLength
                add(RetrievedPart(descriptor.mimeType, descriptor.name, descriptor.contentId, bytes))
            }
        }
        return Retrieved(
            transactionId = headers.transactionId,
            messageId = headers.messageId,
            sender = headers.sender.orEmpty(),
            dateMillis = headers.dateSeconds?.times(1000L) ?: System.currentTimeMillis(),
            parts = parts
        )
    }

    private data class Headers(
        var messageType: Int? = null,
        var transactionId: String? = null,
        var messageId: String? = null,
        var contentLocation: String? = null,
        var sender: String? = null,
        var dateSeconds: Long? = null,
        var bodyOffset: Int? = null
    )

    private fun parseHeaders(data: ByteArray): Headers {
        val c = Cursor(data)
        val result = Headers()
        while (c.remaining > 0) {
            val name = c.readByte()
            if (name < 0x80) {
                c.skipTextStartingWith(name)
                c.skipUnknownValue()
                continue
            }
            when (name) {
                0x83 -> result.contentLocation = c.readText()
                0x84 -> {
                    c.skipContentType()
                    result.bodyOffset = c.position
                    return result
                }
                0x85 -> result.dateSeconds = c.readLongInteger()
                0x89 -> result.sender = c.readFrom()
                0x8B -> result.messageId = c.readText()
                0x8C -> result.messageType = c.readByte()
                0x98 -> result.transactionId = c.readText()
                // Encoded-string-value headers.
                0x81, 0x82, 0x93, 0x96, 0x97 -> c.readEncodedString()
                // Value-length headers.
                0x87, 0x88 -> c.skipValueLengthField()
                // Long-integer headers.
                0x8E -> c.readLongInteger()
                // One-octet/token headers.
                0x86, 0x8D, 0x8F, 0x90, 0x91, 0x92, 0x94, 0x95 -> c.skip(1)
                // Message-Class may be a token or text string.
                0x8A -> if (c.peek() >= 0x80) c.skip(1) else c.readText()
                else -> c.skipUnknownValue()
            }
        }
        return result
    }

    private data class PartDescriptor(val mimeType: String, val name: String, val contentId: String?)

    private fun parsePartHeaders(data: ByteArray, start: Int, end: Int): PartDescriptor {
        val c = Cursor(data, start, end)
        var name: String? = null
        var contentId: String? = null
        val mimeType: String
        val first = c.peek()
        if (first <= 31) {
            val length = c.readValueLength().toInt().coerceAtMost(c.remaining)
            val typeEnd = c.position + length
            mimeType = c.readContentTypeValue()
            while (c.position < typeEnd) {
                when (c.readByte()) {
                    0x85, 0x86 -> name = c.readText()
                    0x81 -> c.skipInteger()
                    else -> c.skipUnknownValue()
                }
            }
            c.position = typeEnd
        } else {
            mimeType = c.readContentTypeValue()
        }
        while (c.remaining > 0) {
            when (c.readByte()) {
                0x8E -> name = c.readText()
                0xC0 -> contentId = c.readText().trim('<', '>')
                else -> c.skipUnknownValue()
            }
        }
        val safeName = (name ?: contentId ?: defaultName(mimeType))
            .replace(Regex("[\\r\\n/\\\\]+"), "_").take(120).ifBlank { "attachment" }
        return PartDescriptor(mimeType, safeName, contentId)
    }

    private fun defaultName(mimeType: String): String = when {
        mimeType.startsWith("text/plain") -> "text.txt"
        mimeType.contains("smil") -> "presentation.smil"
        mimeType.startsWith("image/jpeg") -> "image.jpg"
        mimeType.startsWith("image/png") -> "image.png"
        mimeType.startsWith("image/gif") -> "image.gif"
        mimeType.startsWith("audio/ogg") -> "voice-message.ogg"
        mimeType.startsWith("audio/") -> "audio"
        mimeType.startsWith("video/") -> "video"
        else -> "attachment"
    }

    private class Cursor(private val bytes: ByteArray, start: Int = 0, private val limit: Int = bytes.size) {
        var position: Int = start
        val remaining: Int get() = (limit - position).coerceAtLeast(0)

        fun peek(): Int = if (position < limit) bytes[position].toInt() and 0xff else 0
        fun readByte(): Int { require(position < limit) { "Truncated MMS PDU." }; return bytes[position++].toInt() and 0xff }
        fun skip(count: Int) { require(count >= 0 && count <= remaining) { "Truncated MMS PDU." }; position += count }

        fun readText(): String {
            if (peek() == 0x7F) position++
            val start = position
            while (position < limit && bytes[position].toInt() != 0) position++
            val value = bytes.copyOfRange(start, position).toString(Charsets.UTF_8)
            if (position < limit) position++
            return value
        }

        fun skipTextStartingWith(first: Int) {
            if (first == 0x7F) Unit
            while (position < limit && bytes[position++].toInt() != 0) Unit
        }

        fun readUintvar(): Long {
            var value = 0L
            repeat(5) {
                val octet = readByte()
                value = (value shl 7) or (octet and 0x7F).toLong()
                if (octet and 0x80 == 0) return value
            }
            error("Invalid MMS uintvar.")
        }

        fun readValueLength(): Long {
            val first = readByte()
            return when {
                first <= 30 -> first.toLong()
                first == 31 -> readUintvar()
                else -> error("Invalid MMS value length.")
            }
        }

        fun readLongInteger(): Long {
            val length = readByte()
            require(length in 1..8 && length <= remaining) { "Invalid MMS integer." }
            var result = 0L
            repeat(length) { result = (result shl 8) or readByte().toLong() }
            return result
        }

        fun skipInteger() {
            if (peek() >= 0x80) skip(1) else readLongInteger()
        }

        fun readEncodedString(): String {
            if (peek() > 31) return readText()
            val length = readValueLength().toInt().coerceAtMost(remaining)
            val end = position + length
            if (position < end) skipInteger()
            val value = if (position < end) readText() else ""
            position = end
            return value
        }

        fun readFrom(): String? {
            val length = readValueLength().toInt().coerceAtMost(remaining)
            val end = position + length
            val token = if (position < end) readByte() else 0x81
            val value = if (token == 0x80 && position < end) readEncodedString() else null
            position = end
            return value?.substringBefore("/TYPE=")
        }

        fun skipValueLengthField() { skip(readValueLength().toInt().coerceAtMost(remaining)) }

        fun skipContentType() {
            if (peek() <= 31) skip(readValueLength().toInt().coerceAtMost(remaining))
            else if (peek() >= 0x80) skip(1)
            else readText()
        }

        fun readContentTypeValue(): String {
            val first = peek()
            return if (first >= 0x80) contentTypeFor(readByte()) else readText()
        }

        fun skipUnknownValue() {
            when (peek()) {
                in 0..30 -> { val length = readByte(); skip(length.coerceAtMost(remaining)) }
                31 -> { readByte(); skip(readUintvar().toInt().coerceAtMost(remaining)) }
                in 32..127 -> readText()
                else -> skip(1)
            }
        }
    }

    private fun contentTypeFor(encoded: Int): String = when (encoded and 0x7F) {
        0x03 -> "text/plain"
        0x1D -> "image/gif"
        0x1E -> "image/jpeg"
        0x20 -> "image/png"
        0x23 -> "application/vnd.wap.multipart.mixed"
        0x24 -> "application/vnd.wap.multipart.form-data"
        0x25 -> "application/vnd.wap.multipart.byteranges"
        0x26 -> "application/vnd.wap.multipart.alternative"
        0x27 -> "application/xml"
        0x31 -> "text/vnd.wap.co"
        0x33 -> "application/vnd.wap.multipart.related"
        0x3E -> "application/vnd.wap.mms-message"
        0x4F -> "audio/*"
        0x50 -> "video/*"
        else -> "application/octet-stream"
    }

    private const val MMS_NOTIFICATION_IND = 0x82
    private const val MMS_RETRIEVE_CONF = 0x84
    private const val MAX_PARTS = 100
}
