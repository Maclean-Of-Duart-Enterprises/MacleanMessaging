/*
 * Maclean Messaging
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * Copyright (C) 2026 Maclean Of Duart Enterprises
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 */

package com.macleanofduartenterprises.macleanmessaging.email.compose

import android.content.Context
import com.macleanofduartenterprises.macleanmessaging.data.LocalDatabase
import com.macleanofduartenterprises.macleanmessaging.email.data.EmailMessageEntity
import com.macleanofduartenterprises.macleanmessaging.email.notifications.EmailNotifier
import com.macleanofduartenterprises.macleanmessaging.email.transport.ImapTransport
import org.json.JSONArray

enum class ComposeMode { NEW, REPLY, REPLY_ALL, FORWARD }

data class ComposeSeed(
    val mode: ComposeMode,
    val accountId: String?,
    val to: List<String> = emptyList(),
    val cc: List<String> = emptyList(),
    val subject: String = "",
    val body: String = "",
    val sourceMessageId: String? = null
)

class EmailActionService(private val context: Context) {
    private val db = LocalDatabase.get(context)

    suspend fun threadMessages(threadId: String): List<EmailMessageEntity> =
        db.emailMessageDao().forThread(threadId)

    /** Marks the local rows immediately so the inbox badge and notification react at once. */
    suspend fun markThreadReadLocally(threadId: String): List<EmailMessageEntity> {
        val unread = db.emailMessageDao().forThread(threadId).filter(EmailMessageEntity::unread)
        if (unread.isEmpty()) return emptyList()
        db.markEmailThreadRead(threadId)
        updateNotifications(unread.map(EmailMessageEntity::accountId).toSet())
        return unread.filter(::isRemoteInboxMessage)
    }

    /** Pushes a local read-state decision to the configured IMAP server. */
    suspend fun pushSeenState(messages: List<EmailMessageEntity>, seen: Boolean): Result<Unit> = runCatching {
        messages.filter(::isRemoteInboxMessage).groupBy(EmailMessageEntity::accountId).forEach { (accountId, group) ->
            val account = requireNotNull(db.emailAccountDao().get(accountId)) { "The email account was removed." }
            ImapTransport(context).setSeen(account, group, seen).getOrThrow()
        }
    }

    suspend fun setUnread(messageId: String, unread: Boolean): Result<Unit> = runCatching {
        check(setUnread(listOf(messageId), unread).getOrThrow() == 1) { "Message was not found." }
    }

    /**
     * Applies a bulk read-state change with one IMAP STORE operation per account. Each account's
     * local rows are updated only after its remote operation succeeds, keeping the two stores in
     * agreement if a later account fails.
     */
    suspend fun setUnread(messageIds: Collection<String>, unread: Boolean): Result<Int> = runCatching {
        val messages = db.emailMessages(messageIds)
        if (messages.isEmpty()) return@runCatching 0
        messages.groupBy(EmailMessageEntity::accountId).forEach { (accountId, group) ->
            val remote = group.filter(::isRemoteInboxMessage)
            if (remote.isNotEmpty()) {
                val account = requireNotNull(db.emailAccountDao().get(accountId)) { "The email account was removed." }
                ImapTransport(context).setSeen(account, remote, !unread).getOrThrow()
            }
            db.setEmailMessagesUnread(group.map(EmailMessageEntity::stableId), unread)
            updateNotifications(setOf(accountId))
        }
        messages.size
    }

    /** Deletes remote INBOX records first, then removes the corresponding local rows. */
    suspend fun deleteMessages(messageIds: Collection<String>): Result<Int> = runCatching {
        val messages = messageIds.distinct().mapNotNull(db.emailMessageDao()::get)
        if (messages.isEmpty()) return@runCatching 0
        messages.filter(::isRemoteInboxMessage)
            .groupBy(EmailMessageEntity::accountId)
            .forEach { (accountId, group) ->
                val account = requireNotNull(db.emailAccountDao().get(accountId)) { "The email account was removed." }
                ImapTransport(context).delete(account, group).getOrThrow()
            }
        messages.forEach { db.deleteEmailMessage(it.stableId) }
        updateNotifications(messages.map(EmailMessageEntity::accountId).toSet())
        messages.size
    }

    suspend fun deleteThread(threadId: String): Result<Int> =
        deleteMessages(db.emailMessageDao().forThread(threadId).map(EmailMessageEntity::stableId))

    suspend fun seed(mode: ComposeMode, sourceId: String): ComposeSeed {
        val msg = requireNotNull(db.emailMessageDao().get(sourceId)) { "Message was not found." }
        val account = requireNotNull(db.emailAccountDao().get(msg.accountId))
        val recipients = parseRecipients(msg.recipientsJson)
        val replyTo = extractAddress(msg.sender)
        val quoted = quotedBlock(msg)

        return when (mode) {
            ComposeMode.REPLY -> ComposeSeed(
                mode, msg.accountId, to=listOf(replyTo),
                subject=replySubject(msg.subject), body="\n\n$quoted", sourceMessageId=sourceId
            )
            ComposeMode.REPLY_ALL -> {
                val all = (listOf(replyTo) + recipients)
                    .map(::extractAddress)
                    .filter { !it.equals(account.emailAddress, true) }
                    .distinctBy(String::lowercase)
                ComposeSeed(
                    mode, msg.accountId, to=all,
                    subject=replySubject(msg.subject), body="\n\n$quoted", sourceMessageId=sourceId
                )
            }
            ComposeMode.FORWARD -> ComposeSeed(
                mode, msg.accountId,
                subject=forwardSubject(msg.subject),
                body="\n\n---------- Forwarded message ----------\n$quoted",
                sourceMessageId=sourceId
            )
            ComposeMode.NEW -> ComposeSeed(mode, null)
        }
    }

    private fun parseRecipients(json: String): List<String> = runCatching {
        val a = JSONArray(json)
        (0 until a.length()).map { a.getString(it) }
    }.getOrDefault(emptyList())

    private fun replySubject(s: String?) =
        if (s.orEmpty().trim().startsWith("Re:", true)) s.orEmpty() else "Re: ${s.orEmpty()}".trim()
    private fun forwardSubject(s: String?) =
        if (s.orEmpty().trim().startsWith("Fwd:", true)) s.orEmpty() else "Fwd: ${s.orEmpty()}".trim()

    private fun quotedBlock(m: EmailMessageEntity) =
        "From: ${m.sender}\nSubject: ${m.subject.orEmpty()}\n\n${m.bodyText}"
            .lines().joinToString("\n") { "> $it" }

    private fun extractAddress(v: String): String =
        Regex("""<([^>]+)>""").find(v)?.groupValues?.get(1) ?: v.trim()

    private fun isRemoteInboxMessage(message: EmailMessageEntity): Boolean =
        message.folder.equals("INBOX", true) && !message.stableId.startsWith("sent:")

    private fun updateNotifications(accountIds: Set<String>) {
        accountIds.forEach { accountId ->
            db.emailAccountDao().get(accountId)?.let { account ->
                EmailNotifier.updateUnread(context, account, db.emailUnreadCount(accountId))
            }
        }
    }
}
