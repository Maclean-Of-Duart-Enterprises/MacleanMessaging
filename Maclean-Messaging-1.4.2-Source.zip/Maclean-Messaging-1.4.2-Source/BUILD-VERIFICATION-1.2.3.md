# Maclean Messaging 1.2.3 — Build Verification

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name: `1.2.3`
- Version code: `10203`
- Minimum Android API: 29
- Target/compile Android API: 35
- License: GNU AGPLv3 / `AGPL-3.0-only`

## Interface and settings changes

- Main-page conversation management, filtering, and sorting use compact controls and overflow menus instead of large action grids.
- Conversation cards and SMS, MMS, and email items expose compact individual action menus while preserving bulk management.
- Incoming and outgoing items use compact offset message panels.
- Six coordinated palettes and a custom `#RRGGBB` background color are available.
- A local image can be chosen, previewed, enabled/disabled, replaced, or removed as the app background; persisted Android document access is used instead of copying the user's photo.
- Background strength, message-panel opacity, text scale, and high contrast remain adjustable.
- Main-page transport, saved-contact status, and ordering defaults persist in settings.
- Every SMS/MMS and email conversation has a remembered oldest/newest/received/sent/text sort override.
- Standard Android SMS/MMS compose entry points and an explicit `mailto:` launch path remain available for later Maclean Phone integration.

## Completed build checks

- All 54 Kotlin source files compiled without errors using Kotlin 1.9.24 and Java 17 against Android API 35.
- Standalone Android lint completed with 0 errors and 28 non-blocking warnings. Most warnings are pre-existing conservative resource/cursor checks that do not recognize Kotlin `use`; the temporary standalone lint manifest also lacks Gradle-injected version metadata.
- Unicode/MIME regression tests passed for accented Latin text, Polish text, Cyrillic, Japanese, emoji, RFC 2047, raw UTF-8 headers, Base64 multipart content, quoted-printable content, ISO-8859-1, and a Unicode attachment filename.
- Android resources and manifest linked successfully with Build Tools 35.0.1.
- D8 release DEX generation completed successfully.
- APK archive integrity and four-byte ZIP alignment verified.
- Package metadata verified as version `1.2.3` / code `10203` with minimum API 29 and target API 35.
- APK Signature Scheme v3 verified with one signer. This matches the signature scheme used by the supplied 1.2.1 and 1.2.2 builds and is supported throughout this app's API 29+ range.
- Signing certificate exactly matches both prior production APKs.
- Signing key: 4096-bit RSA.
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`.
- APK SHA-256: `56e246e454cb30b2722d0b3d4b37b369e4a2bce0a0fded50839bef455718a763`.
- The signing password and keystore are absent from the release source and APK.
- `LocalDatabase.kt` is byte-for-byte unchanged from 1.2.2, preserving the existing database schema and upgrade path.

## Device-validation boundary

No Android device or emulator was attached to the build environment, so installation, in-place upgrade, startup, and visual interaction could not be executed here. Real-device checks remain for compact layout at different display/text sizes, all palettes, document-provider photo persistence, rotation/process recreation, TalkBack, carrier SMS/MMS, dual-SIM behavior, Android Contacts synchronization, and live IMAP/SMTP/OAuth accounts.

The app reads contacts already synchronized into Android's aggregated Contacts provider. Android and each configured account provider perform the actual network synchronization.
