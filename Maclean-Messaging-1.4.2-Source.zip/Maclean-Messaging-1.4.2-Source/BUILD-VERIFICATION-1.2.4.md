# Maclean Messaging 1.2.4 — Build Verification

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name: `1.2.4`
- Version code: `10204`
- Minimum Android API: 29
- Target/compile Android API: 35
- License: GNU AGPLv3 / `AGPL-3.0-only`

## Repairs in this release

- Startup now launches one inbox request instead of repeating it from the first `onResume` callback.
- A previously rendered inbox is shown immediately while later resume refreshes complete.
- SMS and MMS provider rows are scanned as lightweight thread summaries. Historical MMS parts and addresses are no longer materialized to build the inbox; only the newest MMS selected for a thread is hydrated for its list preview.
- Participant names and photos use one short-lived bulk Contacts index instead of a provider query for every conversation participant.
- Android 15+ receives a white system-status inset above every toolbar; Android 10–14 retain the platform inset and receive a slim white separator.
- Selected background photos are copied to private app storage, existing readable 1.2.3 URI selections migrate automatically, and sampled bitmaps are cached between screens.
- Root content, scrolling content, and page content are explicitly transparent so photos and palettes appear on the inbox and SMS/MMS/email conversation screens.
- Subscription-specific SMS/MMS manager creation now has the required Android 10/11 compatibility fallback.

## Completed build checks

- All 55 Kotlin source files compiled without errors using Kotlin 1.9.24 and Java 17 against Android API 35.
- Standalone Android lint completed with 0 errors and 8 non-blocking warnings. Remaining warnings concern Gradle-injected version metadata in the standalone lint manifest, an API-gated notification permission, localization of two programmatic labels, backup metadata, one conservative stream check, and resource analysis that cannot see the custom provider reference.
- Unicode/MIME regression tests passed for accented Latin text, Polish text, Cyrillic, Japanese, emoji, RFC 2047, raw UTF-8 headers, Base64 multipart content, quoted-printable content, ISO-8859-1, and a Unicode attachment filename.
- Regression-path inspection confirmed the lightweight SMS and MMS scans, bulk Contacts index, first-resume guard, private background directory, transparent content layers, and status-inset listener are present.
- Android resources and manifest linked successfully with Build Tools 35.0.1.
- D8 release DEX generation completed successfully.
- APK archive integrity and four-byte ZIP alignment verified.
- Package metadata verified as version `1.2.4` / code `10204`, minimum API 29, and target API 35.
- APK Signature Scheme v3 verified with one signer, matching the supplied 1.2.3 production certificate.
- Signing key: 4096-bit RSA.
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`.
- APK SHA-256: `86e3908ccd11742c5ff98f0a5a192ae1a2f1bfa4b9db08d90f44993caca60671`.
- The signing password and keystore are absent from the release source and APK.
- `LocalDatabase.kt` is byte-for-byte unchanged from 1.2.3, preserving the existing schema and upgrade path.

## Device-validation boundary

No Android device or emulator was attached to the build environment, so installation, in-place upgrade, timed cold/warm startup, and visual interaction could not be executed here. The performance repair is verified structurally and by compilation, but its device-specific improvement must be timed against the user's real SMS/MMS and Contacts providers.

Real-device checks remain for the white status safe area on cutout and non-cutout displays, background selection and 1.2.3 migration across process/device restarts, inbox and conversation background visibility, high contrast, TalkBack, carrier SMS/MMS, dual-SIM behavior, Android Contacts changes, and live IMAP/SMTP/OAuth accounts.
