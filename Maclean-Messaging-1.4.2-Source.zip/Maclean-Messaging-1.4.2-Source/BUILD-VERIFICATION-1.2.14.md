# Maclean Messaging 1.2.14 — build verification

Built on 2026-09-13. This corrective release repairs SMS/MMS carrier handoff, 2 MiB MMS upload/download, provider visibility isolation, and interrupted incoming-MMS recovery.

## Release identity

- Application/package ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name/code: `1.2.14` / `10214`
- Minimum/target Android API: 29 / 35
- Signed APK: `Maclean-Messaging-1.2.14-Signed.apk`
- APK size: 1,073,810 bytes
- APK SHA-256: `83da93b71b5d87fead46ab7dcda1fd8c73f49593d674edaf03d44b8d6faf9478`
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`
- Signature: APK Signature Scheme v3, one 4096-bit RSA signer, matching 1.2.13.

The increasing version code, unchanged package ID, and unchanged signer support an in-place update without uninstalling or clearing app data.

## SMS/MMS repairs

- Normalizes SMS and MMS phone recipients before handoff and uses `sendTextMessage` for a single SMS segment or `sendMultipartTextMessage` for multiple segments.
- Attempts both the typed Outbox and canonical provider insertion paths; a transient vendor provider-write defect no longer prevents carrier submission.
- Passes a 2 MiB maximum-message override to both `sendMultimediaMessage` and `downloadMultimediaMessage`, rather than treating a legacy 300 KiB vendor value as the app limit.
- Retains cellular-network constraints for scheduled MMS and incoming retry. Ordinary SMS continues through the selected SIM without IP data.
- Isolates SMS and MMS conversation scans, counts, headers, and per-message hydration so one failing MMS cannot blank SMS or the complete inbox.
- Observes Android's SMS/MMS providers and refreshes the active inbox or conversation after incoming messages and carrier state changes.
- Imports a non-empty downloaded MMS left behind by process death, persists the originating subscription for dual-SIM retry, and re-arms retained notifications after restart or role restoration.
- Keeps receiver completion, notifications, staging, provider import, attachment rendering, and provider status updates contained against uncaught failures.

## Completed host checks

- All Kotlin production sources compiled with Kotlin 1.9.24, Java 17, and Android API 35.
- AAPT2 manifest/resource linking, D8 release conversion, ZIP alignment, and APK archive integrity passed with Build Tools 35.0.1.
- APK badging confirms package/version, API levels, launcher, and SMS/MMS/WAP/network/audio/notification permissions.
- Packaged manifest inspection confirms both delivery receivers, the MMS completion receiver, persisted SMS/MMS retry jobs, and the PDU content provider.
- Standalone Android lint over shipping sources completed with **0 errors and 3 warnings**.
- **12 workflow SQL tests passed**, **5 transport-state tests passed**, and **16 release-contract tests passed**.
- Synthetic MM1 Notification.ind and Retrieve.conf parser tests passed, including UTF-8 text and binary JPEG attachment boundaries.
- APK Signature Scheme v3, the expected single signer, certificate identity, four-byte alignment, and ZIP integrity were verified.

## Device-only boundary

No Android device, active SIM, carrier MMSC, or emulator was attached to this build host. Actual carrier acceptance, APN provisioning, mobile-data routing, server-side MMS size policy, dual-SIM behavior, and sender/recipient interoperability require a two-device live test. The code, packaging, receiver lifecycle, durable retry, parser, provider isolation, and signed artifact were host-verified; they are not a substitute for live carrier certification.
