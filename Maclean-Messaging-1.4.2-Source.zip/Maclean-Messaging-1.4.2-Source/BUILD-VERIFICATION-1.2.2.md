# Maclean Messaging 1.2.2 — Build Verification

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name: `1.2.2`
- Version code: `10202`
- Minimum Android API: 29
- Target/compile Android API: 35
- License: GNU AGPLv3 / `AGPL-3.0-only`

## Repairs in 1.2.2

- MMS text and HTML parts are read from Android's MMS provider with the part's declared MMS charset.
- MMS images render inline; image, video, audio, contact-card, and file parts expose Open and Save actions.
- MMS attachment filenames, content types, sizes, and UTF-8 text exports are preserved.
- Incoming email MIME decoding supports nested multipart content, Base64, quoted-printable, declared charsets, RFC 2047 encoded headers, and raw UTF-8 headers.
- Outgoing email uses Unicode-safe encoded subjects, Base64 UTF-8 bodies, and RFC 5987 attachment filenames.
- Text views and editors use Android's Unicode-capable sans-serif fallback family.
- Contacts are read live from Android's aggregated Contacts provider and can be searched or refreshed.
- The Contacts page links to Android account synchronization and contact creation.
- SMS/MMS recipients support contact-name/phone autocomplete and multi-contact selection.
- Email To, Cc, and Bcc fields support contact-name/email autocomplete and multi-contact selection.

## Completed build checks

- Full Kotlin source compilation completed without errors using Kotlin 1.9.24 and Java 17.
- MIME round-trip tests passed for accented Latin text, Polish text, Cyrillic, Japanese, emoji, RFC 2047, raw UTF-8 headers, Base64 multipart content, quoted-printable content, ISO-8859-1, and a Unicode attachment filename.
- Android resources and manifest linked successfully.
- DEX generation completed successfully, and the APK contains the repaired `MimeCodec`, `DeviceMessageRepository`, `DeviceAttachment`, `ContactDirectory`, `ContactEntry`, and `MainActivity` implementations.
- APK archive integrity and four-byte ZIP alignment verified.
- Package metadata verified as version `1.2.2` / code `10202` with minimum API 29 and target API 35.
- APK Signature Schemes v2 and v3 verified.
- Signing certificate exactly matches the Maclean Messaging 1.2.1 production APK.
- Signing key: 4096-bit RSA.
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`.
- APK SHA-256: `a106f807db92f295460eff882884fd5e32aafc9a4c1ddfeae929496c89fefb2e`.
- The signing password is absent from packaged APK strings and source files.

## Device-validation boundary

No Android device or emulator was attached to the build environment. Installation/upgrade, startup, real carrier MMS-provider variations, inline media rendering, external attachment viewers, Downloads, Android account/contact synchronization, recipient autocomplete UI, SMS role behavior, and live IMAP/SMTP/OAuth behavior remain device tests.

The app reads contacts already synchronized into Android's aggregated Contacts provider. The Account sync control opens Android's synchronization settings; the operating system and configured account providers perform the network synchronization.
