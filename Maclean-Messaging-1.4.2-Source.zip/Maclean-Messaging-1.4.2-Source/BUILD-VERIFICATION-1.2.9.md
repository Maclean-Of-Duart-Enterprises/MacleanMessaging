# Maclean Messaging 1.2.9 — Build Verification

## Release identity

- Application ID: `com.macleanofduartenterprises.macleanmessaging`
- Version name: `1.2.9`
- Version code: `10209`
- Minimum Android API: 29
- Target/compile Android API: 35
- License: GNU AGPLv3 / `AGPL-3.0-only`

## Selectable display implementation

- Fresh installs and upgrades without a display-style preference select **Sleek** by default.
- **Sleek** and **Utility** use separate preference-key namespaces, so each profile retains its own settings and can be reset independently.
- The active profile stores message-bubble, card/panel, and button/control shape; density; message width; inbox preview lines; outlines; elevation; and sent-message tint.
- Square, Soft corners, Rounded, and Oval geometry is rendered through shared shape helpers rather than screen-specific imitations.
- Shared layout tokens drive screen padding, card spacing, control size/gaps, toolbar typography/depth, inbox cards, settings panels, contacts, account management, composers, inputs, SMS/MMS rows, and email rows.
- Incoming messages remain left-aligned and sent messages right-aligned; the selected 70–100% width applies to both recycled thread adapters.
- Sent-message tint blends the chosen surface and accent colors without changing stored message data.
- Custom palettes now accept independent background, surface, accent/toolbar, and text colors. Existing photo backgrounds, text sizing, high contrast, and opacity controls remain available to both display profiles.

## Completed build checks

- All 59 Kotlin source files compiled without errors using Kotlin 1.9.24 and Java 17 against Android API 35.
- Full standalone Android lint completed with 0 errors and 58 non-blocking warnings: 31 conservative resource/cursor findings on Kotlin `.use` paths, 24 programmatic English-label localization findings, and one each for backup metadata, the supplied square launcher art, and a retained legacy XML resource.
- Android resources and manifest linked successfully with Build Tools 35.0.1; D8 release generation completed as DEX version 039.
- APK archive integrity and four-byte ZIP alignment verified.
- Package metadata verified as version `1.2.9` / code `10209`, minimum API 29, target API 35.
- APK Signature Scheme v3 verified with one signer.
- Signing key: 4096-bit RSA.
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`.
- APK SHA-256: `4c57da4bc2b65221826bb4b4ee6d6a7e72fcc54c51c13454078170c3879f49b8`.
- APK size: 999,883 bytes.
- Static checks confirmed that the release source contains neither a keystore nor the signing password.
- The manifest differs from 1.2.8 only by version name/code; package ID, permissions, components, intent filters, and launcher icon are unchanged.
- Database source and database version 5 are unchanged, preserving installed messages, accounts, backgrounds, notification choices, sorting, and other upgrade data.

## Device-validation boundary

ADB reported no attached Android device or emulator. Installation, in-place upgrade, live rendering interaction, SIM/MMSC transfer, and mail-provider tests could not be executed here.

Real-device checks remain for:

- upgrading 1.2.8 in place and confirming all messages, email accounts, contacts, backgrounds, notifications, sorting, and voice data remain intact;
- confirming a fresh install and an upgrade with no prior display-style key open in Sleek;
- configuring both profiles, switching repeatedly, restarting the process/device, and confirming that each profile retains only its own settings;
- exercising every bubble, card, and button shape with Compact, Comfortable, and Spacious density, 70% and 100% message widths, one and four preview lines, outlines, shadows, and sent tint;
- checking short, long, Unicode, link-rich, MMS-media, voice, and attachment messages in both directions at minimum and maximum text size;
- checking every screen with all palettes, custom colors, photo backgrounds, transparency, high contrast, portrait/landscape, cutouts, gesture navigation, and representative OEM launcher/rendering behavior;
- long-thread paging/recycling and memory tests on SMS/MMS and email conversations;
- all previously documented live notification, carrier, Contacts, microphone/audio, document-provider, SMTP, IMAP, OAuth, accessibility, and interoperability tests.

The APK is build-verified and correctly signed. It is not called production-verified until the relevant live device, carrier, and provider checks pass.
